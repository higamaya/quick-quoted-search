/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./modules/__config.js":
/*!*****************************!*\
  !*** ./modules/__config.js ***!
  \*****************************/
/***/ ((module) => {

module.exports = {
  config: {
    "logEnabled": true,
    "privateOptionEnabled": true,
    "isMac": false
  }
};

/***/ }),

/***/ "./modules/__constants.js":
/*!********************************!*\
  !*** ./modules/__constants.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommandType": () => (/* binding */ CommandType),
/* harmony export */   "MessageType": () => (/* binding */ MessageType),
/* harmony export */   "QUOTATION_MARKS": () => (/* binding */ QUOTATION_MARKS),
/* harmony export */   "SELECTION_TEXT_MAX_LENGTH": () => (/* binding */ SELECTION_TEXT_MAX_LENGTH),
/* harmony export */   "SELECTION_TEXT_TOO_LONG_MARKER": () => (/* binding */ SELECTION_TEXT_TOO_LONG_MARKER),
/* harmony export */   "ScriptId": () => (/* binding */ ScriptId)
/* harmony export */ });
/**
 * Script id.
 */
const ScriptId = {
  ACTION: "ACTION",
  BACKGROUND: "BACKGROUND",
  CONTENT: "-",
  OPTIONS: "OPTIONS"
};

/**
 * Command IDs for keyboard shortcuts and context menus.
 */
const CommandType = {
  DO_QUOTED_SEARCH: "do_quoted_search",
  PUT_QUOTES: "put_quotes"
};

/**
 * Message types.
 */
const MessageType = {
  // ---------------------------------------------------------------------------
  // Content scripts --> Background service worker
  // ---------------------------------------------------------------------------
  HELLO: "hello",
  NOTIFY_SELECTION_UPDATED: "notify_selection_updated",
  DO_QUOTED_SEARCH: "do_quoted_search",
  OPEN_OPTIONS_PAGE: "open_options_page",
  // ---------------------------------------------------------------------------
  // Content scripts <-- Background service worker
  // ---------------------------------------------------------------------------
  WELCOME: "welcome",
  PUT_QUOTES: "put_quotes",
  // ---------------------------------------------------------------------------
  // Action scripts --> Background service worker
  // ---------------------------------------------------------------------------
  GET_SELECTION: "get_selection",
  // ---------------------------------------------------------------------------
  // Action scripts <-- Background service worker
  // ---------------------------------------------------------------------------
  NOTIFY_SELECTION: "notify_selection"
};

/**
 * Various double quotes.
 *
 * If you surround your search phrase with characters in this string, Google
 * Search will give you an exact match. In other words, these are the characters
 * that Google Search recognizes as valid double quotes for an exact match.
 *
 * Text containing double quotes cannot be enclosed in double quotes, so those
 * characters must be removed if they are included in the selected text when
 * searching for an exact match.
 */
const QUOTATION_MARKS = "\u0022\u201c\u201d\u201e\u201f\u2033\u301d\u301e\u301f\uff02"; // "“”„‟″〝〞〟＂

/**
 * The maximum length of the selected text to be processed.
 */
const SELECTION_TEXT_MAX_LENGTH = 1024;

/**
 * Indicates that the length of the selected text exceeds the limit.
 *
 * A very large text may be selected, in which case this string is preserved
 * instead of the original string as the selected text to avoid wasting memory
 * and making logs noisy.
 */
const SELECTION_TEXT_TOO_LONG_MARKER = "### Too Long! ### yoBjv^F7%sg#NMxCrqvYKMgD85sRXRiG";

/***/ }),

/***/ "./modules/__functions.js":
/*!********************************!*\
  !*** ./modules/__functions.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addDOMContentLoadedEventListener": () => (/* binding */ addDOMContentLoadedEventListener),
/* harmony export */   "addLoadCompletedEventListener": () => (/* binding */ addLoadCompletedEventListener),
/* harmony export */   "cloneDto": () => (/* binding */ cloneDto),
/* harmony export */   "createNewTab": () => (/* binding */ createNewTab),
/* harmony export */   "createNewWindow": () => (/* binding */ createNewWindow),
/* harmony export */   "doQuotedSearch": () => (/* binding */ doQuotedSearch),
/* harmony export */   "filterSelectionText": () => (/* binding */ filterSelectionText),
/* harmony export */   "getActiveTab": () => (/* binding */ getActiveTab),
/* harmony export */   "getSelection": () => (/* binding */ getSelection),
/* harmony export */   "injectI18NMessagesInHtml": () => (/* binding */ injectI18NMessagesInHtml),
/* harmony export */   "isNormalizedSelectionTextValid": () => (/* binding */ isNormalizedSelectionTextValid),
/* harmony export */   "mergeObject": () => (/* binding */ mergeObject),
/* harmony export */   "normalizeSelectionText": () => (/* binding */ normalizeSelectionText),
/* harmony export */   "openLink": () => (/* binding */ openLink),
/* harmony export */   "openOptionsPage": () => (/* binding */ openOptionsPage),
/* harmony export */   "openSearchEngineSettings": () => (/* binding */ openSearchEngineSettings),
/* harmony export */   "openShortcutsSettings": () => (/* binding */ openShortcutsSettings),
/* harmony export */   "postMessage": () => (/* binding */ postMessage),
/* harmony export */   "quoteText": () => (/* binding */ quoteText)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _globals_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__globals.js */ "./modules/__globals.js");
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");




/**
 * Filters the selected text obtained from external sources.
 *
 * For security purposes, be sure to pass the selected text obtained from
 * external sources through this filter before using it.
 *
 * @param {?string} selectionText
 * @returns {!string}
 */
function filterSelectionText(selectionText) {
  selectionText ??= "";
  return selectionText.length > _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_MAX_LENGTH ? _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER : selectionText;
}

/**
 * Normalizes the selected text.
 *
 * The normalization includes:
 *
 * - Replace double quotes with a space.
 * - Collapse consecutive whitespace characters into single space.
 * - Remove whitespace from both ends of the string.
 *
 * @param {?string} selectionText
 * @returns {!string}
 */
function normalizeSelectionText(selectionText) {
  selectionText = filterSelectionText(selectionText);
  return selectionText === _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER ? selectionText : selectionText.replaceAll(new RegExp(`[\\s${_constants_js__WEBPACK_IMPORTED_MODULE_0__.QUOTATION_MARKS}]+`, "g"), " ").trim();
}

/**
 * Checks if the normalized selection text is valid for processing.
 *
 * @param {?string} normalizedSelectionText
 * @returns {!boolean}
 */
function isNormalizedSelectionTextValid(normalizedSelectionText) {
  normalizedSelectionText ??= "";
  return normalizedSelectionText !== _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER && normalizedSelectionText.length > 0 && normalizedSelectionText.length <= _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_MAX_LENGTH;
}

/**
 * Puts double quotes around the string.
 *
 * @param {?string} text
 * @returns {!string}
 */
function quoteText(text) {
  return '"' + (text ?? "") + '"';
}

/**
 * Clones an object treated as a DTO.
 *
 * If you need pass an object whose contents may be changed later to an
 * asynchronous method, pass an object cloned by this function instead of the
 * origin object.
 *
 * @param {?object} obj
 * @returns {!object}
 */
function cloneDto(obj) {
  return JSON.parse(JSON.stringify(obj ?? {}));
}

/**
 * Merges `rhs` to `lhs`, ignoring properties with a value of `undefined`.
 *
 * @param {?object} target
 * @param {?object} source
 * @returns {!object}
 */
function mergeObject(target, source) {
  return {
    ...target,
    ...Object.fromEntries(Object.entries(source ?? {}).filter(([, v]) => v !== undefined))
  };
}

/**
 * Sets up an event listener for `DOMContentLoaded` event.
 *
 * This function checks `Document.readyState` and sets up the event listener as
 * a microtasks if the event has already been fired.
 *
 * @param {!Window} win
 * @param {!function():void} listener
 */
function addDOMContentLoadedEventListener(win, listener) {
  if (win.document.readyState === "loading") {
    win.document.addEventListener("DOMContentLoaded", listener);
  } else {
    queueMicrotask(listener);
  }
}

/**
 * Sets up an event listener for `load` event.
 *
 * This function checks `Document.readyState` and sets up the event listener as
 * a microtasks if the event has already been fired.
 *
 * @param {!Window} win
 * @param {!function():void} listener
 */
function addLoadCompletedEventListener(win, listener) {
  if (win.document.readyState !== "complete") {
    win.addEventListener("load", listener);
  } else {
    queueMicrotask(listener);
  }
}

/**
 * Injects localized strings into HTML document.
 *
 * @param {!Document} doc
 */
function injectI18NMessagesInHtml(doc) {
  const I18N_TARGETS = ["outerHTML", "innerHTML", "outerText", "innerText", "value"];
  for (const element of doc.querySelectorAll("[data-group~='i18n'")) {
    const substitutions = (() => {
      const result = [];
      const args = element.dataset.i18nArgs;
      if (!args) {
        return result;
      }
      const ids = args.split(" ");
      for (const id of ids) {
        const argElement = doc.getElementById(id);
        const argTarget = argElement.dataset.i18nTarget;
        _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.assert(I18N_TARGETS.includes(argTarget), "Unexpected target", {
          argTarget,
          argElement
        });
        result.push(argElement[argTarget]);
      }
      return result;
    })();
    const target = element.dataset.i18nTarget;
    _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.assert(I18N_TARGETS.includes(target), "Unexpected target", {
      target,
      element
    });
    element[target] = chrome.i18n.getMessage(element.dataset.i18nName, substitutions);
  }
}

/**
 * Gets `Selection` object.
 *
 * This function not only calls `Window.getSelection()`, but also recursively
 * searches within the nested Shadow DOMs.
 *
 * @param {!Window} win
 * @returns {!Selection}
 */
function getSelection(win) {
  function findSelectionRecursively(selection) {
    if (selection.rangeCount === 1) {
      const range = selection.getRangeAt(0);
      if (range.startContainer === range.endContainer) {
        const commonAncestorContainer = range.commonAncestorContainer;
        if (commonAncestorContainer instanceof Element) {
          if (commonAncestorContainer.shadowRoot) {
            return findSelectionRecursively(commonAncestorContainer.shadowRoot.getSelection());
          } else {
            const elementsWithShadowRoot = Array.prototype.filter.call(commonAncestorContainer.querySelectorAll("*"), element => !!element.shadowRoot);
            if (elementsWithShadowRoot.length === 1) {
              return findSelectionRecursively(elementsWithShadowRoot[0].shadowRoot.getSelection());
            }
          }
        }
      }
    }
    return selection;
  }
  return findSelectionRecursively(win.getSelection());
}

/**
 * Calls `chrome.runtime.Port.postMessage()` method.
 *
 * Catches the error thrown from `chrome.runtime.Port.postMessage()` method and
 * logs a warning message.
 *
 * `chrome.runtime.Port.postMessage()` throws an error if the other side of the
 * port has already been closed, but there is no way to check in advance whether
 * the port is still opened or has been closed.
 * Port disconnection is one of the expected conditions, even in an edge case,
 * and most of the time it is not an error case.
 * Therefore, if an error is thrown from `chrome.runtime.Port.postMessage()`
 * method, this function assumes the cause is port disconnection and logs it as
 * a warning instead of an error.
 *
 * @param {!chrome.runtime.Port} port
 * @param {!*} message
 */
function postMessage(port, message) {
  try {
    port.postMessage(message);
  } catch (error) {
    _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.warn("It seems that the message could not be sent because the other side of the port has already been closed", {
      error,
      port,
      message
    });
  }
}

/**
 * Gets the active tab.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @returns {!Promise<!chrome.tabs.Tab>}
 */
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });
  return tab;
}

/**
 * Creates a new tab.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?{url:?string=, active:?boolean=}=} params
 * @returns {!Promise<void>}
 */
async function createNewTab(tab, params) {
  return await chrome.tabs.create({
    windowId: tab.windowId,
    openerTabId: tab.id,
    index: tab.index + 1,
    url: params?.url,
    active: params?.active ?? true
  });
}

/**
 * Creates a new window.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {?{url:?string=}=} params
 * @returns {!Promise<void>}
 */
async function createNewWindow(params) {
  const currentWindow = await chrome.windows.getCurrent();
  return await chrome.windows.create({
    state: currentWindow.state,
    url: params?.url
  });
}

/**
 * Invokes search engine to do quoted search.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {!string} searchText Text to search, not to be enclosed in double quotes.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @returns {!Promise<void>}
 */
async function doQuotedSearch(tab, searchText, keyState) {
  const howToOpenLink = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.decide(keyState, new _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink(_globals_js__WEBPACK_IMPORTED_MODULE_1__.options.disposition, true));
  if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.NEW_TAB) {
    const newTab = await createNewTab(tab, {
      active: false
    });
    await chrome.search.query({
      tabId: newTab.id,
      text: quoteText(searchText)
    });
    // To prevent the omnibox from receiving focus, activate new tab after
    // creation and search.
    if (howToOpenLink.active ?? true) {
      await chrome.tabs.update(newTab.id, {
        active: true
      });
    }
  } else {
    await chrome.search.query({
      disposition: howToOpenLink.disposition,
      text: quoteText(searchText)
    });
  }
}

/**
 * Opens the web page with specified URL.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {!string} url
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openLink(tab, url, keyState, defaultHowToOpenLink) {
  const howToOpenLink = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.decide(keyState, defaultHowToOpenLink);
  if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.CURRENT_TAB) {
    await chrome.tabs.update(tab.id, {
      url: url
    });
  } else if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.NEW_WINDOW) {
    await createNewWindow({
      url: url
    });
  } else {
    await createNewTab(tab, {
      url: url,
      active: howToOpenLink.active ?? true
    });
  }
}

/**
 * Opens the extension's Options page.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openOptionsPage(tab, keyState, defaultHowToOpenLink) {
  const url = chrome.runtime.getURL("options.html");
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/**
 * Opens search engine settings page of the browser.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openSearchEngineSettings(tab, keyState, defaultHowToOpenLink) {
  const url = "chrome://settings/search";
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/**
 * Opens keyboard shortcuts settings page of the browser.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openShortcutsSettings(tab, keyState, defaultHowToOpenLink) {
  const url = "chrome://extensions/shortcuts";
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/***/ }),

/***/ "./modules/__globals.js":
/*!******************************!*\
  !*** ./modules/__globals.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "init": () => (/* binding */ init),
/* harmony export */   "logger": () => (/* binding */ logger),
/* harmony export */   "options": () => (/* binding */ options)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__logger.js */ "./modules/__logger.js");
/* harmony import */ var _options_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./__options.js */ "./modules/__options.js");





/**
 * Logger used used throughout the extension.
 *
 * It will be initialized in {@link init()} function.
 *
 * @type {Logger}
 */
let logger;

/**
 * Options used used throughout the extension.
 *
 * It will be initialized in {@link init()} function.
 *
 * @type {Options}
 */
let options;

/**
 * Initializes the module.
 *
 * This function must be called first to initialize global variables before
 * using them and any other functions depending these global variables.
 *
 * @param {!string} scriptId
 * @returns {!Promise<void>}
 */
async function init(scriptId) {
  logger = new _logger_js__WEBPACK_IMPORTED_MODULE_2__.Logger(scriptId);
  logger.state("Initialize script", {
    scriptId
  });
  options = new _options_js__WEBPACK_IMPORTED_MODULE_3__.Options(logger);
  await options.init();
  await checkOsIsMac(scriptId);
}
async function checkOsIsMac(scriptId) {
  const STORAGE_KEY = "isMac";
  const storage = chrome.storage.local;
  if (scriptId === _constants_js__WEBPACK_IMPORTED_MODULE_1__.ScriptId.BACKGROUND) {
    _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac = (await chrome.runtime.getPlatformInfo()).os === "mac";
    await storage.set({
      [STORAGE_KEY]: _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac
    });
  } else {
    _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac = !!(await storage.get(STORAGE_KEY))[STORAGE_KEY];
  }
  logger.state("Updated `isMac` in config", {
    ["config.isMac"]: _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac
  });
}

/***/ }),

/***/ "./modules/__how_to_open_link.js":
/*!***************************************!*\
  !*** ./modules/__how_to_open_link.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HowToOpenLink": () => (/* binding */ HowToOpenLink)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Controls how to open a link based on the state of control keys such as `Ctrl`
 * and `Shift`.
 */
class HowToOpenLink {
  /**
   * Location where a link should be opened.
   *
   * The values of this enum are same as
   * [chrome.search.Disposition](https://developer.chrome.com/docs/extensions/reference/search/#type-Disposition).
   * Therefore, they can be used as-is as a parameter to
   * [chrome.search.query()](https://developer.chrome.com/docs/extensions/reference/search/#method-query).
   */
  static Disposition = {
    CURRENT_TAB: "CURRENT_TAB",
    NEW_TAB: "NEW_TAB",
    NEW_WINDOW: "NEW_WINDOW"
  };
  static KeyState = class KeyState {
    ctrlKey;
    shiftKey;

    /**
     * @param {!boolean} ctrlKey
     * @param {!boolean} shiftKey
     * @param {!boolean=} metaKey If specified, `metaKey` is used instead of
     *    `ctrlKey` when running on MAC.
     */
    constructor(ctrlKey, shiftKey, metaKey = ctrlKey) {
      this.ctrlKey = _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac ? metaKey : ctrlKey;
      this.shiftKey = shiftKey;
    }
    equals(other) {
      return other && this.ctrlKey === other.ctrlKey && this.shiftKey === other.shiftKey;
    }
    static CURRENT_TAB = new KeyState(false, false);
    static NEW_TAB_ACTIVE = new KeyState(true, true);
    static NEW_TAB_INACTIVE = new KeyState(true, false);
    static NEW_WINDOW = new KeyState(false, true);
  };

  /**
   * @type {!HowToOpenLink.Disposition}
   */
  disposition;

  /**
   * Available only if `disposition ===  NEW_TAB`.
   *
   * @type {boolean=}
   */
  active;

  /**
   * @param {!HowToOpenLink.Disposition} disposition
   * @param {boolean=} active Available only if `disposition ===  NEW_TAB`.
   */
  constructor(disposition, active = true) {
    this.disposition = disposition;
    this.active = active;
  }
  static CURRENT_TAB = new HowToOpenLink(HowToOpenLink.Disposition.CURRENT_TAB);
  static NEW_TAB_ACTIVE = new HowToOpenLink(HowToOpenLink.Disposition.NEW_TAB, true);
  static NEW_TAB_INACTIVE = new HowToOpenLink(HowToOpenLink.Disposition.NEW_TAB, false);
  static NEW_WINDOW = new HowToOpenLink(HowToOpenLink.Disposition.NEW_WINDOW);

  /**
   * Decides location where a link should be opened.
   *
   * @param {?HowToOpenLink.KeyState=} keyState
   * @param {?HowToOpenLink=} defaultHowToOpenLink
   * @returns {!HowToOpenLink}
   */
  static decide(keyState, defaultHowToOpenLink) {
    if (HowToOpenLink.KeyState.NEW_TAB_ACTIVE.equals(keyState)) return HowToOpenLink.NEW_TAB_ACTIVE;else if (HowToOpenLink.KeyState.NEW_TAB_INACTIVE.equals(keyState)) return HowToOpenLink.NEW_TAB_INACTIVE;else if (HowToOpenLink.KeyState.NEW_WINDOW.equals(keyState)) return HowToOpenLink.NEW_WINDOW;else return defaultHowToOpenLink ?? HowToOpenLink.CURRENT_TAB;
  }
}

/***/ }),

/***/ "./modules/__logger.js":
/*!*****************************!*\
  !*** ./modules/__logger.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Logger": () => (/* binding */ Logger)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Outputs logs only if `config.logEnabled` is true. Otherwise, all of the
 * instance methods of this class have no operations (ie empty).
 */
class Logger {
  #id;

  /**
   * @param {!string} id Appears at the beginning of the log message, enclosed
   *    in square brackets.
   */
  constructor(id) {
    this.#id = id;
  }

  /**
   * @param {!string} id
   */
  setId(id) {
    this.#id = id;
  }

  /**
   * Call `console.debug()` with the header `[INFO]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  info(message, ...args) {
    this.#output("debug", "[INFO]", message, args);
  }

  /**
   * Call `console.debug()` with the header `[STATE]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  state(message, ...args) {
    this.#output("debug", "[STATE]", message, args);
  }

  /**
   * Call `console.debug()` with the header `[CALLBACK]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  callback(message, ...args) {
    this.#output("debug", "[CALLBACK]", message, args);
  }

  /**
   * Call `console.warn()` with the header `[WARN]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  warn(message, ...args) {
    this.#output("warn", "[WARN]", message, args);
  }

  /**
   * Call `console.error()` with the header `[ERROR]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  error(message, ...args) {
    this.#output("error", "[ERROR]", message, args);
  }

  /**
   * Call `console.assert()` with the header `[ERROR]` prepended to the message.
   *
   * @param {!boolean} assertion
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  assert(assertion, message, ...args) {
    this.#output("assert", "[ERROR]", message, args, assertion);
  }

  /**
   * Call Console API specified by the `method` argument.
   *
   * @param {!string} consoleApi Console API to call.
   * @param {!string} header
   * @param {!string} message
   * @param {?any[]=} args
   * @param {?boolean=} assertion must be specified if `method` is "assert", otherwise ignored.
   */
  #output(consoleApi, header, message, args, assertion) {
    if (!_config_js__WEBPACK_IMPORTED_MODULE_0__.config.logEnabled) {
      return;
    }
    const optionalArgs = [];
    if (args && args.length > 0 && typeof args.at(-1) === "object") {
      for (const [key, value] of Object.entries(args.pop())) {
        optionalArgs.push(`\n${key}=`);
        optionalArgs.push(value);
      }
    }
    console[consoleApi](...(consoleApi === "assert" ? [!!assertion] : []), `[${this.#id}] ${header} ${message}`, ...args, ...optionalArgs);
  }
}

/***/ }),

/***/ "./modules/__options.js":
/*!******************************!*\
  !*** ./modules/__options.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Options": () => (/* binding */ Options)
/* harmony export */ });
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");


/**
 * User-customizable extension options.
 *
 * Options is stored in the
 * [sync](https://developer.chrome.com/docs/extensions/reference/storage/#property-sync)
 * storage area that is synced using Chrome Sync.
 */
class Options {
  static #storage = chrome.storage.sync;
  static #STORAGE_KEY = "options";
  static #UPDATED_AT_KEY = "__updatedAt__";
  static #DEFAULT_VALUES = {
    [Options.#UPDATED_AT_KEY]: 0
  };
  static Disposition = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.Disposition;
  static ICON_SIZE_MIN = 1;
  static ICON_SIZE_MAX = 5;

  // prettier-ignore
  /**
   * Definition of options.
   *
   * Just add a row into this table to add a new option item. The code necessary
   * to read and write option values is automatically generated.
   *
   * @type {{name:!string, defaultValue:!*, validator:!function(?*):boolean}[]}
   */
  static #ITEMS = [{
    name: "popupIcon",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "iconSize",
    defaultValue: 3,
    validator: value => typeof value === "number" && value >= Options.ICON_SIZE_MIN && value <= Options.ICON_SIZE_MAX
  }, {
    name: "avoidSelection",
    defaultValue: false,
    validator: value => typeof value === "boolean"
  }, {
    name: "optionsButton",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "contextMenu",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "disposition",
    defaultValue: Options.Disposition.NEW_TAB,
    validator: value => typeof value === "string" && Object.values(Options.Disposition).includes(value)
  }, {
    name: "autoCopy",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "autoEnter",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "autoSurround",
    defaultValue: false,
    validator: value => typeof value === "boolean"
  }];
  static #defineOptions() {
    for (const {
      name,
      defaultValue,
      validator
    } of Options.#ITEMS) {
      Options.#DEFAULT_VALUES[name] = defaultValue;
      Object.defineProperty(Options.prototype, name, {
        set(value) {
          if (!validator(value)) {
            throw new Error(`Options: Invalid value for '${name}'\nvalue=${value}`);
          }
          if (value !== this.#cache[name]) {
            this.#cache[name] = value;
            /* async */
            this.#updateStorage();
          }
        },
        get() {
          return validator(this.#cache[name]) ? this.#cache[name] : defaultValue;
        }
      });
    }
  }
  static #_ = Options.#defineOptions();
  /**
   * Fired when one or more options are changed externally.
   */
  onChanged = new class onChanged {
    #listeners = [];
    /**
     * @param {!function(!Options):void} listener
     */
    addListener(listener) {
      this.#listeners.push(listener);
    }
    _fire() {
      for (const listener of this.#listeners) {
        listener();
      }
    }
  }();
  #logger;
  #cache;

  /**
   * @param {!Logger} logger
   */
  constructor(logger) {
    this.#logger = logger;
    this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
    Options.#storage.onChanged.addListener((changes, areaName) => {
      this.#onChangedListener(changes, areaName);
    });
  }

  /**
   * Load options from the storage.
   */
  async init() {
    const values = await Options.#storage.get(Options.#STORAGE_KEY);
    // Merge rather than assign to ensure completeness of options in case of
    // missing data in the storage.
    Object.assign(this.#cache, values[Options.#STORAGE_KEY]);
    this.#logger.state("Options: Initialized", {
      ["this.#cache"]: this.#cache
    });
  }

  /**
   * Reset all options to restore defaults.
   */
  reset() {
    this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
    /* async */
    this.#updateStorage();
  }
  async #updateStorage() {
    this.#cache[Options.#UPDATED_AT_KEY] = Date.now();
    const values = {
      [Options.#STORAGE_KEY]: this.#cache
    };
    this.#logger.state("Options: Update storage", {
      values
    });
    await Options.#storage.set(values);
  }
  #onChangedListener(changes, areaName) {
    this.#logger.callback("Options: onChangedListener()", {
      changes,
      areaName
    });
    if (!Object.hasOwn(changes, Options.#STORAGE_KEY)) {
      return;
    }
    if (Object.hasOwn(changes[Options.#STORAGE_KEY], "newValue")) {
      const newValue = changes[Options.#STORAGE_KEY].newValue;
      if (newValue[Options.#UPDATED_AT_KEY] <= this.#cache[Options.#UPDATED_AT_KEY]) {
        this.#logger.info("Options: Cache was not overwritten because it is up to date", {
          ["this.#cache"]: this.#cache
        });
        return;
      }

      // Merge rather than assign to ensure completeness of options in case of
      // missing data in the storage.
      Object.assign(this.#cache, newValue);
      this.#logger.state("Options: Cache was overwritten by values in storage updated by other", {
        ["this.#cache"]: this.#cache
      });
    } else {
      // The storage has been cleared.

      this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
      this.#logger.state("Options: Cache was reset to default values because the storage has been cleared", {
        ["this.#cache"]: this.#cache
      });
    }
    this.onChanged._fire();
  }
}

/***/ }),

/***/ "./modules/common.js":
/*!***************************!*\
  !*** ./modules/common.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommandType": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.CommandType),
/* harmony export */   "HowToOpenLink": () => (/* reexport safe */ _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_4__.HowToOpenLink),
/* harmony export */   "Logger": () => (/* reexport safe */ _logger_js__WEBPACK_IMPORTED_MODULE_5__.Logger),
/* harmony export */   "MessageType": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.MessageType),
/* harmony export */   "Options": () => (/* reexport safe */ _options_js__WEBPACK_IMPORTED_MODULE_6__.Options),
/* harmony export */   "QUOTATION_MARKS": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.QUOTATION_MARKS),
/* harmony export */   "SELECTION_TEXT_MAX_LENGTH": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.SELECTION_TEXT_MAX_LENGTH),
/* harmony export */   "SELECTION_TEXT_TOO_LONG_MARKER": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.SELECTION_TEXT_TOO_LONG_MARKER),
/* harmony export */   "ScriptId": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.ScriptId),
/* harmony export */   "addDOMContentLoadedEventListener": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.addDOMContentLoadedEventListener),
/* harmony export */   "addLoadCompletedEventListener": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.addLoadCompletedEventListener),
/* harmony export */   "cloneDto": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.cloneDto),
/* harmony export */   "createNewTab": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.createNewTab),
/* harmony export */   "createNewWindow": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.createNewWindow),
/* harmony export */   "doQuotedSearch": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.doQuotedSearch),
/* harmony export */   "filterSelectionText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.filterSelectionText),
/* harmony export */   "getActiveTab": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.getActiveTab),
/* harmony export */   "getSelection": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.getSelection),
/* harmony export */   "init": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.init),
/* harmony export */   "injectI18NMessagesInHtml": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.injectI18NMessagesInHtml),
/* harmony export */   "isNormalizedSelectionTextValid": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.isNormalizedSelectionTextValid),
/* harmony export */   "logger": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.logger),
/* harmony export */   "mergeObject": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.mergeObject),
/* harmony export */   "normalizeSelectionText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.normalizeSelectionText),
/* harmony export */   "openLink": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openLink),
/* harmony export */   "openOptionsPage": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openOptionsPage),
/* harmony export */   "openSearchEngineSettings": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openSearchEngineSettings),
/* harmony export */   "openShortcutsSettings": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openShortcutsSettings),
/* harmony export */   "options": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.options),
/* harmony export */   "postMessage": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.postMessage),
/* harmony export */   "quoteText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.quoteText)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _config_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _config_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _functions_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__functions.js */ "./modules/__functions.js");
/* harmony import */ var _globals_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./__globals.js */ "./modules/__globals.js");
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./__logger.js */ "./modules/__logger.js");
/* harmony import */ var _options_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./__options.js */ "./modules/__options.js");
/**
 * @file Aggregates modules.
 */









/***/ }),

/***/ "./modules/popup_icon.js":
/*!*******************************!*\
  !*** ./modules/popup_icon.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PopupIcon": () => (/* binding */ PopupIcon)
/* harmony export */ });
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common.js */ "./modules/common.js");


/**
 * Implements Popup Icon rendered on any web pages.
 */
class PopupIcon {
  #win;
  #dom;
  #editableNode;
  #enabled = false;
  #mouseMovement = {
    prevX: 0,
    prevY: 0,
    isForward: true
  };

  /**
   * @param {!Window} win
   * @param {!function(!MouseEvent):void} callbackOnClickSearch
   * @param {!function(!MouseEvent,!HTMLElement):void} callbackOnClickQuote
   * @param {!function(!MouseEvent):void} callbackOnClickOptions
   */
  constructor(win, callbackOnClickSearch, callbackOnClickQuote, callbackOnClickOptions) {
    this.#win = win;
    this.#dom = new PopupIconDom(win, callbackOnClickSearch, callbackOnClickQuote, callbackOnClickOptions);
    this.#win.document.documentElement.addEventListener("mousemove", e => this.#onMouseMove(e));
    this.#win.document.documentElement.addEventListener("mouseup", e => this.#onMouseUp(e));
    this.#win.document.addEventListener("selectionchange", e => this.#onSelectionChange(e));
    _common_js__WEBPACK_IMPORTED_MODULE_0__.options.onChanged.addListener(() => this.#onOptionsChanged());
  }

  /**
   * @param {!HTMLElement} editableNode
   */
  setEditableNode(editableNode) {
    this.#editableNode = editableNode;
  }

  /**
   * Since Popup Icon is disabled in the initial state, call this method to
   * enable it when ready.
   */
  enable() {
    this.#enabled = true;
  }
  disable() {
    this.#enabled = false;
    this.#dom.hide();
  }
  #onMouseMove(e) {
    const THRESHOLD = 32;
    const movementX = e.clientX - this.#mouseMovement.prevX;
    const movementY = e.clientY - this.#mouseMovement.prevY;
    if (Math.abs(movementX) > THRESHOLD || Math.abs(movementY) > THRESHOLD) {
      this.#mouseMovement.isForward = movementX !== 0 ? movementX > 0 : movementY > 0;
      this.#mouseMovement.prevX = e.clientX;
      this.#mouseMovement.prevY = e.clientY;
    }
  }
  #onMouseUp(e) {
    const MOUSE_LEFT_BUTTON = 0;
    if (e.button === MOUSE_LEFT_BUTTON) {
      this.#show(e.clientX, e.clientY);
    }
  }
  #onSelectionChange(_e) {
    if (_common_js__WEBPACK_IMPORTED_MODULE_0__.getSelection(this.#win).toString() === "") {
      this.#dom.hide();
    }
  }
  #onOptionsChanged() {
    this.#dom.reflectOptions();
    if (!_common_js__WEBPACK_IMPORTED_MODULE_0__.options.popupIcon) {
      this.#dom.hide();
    }
  }
  #show(mouseClientX, mouseClientY) {
    // Executes this task after all UI events in the queue is processed, because
    // text may be selected after this mouseup event, such as when double-clicked.
    setTimeout(() => {
      const selection = _common_js__WEBPACK_IMPORTED_MODULE_0__.getSelection(this.#win);
      const selectionText = _common_js__WEBPACK_IMPORTED_MODULE_0__.filterSelectionText(selection.toString());
      if (_common_js__WEBPACK_IMPORTED_MODULE_0__.options.popupIcon && this.#enabled && _common_js__WEBPACK_IMPORTED_MODULE_0__.isNormalizedSelectionTextValid(_common_js__WEBPACK_IMPORTED_MODULE_0__.normalizeSelectionText(selectionText))) {
        if (selectionText === this.#dom.atMouseup.selectionText || this.#dom.clicking) {
          // Popup Icon should not move because current mouseup event is not
          // intended to change text selection.
          return;
        }
        this.#dom.atMouseup.selectionText = selectionText;
        this.#dom.atMouseup.editableNode = this.#editableNode;
        const clientRect = this.#dom.show();
        const clientLeft = (() => {
          const GOOGLE_TRANSLATE_POPUP_SIZE = 27;
          const leftOffset = _common_js__WEBPACK_IMPORTED_MODULE_0__.options.avoidSelection ?
          // Prevents Popup Icon from overlapping with Google Translate
          // Extension's one.
          GOOGLE_TRANSLATE_POPUP_SIZE + clientRect.width / 2 :
          // Prevents Popup Icon from overlapping with mouse pointer.
          clientRect.width * 1.2;
          const isForward = this.#editableNode ? this.#editableNode.selectionDirection !== "backward" : this.#mouseMovement.isForward;
          return mouseClientX - clientRect.width / 2 + (isForward ? leftOffset : -leftOffset);
        })();
        const clientTop = (() => {
          if (!_common_js__WEBPACK_IMPORTED_MODULE_0__.options.avoidSelection || this.#editableNode) {
            return mouseClientY - clientRect.height / 2;
          } else {
            const selectionClientRect = selection.getRangeAt(0).getBoundingClientRect();
            const MARGIN = 1;
            return mouseClientY < selectionClientRect.top + selectionClientRect.height / 2 ? selectionClientRect.top - clientRect.height - MARGIN : selectionClientRect.bottom + MARGIN;
          }
        })();
        this.#dom.setPosition(clientLeft, clientTop);
      } else {
        this.#dom.hide();
      }
    });
  }
}

/**
 * Implements DOM-related processing among the functions of Popup Icon.
 */
class PopupIconDom {
  static #FONT_SIZES = {
    1: "max(0.625em, 10px)",
    2: "max(0.75em, 12px)",
    3: "max(1em, 16px)",
    4: "max(1.25em, 20px)",
    5: "max(1.5em, 24px)"
  };
  #win;
  #rootNode;
  #position = {};
  #drag = {};

  /**
   * Save the state at mouseup event (ie at showing Popup Icon).
   */
  atMouseup = new class AtMouseup {
    #owner;
    selectionText = "";
    #_editableNode;
    constructor(owner) {
      this.#owner = owner;
    }
    set editableNode(value) {
      this.#_editableNode = value;
      if (this.#_editableNode) {
        this.#owner.#rootNode.classList.add("qqs-editable");
      } else {
        this.#owner.#rootNode.classList.remove("qqs-editable");
      }
    }
    get editableNode() {
      return this.#_editableNode;
    }
    _reset() {
      this.selectionText = "";
      this.editableNode = undefined;
    }
  }(this);
  #_clicking = false;
  set clicking(value) {
    // `clicking` flag prevents Popup Icon from moving unnecessarily and
    // is then cleared automatically.
    this.#_clicking = value;
    if (this.#_clicking) {
      setTimeout(() => this.#_clicking = false);
    }
  }
  get clicking() {
    return this.#_clicking;
  }
  constructor(win, callbackOnClickSearch, callbackOnClickQuote, callbackOnClickOptions) {
    this.#win = win;
    this.#create(callbackOnClickSearch, callbackOnClickQuote, callbackOnClickOptions);
  }
  #create(callbackOnClickSearch, callbackOnClickQuote, callbackOnClickOptions) {
    // -------------------------------------------------------------------------
    // Creates root HTML element of Popup Icon.
    // -------------------------------------------------------------------------
    this.#rootNode = this.#win.document.createElement("div");
    this.#rootNode.classList.add("qqs-root", "qqs-popup-icon");

    // -------------------------------------------------------------------------
    // Creates buttons in Popup Icon.
    // -------------------------------------------------------------------------
    const createButton = (buttonClass, imageClass, clickEventListener) => {
      const button = this.#rootNode.appendChild(this.#win.document.createElement("div"));
      button.classList.add(buttonClass);
      button.addEventListener("click", clickEventListener);
      const image = button.appendChild(this.#win.document.createElement("i"));
      image.classList.add(imageClass);
    };
    createButton("qqs-search-button", "qqs-search-icon", e => {
      this.clicking = true;
      callbackOnClickSearch(e);
    });
    createButton("qqs-quote-button", "qqs-quote-icon", e => {
      this.clicking = true;
      callbackOnClickQuote(e, this.atMouseup.editableNode);
    });
    createButton("qqs-options-button", "qqs-options-icon", e => {
      this.clicking = true;
      callbackOnClickOptions(e);
    });

    // -------------------------------------------------------------------------
    // Makes Popup Icon draggable.
    // -------------------------------------------------------------------------
    this.#rootNode.setAttribute("draggable", "true");
    const DRAG_TYPE = "qqs/popup-icon";
    this.#win.document.documentElement.addEventListener("dragover", e => {
      if (e.dataTransfer.types.includes(DRAG_TYPE)) {
        e.preventDefault();
      }
    });
    this.#rootNode.addEventListener("dragstart", e => {
      e.dataTransfer.setData(DRAG_TYPE, "");
      e.dataTransfer.effectAllowed = "move";
      const clientRect = this.#rootNode.getBoundingClientRect();
      this.#drag.offsetX = clientRect.left - e.clientX;
      this.#drag.offsetY = clientRect.top - e.clientY;
    });
    this.#rootNode.addEventListener("dragend", e => {
      const clientLeft = e.clientX + this.#drag.offsetX;
      const clientTop = e.clientY + this.#drag.offsetY;
      this.setPosition(clientLeft, clientTop);
    });

    // -------------------------------------------------------------------------
    // Reflects options in Popup Icon style.
    // -------------------------------------------------------------------------
    this.reflectOptions();
  }

  /**
   * Shows Popup Icon's dom element, but its position is off screen. This is
   * necessary to get the size of Popup Icon and the offsets to calculate its
   * position. After calculating the position at which Popup Icon should appear,
   * call {@link PopupIconDom.setPosition()} to correct it.
   *
   * @returns {!DOMRect} The size of Popup Icon, that is return value of
   *    `Element.getBoundingClientRect()`.
   */
  show() {
    const tempPosition = -9999;
    this.#rootNode.style.left = tempPosition + "px";
    this.#rootNode.style.top = tempPosition + "px";
    this.#win.document.body.appendChild(this.#rootNode);

    // Calculates offsets used later to convert the client coordinates to the
    // position of Popup Icon.
    const clientRect = this.#rootNode.getBoundingClientRect();
    this.#position.offsetX = tempPosition - (clientRect.left + this.#win.scrollX);
    this.#position.offsetY = tempPosition - (clientRect.top + this.#win.scrollY);
    return clientRect;
  }

  /**
   * Sets the position of Popup Icon.
   *
   * The position must be specified in the "client" coordinate system.
   *
   * @see [Coordinate systems](https://developer.mozilla.org/en-US/docs/Web/CSS/CSSOM_View/Coordinate_systems)
   * @param {!number} clientLeft
   * @param {!number} clientTop
   */
  setPosition(clientLeft, clientTop) {
    // Prevents Popup Icon from overflowing the layout viewport.
    const {
      width,
      height
    } = this.#rootNode.getBoundingClientRect();
    const leftMax = this.#win.innerWidth - width;
    const topMax = this.#win.innerHeight - height;
    const clientLeftCorrected = Math.max(0, Math.min(leftMax, clientLeft));
    const clientTopCorrected = Math.max(0, Math.min(topMax, clientTop));

    // Converts the client coordinates to the position relative to the top-left
    // corner of the containing block.
    const left = clientLeftCorrected + this.#win.scrollX + this.#position.offsetX;
    const top = clientTopCorrected + this.#win.scrollY + this.#position.offsetY;
    this.#rootNode.style.left = left + "px";
    this.#rootNode.style.top = top + "px";
  }
  reflectOptions() {
    this.#rootNode.style.fontSize = PopupIconDom.#FONT_SIZES[_common_js__WEBPACK_IMPORTED_MODULE_0__.options.iconSize];
    if (_common_js__WEBPACK_IMPORTED_MODULE_0__.options.optionsButton) {
      this.#rootNode.classList.add("qqs-show-options-button");
    } else {
      this.#rootNode.classList.remove("qqs-show-options-button");
    }
  }
  hide() {
    if (this.#rootNode.isConnected) {
      this.#rootNode.parentNode.removeChild(this.#rootNode);
      this.atMouseup._reset();
    }
  }
}

/***/ }),

/***/ "./modules/port_to_background.js":
/*!***************************************!*\
  !*** ./modules/port_to_background.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortToBackground": () => (/* binding */ PortToBackground)
/* harmony export */ });
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common.js */ "./modules/common.js");


/**
 * Represent the connection to Background service worker, and provide ability to
 * re-connect to it automatically if it is idle (i.e. is disconnected).
 */
class PortToBackground {
  #port;
  #params = {
    name: "",
    autoConnect: false,
    onConnect: () => {},
    onDisconnect: () => {},
    onMessage: () => {}
  };

  /**
   * @param {?{name:?string=,autoConnect:?boolean=,onConnect:?function():void=,onDisconnect:?function():void=,onMessage:?function(!*):void=}=} params
   */
  constructor(params) {
    this.#params = _common_js__WEBPACK_IMPORTED_MODULE_0__.mergeObject(this.#params, params);
  }
  connect() {
    if (this.#port) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.warn("Already connected", {
        port: this.#port
      });
      return;
    }
    try {
      this.#port = chrome.runtime.connect(undefined, {
        name: this.#params.name
      });
    } catch (error) {
      // The extension might have been refreshed, in which case it will never be
      // able to connect to Background service worker from this context again.
      _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("⚠ The extension might have been refreshed, in which case it is impossible to connect to Background service worker", {
        error
      });
      return;
    }
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Connected to Background service worker", {
      port: this.#port
    });
    this.#port.onDisconnect.addListener(port => this.#onDisconnect(port));
    this.#port.onMessage.addListener((message, port) => this.#onMessage(message, port));
    this.#params.onConnect();
  }
  disconnect() {
    if (this.#port) {
      this.#port.disconnect();
      this.#port = undefined;
      _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Disconnected from Background service worker");
    }
  }
  reconnect() {
    this.disconnect();
    this.connect();
  }

  /**
   * @returns {!chrome.runtime.Port}
   */
  get port() {
    return this.#port;
  }

  /**
   * @param {!*} message
   */
  postMessage(message) {
    if (!this.#checkConnection()) {
      return;
    }
    _common_js__WEBPACK_IMPORTED_MODULE_0__.postMessage(this.#port, message);
  }
  #checkConnection() {
    if (!this.#port) {
      if (this.#params.autoConnect) {
        this.connect();
      } else {
        _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.warn("Could not send message to Background service worker because the port has already been closed");
      }
    }
    return !!this.#port;
  }
  #onDisconnect(port) {
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onDisconnect()", {
      port
    });
    this.#port = undefined;
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Port to Background service worker has been closed by the other end");
    this.#params.onDisconnect();
  }
  #onMessage(message, port) {
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onMessage()", {
      message,
      port
    });
    this.#params.onMessage(message);
  }
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
var __webpack_exports__ = {};
/*!********************!*\
  !*** ./content.js ***!
  \********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _modules_common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modules/common.js */ "./modules/common.js");
/* harmony import */ var _modules_port_to_background_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modules/port_to_background.js */ "./modules/port_to_background.js");
/* harmony import */ var _modules_popup_icon_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modules/popup_icon.js */ "./modules/popup_icon.js");





(async function main() {
  //////////////////////////////////////////////////////////////////////////////
  // Initialize common modules
  //////////////////////////////////////////////////////////////////////////////

  await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.init(_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.ScriptId.CONTENT);
  if (document.contentType !== "text/html" || !document.body) {
    // Content scripts may be injected into non-HTML content. (e.g. image/svg+xml)
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Exit the content scripts because this document is not HTML", {
      contentType: document.contentType,
      body: document.body
    });
    return;
  }

  //////////////////////////////////////////////////////////////////////////////
  // Constants
  //////////////////////////////////////////////////////////////////////////////

  const EDITABLE_NODE_SELECTOR = "input, textarea";

  // prettier-ignore
  const SEARCH_ENGINES = [{
    hostnamePattern: /^www\.google\.[a-z]+(\.[a-z]+)?$/i,
    inputName: "q",
    formActionPattern: /^\/search$/
  }, {
    hostnamePattern: /^scholar\.google\.[a-z]+(\.[a-z]+)?$/i,
    inputName: "q",
    formActionPattern: /^\/scholar$/
  }, {
    hostnamePattern: /^www\.bing\.com$/i,
    inputName: "q",
    formActionPattern: /^\/search$/
  }, {
    hostnamePattern: /^(www|[a-z]+|([a-z]+\.)?search)\.yahoo\.com$/i,
    inputName: "p",
    formActionPattern: /^(https:\/\/[^/]+)?\/search(;.+)?$/
  }, {
    hostnamePattern: /^(www|search)\.yahoo\.co\.jp$/i,
    inputName: "p",
    formActionPattern: /^(https:\/\/[^/]+)?\/search$/
  }, {
    hostnamePattern: /^duckduckgo\.com$/i,
    inputName: "q",
    formActionPattern: /^\/$/
  }];
  const MESSAGE_HANDLERS = {
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.WELCOME]: onWelcome,
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.PUT_QUOTES]: onPutQuotes
  };

  //////////////////////////////////////////////////////////////////////////////
  // Variables
  //////////////////////////////////////////////////////////////////////////////

  const contentId = {
    tabId: NaN,
    frameId: NaN,
    initialize(tabId, frameId) {
      this.tabId = tabId;
      this.frameId = frameId;
    },
    isInitialized() {
      return Number.isInteger(this.tabId) && Number.isInteger(this.frameId);
    },
    toString() {
      return this.isInitialized() ? this.tabId + "-" + this.frameId : "-";
    }
  };
  const portToBackground = new _modules_port_to_background_js__WEBPACK_IMPORTED_MODULE_1__.PortToBackground({
    name: (window === window.parent ? "" : "(in frame) ") + document.URL,
    autoConnect: true,
    onConnect: onPortToBackgroundConnect,
    onDisconnect: onPortToBackgroundDisconnect,
    onMessage: onPortToBackgroundMessage
  });
  const popupIcon = new _modules_popup_icon_js__WEBPACK_IMPORTED_MODULE_2__.PopupIcon(window, onClickPopupIconSearch, onClickPopupIconQuote, onClickPopupIconOptions);
  let editableNodeWithSelection;

  //////////////////////////////////////////////////////////////////////////////
  // Startup Operations
  //////////////////////////////////////////////////////////////////////////////

  portToBackground.connect();
  chrome.runtime.onConnect.addListener(onConnect);
  window.addEventListener("focus", onWindowFocus);
  window.addEventListener("blur", onWindowBlur);
  document.addEventListener("selectionchange", onSelectionChange);
  const observer = new MutationObserver(onMutation);
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true
  });
  for (const node of document.querySelectorAll(EDITABLE_NODE_SELECTOR)) {
    addEventListenerToEditableNode(node);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (Background service worker)
  //////////////////////////////////////////////////////////////////////////////

  function onPortToBackgroundConnect() {
    portToBackground.postMessage({
      type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.HELLO
    });
    popupIcon.enable();
  }
  function onPortToBackgroundDisconnect() {
    popupIcon.disable();
  }
  function onPortToBackgroundMessage(message) {
    MESSAGE_HANDLERS[message.type](message, portToBackground.port);
  }
  function onConnect(port) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onConnect()", {
      port
    });
    port.onMessage.addListener(onMessage);
  }
  function onMessage(message, port) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onMessage()", {
      message,
      port
    });
    MESSAGE_HANDLERS[message.type](message, port);
  }
  function onWelcome(message, _port) {
    contentId.initialize(message.identity.tab.id, message.identity.frameId);
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.setId(contentId.toString());
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Update content identifier", {
      contentId
    });
    notifySelectionUpdated("contentId.initialize");
  }
  function onPutQuotes(_message, _port) {
    if (!editableNodeWithSelection) {
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info(`Ignore ${_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.CommandType.PUT_QUOTES} command due to no editable node selected `);
      return;
    }
    putQuotesAroundSelectionText(editableNodeWithSelection);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (DOM)
  //////////////////////////////////////////////////////////////////////////////

  function onWindowFocus(_e) {
    // Reconnect to refresh port
    portToBackground.reconnect();
    notifySelectionUpdated("window.focus");
  }
  function onWindowBlur(_e) {
    notifySelectionUpdated("window.blur");
  }
  function onSelectionChange(_e) {
    notifySelectionUpdated("document.selectionchange");
  }
  function onMutation(mutationList, _observer) {
    for (const mutation of mutationList) {
      if (mutation.type === "childList") {
        for (const node of mutation.addedNodes) {
          if (node.isConnected && node instanceof Element) {
            if (node.matches(EDITABLE_NODE_SELECTOR)) {
              _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Editable node has been added", {
                node
              });
              addEventListenerToEditableNode(node);
            }
            for (const descendantNode of node.querySelectorAll(EDITABLE_NODE_SELECTOR)) {
              _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Editable node has been added", {
                descendantNode
              });
              addEventListenerToEditableNode(descendantNode);
            }
          }
        }
      }
    }
  }
  function addEventListenerToEditableNode(editableNode) {
    if (typeof editableNode.selectionStart !== "number") {
      // An input field that does not support selection feature is not considered as an "editable node".
      // See also: https://html.spec.whatwg.org/multipage/input.html#concept-input-apply
      return;
    }
    if (editableNode.matches(":focus")) {
      updateEditableNodeWithSelection(editableNode, "editable.initial");
    }
    editableNode.addEventListener("focus", _e => {
      updateEditableNodeWithSelection(editableNode, "editable.focus");
    });
    editableNode.addEventListener("blur", _e => {
      if (document.activeElement !== editableNode && editableNodeWithSelection === editableNode) {
        updateEditableNodeWithSelection(undefined, "editable.blur");
      }
    });
    editableNode.addEventListener("select", _e => {
      updateEditableNodeWithSelection(editableNode, "editable.select");
    });
    editableNode.addEventListener("keydown", e => {
      if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.autoSurround && e.key === '"' && e.cancelable && !e.isComposing && !e.ctrlKey && !e.altKey && !e.metaKey && !e.repeat) {
        if (putQuotesAroundSelectionText(editableNode)) {
          e.preventDefault();
        }
      }
    });
  }

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (PopupIcon)
  //////////////////////////////////////////////////////////////////////////////

  function onClickPopupIconSearch(e) {
    portToBackground.postMessage({
      type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.DO_QUOTED_SEARCH,
      keyState: new _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.KeyState(e.ctrlKey, e.shiftKey, e.metaKey),
      selectionText: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.filterSelectionText(_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.getSelection(window).toString())
    });
  }
  function onClickPopupIconQuote(_e, editableNode) {
    // Uses `editableNode` specified as an argument of the event instead of
    // `editableNodeWithSelection`, because `editableNodeWithSelection` may be
    // already cleared on `blur` event caused by clicking the button.
    if (!editableNode) {
      return;
    }
    putQuotesAroundSelectionText(editableNode);
  }
  function onClickPopupIconOptions(e) {
    portToBackground.postMessage({
      type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.OPEN_OPTIONS_PAGE,
      keyState: new _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.KeyState(e.ctrlKey, e.shiftKey, e.metaKey),
      defaultHowToOpenLink: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.NEW_TAB_ACTIVE
    });
  }

  //////////////////////////////////////////////////////////////////////////////
  // Functions
  //////////////////////////////////////////////////////////////////////////////

  function updateEditableNodeWithSelection(editableNode, reason) {
    editableNodeWithSelection = editableNode && editableNode.matches(":focus") && !editableNode.disabled && !editableNode.readOnly && editableNode.value.substring(editableNode.selectionStart, editableNode.selectionEnd) === _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.getSelection(window).toString() ? editableNode : undefined;
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Update editableNodeWithSelection", {
      reason,
      editable: !!editableNodeWithSelection,
      text: editableNodeWithSelection ? _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.filterSelectionText(editableNodeWithSelection.value) : "N/A",
      selectionStart: editableNodeWithSelection ? editableNodeWithSelection.selectionStart : "N/A",
      selectionDirection: editableNodeWithSelection ? editableNodeWithSelection.selectionDirection : "N/A",
      editableNodeWithSelection
    });
    popupIcon.setEditableNode(editableNodeWithSelection);
    notifySelectionUpdated(reason);
  }
  function notifySelectionUpdated(reason) {
    const blur = reason.endsWith(".blur");
    if (contentId.isInitialized() && (blur || document.hasFocus())) {
      const message = {
        type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.NOTIFY_SELECTION_UPDATED,
        reason: reason,
        selection: {
          text: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.filterSelectionText(_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.getSelection(window).toString()),
          editable: !!editableNodeWithSelection,
          searchable: isSearchable(editableNodeWithSelection),
          blur: blur
        }
      };
      portToBackground.postMessage(message);
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info(`Send '${message.type}' message to background service worker`, {
        message
      });
    }
  }
  function putQuotesAroundSelectionText(editableNode) {
    if (editableNode.disabled || editableNode.readOnly) {
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info(`Ignore ${_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.CommandType.PUT_QUOTES} command because the input field can not be changed`, {
        disabled: editableNode.disabled,
        readOnly: editableNode.readOnly
      });
      return false;
    }
    const selectionText = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.filterSelectionText(editableNode.value.substring(editableNode.selectionStart, editableNode.selectionEnd));
    const normalizedSelectionText = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.normalizeSelectionText(selectionText);
    if (!_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.isNormalizedSelectionTextValid(normalizedSelectionText)) {
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info(`Ignore ${_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.CommandType.PUT_QUOTES} command due to unexpected selection text`, {
        selectionText
      });
      return false;
    }
    replaceSelectionText(editableNode, _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.quoteText(normalizedSelectionText));
    if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.autoEnter && isSearchable(editableNode)) {
      if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.autoCopy) {
        window.navigator.clipboard.writeText(normalizedSelectionText);
      }
      editableNode.form.submit();
    }
    return true;
  }
  function replaceSelectionText(editableNode, replacement) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.assert(replacement.length >= 3 && replacement.charAt(0) === '"' && replacement.charAt(replacement.length - 1) === '"', "Replacement for selection text is unexpected", {
      replacement
    });
    const spacePattern = /\s/;
    const text = editableNode.value;
    let oldSelectionStart = editableNode.selectionStart;
    let oldSelectionEnd = editableNode.selectionEnd;
    if (oldSelectionStart > 0 && _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.QUOTATION_MARKS.includes(text.charAt(oldSelectionStart - 1)) && !spacePattern.test(text.charAt(oldSelectionStart))) {
      oldSelectionStart--;
    }
    if (oldSelectionEnd < text.length && _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.QUOTATION_MARKS.includes(text.charAt(oldSelectionEnd)) && !spacePattern.test(text.charAt(oldSelectionEnd - 1))) {
      oldSelectionEnd++;
    }
    let tempReplacement = replacement;
    let selectionStartDelta = 1;
    let selectionEndDelta = -1;
    if (oldSelectionStart > 0 && !spacePattern.test(text.charAt(oldSelectionStart - 1))) {
      tempReplacement = " " + tempReplacement;
      selectionStartDelta++;
    }
    if (oldSelectionEnd < text.length && !spacePattern.test(text.charAt(oldSelectionEnd))) {
      tempReplacement = tempReplacement + " ";
      selectionEndDelta--;
    }
    const newSelectionStart = oldSelectionStart + selectionStartDelta;
    const newSelectionEnd = oldSelectionStart + tempReplacement.length + selectionEndDelta;
    editableNode.focus();
    // -------------------------------------------------------------------------
    // Avoid Chromium crashing
    //   https://github.com/higamaya/chrome-bug-20221018
    //   https://bugs.chromium.org/p/chromium/issues/detail?id=1376037
    //
    //editableNode.setRangeText(tempReplacement, oldSelectionStart, oldSelectionEnd);
    editableNode.value = text.substring(0, oldSelectionStart) + tempReplacement + text.substring(oldSelectionEnd);
    // -------------------------------------------------------------------------
    editableNode.setSelectionRange(newSelectionStart, newSelectionEnd, editableNode.selectionDirection);
  }
  function isSearchable(editableNode) {
    if (!editableNode) {
      return false;
    }
    editableNode.qqs ??= {};
    if (!Object.hasOwn(editableNode.qqs, "isSearchable")) {
      editableNode.qqs.isSearchable = (() => {
        if (editableNode instanceof HTMLInputElement) {
          for (const searchEngine of SEARCH_ENGINES) {
            if (searchEngine.hostnamePattern.test(window.location.hostname) && searchEngine.inputName === editableNode.name && searchEngine.formActionPattern.test(editableNode.form?.getAttribute("action"))) {
              return true;
            }
          }
        }
        return false;
      })();
    }
    return editableNode.qqs.isSearchable;
  }
})();
})();

// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!**********************!*\
  !*** ./content.scss ***!
  \**********************/
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin

})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudF9idW5kbGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsT0FBTyxHQUFHO0VBQUVDLE1BQU0sRUFBRTtJQUFDLFlBQVksRUFBQyxJQUFJO0lBQUMsc0JBQXNCLEVBQUMsSUFBSTtJQUFDLE9BQU8sRUFBQztFQUFLO0FBQUUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBMUY7QUFDQTtBQUNBO0FBQ08sTUFBTUMsUUFBUSxHQUFHO0VBQ3RCQyxNQUFNLEVBQUUsUUFBUTtFQUNoQkMsVUFBVSxFQUFFLFlBQVk7RUFDeEJDLE9BQU8sRUFBRSxHQUFHO0VBQ1pDLE9BQU8sRUFBRTtBQUNYLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ08sTUFBTUMsV0FBVyxHQUFHO0VBQ3pCQyxnQkFBZ0IsRUFBRSxrQkFBa0I7RUFDcENDLFVBQVUsRUFBRTtBQUNkLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ08sTUFBTUMsV0FBVyxHQUFHO0VBQ3pCO0VBQ0E7RUFDQTtFQUNBQyxLQUFLLEVBQUUsT0FBTztFQUNkQyx3QkFBd0IsRUFBRSwwQkFBMEI7RUFDcERKLGdCQUFnQixFQUFFLGtCQUFrQjtFQUNwQ0ssaUJBQWlCLEVBQUUsbUJBQW1CO0VBRXRDO0VBQ0E7RUFDQTtFQUNBQyxPQUFPLEVBQUUsU0FBUztFQUNsQkwsVUFBVSxFQUFFLFlBQVk7RUFFeEI7RUFDQTtFQUNBO0VBQ0FNLGFBQWEsRUFBRSxlQUFlO0VBRTlCO0VBQ0E7RUFDQTtFQUNBQyxnQkFBZ0IsRUFBRTtBQUNwQixDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQyxlQUFlLEdBQUcsOERBQThELENBQUMsQ0FBQzs7QUFFL0Y7QUFDQTtBQUNBO0FBQ08sTUFBTUMseUJBQXlCLEdBQUcsSUFBSTs7QUFFN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQyw4QkFBOEIsR0FBRyxvREFBb0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hFWTtBQUM3RDtBQUNPOztBQUV4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTSSxtQkFBbUIsQ0FBQ0MsYUFBYSxFQUFFO0VBQ2pEQSxhQUFhLEtBQUssRUFBRTtFQUNwQixPQUFPQSxhQUFhLENBQUNDLE1BQU0sR0FBR1Asb0VBQXlCLEdBQUdDLHlFQUE4QixHQUFHSyxhQUFhO0FBQzFHOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNFLHNCQUFzQixDQUFDRixhQUFhLEVBQUU7RUFDcERBLGFBQWEsR0FBR0QsbUJBQW1CLENBQUNDLGFBQWEsQ0FBQztFQUNsRCxPQUFPQSxhQUFhLEtBQUtMLHlFQUE4QixHQUNuREssYUFBYSxHQUNiQSxhQUFhLENBQUNHLFVBQVUsQ0FBQyxJQUFJQyxNQUFNLENBQUUsT0FBTVgsMERBQWdCLElBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQ1ksSUFBSSxFQUFFO0FBQ3ZGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLDhCQUE4QixDQUFDQyx1QkFBdUIsRUFBRTtFQUN0RUEsdUJBQXVCLEtBQUssRUFBRTtFQUM5QixPQUNFQSx1QkFBdUIsS0FBS1oseUVBQThCLElBQzFEWSx1QkFBdUIsQ0FBQ04sTUFBTSxHQUFHLENBQUMsSUFDbENNLHVCQUF1QixDQUFDTixNQUFNLElBQUlQLG9FQUF5QjtBQUUvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTYyxTQUFTLENBQUNDLElBQUksRUFBRTtFQUM5QixPQUFPLEdBQUcsSUFBSUEsSUFBSSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUc7QUFDakM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTQyxRQUFRLENBQUNDLEdBQUcsRUFBRTtFQUM1QixPQUFPQyxJQUFJLENBQUNDLEtBQUssQ0FBQ0QsSUFBSSxDQUFDRSxTQUFTLENBQUNILEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0ksV0FBVyxDQUFDQyxNQUFNLEVBQUVDLE1BQU0sRUFBRTtFQUMxQyxPQUFPO0lBQUUsR0FBR0QsTUFBTTtJQUFFLEdBQUdFLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDRCxNQUFNLENBQUNFLE9BQU8sQ0FBQ0gsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNJLE1BQU0sQ0FBQyxDQUFDLEdBQUdDLENBQUMsQ0FBQyxLQUFLQSxDQUFDLEtBQUtDLFNBQVMsQ0FBQztFQUFFLENBQUM7QUFDOUc7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsZ0NBQWdDLENBQUNDLEdBQUcsRUFBRUMsUUFBUSxFQUFFO0VBQzlELElBQUlELEdBQUcsQ0FBQ0UsUUFBUSxDQUFDQyxVQUFVLEtBQUssU0FBUyxFQUFFO0lBQ3pDSCxHQUFHLENBQUNFLFFBQVEsQ0FBQ0UsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUVILFFBQVEsQ0FBQztFQUM3RCxDQUFDLE1BQU07SUFDTEksY0FBYyxDQUFDSixRQUFRLENBQUM7RUFDMUI7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTSyw2QkFBNkIsQ0FBQ04sR0FBRyxFQUFFQyxRQUFRLEVBQUU7RUFDM0QsSUFBSUQsR0FBRyxDQUFDRSxRQUFRLENBQUNDLFVBQVUsS0FBSyxVQUFVLEVBQUU7SUFDMUNILEdBQUcsQ0FBQ0ksZ0JBQWdCLENBQUMsTUFBTSxFQUFFSCxRQUFRLENBQUM7RUFDeEMsQ0FBQyxNQUFNO0lBQ0xJLGNBQWMsQ0FBQ0osUUFBUSxDQUFDO0VBQzFCO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNNLHdCQUF3QixDQUFDQyxHQUFHLEVBQUU7RUFDNUMsTUFBTUMsWUFBWSxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQztFQUNsRixLQUFLLE1BQU1DLE9BQU8sSUFBSUYsR0FBRyxDQUFDRyxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO0lBQ2pFLE1BQU1DLGFBQWEsR0FBRyxDQUFDLE1BQU07TUFDM0IsTUFBTUMsTUFBTSxHQUFHLEVBQUU7TUFDakIsTUFBTUMsSUFBSSxHQUFHSixPQUFPLENBQUNLLE9BQU8sQ0FBQ0MsUUFBUTtNQUNyQyxJQUFJLENBQUNGLElBQUksRUFBRTtRQUNULE9BQU9ELE1BQU07TUFDZjtNQUNBLE1BQU1JLEdBQUcsR0FBR0gsSUFBSSxDQUFDSSxLQUFLLENBQUMsR0FBRyxDQUFDO01BQzNCLEtBQUssTUFBTUMsRUFBRSxJQUFJRixHQUFHLEVBQUU7UUFDcEIsTUFBTUcsVUFBVSxHQUFHWixHQUFHLENBQUNhLGNBQWMsQ0FBQ0YsRUFBRSxDQUFDO1FBQ3pDLE1BQU1HLFNBQVMsR0FBR0YsVUFBVSxDQUFDTCxPQUFPLENBQUNRLFVBQVU7UUFDL0NwRCxzREFBYSxDQUFDc0MsWUFBWSxDQUFDZ0IsUUFBUSxDQUFDSCxTQUFTLENBQUMsRUFBRSxtQkFBbUIsRUFBRTtVQUFFQSxTQUFTO1VBQUVGO1FBQVcsQ0FBQyxDQUFDO1FBQy9GUCxNQUFNLENBQUNhLElBQUksQ0FBQ04sVUFBVSxDQUFDRSxTQUFTLENBQUMsQ0FBQztNQUNwQztNQUNBLE9BQU9ULE1BQU07SUFDZixDQUFDLEdBQUc7SUFDSixNQUFNdEIsTUFBTSxHQUFHbUIsT0FBTyxDQUFDSyxPQUFPLENBQUNRLFVBQVU7SUFDekNwRCxzREFBYSxDQUFDc0MsWUFBWSxDQUFDZ0IsUUFBUSxDQUFDbEMsTUFBTSxDQUFDLEVBQUUsbUJBQW1CLEVBQUU7TUFBRUEsTUFBTTtNQUFFbUI7SUFBUSxDQUFDLENBQUM7SUFDdEZBLE9BQU8sQ0FBQ25CLE1BQU0sQ0FBQyxHQUFHb0MsTUFBTSxDQUFDQyxJQUFJLENBQUNDLFVBQVUsQ0FBQ25CLE9BQU8sQ0FBQ0ssT0FBTyxDQUFDZSxRQUFRLEVBQUVsQixhQUFhLENBQUM7RUFDbkY7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTbUIsWUFBWSxDQUFDL0IsR0FBRyxFQUFFO0VBQ2hDLFNBQVNnQyx3QkFBd0IsQ0FBQ0MsU0FBUyxFQUFFO0lBQzNDLElBQUlBLFNBQVMsQ0FBQ0MsVUFBVSxLQUFLLENBQUMsRUFBRTtNQUM5QixNQUFNQyxLQUFLLEdBQUdGLFNBQVMsQ0FBQ0csVUFBVSxDQUFDLENBQUMsQ0FBQztNQUNyQyxJQUFJRCxLQUFLLENBQUNFLGNBQWMsS0FBS0YsS0FBSyxDQUFDRyxZQUFZLEVBQUU7UUFDL0MsTUFBTUMsdUJBQXVCLEdBQUdKLEtBQUssQ0FBQ0ksdUJBQXVCO1FBQzdELElBQUlBLHVCQUF1QixZQUFZQyxPQUFPLEVBQUU7VUFDOUMsSUFBSUQsdUJBQXVCLENBQUNFLFVBQVUsRUFBRTtZQUN0QyxPQUFPVCx3QkFBd0IsQ0FBQ08sdUJBQXVCLENBQUNFLFVBQVUsQ0FBQ1YsWUFBWSxFQUFFLENBQUM7VUFDcEYsQ0FBQyxNQUFNO1lBQ0wsTUFBTVcsc0JBQXNCLEdBQUdDLEtBQUssQ0FBQ0MsU0FBUyxDQUFDaEQsTUFBTSxDQUFDaUQsSUFBSSxDQUN4RE4sdUJBQXVCLENBQUM1QixnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsRUFDNUNELE9BQU8sSUFBSyxDQUFDLENBQUNBLE9BQU8sQ0FBQytCLFVBQVUsQ0FDbEM7WUFDRCxJQUFJQyxzQkFBc0IsQ0FBQ2xFLE1BQU0sS0FBSyxDQUFDLEVBQUU7Y0FDdkMsT0FBT3dELHdCQUF3QixDQUFDVSxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ0QsVUFBVSxDQUFDVixZQUFZLEVBQUUsQ0FBQztZQUN0RjtVQUNGO1FBQ0Y7TUFDRjtJQUNGO0lBQ0EsT0FBT0UsU0FBUztFQUNsQjtFQUVBLE9BQU9ELHdCQUF3QixDQUFDaEMsR0FBRyxDQUFDK0IsWUFBWSxFQUFFLENBQUM7QUFDckQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU2UsV0FBVyxDQUFDQyxJQUFJLEVBQUVDLE9BQU8sRUFBRTtFQUN6QyxJQUFJO0lBQ0ZELElBQUksQ0FBQ0QsV0FBVyxDQUFDRSxPQUFPLENBQUM7RUFDM0IsQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtJQUNkOUUsb0RBQVcsQ0FDVCx3R0FBd0csRUFDeEc7TUFBRThFLEtBQUs7TUFBRUYsSUFBSTtNQUFFQztJQUFRLENBQUMsQ0FDekI7RUFDSDtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlRyxZQUFZLEdBQUc7RUFDbkMsTUFBTSxDQUFDQyxHQUFHLENBQUMsR0FBRyxNQUFNekIsTUFBTSxDQUFDMEIsSUFBSSxDQUFDQyxLQUFLLENBQUM7SUFBRUMsTUFBTSxFQUFFLElBQUk7SUFBRUMsYUFBYSxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQzVFLE9BQU9KLEdBQUc7QUFDWjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVLLFlBQVksQ0FBQ0wsR0FBRyxFQUFFTSxNQUFNLEVBQUU7RUFDOUMsT0FBTyxNQUFNL0IsTUFBTSxDQUFDMEIsSUFBSSxDQUFDTSxNQUFNLENBQUM7SUFDOUJDLFFBQVEsRUFBRVIsR0FBRyxDQUFDUSxRQUFRO0lBQ3RCQyxXQUFXLEVBQUVULEdBQUcsQ0FBQ2pDLEVBQUU7SUFDbkIyQyxLQUFLLEVBQUVWLEdBQUcsQ0FBQ1UsS0FBSyxHQUFHLENBQUM7SUFDcEJDLEdBQUcsRUFBRUwsTUFBTSxFQUFFSyxHQUFHO0lBQ2hCUixNQUFNLEVBQUVHLE1BQU0sRUFBRUgsTUFBTSxJQUFJO0VBQzVCLENBQUMsQ0FBQztBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVTLGVBQWUsQ0FBQ04sTUFBTSxFQUFFO0VBQzVDLE1BQU1GLGFBQWEsR0FBRyxNQUFNN0IsTUFBTSxDQUFDc0MsT0FBTyxDQUFDQyxVQUFVLEVBQUU7RUFDdkQsT0FBTyxNQUFNdkMsTUFBTSxDQUFDc0MsT0FBTyxDQUFDTixNQUFNLENBQUM7SUFDakNRLEtBQUssRUFBRVgsYUFBYSxDQUFDVyxLQUFLO0lBQzFCSixHQUFHLEVBQUVMLE1BQU0sRUFBRUs7RUFDZixDQUFDLENBQUM7QUFDSjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZUssY0FBYyxDQUFDaEIsR0FBRyxFQUFFaUIsVUFBVSxFQUFFQyxRQUFRLEVBQUU7RUFDOUQsTUFBTUMsYUFBYSxHQUFHbEcsc0VBQW9CLENBQUNpRyxRQUFRLEVBQUUsSUFBSWpHLCtEQUFhLENBQUNELDREQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO0VBQ2xHLElBQUltRyxhQUFhLENBQUNFLFdBQVcsS0FBS3BHLG1GQUFpQyxFQUFFO0lBQ25FLE1BQU11RyxNQUFNLEdBQUcsTUFBTW5CLFlBQVksQ0FBQ0wsR0FBRyxFQUFFO01BQUVHLE1BQU0sRUFBRTtJQUFNLENBQUMsQ0FBQztJQUN6RCxNQUFNNUIsTUFBTSxDQUFDa0QsTUFBTSxDQUFDdkIsS0FBSyxDQUFDO01BQUV3QixLQUFLLEVBQUVGLE1BQU0sQ0FBQ3pELEVBQUU7TUFBRW5DLElBQUksRUFBRUQsU0FBUyxDQUFDc0YsVUFBVTtJQUFFLENBQUMsQ0FBQztJQUM1RTtJQUNBO0lBQ0EsSUFBSUUsYUFBYSxDQUFDaEIsTUFBTSxJQUFJLElBQUksRUFBRTtNQUNoQyxNQUFNNUIsTUFBTSxDQUFDMEIsSUFBSSxDQUFDMEIsTUFBTSxDQUFDSCxNQUFNLENBQUN6RCxFQUFFLEVBQUU7UUFBRW9DLE1BQU0sRUFBRTtNQUFLLENBQUMsQ0FBQztJQUN2RDtFQUNGLENBQUMsTUFBTTtJQUNMLE1BQU01QixNQUFNLENBQUNrRCxNQUFNLENBQUN2QixLQUFLLENBQUM7TUFBRW1CLFdBQVcsRUFBRUYsYUFBYSxDQUFDRSxXQUFXO01BQUV6RixJQUFJLEVBQUVELFNBQVMsQ0FBQ3NGLFVBQVU7SUFBRSxDQUFDLENBQUM7RUFDcEc7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVXLFFBQVEsQ0FBQzVCLEdBQUcsRUFBRVcsR0FBRyxFQUFFTyxRQUFRLEVBQUVXLG9CQUFvQixFQUFFO0VBQ3ZFLE1BQU1WLGFBQWEsR0FBR2xHLHNFQUFvQixDQUFDaUcsUUFBUSxFQUFFVyxvQkFBb0IsQ0FBQztFQUMxRSxJQUFJVixhQUFhLENBQUNFLFdBQVcsS0FBS3BHLHVGQUFxQyxFQUFFO0lBQ3ZFLE1BQU1zRCxNQUFNLENBQUMwQixJQUFJLENBQUMwQixNQUFNLENBQUMzQixHQUFHLENBQUNqQyxFQUFFLEVBQUU7TUFBRTRDLEdBQUcsRUFBRUE7SUFBSSxDQUFDLENBQUM7RUFDaEQsQ0FBQyxNQUFNLElBQUlRLGFBQWEsQ0FBQ0UsV0FBVyxLQUFLcEcsc0ZBQW9DLEVBQUU7SUFDN0UsTUFBTTJGLGVBQWUsQ0FBQztNQUFFRCxHQUFHLEVBQUVBO0lBQUksQ0FBQyxDQUFDO0VBQ3JDLENBQUMsTUFBTTtJQUNMLE1BQU1OLFlBQVksQ0FBQ0wsR0FBRyxFQUFFO01BQUVXLEdBQUcsRUFBRUEsR0FBRztNQUFFUixNQUFNLEVBQUVnQixhQUFhLENBQUNoQixNQUFNLElBQUk7SUFBSyxDQUFDLENBQUM7RUFDN0U7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlNkIsZUFBZSxDQUFDaEMsR0FBRyxFQUFFa0IsUUFBUSxFQUFFVyxvQkFBb0IsRUFBRTtFQUN6RSxNQUFNbEIsR0FBRyxHQUFHcEMsTUFBTSxDQUFDMEQsT0FBTyxDQUFDQyxNQUFNLENBQUMsY0FBYyxDQUFDO0VBQ2pELE1BQU1OLFFBQVEsQ0FBQzVCLEdBQUcsRUFBRVcsR0FBRyxFQUFFTyxRQUFRLEVBQUVXLG9CQUFvQixDQUFDO0FBQzFEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVNLHdCQUF3QixDQUFDbkMsR0FBRyxFQUFFa0IsUUFBUSxFQUFFVyxvQkFBb0IsRUFBRTtFQUNsRixNQUFNbEIsR0FBRyxHQUFHLDBCQUEwQjtFQUN0QyxNQUFNaUIsUUFBUSxDQUFDNUIsR0FBRyxFQUFFVyxHQUFHLEVBQUVPLFFBQVEsRUFBRVcsb0JBQW9CLENBQUM7QUFDMUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZU8scUJBQXFCLENBQUNwQyxHQUFHLEVBQUVrQixRQUFRLEVBQUVXLG9CQUFvQixFQUFFO0VBQy9FLE1BQU1sQixHQUFHLEdBQUcsK0JBQStCO0VBQzNDLE1BQU1pQixRQUFRLENBQUM1QixHQUFHLEVBQUVXLEdBQUcsRUFBRU8sUUFBUSxFQUFFVyxvQkFBb0IsQ0FBQztBQUMxRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVXdUM7QUFDSztBQUNMO0FBQ0U7O0FBRXpDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBSTlHLE1BQU07O0FBRWpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBSUMsT0FBTzs7QUFFbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZXVILElBQUksQ0FBQ0MsUUFBUSxFQUFFO0VBQ25DekgsTUFBTSxHQUFHLElBQUlzSCw4Q0FBTSxDQUFDRyxRQUFRLENBQUM7RUFDN0J6SCxNQUFNLENBQUNnRyxLQUFLLENBQUMsbUJBQW1CLEVBQUU7SUFBRXlCO0VBQVMsQ0FBQyxDQUFDO0VBRS9DeEgsT0FBTyxHQUFHLElBQUlzSCxnREFBTyxDQUFDdkgsTUFBTSxDQUFDO0VBQzdCLE1BQU1DLE9BQU8sQ0FBQ3VILElBQUksRUFBRTtFQUVwQixNQUFNRSxZQUFZLENBQUNELFFBQVEsQ0FBQztBQUM5QjtBQUVBLGVBQWVDLFlBQVksQ0FBQ0QsUUFBUSxFQUFFO0VBQ3BDLE1BQU1FLFdBQVcsR0FBRyxPQUFPO0VBQzNCLE1BQU1DLE9BQU8sR0FBR3BFLE1BQU0sQ0FBQ29FLE9BQU8sQ0FBQ0MsS0FBSztFQUNwQyxJQUFJSixRQUFRLEtBQUszSSw4REFBbUIsRUFBRTtJQUNwQ0Qsb0RBQVksR0FBRyxDQUFDLE1BQU0yRSxNQUFNLENBQUMwRCxPQUFPLENBQUNhLGVBQWUsRUFBRSxFQUFFQyxFQUFFLEtBQUssS0FBSztJQUNwRSxNQUFNSixPQUFPLENBQUNLLEdBQUcsQ0FBQztNQUFFLENBQUNOLFdBQVcsR0FBRzlJLG9EQUFZaUo7SUFBQyxDQUFDLENBQUM7RUFDcEQsQ0FBQyxNQUFNO0lBQ0xqSixvREFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0rSSxPQUFPLENBQUNNLEdBQUcsQ0FBQ1AsV0FBVyxDQUFDLEVBQUVBLFdBQVcsQ0FBQztFQUNoRTtFQUNBM0gsTUFBTSxDQUFDZ0csS0FBSyxDQUFDLDJCQUEyQixFQUFFO0lBQUUsQ0FBQyxjQUFjLEdBQUduSCxvREFBWWlKO0VBQUMsQ0FBQyxDQUFDO0FBQy9FOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BEdUM7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTTVILGFBQWEsQ0FBQztFQUN6QjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT3FHLFdBQVcsR0FBRztJQUNuQlEsV0FBVyxFQUFFLGFBQWE7SUFDMUJQLE9BQU8sRUFBRSxTQUFTO0lBQ2xCUSxVQUFVLEVBQUU7RUFDZCxDQUFDO0VBRUQsT0FBT21CLFFBQVEsR0FBRyxNQUFNQSxRQUFRLENBQUM7SUFDL0JDLE9BQU87SUFDUEMsUUFBUTs7SUFFUjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDSUMsV0FBVyxDQUFDRixPQUFPLEVBQUVDLFFBQVEsRUFBRUUsT0FBTyxHQUFHSCxPQUFPLEVBQUU7TUFDaEQsSUFBSSxDQUFDQSxPQUFPLEdBQUd2SixvREFBWSxHQUFHMEosT0FBTyxHQUFHSCxPQUFPO01BQy9DLElBQUksQ0FBQ0MsUUFBUSxHQUFHQSxRQUFRO0lBQzFCO0lBRUFHLE1BQU0sQ0FBQ0MsS0FBSyxFQUFFO01BQ1osT0FBT0EsS0FBSyxJQUFJLElBQUksQ0FBQ0wsT0FBTyxLQUFLSyxLQUFLLENBQUNMLE9BQU8sSUFBSSxJQUFJLENBQUNDLFFBQVEsS0FBS0ksS0FBSyxDQUFDSixRQUFRO0lBQ3BGO0lBRUEsT0FBT3RCLFdBQVcsR0FBRyxJQUFJb0IsUUFBUSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUM7SUFDL0MsT0FBT08sY0FBYyxHQUFHLElBQUlQLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDO0lBQ2hELE9BQU9RLGdCQUFnQixHQUFHLElBQUlSLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDO0lBQ25ELE9BQU9uQixVQUFVLEdBQUcsSUFBSW1CLFFBQVEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDO0VBQy9DLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0VBQ0U3QixXQUFXOztFQUVYO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRWxCLE1BQU07O0VBRU47QUFDRjtBQUNBO0FBQ0E7RUFDRWtELFdBQVcsQ0FBQ2hDLFdBQVcsRUFBRWxCLE1BQU0sR0FBRyxJQUFJLEVBQUU7SUFDdEMsSUFBSSxDQUFDa0IsV0FBVyxHQUFHQSxXQUFXO0lBQzlCLElBQUksQ0FBQ2xCLE1BQU0sR0FBR0EsTUFBTTtFQUN0QjtFQUVBLE9BQU8yQixXQUFXLEdBQUcsSUFBSTdHLGFBQWEsQ0FBQ0EsYUFBYSxDQUFDcUcsV0FBVyxDQUFDUSxXQUFXLENBQUM7RUFDN0UsT0FBTzJCLGNBQWMsR0FBRyxJQUFJeEksYUFBYSxDQUFDQSxhQUFhLENBQUNxRyxXQUFXLENBQUNDLE9BQU8sRUFBRSxJQUFJLENBQUM7RUFDbEYsT0FBT21DLGdCQUFnQixHQUFHLElBQUl6SSxhQUFhLENBQUNBLGFBQWEsQ0FBQ3FHLFdBQVcsQ0FBQ0MsT0FBTyxFQUFFLEtBQUssQ0FBQztFQUNyRixPQUFPUSxVQUFVLEdBQUcsSUFBSTlHLGFBQWEsQ0FBQ0EsYUFBYSxDQUFDcUcsV0FBVyxDQUFDUyxVQUFVLENBQUM7O0VBRTNFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT1gsTUFBTSxDQUFDRixRQUFRLEVBQUVXLG9CQUFvQixFQUFFO0lBQzVDLElBQUk1RyxhQUFhLENBQUNpSSxRQUFRLENBQUNPLGNBQWMsQ0FBQ0YsTUFBTSxDQUFDckMsUUFBUSxDQUFDLEVBQUUsT0FBT2pHLGFBQWEsQ0FBQ3dJLGNBQWMsQ0FBQyxLQUMzRixJQUFJeEksYUFBYSxDQUFDaUksUUFBUSxDQUFDUSxnQkFBZ0IsQ0FBQ0gsTUFBTSxDQUFDckMsUUFBUSxDQUFDLEVBQUUsT0FBT2pHLGFBQWEsQ0FBQ3lJLGdCQUFnQixDQUFDLEtBQ3BHLElBQUl6SSxhQUFhLENBQUNpSSxRQUFRLENBQUNuQixVQUFVLENBQUN3QixNQUFNLENBQUNyQyxRQUFRLENBQUMsRUFBRSxPQUFPakcsYUFBYSxDQUFDOEcsVUFBVSxDQUFDLEtBQ3hGLE9BQU9GLG9CQUFvQixJQUFJNUcsYUFBYSxDQUFDNkcsV0FBVztFQUMvRDtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3JGdUM7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTU8sTUFBTSxDQUFDO0VBQ2xCLENBQUN0RSxFQUFFOztFQUVIO0FBQ0Y7QUFDQTtBQUNBO0VBQ0VzRixXQUFXLENBQUN0RixFQUFFLEVBQUU7SUFDZCxJQUFJLENBQUMsQ0FBQ0EsRUFBRSxHQUFHQSxFQUFFO0VBQ2Y7O0VBRUE7QUFDRjtBQUNBO0VBQ0U0RixLQUFLLENBQUM1RixFQUFFLEVBQUU7SUFDUixJQUFJLENBQUMsQ0FBQ0EsRUFBRSxHQUFHQSxFQUFFO0VBQ2Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFNkYsSUFBSSxDQUFDaEUsT0FBTyxFQUFFLEdBQUdsQyxJQUFJLEVBQUU7SUFDckIsSUFBSSxDQUFDLENBQUNtRyxNQUFNLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRWpFLE9BQU8sRUFBRWxDLElBQUksQ0FBQztFQUNoRDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VxRCxLQUFLLENBQUNuQixPQUFPLEVBQUUsR0FBR2xDLElBQUksRUFBRTtJQUN0QixJQUFJLENBQUMsQ0FBQ21HLE1BQU0sQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFakUsT0FBTyxFQUFFbEMsSUFBSSxDQUFDO0VBQ2pEOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRW9HLFFBQVEsQ0FBQ2xFLE9BQU8sRUFBRSxHQUFHbEMsSUFBSSxFQUFFO0lBQ3pCLElBQUksQ0FBQyxDQUFDbUcsTUFBTSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUVqRSxPQUFPLEVBQUVsQyxJQUFJLENBQUM7RUFDcEQ7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFb0MsSUFBSSxDQUFDRixPQUFPLEVBQUUsR0FBR2xDLElBQUksRUFBRTtJQUNyQixJQUFJLENBQUMsQ0FBQ21HLE1BQU0sQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFakUsT0FBTyxFQUFFbEMsSUFBSSxDQUFDO0VBQy9DOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRW1DLEtBQUssQ0FBQ0QsT0FBTyxFQUFFLEdBQUdsQyxJQUFJLEVBQUU7SUFDdEIsSUFBSSxDQUFDLENBQUNtRyxNQUFNLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRWpFLE9BQU8sRUFBRWxDLElBQUksQ0FBQztFQUNqRDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRVUsTUFBTSxDQUFDMkYsU0FBUyxFQUFFbkUsT0FBTyxFQUFFLEdBQUdsQyxJQUFJLEVBQUU7SUFDbEMsSUFBSSxDQUFDLENBQUNtRyxNQUFNLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRWpFLE9BQU8sRUFBRWxDLElBQUksRUFBRXFHLFNBQVMsQ0FBQztFQUM3RDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxDQUFDRixNQUFNLENBQUNHLFVBQVUsRUFBRUMsTUFBTSxFQUFFckUsT0FBTyxFQUFFbEMsSUFBSSxFQUFFcUcsU0FBUyxFQUFFO0lBQ3BELElBQUksQ0FBQ25LLHlEQUFpQixFQUFFO01BQ3RCO0lBQ0Y7SUFFQSxNQUFNdUssWUFBWSxHQUFHLEVBQUU7SUFDdkIsSUFBSXpHLElBQUksSUFBSUEsSUFBSSxDQUFDdEMsTUFBTSxHQUFHLENBQUMsSUFBSSxPQUFPc0MsSUFBSSxDQUFDMEcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO01BQzlELEtBQUssTUFBTSxDQUFDQyxHQUFHLEVBQUVDLEtBQUssQ0FBQyxJQUFJakksTUFBTSxDQUFDRSxPQUFPLENBQUNtQixJQUFJLENBQUM2RyxHQUFHLEVBQUUsQ0FBQyxFQUFFO1FBQ3JESixZQUFZLENBQUM3RixJQUFJLENBQUUsS0FBSStGLEdBQUksR0FBRSxDQUFDO1FBQzlCRixZQUFZLENBQUM3RixJQUFJLENBQUNnRyxLQUFLLENBQUM7TUFDMUI7SUFDRjtJQUVBRSxPQUFPLENBQUNSLFVBQVUsQ0FBQyxDQUNqQixJQUFJQSxVQUFVLEtBQUssUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDRCxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsRUFDaEQsSUFBRyxJQUFJLENBQUMsQ0FBQ2hHLEVBQUcsS0FBSWtHLE1BQU8sSUFBR3JFLE9BQVEsRUFBQyxFQUNwQyxHQUFHbEMsSUFBSSxFQUNQLEdBQUd5RyxZQUFZLENBQ2hCO0VBQ0g7QUFDRjs7Ozs7Ozs7Ozs7Ozs7OztBQzlId0Q7O0FBRXhEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTTdCLE9BQU8sQ0FBQztFQUNuQixPQUFPLENBQUNLLE9BQU8sR0FBR3BFLE1BQU0sQ0FBQ29FLE9BQU8sQ0FBQzhCLElBQUk7RUFFckMsT0FBTyxDQUFDL0IsV0FBVyxHQUFHLFNBQVM7RUFFL0IsT0FBTyxDQUFDZ0MsY0FBYyxHQUFHLGVBQWU7RUFFeEMsT0FBTyxDQUFDQyxjQUFjLEdBQUc7SUFDdkIsQ0FBQ3JDLE9BQU8sQ0FBQyxDQUFDb0MsY0FBYyxHQUFHO0VBQzdCLENBQUM7RUFFRCxPQUFPcEQsV0FBVyxHQUFHckcsMkVBQXlCO0VBRTlDLE9BQU8ySixhQUFhLEdBQUcsQ0FBQztFQUN4QixPQUFPQyxhQUFhLEdBQUcsQ0FBQzs7RUFFeEI7RUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBTyxDQUFDQyxLQUFLLEdBQUcsQ0FDZDtJQUFFQyxJQUFJLEVBQUUsV0FBVztJQUFPQyxZQUFZLEVBQUUsSUFBSTtJQUF5QkMsU0FBUyxFQUFHWCxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsRUFDMUw7SUFBRVMsSUFBSSxFQUFFLFVBQVU7SUFBUUMsWUFBWSxFQUFFLENBQUM7SUFBNEJDLFNBQVMsRUFBR1gsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSyxRQUFRLElBQUlBLEtBQUssSUFBSWhDLE9BQU8sQ0FBQ3NDLGFBQWEsSUFBSU4sS0FBSyxJQUFJaEMsT0FBTyxDQUFDdUM7RUFBYyxDQUFDLEVBQzFMO0lBQUVFLElBQUksRUFBRSxnQkFBZ0I7SUFBRUMsWUFBWSxFQUFFLEtBQUs7SUFBd0JDLFNBQVMsRUFBR1gsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSztFQUE2RSxDQUFDLEVBQzFMO0lBQUVTLElBQUksRUFBRSxlQUFlO0lBQUdDLFlBQVksRUFBRSxJQUFJO0lBQXlCQyxTQUFTLEVBQUdYLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUs7RUFBNkUsQ0FBQyxFQUMxTDtJQUFFUyxJQUFJLEVBQUUsYUFBYTtJQUFLQyxZQUFZLEVBQUUsSUFBSTtJQUF5QkMsU0FBUyxFQUFHWCxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsRUFDMUw7SUFBRVMsSUFBSSxFQUFFLGFBQWE7SUFBS0MsWUFBWSxFQUFFMUMsT0FBTyxDQUFDaEIsV0FBVyxDQUFDQyxPQUFPO0lBQUUwRCxTQUFTLEVBQUdYLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUssUUFBUSxJQUFJakksTUFBTSxDQUFDNkksTUFBTSxDQUFDNUMsT0FBTyxDQUFDaEIsV0FBVyxDQUFDLENBQUNqRCxRQUFRLENBQUNpRyxLQUFLO0VBQWdCLENBQUMsRUFDMUw7SUFBRVMsSUFBSSxFQUFFLFVBQVU7SUFBUUMsWUFBWSxFQUFFLElBQUk7SUFBeUJDLFNBQVMsRUFBR1gsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSztFQUE2RSxDQUFDLEVBQzFMO0lBQUVTLElBQUksRUFBRSxXQUFXO0lBQU9DLFlBQVksRUFBRSxJQUFJO0lBQXlCQyxTQUFTLEVBQUdYLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUs7RUFBNkUsQ0FBQyxFQUMxTDtJQUFFUyxJQUFJLEVBQUUsY0FBYztJQUFJQyxZQUFZLEVBQUUsS0FBSztJQUF3QkMsU0FBUyxFQUFHWCxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsQ0FDM0w7RUFFRCxPQUFPLENBQUNhLGFBQWEsR0FBRztJQUN0QixLQUFLLE1BQU07TUFBRUosSUFBSTtNQUFFQyxZQUFZO01BQUVDO0lBQVUsQ0FBQyxJQUFJM0MsT0FBTyxDQUFDLENBQUN3QyxLQUFLLEVBQUU7TUFDOUR4QyxPQUFPLENBQUMsQ0FBQ3FDLGNBQWMsQ0FBQ0ksSUFBSSxDQUFDLEdBQUdDLFlBQVk7TUFDNUMzSSxNQUFNLENBQUMrSSxjQUFjLENBQUM5QyxPQUFPLENBQUM5QyxTQUFTLEVBQUV1RixJQUFJLEVBQUU7UUFDN0MvQixHQUFHLENBQUNzQixLQUFLLEVBQUU7VUFDVCxJQUFJLENBQUNXLFNBQVMsQ0FBQ1gsS0FBSyxDQUFDLEVBQUU7WUFDckIsTUFBTSxJQUFJZSxLQUFLLENBQUUsK0JBQThCTixJQUFLLFlBQVdULEtBQU0sRUFBQyxDQUFDO1VBQ3pFO1VBQ0EsSUFBSUEsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDZ0IsS0FBSyxDQUFDUCxJQUFJLENBQUMsRUFBRTtZQUMvQixJQUFJLENBQUMsQ0FBQ08sS0FBSyxDQUFDUCxJQUFJLENBQUMsR0FBR1QsS0FBSztZQUN6QjtZQUFZLElBQUksQ0FBQyxDQUFDaUIsYUFBYSxFQUFFO1VBQ25DO1FBQ0YsQ0FBQztRQUNEdEMsR0FBRyxHQUFHO1VBQ0osT0FBT2dDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQ0ssS0FBSyxDQUFDUCxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDTyxLQUFLLENBQUNQLElBQUksQ0FBQyxHQUFHQyxZQUFZO1FBQ3hFO01BQ0YsQ0FBQyxDQUFDO0lBQ0o7RUFDRjtFQUFDLFlBR0MxQyxPQUFPLENBQUMsQ0FBQzZDLGFBQWEsRUFBRTtFQUcxQjtBQUNGO0FBQ0E7RUFDRUssU0FBUyxHQUFHLElBQUssTUFBTUEsU0FBUyxDQUFDO0lBQy9CLENBQUNDLFNBQVMsR0FBRyxFQUFFO0lBQ2Y7QUFDSjtBQUNBO0lBQ0lDLFdBQVcsQ0FBQzdJLFFBQVEsRUFBRTtNQUNwQixJQUFJLENBQUMsQ0FBQzRJLFNBQVMsQ0FBQ25ILElBQUksQ0FBQ3pCLFFBQVEsQ0FBQztJQUNoQztJQUNBOEksS0FBSyxHQUFHO01BQ04sS0FBSyxNQUFNOUksUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDNEksU0FBUyxFQUFFO1FBQ3RDNUksUUFBUSxFQUFFO01BQ1o7SUFDRjtFQUNGLENBQUMsRUFBRztFQUVKLENBQUM5QixNQUFNO0VBQ1AsQ0FBQ3VLLEtBQUs7O0VBRU47QUFDRjtBQUNBO0VBQ0VqQyxXQUFXLENBQUN0SSxNQUFNLEVBQUU7SUFDbEIsSUFBSSxDQUFDLENBQUNBLE1BQU0sR0FBR0EsTUFBTTtJQUNyQixJQUFJLENBQUMsQ0FBQ3VLLEtBQUssR0FBR2pKLE1BQU0sQ0FBQ3VKLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXRELE9BQU8sQ0FBQyxDQUFDcUMsY0FBYyxDQUFDO0lBRXhEckMsT0FBTyxDQUFDLENBQUNLLE9BQU8sQ0FBQzZDLFNBQVMsQ0FBQ0UsV0FBVyxDQUFDLENBQUNHLE9BQU8sRUFBRUMsUUFBUSxLQUFLO01BQzVELElBQUksQ0FBQyxDQUFDQyxpQkFBaUIsQ0FBQ0YsT0FBTyxFQUFFQyxRQUFRLENBQUM7SUFDNUMsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7QUFDRjtBQUNBO0VBQ0UsTUFBTXZELElBQUksR0FBRztJQUNYLE1BQU0yQyxNQUFNLEdBQUcsTUFBTTVDLE9BQU8sQ0FBQyxDQUFDSyxPQUFPLENBQUNNLEdBQUcsQ0FBQ1gsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQztJQUMvRDtJQUNBO0lBQ0FyRyxNQUFNLENBQUN1SixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUNOLEtBQUssRUFBRUosTUFBTSxDQUFDNUMsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDO0lBQ3hELElBQUksQ0FBQyxDQUFDM0gsTUFBTSxDQUFDZ0csS0FBSyxDQUFDLHNCQUFzQixFQUFFO01BQUUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLENBQUN1RTtJQUFNLENBQUMsQ0FBQztFQUM5RTs7RUFFQTtBQUNGO0FBQ0E7RUFDRVUsS0FBSyxHQUFHO0lBQ04sSUFBSSxDQUFDLENBQUNWLEtBQUssR0FBR2pKLE1BQU0sQ0FBQ3VKLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXRELE9BQU8sQ0FBQyxDQUFDcUMsY0FBYyxDQUFDO0lBQ3hEO0lBQVksSUFBSSxDQUFDLENBQUNZLGFBQWEsRUFBRTtFQUNuQztFQUVBLE1BQU0sQ0FBQ0EsYUFBYSxHQUFHO0lBQ3JCLElBQUksQ0FBQyxDQUFDRCxLQUFLLENBQUNoRCxPQUFPLENBQUMsQ0FBQ29DLGNBQWMsQ0FBQyxHQUFHdUIsSUFBSSxDQUFDQyxHQUFHLEVBQUU7SUFDakQsTUFBTWhCLE1BQU0sR0FBRztNQUFFLENBQUM1QyxPQUFPLENBQUMsQ0FBQ0ksV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDNEM7SUFBTSxDQUFDO0lBQ3RELElBQUksQ0FBQyxDQUFDdkssTUFBTSxDQUFDZ0csS0FBSyxDQUFDLHlCQUF5QixFQUFFO01BQUVtRTtJQUFPLENBQUMsQ0FBQztJQUN6RCxNQUFNNUMsT0FBTyxDQUFDLENBQUNLLE9BQU8sQ0FBQ0ssR0FBRyxDQUFDa0MsTUFBTSxDQUFDO0VBQ3BDO0VBRUEsQ0FBQ2EsaUJBQWlCLENBQUNGLE9BQU8sRUFBRUMsUUFBUSxFQUFFO0lBQ3BDLElBQUksQ0FBQyxDQUFDL0ssTUFBTSxDQUFDK0ksUUFBUSxDQUFDLDhCQUE4QixFQUFFO01BQUUrQixPQUFPO01BQUVDO0lBQVMsQ0FBQyxDQUFDO0lBRTVFLElBQUksQ0FBQ3pKLE1BQU0sQ0FBQzhKLE1BQU0sQ0FBQ04sT0FBTyxFQUFFdkQsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxFQUFFO01BQ2pEO0lBQ0Y7SUFFQSxJQUFJckcsTUFBTSxDQUFDOEosTUFBTSxDQUFDTixPQUFPLENBQUN2RCxPQUFPLENBQUMsQ0FBQ0ksV0FBVyxDQUFDLEVBQUUsVUFBVSxDQUFDLEVBQUU7TUFDNUQsTUFBTTBELFFBQVEsR0FBR1AsT0FBTyxDQUFDdkQsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDMEQsUUFBUTtNQUN2RCxJQUFJQSxRQUFRLENBQUM5RCxPQUFPLENBQUMsQ0FBQ29DLGNBQWMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDWSxLQUFLLENBQUNoRCxPQUFPLENBQUMsQ0FBQ29DLGNBQWMsQ0FBQyxFQUFFO1FBQzdFLElBQUksQ0FBQyxDQUFDM0osTUFBTSxDQUFDNkksSUFBSSxDQUFDLDZEQUE2RCxFQUFFO1VBQy9FLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxDQUFDMEI7UUFDekIsQ0FBQyxDQUFDO1FBQ0Y7TUFDRjs7TUFFQTtNQUNBO01BQ0FqSixNQUFNLENBQUN1SixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUNOLEtBQUssRUFBRWMsUUFBUSxDQUFDO01BQ3BDLElBQUksQ0FBQyxDQUFDckwsTUFBTSxDQUFDZ0csS0FBSyxDQUFDLHNFQUFzRSxFQUFFO1FBQ3pGLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxDQUFDdUU7TUFDekIsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxNQUFNO01BQ0w7O01BRUEsSUFBSSxDQUFDLENBQUNBLEtBQUssR0FBR2pKLE1BQU0sQ0FBQ3VKLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXRELE9BQU8sQ0FBQyxDQUFDcUMsY0FBYyxDQUFDO01BQ3hELElBQUksQ0FBQyxDQUFDNUosTUFBTSxDQUFDZ0csS0FBSyxDQUFDLGlGQUFpRixFQUFFO1FBQ3BHLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxDQUFDdUU7TUFDekIsQ0FBQyxDQUFDO0lBQ0o7SUFFQSxJQUFJLENBQUNFLFNBQVMsQ0FBQ0csS0FBSyxFQUFFO0VBQ3hCO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEtBO0FBQ0E7QUFDQTs7QUFFOEI7QUFDRztBQUNBO0FBQ0Y7QUFDUztBQUNWOzs7Ozs7Ozs7Ozs7Ozs7OztBQ1RLOztBQUVuQztBQUNBO0FBQ0E7QUFDTyxNQUFNVyxTQUFTLENBQUM7RUFDckIsQ0FBQzFKLEdBQUc7RUFDSixDQUFDMkosR0FBRztFQUVKLENBQUNDLFlBQVk7RUFDYixDQUFDQyxPQUFPLEdBQUcsS0FBSztFQUVoQixDQUFDQyxhQUFhLEdBQUc7SUFBRUMsS0FBSyxFQUFFLENBQUM7SUFBRUMsS0FBSyxFQUFFLENBQUM7SUFBRUMsU0FBUyxFQUFFO0VBQUssQ0FBQzs7RUFFeEQ7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0V4RCxXQUFXLENBQUN6RyxHQUFHLEVBQUVrSyxxQkFBcUIsRUFBRUMsb0JBQW9CLEVBQUVDLHNCQUFzQixFQUFFO0lBQ3BGLElBQUksQ0FBQyxDQUFDcEssR0FBRyxHQUFHQSxHQUFHO0lBQ2YsSUFBSSxDQUFDLENBQUMySixHQUFHLEdBQUcsSUFBSVUsWUFBWSxDQUFDckssR0FBRyxFQUFFa0sscUJBQXFCLEVBQUVDLG9CQUFvQixFQUFFQyxzQkFBc0IsQ0FBQztJQUV0RyxJQUFJLENBQUMsQ0FBQ3BLLEdBQUcsQ0FBQ0UsUUFBUSxDQUFDb0ssZUFBZSxDQUFDbEssZ0JBQWdCLENBQUMsV0FBVyxFQUFHbUssQ0FBQyxJQUFLLElBQUksQ0FBQyxDQUFDQyxXQUFXLENBQUNELENBQUMsQ0FBQyxDQUFDO0lBQzdGLElBQUksQ0FBQyxDQUFDdkssR0FBRyxDQUFDRSxRQUFRLENBQUNvSyxlQUFlLENBQUNsSyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUdtSyxDQUFDLElBQUssSUFBSSxDQUFDLENBQUNFLFNBQVMsQ0FBQ0YsQ0FBQyxDQUFDLENBQUM7SUFDekYsSUFBSSxDQUFDLENBQUN2SyxHQUFHLENBQUNFLFFBQVEsQ0FBQ0UsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUdtSyxDQUFDLElBQUssSUFBSSxDQUFDLENBQUNHLGlCQUFpQixDQUFDSCxDQUFDLENBQUMsQ0FBQztJQUV6RmQscUVBQWlDLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQ2tCLGdCQUFnQixFQUFFLENBQUM7RUFDbkU7O0VBRUE7QUFDRjtBQUNBO0VBQ0VDLGVBQWUsQ0FBQ2hCLFlBQVksRUFBRTtJQUM1QixJQUFJLENBQUMsQ0FBQ0EsWUFBWSxHQUFHQSxZQUFZO0VBQ25DOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0VBQ0VpQixNQUFNLEdBQUc7SUFDUCxJQUFJLENBQUMsQ0FBQ2hCLE9BQU8sR0FBRyxJQUFJO0VBQ3RCO0VBRUFpQixPQUFPLEdBQUc7SUFDUixJQUFJLENBQUMsQ0FBQ2pCLE9BQU8sR0FBRyxLQUFLO0lBQ3JCLElBQUksQ0FBQyxDQUFDRixHQUFHLENBQUNvQixJQUFJLEVBQUU7RUFDbEI7RUFFQSxDQUFDUCxXQUFXLENBQUNELENBQUMsRUFBRTtJQUNkLE1BQU1TLFNBQVMsR0FBRyxFQUFFO0lBQ3BCLE1BQU1DLFNBQVMsR0FBR1YsQ0FBQyxDQUFDVyxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUNwQixhQUFhLENBQUNDLEtBQUs7SUFDdkQsTUFBTW9CLFNBQVMsR0FBR1osQ0FBQyxDQUFDYSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUN0QixhQUFhLENBQUNFLEtBQUs7SUFDdkQsSUFBSXFCLElBQUksQ0FBQ0MsR0FBRyxDQUFDTCxTQUFTLENBQUMsR0FBR0QsU0FBUyxJQUFJSyxJQUFJLENBQUNDLEdBQUcsQ0FBQ0gsU0FBUyxDQUFDLEdBQUdILFNBQVMsRUFBRTtNQUN0RSxJQUFJLENBQUMsQ0FBQ2xCLGFBQWEsQ0FBQ0csU0FBUyxHQUFHZ0IsU0FBUyxLQUFLLENBQUMsR0FBR0EsU0FBUyxHQUFHLENBQUMsR0FBR0UsU0FBUyxHQUFHLENBQUM7TUFDL0UsSUFBSSxDQUFDLENBQUNyQixhQUFhLENBQUNDLEtBQUssR0FBR1EsQ0FBQyxDQUFDVyxPQUFPO01BQ3JDLElBQUksQ0FBQyxDQUFDcEIsYUFBYSxDQUFDRSxLQUFLLEdBQUdPLENBQUMsQ0FBQ2EsT0FBTztJQUN2QztFQUNGO0VBRUEsQ0FBQ1gsU0FBUyxDQUFDRixDQUFDLEVBQUU7SUFDWixNQUFNZ0IsaUJBQWlCLEdBQUcsQ0FBQztJQUMzQixJQUFJaEIsQ0FBQyxDQUFDaUIsTUFBTSxLQUFLRCxpQkFBaUIsRUFBRTtNQUNsQyxJQUFJLENBQUMsQ0FBQ0UsSUFBSSxDQUFDbEIsQ0FBQyxDQUFDVyxPQUFPLEVBQUVYLENBQUMsQ0FBQ2EsT0FBTyxDQUFDO0lBQ2xDO0VBQ0Y7RUFFQSxDQUFDVixpQkFBaUIsQ0FBQ2dCLEVBQUUsRUFBRTtJQUNyQixJQUFJakMsb0RBQWdCLENBQUMsSUFBSSxDQUFDLENBQUN6SixHQUFHLENBQUMsQ0FBQzJMLFFBQVEsRUFBRSxLQUFLLEVBQUUsRUFBRTtNQUNqRCxJQUFJLENBQUMsQ0FBQ2hDLEdBQUcsQ0FBQ29CLElBQUksRUFBRTtJQUNsQjtFQUNGO0VBRUEsQ0FBQ0osZ0JBQWdCLEdBQUc7SUFDbEIsSUFBSSxDQUFDLENBQUNoQixHQUFHLENBQUNpQyxjQUFjLEVBQUU7SUFFMUIsSUFBSSxDQUFDbkMseURBQXFCLEVBQUU7TUFDMUIsSUFBSSxDQUFDLENBQUNFLEdBQUcsQ0FBQ29CLElBQUksRUFBRTtJQUNsQjtFQUNGO0VBRUEsQ0FBQ1UsSUFBSSxDQUFDSyxZQUFZLEVBQUVDLFlBQVksRUFBRTtJQUNoQztJQUNBO0lBQ0FDLFVBQVUsQ0FBQyxNQUFNO01BQ2YsTUFBTS9KLFNBQVMsR0FBR3dILG9EQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDekosR0FBRyxDQUFDO01BQzdDLE1BQU16QixhQUFhLEdBQUdrTCwyREFBdUIsQ0FBQ3hILFNBQVMsQ0FBQzBKLFFBQVEsRUFBRSxDQUFDO01BQ25FLElBQ0VsQyx5REFBcUIsSUFDckIsSUFBSSxDQUFDLENBQUNJLE9BQU8sSUFDYkosc0VBQWtDLENBQUNBLDhEQUEwQixDQUFDbEwsYUFBYSxDQUFDLENBQUMsRUFDN0U7UUFDQSxJQUFJQSxhQUFhLEtBQUssSUFBSSxDQUFDLENBQUNvTCxHQUFHLENBQUNzQyxTQUFTLENBQUMxTixhQUFhLElBQUksSUFBSSxDQUFDLENBQUNvTCxHQUFHLENBQUN1QyxRQUFRLEVBQUU7VUFDN0U7VUFDQTtVQUNBO1FBQ0Y7UUFFQSxJQUFJLENBQUMsQ0FBQ3ZDLEdBQUcsQ0FBQ3NDLFNBQVMsQ0FBQzFOLGFBQWEsR0FBR0EsYUFBYTtRQUNqRCxJQUFJLENBQUMsQ0FBQ29MLEdBQUcsQ0FBQ3NDLFNBQVMsQ0FBQ3JDLFlBQVksR0FBRyxJQUFJLENBQUMsQ0FBQ0EsWUFBWTtRQUVyRCxNQUFNdUMsVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDeEMsR0FBRyxDQUFDOEIsSUFBSSxFQUFFO1FBRW5DLE1BQU1XLFVBQVUsR0FBRyxDQUFDLE1BQU07VUFDeEIsTUFBTUMsMkJBQTJCLEdBQUcsRUFBRTtVQUN0QyxNQUFNQyxVQUFVLEdBQUc3Qyw4REFBMEI7VUFDekM7VUFDQTtVQUNBNEMsMkJBQTJCLEdBQUdGLFVBQVUsQ0FBQ0ssS0FBSyxHQUFHLENBQUM7VUFDbEQ7VUFDQUwsVUFBVSxDQUFDSyxLQUFLLEdBQUcsR0FBRztVQUUxQixNQUFNdkMsU0FBUyxHQUFHLElBQUksQ0FBQyxDQUFDTCxZQUFZLEdBQ2hDLElBQUksQ0FBQyxDQUFDQSxZQUFZLENBQUM2QyxrQkFBa0IsS0FBSyxVQUFVLEdBQ3BELElBQUksQ0FBQyxDQUFDM0MsYUFBYSxDQUFDRyxTQUFTO1VBRWpDLE9BQU82QixZQUFZLEdBQUdLLFVBQVUsQ0FBQ0ssS0FBSyxHQUFHLENBQUMsSUFBSXZDLFNBQVMsR0FBR3FDLFVBQVUsR0FBRyxDQUFDQSxVQUFVLENBQUM7UUFDckYsQ0FBQyxHQUFHO1FBRUosTUFBTUksU0FBUyxHQUFHLENBQUMsTUFBTTtVQUN2QixJQUFJLENBQUNqRCw4REFBMEIsSUFBSSxJQUFJLENBQUMsQ0FBQ0csWUFBWSxFQUFFO1lBQ3JELE9BQU9tQyxZQUFZLEdBQUdJLFVBQVUsQ0FBQ1EsTUFBTSxHQUFHLENBQUM7VUFDN0MsQ0FBQyxNQUFNO1lBQ0wsTUFBTUMsbUJBQW1CLEdBQUczSyxTQUFTLENBQUNHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3lLLHFCQUFxQixFQUFFO1lBQzNFLE1BQU1DLE1BQU0sR0FBRyxDQUFDO1lBQ2hCLE9BQU9mLFlBQVksR0FBR2EsbUJBQW1CLENBQUNHLEdBQUcsR0FBR0gsbUJBQW1CLENBQUNELE1BQU0sR0FBRyxDQUFDLEdBQzFFQyxtQkFBbUIsQ0FBQ0csR0FBRyxHQUFHWixVQUFVLENBQUNRLE1BQU0sR0FBR0csTUFBTSxHQUNwREYsbUJBQW1CLENBQUNJLE1BQU0sR0FBR0YsTUFBTTtVQUN6QztRQUNGLENBQUMsR0FBRztRQUVKLElBQUksQ0FBQyxDQUFDbkQsR0FBRyxDQUFDc0QsV0FBVyxDQUFDYixVQUFVLEVBQUVNLFNBQVMsQ0FBQztNQUM5QyxDQUFDLE1BQU07UUFDTCxJQUFJLENBQUMsQ0FBQy9DLEdBQUcsQ0FBQ29CLElBQUksRUFBRTtNQUNsQjtJQUNGLENBQUMsQ0FBQztFQUNKO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsTUFBTVYsWUFBWSxDQUFDO0VBQ2pCLE9BQU8sQ0FBQzZDLFVBQVUsR0FBRztJQUNuQixDQUFDLEVBQUUsb0JBQW9CO0lBQ3ZCLENBQUMsRUFBRSxtQkFBbUI7SUFDdEIsQ0FBQyxFQUFFLGdCQUFnQjtJQUNuQixDQUFDLEVBQUUsbUJBQW1CO0lBQ3RCLENBQUMsRUFBRTtFQUNMLENBQUM7RUFFRCxDQUFDbE4sR0FBRztFQUVKLENBQUNtTixRQUFRO0VBQ1QsQ0FBQ0MsUUFBUSxHQUFHLENBQUMsQ0FBQztFQUNkLENBQUNDLElBQUksR0FBRyxDQUFDLENBQUM7O0VBRVY7QUFDRjtBQUNBO0VBQ0VwQixTQUFTLEdBQUcsSUFBSyxNQUFNcUIsU0FBUyxDQUFDO0lBQy9CLENBQUNDLEtBQUs7SUFDTmhQLGFBQWEsR0FBRyxFQUFFO0lBQ2xCLENBQUNpUCxhQUFhO0lBQ2QvRyxXQUFXLENBQUM4RyxLQUFLLEVBQUU7TUFDakIsSUFBSSxDQUFDLENBQUNBLEtBQUssR0FBR0EsS0FBSztJQUNyQjtJQUNBLElBQUkzRCxZQUFZLENBQUNsQyxLQUFLLEVBQUU7TUFDdEIsSUFBSSxDQUFDLENBQUM4RixhQUFhLEdBQUc5RixLQUFLO01BQzNCLElBQUksSUFBSSxDQUFDLENBQUM4RixhQUFhLEVBQUU7UUFDdkIsSUFBSSxDQUFDLENBQUNELEtBQUssQ0FBQyxDQUFDSixRQUFRLENBQUNNLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDLGNBQWMsQ0FBQztNQUNyRCxDQUFDLE1BQU07UUFDTCxJQUFJLENBQUMsQ0FBQ0gsS0FBSyxDQUFDLENBQUNKLFFBQVEsQ0FBQ00sU0FBUyxDQUFDRSxNQUFNLENBQUMsY0FBYyxDQUFDO01BQ3hEO0lBQ0Y7SUFDQSxJQUFJL0QsWUFBWSxHQUFHO01BQ2pCLE9BQU8sSUFBSSxDQUFDLENBQUM0RCxhQUFhO0lBQzVCO0lBQ0FJLE1BQU0sR0FBRztNQUNQLElBQUksQ0FBQ3JQLGFBQWEsR0FBRyxFQUFFO01BQ3ZCLElBQUksQ0FBQ3FMLFlBQVksR0FBRzlKLFNBQVM7SUFDL0I7RUFDRixDQUFDLENBQUUsSUFBSSxDQUFDO0VBRVIsQ0FBQytOLFNBQVMsR0FBRyxLQUFLO0VBQ2xCLElBQUkzQixRQUFRLENBQUN4RSxLQUFLLEVBQUU7SUFDbEI7SUFDQTtJQUNBLElBQUksQ0FBQyxDQUFDbUcsU0FBUyxHQUFHbkcsS0FBSztJQUN2QixJQUFJLElBQUksQ0FBQyxDQUFDbUcsU0FBUyxFQUFFO01BQ25CN0IsVUFBVSxDQUFDLE1BQU8sSUFBSSxDQUFDLENBQUM2QixTQUFTLEdBQUcsS0FBTSxDQUFDO0lBQzdDO0VBQ0Y7RUFDQSxJQUFJM0IsUUFBUSxHQUFHO0lBQ2IsT0FBTyxJQUFJLENBQUMsQ0FBQzJCLFNBQVM7RUFDeEI7RUFFQXBILFdBQVcsQ0FBQ3pHLEdBQUcsRUFBRWtLLHFCQUFxQixFQUFFQyxvQkFBb0IsRUFBRUMsc0JBQXNCLEVBQUU7SUFDcEYsSUFBSSxDQUFDLENBQUNwSyxHQUFHLEdBQUdBLEdBQUc7SUFDZixJQUFJLENBQUMsQ0FBQzJELE1BQU0sQ0FBQ3VHLHFCQUFxQixFQUFFQyxvQkFBb0IsRUFBRUMsc0JBQXNCLENBQUM7RUFDbkY7RUFFQSxDQUFDekcsTUFBTSxDQUFDdUcscUJBQXFCLEVBQUVDLG9CQUFvQixFQUFFQyxzQkFBc0IsRUFBRTtJQUMzRTtJQUNBO0lBQ0E7SUFDQSxJQUFJLENBQUMsQ0FBQytDLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQ25OLEdBQUcsQ0FBQ0UsUUFBUSxDQUFDNE4sYUFBYSxDQUFDLEtBQUssQ0FBQztJQUN4RCxJQUFJLENBQUMsQ0FBQ1gsUUFBUSxDQUFDTSxTQUFTLENBQUNDLEdBQUcsQ0FBQyxVQUFVLEVBQUUsZ0JBQWdCLENBQUM7O0lBRTFEO0lBQ0E7SUFDQTtJQUNBLE1BQU1LLFlBQVksR0FBRyxDQUFDQyxXQUFXLEVBQUVDLFVBQVUsRUFBRUMsa0JBQWtCLEtBQUs7TUFDcEUsTUFBTTFDLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQzJCLFFBQVEsQ0FBQ2dCLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQ25PLEdBQUcsQ0FBQ0UsUUFBUSxDQUFDNE4sYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO01BQ2xGdEMsTUFBTSxDQUFDaUMsU0FBUyxDQUFDQyxHQUFHLENBQUNNLFdBQVcsQ0FBQztNQUNqQ3hDLE1BQU0sQ0FBQ3BMLGdCQUFnQixDQUFDLE9BQU8sRUFBRThOLGtCQUFrQixDQUFDO01BQ3BELE1BQU1FLEtBQUssR0FBRzVDLE1BQU0sQ0FBQzJDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQ25PLEdBQUcsQ0FBQ0UsUUFBUSxDQUFDNE4sYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO01BQ3ZFTSxLQUFLLENBQUNYLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDTyxVQUFVLENBQUM7SUFDakMsQ0FBQztJQUVERixZQUFZLENBQUMsbUJBQW1CLEVBQUUsaUJBQWlCLEVBQUd4RCxDQUFDLElBQUs7TUFDMUQsSUFBSSxDQUFDMkIsUUFBUSxHQUFHLElBQUk7TUFDcEJoQyxxQkFBcUIsQ0FBQ0ssQ0FBQyxDQUFDO0lBQzFCLENBQUMsQ0FBQztJQUVGd0QsWUFBWSxDQUFDLGtCQUFrQixFQUFFLGdCQUFnQixFQUFHeEQsQ0FBQyxJQUFLO01BQ3hELElBQUksQ0FBQzJCLFFBQVEsR0FBRyxJQUFJO01BQ3BCL0Isb0JBQW9CLENBQUNJLENBQUMsRUFBRSxJQUFJLENBQUMwQixTQUFTLENBQUNyQyxZQUFZLENBQUM7SUFDdEQsQ0FBQyxDQUFDO0lBRUZtRSxZQUFZLENBQUMsb0JBQW9CLEVBQUUsa0JBQWtCLEVBQUd4RCxDQUFDLElBQUs7TUFDNUQsSUFBSSxDQUFDMkIsUUFBUSxHQUFHLElBQUk7TUFDcEI5QixzQkFBc0IsQ0FBQ0csQ0FBQyxDQUFDO0lBQzNCLENBQUMsQ0FBQzs7SUFFRjtJQUNBO0lBQ0E7SUFDQSxJQUFJLENBQUMsQ0FBQzRDLFFBQVEsQ0FBQ2tCLFlBQVksQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDO0lBRWhELE1BQU1DLFNBQVMsR0FBRyxnQkFBZ0I7SUFDbEMsSUFBSSxDQUFDLENBQUN0TyxHQUFHLENBQUNFLFFBQVEsQ0FBQ29LLGVBQWUsQ0FBQ2xLLGdCQUFnQixDQUFDLFVBQVUsRUFBR21LLENBQUMsSUFBSztNQUNyRSxJQUFJQSxDQUFDLENBQUNnRSxZQUFZLENBQUNDLEtBQUssQ0FBQy9NLFFBQVEsQ0FBQzZNLFNBQVMsQ0FBQyxFQUFFO1FBQzVDL0QsQ0FBQyxDQUFDa0UsY0FBYyxFQUFFO01BQ3BCO0lBQ0YsQ0FBQyxDQUFDO0lBRUYsSUFBSSxDQUFDLENBQUN0QixRQUFRLENBQUMvTSxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUdtSyxDQUFDLElBQUs7TUFDbERBLENBQUMsQ0FBQ2dFLFlBQVksQ0FBQ0csT0FBTyxDQUFDSixTQUFTLEVBQUUsRUFBRSxDQUFDO01BQ3JDL0QsQ0FBQyxDQUFDZ0UsWUFBWSxDQUFDSSxhQUFhLEdBQUcsTUFBTTtNQUVyQyxNQUFNeEMsVUFBVSxHQUFHLElBQUksQ0FBQyxDQUFDZ0IsUUFBUSxDQUFDTixxQkFBcUIsRUFBRTtNQUN6RCxJQUFJLENBQUMsQ0FBQ1EsSUFBSSxDQUFDdUIsT0FBTyxHQUFHekMsVUFBVSxDQUFDMEMsSUFBSSxHQUFHdEUsQ0FBQyxDQUFDVyxPQUFPO01BQ2hELElBQUksQ0FBQyxDQUFDbUMsSUFBSSxDQUFDeUIsT0FBTyxHQUFHM0MsVUFBVSxDQUFDWSxHQUFHLEdBQUd4QyxDQUFDLENBQUNhLE9BQU87SUFDakQsQ0FBQyxDQUFDO0lBRUYsSUFBSSxDQUFDLENBQUMrQixRQUFRLENBQUMvTSxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUdtSyxDQUFDLElBQUs7TUFDaEQsTUFBTTZCLFVBQVUsR0FBRzdCLENBQUMsQ0FBQ1csT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDbUMsSUFBSSxDQUFDdUIsT0FBTztNQUNqRCxNQUFNbEMsU0FBUyxHQUFHbkMsQ0FBQyxDQUFDYSxPQUFPLEdBQUcsSUFBSSxDQUFDLENBQUNpQyxJQUFJLENBQUN5QixPQUFPO01BQ2hELElBQUksQ0FBQzdCLFdBQVcsQ0FBQ2IsVUFBVSxFQUFFTSxTQUFTLENBQUM7SUFDekMsQ0FBQyxDQUFDOztJQUVGO0lBQ0E7SUFDQTtJQUNBLElBQUksQ0FBQ2QsY0FBYyxFQUFFO0VBQ3ZCOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFSCxJQUFJLEdBQUc7SUFDTCxNQUFNc0QsWUFBWSxHQUFHLENBQUMsSUFBSTtJQUMxQixJQUFJLENBQUMsQ0FBQzVCLFFBQVEsQ0FBQzZCLEtBQUssQ0FBQ0gsSUFBSSxHQUFHRSxZQUFZLEdBQUcsSUFBSTtJQUMvQyxJQUFJLENBQUMsQ0FBQzVCLFFBQVEsQ0FBQzZCLEtBQUssQ0FBQ2pDLEdBQUcsR0FBR2dDLFlBQVksR0FBRyxJQUFJO0lBQzlDLElBQUksQ0FBQyxDQUFDL08sR0FBRyxDQUFDRSxRQUFRLENBQUMrTyxJQUFJLENBQUNkLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQ2hCLFFBQVEsQ0FBQzs7SUFFbkQ7SUFDQTtJQUNBLE1BQU1oQixVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUNnQixRQUFRLENBQUNOLHFCQUFxQixFQUFFO0lBQ3pELElBQUksQ0FBQyxDQUFDTyxRQUFRLENBQUN3QixPQUFPLEdBQUdHLFlBQVksSUFBSTVDLFVBQVUsQ0FBQzBDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQzdPLEdBQUcsQ0FBQ2tQLE9BQU8sQ0FBQztJQUM3RSxJQUFJLENBQUMsQ0FBQzlCLFFBQVEsQ0FBQzBCLE9BQU8sR0FBR0MsWUFBWSxJQUFJNUMsVUFBVSxDQUFDWSxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMvTSxHQUFHLENBQUNtUCxPQUFPLENBQUM7SUFFNUUsT0FBT2hELFVBQVU7RUFDbkI7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VjLFdBQVcsQ0FBQ2IsVUFBVSxFQUFFTSxTQUFTLEVBQUU7SUFDakM7SUFDQSxNQUFNO01BQUVGLEtBQUs7TUFBRUc7SUFBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUNRLFFBQVEsQ0FBQ04scUJBQXFCLEVBQUU7SUFDaEUsTUFBTXVDLE9BQU8sR0FBRyxJQUFJLENBQUMsQ0FBQ3BQLEdBQUcsQ0FBQ3FQLFVBQVUsR0FBRzdDLEtBQUs7SUFDNUMsTUFBTThDLE1BQU0sR0FBRyxJQUFJLENBQUMsQ0FBQ3RQLEdBQUcsQ0FBQ3VQLFdBQVcsR0FBRzVDLE1BQU07SUFDN0MsTUFBTTZDLG1CQUFtQixHQUFHbkUsSUFBSSxDQUFDb0UsR0FBRyxDQUFDLENBQUMsRUFBRXBFLElBQUksQ0FBQ3FFLEdBQUcsQ0FBQ04sT0FBTyxFQUFFaEQsVUFBVSxDQUFDLENBQUM7SUFDdEUsTUFBTXVELGtCQUFrQixHQUFHdEUsSUFBSSxDQUFDb0UsR0FBRyxDQUFDLENBQUMsRUFBRXBFLElBQUksQ0FBQ3FFLEdBQUcsQ0FBQ0osTUFBTSxFQUFFNUMsU0FBUyxDQUFDLENBQUM7O0lBRW5FO0lBQ0E7SUFDQSxNQUFNbUMsSUFBSSxHQUFHVyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsQ0FBQ3hQLEdBQUcsQ0FBQ2tQLE9BQU8sR0FBRyxJQUFJLENBQUMsQ0FBQzlCLFFBQVEsQ0FBQ3dCLE9BQU87SUFDN0UsTUFBTTdCLEdBQUcsR0FBRzRDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxDQUFDM1AsR0FBRyxDQUFDbVAsT0FBTyxHQUFHLElBQUksQ0FBQyxDQUFDL0IsUUFBUSxDQUFDMEIsT0FBTztJQUUzRSxJQUFJLENBQUMsQ0FBQzNCLFFBQVEsQ0FBQzZCLEtBQUssQ0FBQ0gsSUFBSSxHQUFHQSxJQUFJLEdBQUcsSUFBSTtJQUN2QyxJQUFJLENBQUMsQ0FBQzFCLFFBQVEsQ0FBQzZCLEtBQUssQ0FBQ2pDLEdBQUcsR0FBR0EsR0FBRyxHQUFHLElBQUk7RUFDdkM7RUFFQW5CLGNBQWMsR0FBRztJQUNmLElBQUksQ0FBQyxDQUFDdUIsUUFBUSxDQUFDNkIsS0FBSyxDQUFDWSxRQUFRLEdBQUd2RixZQUFZLENBQUMsQ0FBQzZDLFVBQVUsQ0FBQ3pELHdEQUFvQixDQUFDO0lBRTlFLElBQUlBLDZEQUF5QixFQUFFO01BQzdCLElBQUksQ0FBQyxDQUFDMEQsUUFBUSxDQUFDTSxTQUFTLENBQUNDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQztJQUN6RCxDQUFDLE1BQU07TUFDTCxJQUFJLENBQUMsQ0FBQ1AsUUFBUSxDQUFDTSxTQUFTLENBQUNFLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQztJQUM1RDtFQUNGO0VBRUE1QyxJQUFJLEdBQUc7SUFDTCxJQUFJLElBQUksQ0FBQyxDQUFDb0MsUUFBUSxDQUFDNEMsV0FBVyxFQUFFO01BQzlCLElBQUksQ0FBQyxDQUFDNUMsUUFBUSxDQUFDNkMsVUFBVSxDQUFDQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM5QyxRQUFRLENBQUM7TUFDckQsSUFBSSxDQUFDbEIsU0FBUyxDQUFDMkIsTUFBTSxFQUFFO0lBQ3pCO0VBQ0Y7QUFDRjs7Ozs7Ozs7Ozs7Ozs7OztBQ2hWbUM7O0FBRW5DO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTXNDLGdCQUFnQixDQUFDO0VBQzVCLENBQUNuTixJQUFJO0VBRUwsQ0FBQ1csTUFBTSxHQUFHO0lBQ1J5RSxJQUFJLEVBQUUsRUFBRTtJQUNSZ0ksV0FBVyxFQUFFLEtBQUs7SUFDbEJDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUNuQkMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3RCQyxTQUFTLEVBQUUsTUFBTSxDQUFDO0VBQ3BCLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0VBQ0U3SixXQUFXLENBQUMvQyxNQUFNLEVBQUU7SUFDbEIsSUFBSSxDQUFDLENBQUNBLE1BQU0sR0FBRytGLG1EQUFlLENBQUMsSUFBSSxDQUFDLENBQUMvRixNQUFNLEVBQUVBLE1BQU0sQ0FBQztFQUN0RDtFQUVBNk0sT0FBTyxHQUFHO0lBQ1IsSUFBSSxJQUFJLENBQUMsQ0FBQ3hOLElBQUksRUFBRTtNQUNkMEcsbURBQWUsQ0FBQyxtQkFBbUIsRUFBRTtRQUFFMUcsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDQTtNQUFLLENBQUMsQ0FBQztNQUMxRDtJQUNGO0lBRUEsSUFBSTtNQUNGLElBQUksQ0FBQyxDQUFDQSxJQUFJLEdBQUdwQixNQUFNLENBQUMwRCxPQUFPLENBQUNrTCxPQUFPLENBQUN6USxTQUFTLEVBQUU7UUFBRXFJLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQ3pFLE1BQU0sQ0FBQ3lFO01BQUssQ0FBQyxDQUFDO0lBQzdFLENBQUMsQ0FBQyxPQUFPbEYsS0FBSyxFQUFFO01BQ2Q7TUFDQTtNQUNBd0csbURBQWUsQ0FDYixtSEFBbUgsRUFDbkg7UUFBRXhHO01BQU0sQ0FBQyxDQUNWO01BQ0Q7SUFDRjtJQUNBd0csb0RBQWdCLENBQUMsd0NBQXdDLEVBQUU7TUFBRTFHLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQ0E7SUFBSyxDQUFDLENBQUM7SUFFaEYsSUFBSSxDQUFDLENBQUNBLElBQUksQ0FBQ3NOLFlBQVksQ0FBQ3ZILFdBQVcsQ0FBRS9GLElBQUksSUFBSyxJQUFJLENBQUMsQ0FBQ3NOLFlBQVksQ0FBQ3ROLElBQUksQ0FBQyxDQUFDO0lBQ3ZFLElBQUksQ0FBQyxDQUFDQSxJQUFJLENBQUN1TixTQUFTLENBQUN4SCxXQUFXLENBQUMsQ0FBQzlGLE9BQU8sRUFBRUQsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDdU4sU0FBUyxDQUFDdE4sT0FBTyxFQUFFRCxJQUFJLENBQUMsQ0FBQztJQUVuRixJQUFJLENBQUMsQ0FBQ1csTUFBTSxDQUFDME0sU0FBUyxFQUFFO0VBQzFCO0VBRUFJLFVBQVUsR0FBRztJQUNYLElBQUksSUFBSSxDQUFDLENBQUN6TixJQUFJLEVBQUU7TUFDZCxJQUFJLENBQUMsQ0FBQ0EsSUFBSSxDQUFDeU4sVUFBVSxFQUFFO01BQ3ZCLElBQUksQ0FBQyxDQUFDek4sSUFBSSxHQUFHakQsU0FBUztNQUN0QjJKLG9EQUFnQixDQUFDLDZDQUE2QyxDQUFDO0lBQ2pFO0VBQ0Y7RUFFQWdILFNBQVMsR0FBRztJQUNWLElBQUksQ0FBQ0QsVUFBVSxFQUFFO0lBQ2pCLElBQUksQ0FBQ0QsT0FBTyxFQUFFO0VBQ2hCOztFQUVBO0FBQ0Y7QUFDQTtFQUNFLElBQUl4TixJQUFJLEdBQUc7SUFDVCxPQUFPLElBQUksQ0FBQyxDQUFDQSxJQUFJO0VBQ25COztFQUVBO0FBQ0Y7QUFDQTtFQUNFRCxXQUFXLENBQUNFLE9BQU8sRUFBRTtJQUNuQixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMwTixlQUFlLEVBQUUsRUFBRTtNQUM1QjtJQUNGO0lBRUFqSCxtREFBZSxDQUFDLElBQUksQ0FBQyxDQUFDMUcsSUFBSSxFQUFFQyxPQUFPLENBQUM7RUFDdEM7RUFFQSxDQUFDME4sZUFBZSxHQUFHO0lBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzNOLElBQUksRUFBRTtNQUNmLElBQUksSUFBSSxDQUFDLENBQUNXLE1BQU0sQ0FBQ3lNLFdBQVcsRUFBRTtRQUM1QixJQUFJLENBQUNJLE9BQU8sRUFBRTtNQUNoQixDQUFDLE1BQU07UUFDTDlHLG1EQUFlLENBQUMsOEZBQThGLENBQUM7TUFDakg7SUFDRjtJQUNBLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDMUcsSUFBSTtFQUNyQjtFQUVBLENBQUNzTixZQUFZLENBQUN0TixJQUFJLEVBQUU7SUFDbEIwRyx1REFBbUIsQ0FBQyxnQkFBZ0IsRUFBRTtNQUFFMUc7SUFBSyxDQUFDLENBQUM7SUFFL0MsSUFBSSxDQUFDLENBQUNBLElBQUksR0FBR2pELFNBQVM7SUFDdEIySixvREFBZ0IsQ0FBQyxvRUFBb0UsQ0FBQztJQUV0RixJQUFJLENBQUMsQ0FBQy9GLE1BQU0sQ0FBQzJNLFlBQVksRUFBRTtFQUM3QjtFQUVBLENBQUNDLFNBQVMsQ0FBQ3ROLE9BQU8sRUFBRUQsSUFBSSxFQUFFO0lBQ3hCMEcsdURBQW1CLENBQUMsYUFBYSxFQUFFO01BQUV6RyxPQUFPO01BQUVEO0lBQUssQ0FBQyxDQUFDO0lBRXJELElBQUksQ0FBQyxDQUFDVyxNQUFNLENBQUM0TSxTQUFTLENBQUN0TixPQUFPLENBQUM7RUFDakM7QUFDRjs7Ozs7O1VDekdBO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7O1dDdEJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7Ozs7Ozs7Ozs7Ozs7O0FDTmE7O0FBRThCO0FBQ3dCO0FBQ2Y7QUFFcEQsQ0FBQyxlQUFlMk4sSUFBSSxHQUFHO0VBQ3JCO0VBQ0E7RUFDQTs7RUFFQSxNQUFNbEgsb0RBQVEsQ0FBQ0EsZ0VBQW9CLENBQUM7RUFFcEMsSUFBSXZKLFFBQVEsQ0FBQzBRLFdBQVcsS0FBSyxXQUFXLElBQUksQ0FBQzFRLFFBQVEsQ0FBQytPLElBQUksRUFBRTtJQUMxRDtJQUNBeEYsMkRBQWUsQ0FBQyw0REFBNEQsRUFBRTtNQUM1RW1ILFdBQVcsRUFBRTFRLFFBQVEsQ0FBQzBRLFdBQVc7TUFDakMzQixJQUFJLEVBQUUvTyxRQUFRLENBQUMrTztJQUNqQixDQUFDLENBQUM7SUFDRjtFQUNGOztFQUVBO0VBQ0E7RUFDQTs7RUFFQSxNQUFNNEIsc0JBQXNCLEdBQUcsaUJBQWlCOztFQUVoRDtFQUNBLE1BQU1DLGNBQWMsR0FBRyxDQUNyQjtJQUFFQyxlQUFlLEVBQUUsbUNBQW1DO0lBQWNDLFNBQVMsRUFBRSxHQUFHO0lBQUVDLGlCQUFpQixFQUFFO0VBQXFDLENBQUMsRUFDN0k7SUFBRUYsZUFBZSxFQUFFLHVDQUF1QztJQUFVQyxTQUFTLEVBQUUsR0FBRztJQUFFQyxpQkFBaUIsRUFBRTtFQUFxQyxDQUFDLEVBQzdJO0lBQUVGLGVBQWUsRUFBRSxtQkFBbUI7SUFBOEJDLFNBQVMsRUFBRSxHQUFHO0lBQUVDLGlCQUFpQixFQUFFO0VBQXFDLENBQUMsRUFDN0k7SUFBRUYsZUFBZSxFQUFFLCtDQUErQztJQUFFQyxTQUFTLEVBQUUsR0FBRztJQUFFQyxpQkFBaUIsRUFBRTtFQUFxQyxDQUFDLEVBQzdJO0lBQUVGLGVBQWUsRUFBRSxnQ0FBZ0M7SUFBaUJDLFNBQVMsRUFBRSxHQUFHO0lBQUVDLGlCQUFpQixFQUFFO0VBQXFDLENBQUMsRUFDN0k7SUFBRUYsZUFBZSxFQUFFLG9CQUFvQjtJQUE2QkMsU0FBUyxFQUFFLEdBQUc7SUFBRUMsaUJBQWlCLEVBQUU7RUFBcUMsQ0FBQyxDQUM5STtFQUVELE1BQU1DLGdCQUFnQixHQUFHO0lBQ3ZCLENBQUN6SCxtRUFBdUIsR0FBRzBILFNBQVM7SUFDcEMsQ0FBQzFILHNFQUEwQixHQUFHMkg7RUFDaEMsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7O0VBRUEsTUFBTUMsU0FBUyxHQUFHO0lBQ2hCdk0sS0FBSyxFQUFFd00sR0FBRztJQUNWQyxPQUFPLEVBQUVELEdBQUc7SUFDWkUsVUFBVSxDQUFDMU0sS0FBSyxFQUFFeU0sT0FBTyxFQUFFO01BQ3pCLElBQUksQ0FBQ3pNLEtBQUssR0FBR0EsS0FBSztNQUNsQixJQUFJLENBQUN5TSxPQUFPLEdBQUdBLE9BQU87SUFDeEIsQ0FBQztJQUNERSxhQUFhLEdBQUc7TUFDZCxPQUFPQyxNQUFNLENBQUNDLFNBQVMsQ0FBQyxJQUFJLENBQUM3TSxLQUFLLENBQUMsSUFBSTRNLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDLElBQUksQ0FBQ0osT0FBTyxDQUFDO0lBQ3ZFLENBQUM7SUFDRDVGLFFBQVEsR0FBRztNQUNULE9BQU8sSUFBSSxDQUFDOEYsYUFBYSxFQUFFLEdBQUcsSUFBSSxDQUFDM00sS0FBSyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUN5TSxPQUFPLEdBQUcsR0FBRztJQUNyRTtFQUNGLENBQUM7RUFFRCxNQUFNSyxnQkFBZ0IsR0FBRyxJQUFJMUIsNEVBQWdCLENBQUM7SUFDNUMvSCxJQUFJLEVBQUUsQ0FBQzBKLE1BQU0sS0FBS0EsTUFBTSxDQUFDQyxNQUFNLEdBQUcsRUFBRSxHQUFHLGFBQWEsSUFBSTVSLFFBQVEsQ0FBQzZSLEdBQUc7SUFDcEU1QixXQUFXLEVBQUUsSUFBSTtJQUNqQkMsU0FBUyxFQUFFNEIseUJBQXlCO0lBQ3BDM0IsWUFBWSxFQUFFNEIsNEJBQTRCO0lBQzFDM0IsU0FBUyxFQUFFNEI7RUFDYixDQUFDLENBQUM7RUFFRixNQUFNckcsU0FBUyxHQUFHLElBQUluQyw2REFBUyxDQUFDbUksTUFBTSxFQUFFTSxzQkFBc0IsRUFBRUMscUJBQXFCLEVBQUVDLHVCQUF1QixDQUFDO0VBRS9HLElBQUlDLHlCQUF5Qjs7RUFFN0I7RUFDQTtFQUNBOztFQUVBVixnQkFBZ0IsQ0FBQ3JCLE9BQU8sRUFBRTtFQUUxQjVPLE1BQU0sQ0FBQzBELE9BQU8sQ0FBQytLLFNBQVMsQ0FBQ3RILFdBQVcsQ0FBQ3NILFNBQVMsQ0FBQztFQUUvQ3lCLE1BQU0sQ0FBQ3pSLGdCQUFnQixDQUFDLE9BQU8sRUFBRW1TLGFBQWEsQ0FBQztFQUMvQ1YsTUFBTSxDQUFDelIsZ0JBQWdCLENBQUMsTUFBTSxFQUFFb1MsWUFBWSxDQUFDO0VBQzdDdFMsUUFBUSxDQUFDRSxnQkFBZ0IsQ0FBQyxpQkFBaUIsRUFBRXNLLGlCQUFpQixDQUFDO0VBRS9ELE1BQU0rSCxRQUFRLEdBQUcsSUFBSUMsZ0JBQWdCLENBQUNDLFVBQVUsQ0FBQztFQUNqREYsUUFBUSxDQUFDRyxPQUFPLENBQUMxUyxRQUFRLENBQUNvSyxlQUFlLEVBQUU7SUFBRXVJLE9BQU8sRUFBRSxJQUFJO0lBQUVDLFNBQVMsRUFBRTtFQUFLLENBQUMsQ0FBQztFQUM5RSxLQUFLLE1BQU1DLElBQUksSUFBSTdTLFFBQVEsQ0FBQ1MsZ0JBQWdCLENBQUNrUSxzQkFBc0IsQ0FBQyxFQUFFO0lBQ3BFbUMsOEJBQThCLENBQUNELElBQUksQ0FBQztFQUN0Qzs7RUFFQTtFQUNBO0VBQ0E7O0VBRUEsU0FBU2YseUJBQXlCLEdBQUc7SUFDbkNKLGdCQUFnQixDQUFDOU8sV0FBVyxDQUFDO01BQUVtUSxJQUFJLEVBQUV4SixpRUFBcUIvTDtJQUFDLENBQUMsQ0FBQztJQUU3RG1PLFNBQVMsQ0FBQ2hCLE1BQU0sRUFBRTtFQUNwQjtFQUVBLFNBQVNvSCw0QkFBNEIsR0FBRztJQUN0Q3BHLFNBQVMsQ0FBQ2YsT0FBTyxFQUFFO0VBQ3JCO0VBRUEsU0FBU29ILHlCQUF5QixDQUFDbFAsT0FBTyxFQUFFO0lBQzFDa08sZ0JBQWdCLENBQUNsTyxPQUFPLENBQUNpUSxJQUFJLENBQUMsQ0FBQ2pRLE9BQU8sRUFBRTRPLGdCQUFnQixDQUFDN08sSUFBSSxDQUFDO0VBQ2hFO0VBRUEsU0FBU3FOLFNBQVMsQ0FBQ3JOLElBQUksRUFBRTtJQUN2QjBHLCtEQUFtQixDQUFDLGFBQWEsRUFBRTtNQUFFMUc7SUFBSyxDQUFDLENBQUM7SUFFNUNBLElBQUksQ0FBQ3VOLFNBQVMsQ0FBQ3hILFdBQVcsQ0FBQ3dILFNBQVMsQ0FBQztFQUN2QztFQUVBLFNBQVNBLFNBQVMsQ0FBQ3ROLE9BQU8sRUFBRUQsSUFBSSxFQUFFO0lBQ2hDMEcsK0RBQW1CLENBQUMsYUFBYSxFQUFFO01BQUV6RyxPQUFPO01BQUVEO0lBQUssQ0FBQyxDQUFDO0lBRXJEbU8sZ0JBQWdCLENBQUNsTyxPQUFPLENBQUNpUSxJQUFJLENBQUMsQ0FBQ2pRLE9BQU8sRUFBRUQsSUFBSSxDQUFDO0VBQy9DO0VBRUEsU0FBU29PLFNBQVMsQ0FBQ25PLE9BQU8sRUFBRWtRLEtBQUssRUFBRTtJQUNqQzdCLFNBQVMsQ0FBQ0csVUFBVSxDQUFDeE8sT0FBTyxDQUFDbVEsUUFBUSxDQUFDL1AsR0FBRyxDQUFDakMsRUFBRSxFQUFFNkIsT0FBTyxDQUFDbVEsUUFBUSxDQUFDNUIsT0FBTyxDQUFDO0lBQ3ZFOUgsNERBQWdCLENBQUM0SCxTQUFTLENBQUMxRixRQUFRLEVBQUUsQ0FBQztJQUN0Q2xDLDREQUFnQixDQUFDLDJCQUEyQixFQUFFO01BQUU0SDtJQUFVLENBQUMsQ0FBQztJQUM1RCtCLHNCQUFzQixDQUFDLHNCQUFzQixDQUFDO0VBQ2hEO0VBRUEsU0FBU2hDLFdBQVcsQ0FBQ2lDLFFBQVEsRUFBRUgsS0FBSyxFQUFFO0lBQ3BDLElBQUksQ0FBQ1oseUJBQXlCLEVBQUU7TUFDOUI3SSwyREFBZSxDQUFFLFVBQVNBLHNFQUEyQiw0Q0FBMkMsQ0FBQztNQUNqRztJQUNGO0lBQ0E2Siw0QkFBNEIsQ0FBQ2hCLHlCQUF5QixDQUFDO0VBQ3pEOztFQUVBO0VBQ0E7RUFDQTs7RUFFQSxTQUFTQyxhQUFhLENBQUM3RyxFQUFFLEVBQUU7SUFDekI7SUFDQWtHLGdCQUFnQixDQUFDbkIsU0FBUyxFQUFFO0lBRTVCMkMsc0JBQXNCLENBQUMsY0FBYyxDQUFDO0VBQ3hDO0VBRUEsU0FBU1osWUFBWSxDQUFDOUcsRUFBRSxFQUFFO0lBQ3hCMEgsc0JBQXNCLENBQUMsYUFBYSxDQUFDO0VBQ3ZDO0VBRUEsU0FBUzFJLGlCQUFpQixDQUFDZ0IsRUFBRSxFQUFFO0lBQzdCMEgsc0JBQXNCLENBQUMsMEJBQTBCLENBQUM7RUFDcEQ7RUFFQSxTQUFTVCxVQUFVLENBQUNZLFlBQVksRUFBRUMsU0FBUyxFQUFFO0lBQzNDLEtBQUssTUFBTUMsUUFBUSxJQUFJRixZQUFZLEVBQUU7TUFDbkMsSUFBSUUsUUFBUSxDQUFDUixJQUFJLEtBQUssV0FBVyxFQUFFO1FBQ2pDLEtBQUssTUFBTUYsSUFBSSxJQUFJVSxRQUFRLENBQUNDLFVBQVUsRUFBRTtVQUN0QyxJQUFJWCxJQUFJLENBQUNoRCxXQUFXLElBQUlnRCxJQUFJLFlBQVl2USxPQUFPLEVBQUU7WUFDL0MsSUFBSXVRLElBQUksQ0FBQ1ksT0FBTyxDQUFDOUMsc0JBQXNCLENBQUMsRUFBRTtjQUN4Q3BILDJEQUFlLENBQUMsOEJBQThCLEVBQUU7Z0JBQUVzSjtjQUFLLENBQUMsQ0FBQztjQUN6REMsOEJBQThCLENBQUNELElBQUksQ0FBQztZQUN0QztZQUNBLEtBQUssTUFBTWEsY0FBYyxJQUFJYixJQUFJLENBQUNwUyxnQkFBZ0IsQ0FBQ2tRLHNCQUFzQixDQUFDLEVBQUU7Y0FDMUVwSCwyREFBZSxDQUFDLDhCQUE4QixFQUFFO2dCQUFFbUs7Y0FBZSxDQUFDLENBQUM7Y0FDbkVaLDhCQUE4QixDQUFDWSxjQUFjLENBQUM7WUFDaEQ7VUFDRjtRQUNGO01BQ0Y7SUFDRjtFQUNGO0VBRUEsU0FBU1osOEJBQThCLENBQUNwSixZQUFZLEVBQUU7SUFDcEQsSUFBSSxPQUFPQSxZQUFZLENBQUNpSyxjQUFjLEtBQUssUUFBUSxFQUFFO01BQ25EO01BQ0E7TUFDQTtJQUNGO0lBRUEsSUFBSWpLLFlBQVksQ0FBQytKLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRTtNQUNsQ0csK0JBQStCLENBQUNsSyxZQUFZLEVBQUUsa0JBQWtCLENBQUM7SUFDbkU7SUFFQUEsWUFBWSxDQUFDeEosZ0JBQWdCLENBQUMsT0FBTyxFQUFHc0wsRUFBRSxJQUFLO01BQzdDb0ksK0JBQStCLENBQUNsSyxZQUFZLEVBQUUsZ0JBQWdCLENBQUM7SUFDakUsQ0FBQyxDQUFDO0lBRUZBLFlBQVksQ0FBQ3hKLGdCQUFnQixDQUFDLE1BQU0sRUFBR3NMLEVBQUUsSUFBSztNQUM1QyxJQUFJeEwsUUFBUSxDQUFDNlQsYUFBYSxLQUFLbkssWUFBWSxJQUFJMEkseUJBQXlCLEtBQUsxSSxZQUFZLEVBQUU7UUFDekZrSywrQkFBK0IsQ0FBQ2hVLFNBQVMsRUFBRSxlQUFlLENBQUM7TUFDN0Q7SUFDRixDQUFDLENBQUM7SUFFRjhKLFlBQVksQ0FBQ3hKLGdCQUFnQixDQUFDLFFBQVEsRUFBR3NMLEVBQUUsSUFBSztNQUM5Q29JLCtCQUErQixDQUFDbEssWUFBWSxFQUFFLGlCQUFpQixDQUFDO0lBQ2xFLENBQUMsQ0FBQztJQUVGQSxZQUFZLENBQUN4SixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUdtSyxDQUFDLElBQUs7TUFDOUMsSUFDRWQsb0VBQXdCLElBQ3hCYyxDQUFDLENBQUM5QyxHQUFHLEtBQUssR0FBRyxJQUNiOEMsQ0FBQyxDQUFDMEosVUFBVSxJQUNaLENBQUMxSixDQUFDLENBQUMySixXQUFXLElBQ2QsQ0FBQzNKLENBQUMsQ0FBQ2hFLE9BQU8sSUFDVixDQUFDZ0UsQ0FBQyxDQUFDNEosTUFBTSxJQUNULENBQUM1SixDQUFDLENBQUM3RCxPQUFPLElBQ1YsQ0FBQzZELENBQUMsQ0FBQzZKLE1BQU0sRUFDVDtRQUNBLElBQUlkLDRCQUE0QixDQUFDMUosWUFBWSxDQUFDLEVBQUU7VUFDOUNXLENBQUMsQ0FBQ2tFLGNBQWMsRUFBRTtRQUNwQjtNQUNGO0lBQ0YsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7RUFDQTtFQUNBOztFQUVBLFNBQVMwRCxzQkFBc0IsQ0FBQzVILENBQUMsRUFBRTtJQUNqQ3FILGdCQUFnQixDQUFDOU8sV0FBVyxDQUFDO01BQzNCbVEsSUFBSSxFQUFFeEosNEVBQWdDO01BQ3RDbkYsUUFBUSxFQUFFLElBQUltRixzRUFBMEIsQ0FBQ2MsQ0FBQyxDQUFDaEUsT0FBTyxFQUFFZ0UsQ0FBQyxDQUFDL0QsUUFBUSxFQUFFK0QsQ0FBQyxDQUFDN0QsT0FBTyxDQUFDO01BQzFFbkksYUFBYSxFQUFFa0wsbUVBQXVCLENBQUNBLDREQUFnQixDQUFDb0ksTUFBTSxDQUFDLENBQUNsRyxRQUFRLEVBQUU7SUFDNUUsQ0FBQyxDQUFDO0VBQ0o7RUFFQSxTQUFTeUcscUJBQXFCLENBQUMxRyxFQUFFLEVBQUU5QixZQUFZLEVBQUU7SUFDL0M7SUFDQTtJQUNBO0lBQ0EsSUFBSSxDQUFDQSxZQUFZLEVBQUU7TUFDakI7SUFDRjtJQUNBMEosNEJBQTRCLENBQUMxSixZQUFZLENBQUM7RUFDNUM7RUFFQSxTQUFTeUksdUJBQXVCLENBQUM5SCxDQUFDLEVBQUU7SUFDbENxSCxnQkFBZ0IsQ0FBQzlPLFdBQVcsQ0FBQztNQUMzQm1RLElBQUksRUFBRXhKLDZFQUFpQztNQUN2Q25GLFFBQVEsRUFBRSxJQUFJbUYsc0VBQTBCLENBQUNjLENBQUMsQ0FBQ2hFLE9BQU8sRUFBRWdFLENBQUMsQ0FBQy9ELFFBQVEsRUFBRStELENBQUMsQ0FBQzdELE9BQU8sQ0FBQztNQUMxRXpCLG9CQUFvQixFQUFFd0UsNEVBQWdDNUM7SUFDeEQsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7RUFDQTtFQUNBOztFQUVBLFNBQVNpTiwrQkFBK0IsQ0FBQ2xLLFlBQVksRUFBRXlLLE1BQU0sRUFBRTtJQUM3RC9CLHlCQUF5QixHQUN2QjFJLFlBQVksSUFDWkEsWUFBWSxDQUFDK0osT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUM5QixDQUFDL0osWUFBWSxDQUFDMEssUUFBUSxJQUN0QixDQUFDMUssWUFBWSxDQUFDMkssUUFBUSxJQUN0QjNLLFlBQVksQ0FBQ2xDLEtBQUssQ0FBQzhNLFNBQVMsQ0FBQzVLLFlBQVksQ0FBQ2lLLGNBQWMsRUFBRWpLLFlBQVksQ0FBQzZLLFlBQVksQ0FBQyxLQUNsRmhMLDREQUFnQixDQUFDb0ksTUFBTSxDQUFDLENBQUNsRyxRQUFRLEVBQUUsR0FDakMvQixZQUFZLEdBQ1o5SixTQUFTO0lBRWYySiw0REFBZ0IsQ0FBQyxrQ0FBa0MsRUFBRTtNQUNuRDRLLE1BQU07TUFDTkssUUFBUSxFQUFFLENBQUMsQ0FBQ3BDLHlCQUF5QjtNQUNyQ3RULElBQUksRUFBRXNULHlCQUF5QixHQUFHN0ksbUVBQXVCLENBQUM2SSx5QkFBeUIsQ0FBQzVLLEtBQUssQ0FBQyxHQUFHLEtBQUs7TUFDbEdtTSxjQUFjLEVBQUV2Qix5QkFBeUIsR0FBR0EseUJBQXlCLENBQUN1QixjQUFjLEdBQUcsS0FBSztNQUM1RnBILGtCQUFrQixFQUFFNkYseUJBQXlCLEdBQUdBLHlCQUF5QixDQUFDN0Ysa0JBQWtCLEdBQUcsS0FBSztNQUNwRzZGO0lBQ0YsQ0FBQyxDQUFDO0lBRUZ6RyxTQUFTLENBQUNqQixlQUFlLENBQUMwSCx5QkFBeUIsQ0FBQztJQUVwRGMsc0JBQXNCLENBQUNpQixNQUFNLENBQUM7RUFDaEM7RUFFQSxTQUFTakIsc0JBQXNCLENBQUNpQixNQUFNLEVBQUU7SUFDdEMsTUFBTU0sSUFBSSxHQUFHTixNQUFNLENBQUNPLFFBQVEsQ0FBQyxPQUFPLENBQUM7SUFDckMsSUFBSXZELFNBQVMsQ0FBQ0ksYUFBYSxFQUFFLEtBQUtrRCxJQUFJLElBQUl6VSxRQUFRLENBQUMyVSxRQUFRLEVBQUUsQ0FBQyxFQUFFO01BQzlELE1BQU03UixPQUFPLEdBQUc7UUFDZGlRLElBQUksRUFBRXhKLG9GQUF3QztRQUM5QzRLLE1BQU0sRUFBRUEsTUFBTTtRQUNkcFMsU0FBUyxFQUFFO1VBQ1RqRCxJQUFJLEVBQUV5SyxtRUFBdUIsQ0FBQ0EsNERBQWdCLENBQUNvSSxNQUFNLENBQUMsQ0FBQ2xHLFFBQVEsRUFBRSxDQUFDO1VBQ2xFK0ksUUFBUSxFQUFFLENBQUMsQ0FBQ3BDLHlCQUF5QjtVQUNyQ3dDLFVBQVUsRUFBRUMsWUFBWSxDQUFDekMseUJBQXlCLENBQUM7VUFDbkRxQyxJQUFJLEVBQUVBO1FBQ1I7TUFDRixDQUFDO01BQ0QvQyxnQkFBZ0IsQ0FBQzlPLFdBQVcsQ0FBQ0UsT0FBTyxDQUFDO01BQ3JDeUcsMkRBQWUsQ0FBRSxTQUFRekcsT0FBTyxDQUFDaVEsSUFBSyx3Q0FBdUMsRUFBRTtRQUFFalE7TUFBUSxDQUFDLENBQUM7SUFDN0Y7RUFDRjtFQUVBLFNBQVNzUSw0QkFBNEIsQ0FBQzFKLFlBQVksRUFBRTtJQUNsRCxJQUFJQSxZQUFZLENBQUMwSyxRQUFRLElBQUkxSyxZQUFZLENBQUMySyxRQUFRLEVBQUU7TUFDbEQ5SywyREFBZSxDQUFFLFVBQVNBLHNFQUEyQixxREFBb0QsRUFBRTtRQUN6RzZLLFFBQVEsRUFBRTFLLFlBQVksQ0FBQzBLLFFBQVE7UUFDL0JDLFFBQVEsRUFBRTNLLFlBQVksQ0FBQzJLO01BQ3pCLENBQUMsQ0FBQztNQUNGLE9BQU8sS0FBSztJQUNkO0lBRUEsTUFBTWhXLGFBQWEsR0FBR2tMLG1FQUF1QixDQUMzQ0csWUFBWSxDQUFDbEMsS0FBSyxDQUFDOE0sU0FBUyxDQUFDNUssWUFBWSxDQUFDaUssY0FBYyxFQUFFakssWUFBWSxDQUFDNkssWUFBWSxDQUFDLENBQ3JGO0lBQ0QsTUFBTTNWLHVCQUF1QixHQUFHMkssc0VBQTBCLENBQUNsTCxhQUFhLENBQUM7SUFDekUsSUFBSSxDQUFDa0wsOEVBQWtDLENBQUMzSyx1QkFBdUIsQ0FBQyxFQUFFO01BQ2hFMkssMkRBQWUsQ0FBRSxVQUFTQSxzRUFBMkIsMkNBQTBDLEVBQUU7UUFDL0ZsTDtNQUNGLENBQUMsQ0FBQztNQUNGLE9BQU8sS0FBSztJQUNkO0lBRUF5VyxvQkFBb0IsQ0FBQ3BMLFlBQVksRUFBRUgseURBQWEsQ0FBQzNLLHVCQUF1QixDQUFDLENBQUM7SUFFMUUsSUFBSTJLLGlFQUFxQixJQUFJc0wsWUFBWSxDQUFDbkwsWUFBWSxDQUFDLEVBQUU7TUFDdkQsSUFBSUgsZ0VBQW9CLEVBQUU7UUFDeEJvSSxNQUFNLENBQUNzRCxTQUFTLENBQUNDLFNBQVMsQ0FBQ0MsU0FBUyxDQUFDdlcsdUJBQXVCLENBQUM7TUFDL0Q7TUFDQThLLFlBQVksQ0FBQzBMLElBQUksQ0FBQ0MsTUFBTSxFQUFFO0lBQzVCO0lBRUEsT0FBTyxJQUFJO0VBQ2I7RUFFQSxTQUFTUCxvQkFBb0IsQ0FBQ3BMLFlBQVksRUFBRTRMLFdBQVcsRUFBRTtJQUN2RC9MLDZEQUFpQixDQUNmK0wsV0FBVyxDQUFDaFgsTUFBTSxJQUFJLENBQUMsSUFBSWdYLFdBQVcsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSUQsV0FBVyxDQUFDQyxNQUFNLENBQUNELFdBQVcsQ0FBQ2hYLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQzlHLDhDQUE4QyxFQUM5QztNQUFFZ1g7SUFBWSxDQUFDLENBQ2hCO0lBRUQsTUFBTUUsWUFBWSxHQUFHLElBQUk7SUFFekIsTUFBTTFXLElBQUksR0FBRzRLLFlBQVksQ0FBQ2xDLEtBQUs7SUFDL0IsSUFBSWlPLGlCQUFpQixHQUFHL0wsWUFBWSxDQUFDaUssY0FBYztJQUNuRCxJQUFJK0IsZUFBZSxHQUFHaE0sWUFBWSxDQUFDNkssWUFBWTtJQUMvQyxJQUNFa0IsaUJBQWlCLEdBQUcsQ0FBQyxJQUNyQmxNLHdFQUE0QixDQUFDekssSUFBSSxDQUFDeVcsTUFBTSxDQUFDRSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUNoRSxDQUFDRCxZQUFZLENBQUNHLElBQUksQ0FBQzdXLElBQUksQ0FBQ3lXLE1BQU0sQ0FBQ0UsaUJBQWlCLENBQUMsQ0FBQyxFQUNsRDtNQUNBQSxpQkFBaUIsRUFBRTtJQUNyQjtJQUNBLElBQ0VDLGVBQWUsR0FBRzVXLElBQUksQ0FBQ1IsTUFBTSxJQUM3QmlMLHdFQUE0QixDQUFDekssSUFBSSxDQUFDeVcsTUFBTSxDQUFDRyxlQUFlLENBQUMsQ0FBQyxJQUMxRCxDQUFDRixZQUFZLENBQUNHLElBQUksQ0FBQzdXLElBQUksQ0FBQ3lXLE1BQU0sQ0FBQ0csZUFBZSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQ3BEO01BQ0FBLGVBQWUsRUFBRTtJQUNuQjtJQUVBLElBQUlFLGVBQWUsR0FBR04sV0FBVztJQUNqQyxJQUFJTyxtQkFBbUIsR0FBRyxDQUFDO0lBQzNCLElBQUlDLGlCQUFpQixHQUFHLENBQUMsQ0FBQztJQUMxQixJQUFJTCxpQkFBaUIsR0FBRyxDQUFDLElBQUksQ0FBQ0QsWUFBWSxDQUFDRyxJQUFJLENBQUM3VyxJQUFJLENBQUN5VyxNQUFNLENBQUNFLGlCQUFpQixHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFDbkZHLGVBQWUsR0FBRyxHQUFHLEdBQUdBLGVBQWU7TUFDdkNDLG1CQUFtQixFQUFFO0lBQ3ZCO0lBQ0EsSUFBSUgsZUFBZSxHQUFHNVcsSUFBSSxDQUFDUixNQUFNLElBQUksQ0FBQ2tYLFlBQVksQ0FBQ0csSUFBSSxDQUFDN1csSUFBSSxDQUFDeVcsTUFBTSxDQUFDRyxlQUFlLENBQUMsQ0FBQyxFQUFFO01BQ3JGRSxlQUFlLEdBQUdBLGVBQWUsR0FBRyxHQUFHO01BQ3ZDRSxpQkFBaUIsRUFBRTtJQUNyQjtJQUVBLE1BQU1DLGlCQUFpQixHQUFHTixpQkFBaUIsR0FBR0ksbUJBQW1CO0lBQ2pFLE1BQU1HLGVBQWUsR0FBR1AsaUJBQWlCLEdBQUdHLGVBQWUsQ0FBQ3RYLE1BQU0sR0FBR3dYLGlCQUFpQjtJQUV0RnBNLFlBQVksQ0FBQ3VNLEtBQUssRUFBRTtJQUNwQjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQXZNLFlBQVksQ0FBQ2xDLEtBQUssR0FBRzFJLElBQUksQ0FBQ3dWLFNBQVMsQ0FBQyxDQUFDLEVBQUVtQixpQkFBaUIsQ0FBQyxHQUFHRyxlQUFlLEdBQUc5VyxJQUFJLENBQUN3VixTQUFTLENBQUNvQixlQUFlLENBQUM7SUFDN0c7SUFDQWhNLFlBQVksQ0FBQ3dNLGlCQUFpQixDQUFDSCxpQkFBaUIsRUFBRUMsZUFBZSxFQUFFdE0sWUFBWSxDQUFDNkMsa0JBQWtCLENBQUM7RUFDckc7RUFFQSxTQUFTc0ksWUFBWSxDQUFDbkwsWUFBWSxFQUFFO0lBQ2xDLElBQUksQ0FBQ0EsWUFBWSxFQUFFO01BQ2pCLE9BQU8sS0FBSztJQUNkO0lBQ0FBLFlBQVksQ0FBQ0gsR0FBRyxLQUFLLENBQUMsQ0FBQztJQUN2QixJQUFJLENBQUNoSyxNQUFNLENBQUM4SixNQUFNLENBQUNLLFlBQVksQ0FBQ0gsR0FBRyxFQUFFLGNBQWMsQ0FBQyxFQUFFO01BQ3BERyxZQUFZLENBQUNILEdBQUcsQ0FBQ3NMLFlBQVksR0FBRyxDQUFDLE1BQU07UUFDckMsSUFBSW5MLFlBQVksWUFBWXlNLGdCQUFnQixFQUFFO1VBQzVDLEtBQUssTUFBTUMsWUFBWSxJQUFJeEYsY0FBYyxFQUFFO1lBQ3pDLElBQ0V3RixZQUFZLENBQUN2RixlQUFlLENBQUM4RSxJQUFJLENBQUNoRSxNQUFNLENBQUMwRSxRQUFRLENBQUNDLFFBQVEsQ0FBQyxJQUMzREYsWUFBWSxDQUFDdEYsU0FBUyxLQUFLcEgsWUFBWSxDQUFDekIsSUFBSSxJQUM1Q21PLFlBQVksQ0FBQ3JGLGlCQUFpQixDQUFDNEUsSUFBSSxDQUFDak0sWUFBWSxDQUFDMEwsSUFBSSxFQUFFbUIsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQzlFO2NBQ0EsT0FBTyxJQUFJO1lBQ2I7VUFDRjtRQUNGO1FBQ0EsT0FBTyxLQUFLO01BQ2QsQ0FBQyxHQUFHO0lBQ047SUFDQSxPQUFPN00sWUFBWSxDQUFDSCxHQUFHLENBQUNzTCxZQUFZO0VBQ3RDO0FBQ0YsQ0FBQyxHQUFHLEM7Ozs7Ozs7Ozs7QUNwWkoiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19fY29uZmlnLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19jb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vbW9kdWxlcy9fX2Z1bmN0aW9ucy5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19fZ2xvYmFscy5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19faG93X3RvX29wZW5fbGluay5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19fbG9nZ2VyLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19vcHRpb25zLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvY29tbW9uLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvcG9wdXBfaWNvbi5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL3BvcnRfdG9fYmFja2dyb3VuZC5qcyIsIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovLy93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vLy4vY29udGVudC5qcyIsIndlYnBhY2s6Ly8vLi9jb250ZW50LnNjc3M/NGY3YSJdLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9IHsgY29uZmlnOiB7XCJsb2dFbmFibGVkXCI6dHJ1ZSxcInByaXZhdGVPcHRpb25FbmFibGVkXCI6dHJ1ZSxcImlzTWFjXCI6ZmFsc2V9IH07IiwiLyoqXG4gKiBTY3JpcHQgaWQuXG4gKi9cbmV4cG9ydCBjb25zdCBTY3JpcHRJZCA9IHtcbiAgQUNUSU9OOiBcIkFDVElPTlwiLFxuICBCQUNLR1JPVU5EOiBcIkJBQ0tHUk9VTkRcIixcbiAgQ09OVEVOVDogXCItXCIsXG4gIE9QVElPTlM6IFwiT1BUSU9OU1wiLFxufTtcblxuLyoqXG4gKiBDb21tYW5kIElEcyBmb3Iga2V5Ym9hcmQgc2hvcnRjdXRzIGFuZCBjb250ZXh0IG1lbnVzLlxuICovXG5leHBvcnQgY29uc3QgQ29tbWFuZFR5cGUgPSB7XG4gIERPX1FVT1RFRF9TRUFSQ0g6IFwiZG9fcXVvdGVkX3NlYXJjaFwiLFxuICBQVVRfUVVPVEVTOiBcInB1dF9xdW90ZXNcIixcbn07XG5cbi8qKlxuICogTWVzc2FnZSB0eXBlcy5cbiAqL1xuZXhwb3J0IGNvbnN0IE1lc3NhZ2VUeXBlID0ge1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ29udGVudCBzY3JpcHRzIC0tPiBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBIRUxMTzogXCJoZWxsb1wiLFxuICBOT1RJRllfU0VMRUNUSU9OX1VQREFURUQ6IFwibm90aWZ5X3NlbGVjdGlvbl91cGRhdGVkXCIsXG4gIERPX1FVT1RFRF9TRUFSQ0g6IFwiZG9fcXVvdGVkX3NlYXJjaFwiLFxuICBPUEVOX09QVElPTlNfUEFHRTogXCJvcGVuX29wdGlvbnNfcGFnZVwiLFxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBDb250ZW50IHNjcmlwdHMgPC0tIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIFdFTENPTUU6IFwid2VsY29tZVwiLFxuICBQVVRfUVVPVEVTOiBcInB1dF9xdW90ZXNcIixcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQWN0aW9uIHNjcmlwdHMgLS0+IEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIEdFVF9TRUxFQ1RJT046IFwiZ2V0X3NlbGVjdGlvblwiLFxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBBY3Rpb24gc2NyaXB0cyA8LS0gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlclxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgTk9USUZZX1NFTEVDVElPTjogXCJub3RpZnlfc2VsZWN0aW9uXCIsXG59O1xuXG4vKipcbiAqIFZhcmlvdXMgZG91YmxlIHF1b3Rlcy5cbiAqXG4gKiBJZiB5b3Ugc3Vycm91bmQgeW91ciBzZWFyY2ggcGhyYXNlIHdpdGggY2hhcmFjdGVycyBpbiB0aGlzIHN0cmluZywgR29vZ2xlXG4gKiBTZWFyY2ggd2lsbCBnaXZlIHlvdSBhbiBleGFjdCBtYXRjaC4gSW4gb3RoZXIgd29yZHMsIHRoZXNlIGFyZSB0aGUgY2hhcmFjdGVyc1xuICogdGhhdCBHb29nbGUgU2VhcmNoIHJlY29nbml6ZXMgYXMgdmFsaWQgZG91YmxlIHF1b3RlcyBmb3IgYW4gZXhhY3QgbWF0Y2guXG4gKlxuICogVGV4dCBjb250YWluaW5nIGRvdWJsZSBxdW90ZXMgY2Fubm90IGJlIGVuY2xvc2VkIGluIGRvdWJsZSBxdW90ZXMsIHNvIHRob3NlXG4gKiBjaGFyYWN0ZXJzIG11c3QgYmUgcmVtb3ZlZCBpZiB0aGV5IGFyZSBpbmNsdWRlZCBpbiB0aGUgc2VsZWN0ZWQgdGV4dCB3aGVuXG4gKiBzZWFyY2hpbmcgZm9yIGFuIGV4YWN0IG1hdGNoLlxuICovXG5leHBvcnQgY29uc3QgUVVPVEFUSU9OX01BUktTID0gXCJcXHUwMDIyXFx1MjAxY1xcdTIwMWRcXHUyMDFlXFx1MjAxZlxcdTIwMzNcXHUzMDFkXFx1MzAxZVxcdTMwMWZcXHVmZjAyXCI7IC8vIFwi4oCc4oCd4oCe4oCf4oCz44Cd44Ce44Cf77yCXG5cbi8qKlxuICogVGhlIG1heGltdW0gbGVuZ3RoIG9mIHRoZSBzZWxlY3RlZCB0ZXh0IHRvIGJlIHByb2Nlc3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IFNFTEVDVElPTl9URVhUX01BWF9MRU5HVEggPSAxMDI0O1xuXG4vKipcbiAqIEluZGljYXRlcyB0aGF0IHRoZSBsZW5ndGggb2YgdGhlIHNlbGVjdGVkIHRleHQgZXhjZWVkcyB0aGUgbGltaXQuXG4gKlxuICogQSB2ZXJ5IGxhcmdlIHRleHQgbWF5IGJlIHNlbGVjdGVkLCBpbiB3aGljaCBjYXNlIHRoaXMgc3RyaW5nIGlzIHByZXNlcnZlZFxuICogaW5zdGVhZCBvZiB0aGUgb3JpZ2luYWwgc3RyaW5nIGFzIHRoZSBzZWxlY3RlZCB0ZXh0IHRvIGF2b2lkIHdhc3RpbmcgbWVtb3J5XG4gKiBhbmQgbWFraW5nIGxvZ3Mgbm9pc3kuXG4gKi9cbmV4cG9ydCBjb25zdCBTRUxFQ1RJT05fVEVYVF9UT09fTE9OR19NQVJLRVIgPSBcIiMjIyBUb28gTG9uZyEgIyMjIHlvQmp2XkY3JXNnI05NeENycXZZS01nRDg1c1JYUmlHXCI7XG4iLCJpbXBvcnQgeyBTRUxFQ1RJT05fVEVYVF9NQVhfTEVOR1RILCBTRUxFQ1RJT05fVEVYVF9UT09fTE9OR19NQVJLRVIsIFFVT1RBVElPTl9NQVJLUyB9IGZyb20gXCIuL19fY29uc3RhbnRzLmpzXCI7XG5pbXBvcnQgeyBsb2dnZXIsIG9wdGlvbnMgfSBmcm9tIFwiLi9fX2dsb2JhbHMuanNcIjtcbmltcG9ydCB7IEhvd1RvT3BlbkxpbmsgfSBmcm9tIFwiLi9fX2hvd190b19vcGVuX2xpbmsuanNcIjtcblxuLyoqXG4gKiBGaWx0ZXJzIHRoZSBzZWxlY3RlZCB0ZXh0IG9idGFpbmVkIGZyb20gZXh0ZXJuYWwgc291cmNlcy5cbiAqXG4gKiBGb3Igc2VjdXJpdHkgcHVycG9zZXMsIGJlIHN1cmUgdG8gcGFzcyB0aGUgc2VsZWN0ZWQgdGV4dCBvYnRhaW5lZCBmcm9tXG4gKiBleHRlcm5hbCBzb3VyY2VzIHRocm91Z2ggdGhpcyBmaWx0ZXIgYmVmb3JlIHVzaW5nIGl0LlxuICpcbiAqIEBwYXJhbSB7P3N0cmluZ30gc2VsZWN0aW9uVGV4dFxuICogQHJldHVybnMgeyFzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJTZWxlY3Rpb25UZXh0KHNlbGVjdGlvblRleHQpIHtcbiAgc2VsZWN0aW9uVGV4dCA/Pz0gXCJcIjtcbiAgcmV0dXJuIHNlbGVjdGlvblRleHQubGVuZ3RoID4gU0VMRUNUSU9OX1RFWFRfTUFYX0xFTkdUSCA/IFNFTEVDVElPTl9URVhUX1RPT19MT05HX01BUktFUiA6IHNlbGVjdGlvblRleHQ7XG59XG5cbi8qKlxuICogTm9ybWFsaXplcyB0aGUgc2VsZWN0ZWQgdGV4dC5cbiAqXG4gKiBUaGUgbm9ybWFsaXphdGlvbiBpbmNsdWRlczpcbiAqXG4gKiAtIFJlcGxhY2UgZG91YmxlIHF1b3RlcyB3aXRoIGEgc3BhY2UuXG4gKiAtIENvbGxhcHNlIGNvbnNlY3V0aXZlIHdoaXRlc3BhY2UgY2hhcmFjdGVycyBpbnRvIHNpbmdsZSBzcGFjZS5cbiAqIC0gUmVtb3ZlIHdoaXRlc3BhY2UgZnJvbSBib3RoIGVuZHMgb2YgdGhlIHN0cmluZy5cbiAqXG4gKiBAcGFyYW0gez9zdHJpbmd9IHNlbGVjdGlvblRleHRcbiAqIEByZXR1cm5zIHshc3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplU2VsZWN0aW9uVGV4dChzZWxlY3Rpb25UZXh0KSB7XG4gIHNlbGVjdGlvblRleHQgPSBmaWx0ZXJTZWxlY3Rpb25UZXh0KHNlbGVjdGlvblRleHQpO1xuICByZXR1cm4gc2VsZWN0aW9uVGV4dCA9PT0gU0VMRUNUSU9OX1RFWFRfVE9PX0xPTkdfTUFSS0VSXG4gICAgPyBzZWxlY3Rpb25UZXh0XG4gICAgOiBzZWxlY3Rpb25UZXh0LnJlcGxhY2VBbGwobmV3IFJlZ0V4cChgW1xcXFxzJHtRVU9UQVRJT05fTUFSS1N9XStgLCBcImdcIiksIFwiIFwiKS50cmltKCk7XG59XG5cbi8qKlxuICogQ2hlY2tzIGlmIHRoZSBub3JtYWxpemVkIHNlbGVjdGlvbiB0ZXh0IGlzIHZhbGlkIGZvciBwcm9jZXNzaW5nLlxuICpcbiAqIEBwYXJhbSB7P3N0cmluZ30gbm9ybWFsaXplZFNlbGVjdGlvblRleHRcbiAqIEByZXR1cm5zIHshYm9vbGVhbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzTm9ybWFsaXplZFNlbGVjdGlvblRleHRWYWxpZChub3JtYWxpemVkU2VsZWN0aW9uVGV4dCkge1xuICBub3JtYWxpemVkU2VsZWN0aW9uVGV4dCA/Pz0gXCJcIjtcbiAgcmV0dXJuIChcbiAgICBub3JtYWxpemVkU2VsZWN0aW9uVGV4dCAhPT0gU0VMRUNUSU9OX1RFWFRfVE9PX0xPTkdfTUFSS0VSICYmXG4gICAgbm9ybWFsaXplZFNlbGVjdGlvblRleHQubGVuZ3RoID4gMCAmJlxuICAgIG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0Lmxlbmd0aCA8PSBTRUxFQ1RJT05fVEVYVF9NQVhfTEVOR1RIXG4gICk7XG59XG5cbi8qKlxuICogUHV0cyBkb3VibGUgcXVvdGVzIGFyb3VuZCB0aGUgc3RyaW5nLlxuICpcbiAqIEBwYXJhbSB7P3N0cmluZ30gdGV4dFxuICogQHJldHVybnMgeyFzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBxdW90ZVRleHQodGV4dCkge1xuICByZXR1cm4gJ1wiJyArICh0ZXh0ID8/IFwiXCIpICsgJ1wiJztcbn1cblxuLyoqXG4gKiBDbG9uZXMgYW4gb2JqZWN0IHRyZWF0ZWQgYXMgYSBEVE8uXG4gKlxuICogSWYgeW91IG5lZWQgcGFzcyBhbiBvYmplY3Qgd2hvc2UgY29udGVudHMgbWF5IGJlIGNoYW5nZWQgbGF0ZXIgdG8gYW5cbiAqIGFzeW5jaHJvbm91cyBtZXRob2QsIHBhc3MgYW4gb2JqZWN0IGNsb25lZCBieSB0aGlzIGZ1bmN0aW9uIGluc3RlYWQgb2YgdGhlXG4gKiBvcmlnaW4gb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7P29iamVjdH0gb2JqXG4gKiBAcmV0dXJucyB7IW9iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNsb25lRHRvKG9iaikge1xuICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShvYmogPz8ge30pKTtcbn1cblxuLyoqXG4gKiBNZXJnZXMgYHJoc2AgdG8gYGxoc2AsIGlnbm9yaW5nIHByb3BlcnRpZXMgd2l0aCBhIHZhbHVlIG9mIGB1bmRlZmluZWRgLlxuICpcbiAqIEBwYXJhbSB7P29iamVjdH0gdGFyZ2V0XG4gKiBAcGFyYW0gez9vYmplY3R9IHNvdXJjZVxuICogQHJldHVybnMgeyFvYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtZXJnZU9iamVjdCh0YXJnZXQsIHNvdXJjZSkge1xuICByZXR1cm4geyAuLi50YXJnZXQsIC4uLk9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhzb3VyY2UgPz8ge30pLmZpbHRlcigoWywgdl0pID0+IHYgIT09IHVuZGVmaW5lZCkpIH07XG59XG5cbi8qKlxuICogU2V0cyB1cCBhbiBldmVudCBsaXN0ZW5lciBmb3IgYERPTUNvbnRlbnRMb2FkZWRgIGV2ZW50LlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gY2hlY2tzIGBEb2N1bWVudC5yZWFkeVN0YXRlYCBhbmQgc2V0cyB1cCB0aGUgZXZlbnQgbGlzdGVuZXIgYXNcbiAqIGEgbWljcm90YXNrcyBpZiB0aGUgZXZlbnQgaGFzIGFscmVhZHkgYmVlbiBmaXJlZC5cbiAqXG4gKiBAcGFyYW0geyFXaW5kb3d9IHdpblxuICogQHBhcmFtIHshZnVuY3Rpb24oKTp2b2lkfSBsaXN0ZW5lclxuICovXG5leHBvcnQgZnVuY3Rpb24gYWRkRE9NQ29udGVudExvYWRlZEV2ZW50TGlzdGVuZXIod2luLCBsaXN0ZW5lcikge1xuICBpZiAod2luLmRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgd2luLmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsIGxpc3RlbmVyKTtcbiAgfSBlbHNlIHtcbiAgICBxdWV1ZU1pY3JvdGFzayhsaXN0ZW5lcik7XG4gIH1cbn1cblxuLyoqXG4gKiBTZXRzIHVwIGFuIGV2ZW50IGxpc3RlbmVyIGZvciBgbG9hZGAgZXZlbnQuXG4gKlxuICogVGhpcyBmdW5jdGlvbiBjaGVja3MgYERvY3VtZW50LnJlYWR5U3RhdGVgIGFuZCBzZXRzIHVwIHRoZSBldmVudCBsaXN0ZW5lciBhc1xuICogYSBtaWNyb3Rhc2tzIGlmIHRoZSBldmVudCBoYXMgYWxyZWFkeSBiZWVuIGZpcmVkLlxuICpcbiAqIEBwYXJhbSB7IVdpbmRvd30gd2luXG4gKiBAcGFyYW0geyFmdW5jdGlvbigpOnZvaWR9IGxpc3RlbmVyXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRMb2FkQ29tcGxldGVkRXZlbnRMaXN0ZW5lcih3aW4sIGxpc3RlbmVyKSB7XG4gIGlmICh3aW4uZG9jdW1lbnQucmVhZHlTdGF0ZSAhPT0gXCJjb21wbGV0ZVwiKSB7XG4gICAgd2luLmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsIGxpc3RlbmVyKTtcbiAgfSBlbHNlIHtcbiAgICBxdWV1ZU1pY3JvdGFzayhsaXN0ZW5lcik7XG4gIH1cbn1cblxuLyoqXG4gKiBJbmplY3RzIGxvY2FsaXplZCBzdHJpbmdzIGludG8gSFRNTCBkb2N1bWVudC5cbiAqXG4gKiBAcGFyYW0geyFEb2N1bWVudH0gZG9jXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbmplY3RJMThOTWVzc2FnZXNJbkh0bWwoZG9jKSB7XG4gIGNvbnN0IEkxOE5fVEFSR0VUUyA9IFtcIm91dGVySFRNTFwiLCBcImlubmVySFRNTFwiLCBcIm91dGVyVGV4dFwiLCBcImlubmVyVGV4dFwiLCBcInZhbHVlXCJdO1xuICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgZG9jLnF1ZXJ5U2VsZWN0b3JBbGwoXCJbZGF0YS1ncm91cH49J2kxOG4nXCIpKSB7XG4gICAgY29uc3Qgc3Vic3RpdHV0aW9ucyA9ICgoKSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgIGNvbnN0IGFyZ3MgPSBlbGVtZW50LmRhdGFzZXQuaTE4bkFyZ3M7XG4gICAgICBpZiAoIWFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGlkcyA9IGFyZ3Muc3BsaXQoXCIgXCIpO1xuICAgICAgZm9yIChjb25zdCBpZCBvZiBpZHMpIHtcbiAgICAgICAgY29uc3QgYXJnRWxlbWVudCA9IGRvYy5nZXRFbGVtZW50QnlJZChpZCk7XG4gICAgICAgIGNvbnN0IGFyZ1RhcmdldCA9IGFyZ0VsZW1lbnQuZGF0YXNldC5pMThuVGFyZ2V0O1xuICAgICAgICBsb2dnZXIuYXNzZXJ0KEkxOE5fVEFSR0VUUy5pbmNsdWRlcyhhcmdUYXJnZXQpLCBcIlVuZXhwZWN0ZWQgdGFyZ2V0XCIsIHsgYXJnVGFyZ2V0LCBhcmdFbGVtZW50IH0pO1xuICAgICAgICByZXN1bHQucHVzaChhcmdFbGVtZW50W2FyZ1RhcmdldF0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9KSgpO1xuICAgIGNvbnN0IHRhcmdldCA9IGVsZW1lbnQuZGF0YXNldC5pMThuVGFyZ2V0O1xuICAgIGxvZ2dlci5hc3NlcnQoSTE4Tl9UQVJHRVRTLmluY2x1ZGVzKHRhcmdldCksIFwiVW5leHBlY3RlZCB0YXJnZXRcIiwgeyB0YXJnZXQsIGVsZW1lbnQgfSk7XG4gICAgZWxlbWVudFt0YXJnZXRdID0gY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShlbGVtZW50LmRhdGFzZXQuaTE4bk5hbWUsIHN1YnN0aXR1dGlvbnMpO1xuICB9XG59XG5cbi8qKlxuICogR2V0cyBgU2VsZWN0aW9uYCBvYmplY3QuXG4gKlxuICogVGhpcyBmdW5jdGlvbiBub3Qgb25seSBjYWxscyBgV2luZG93LmdldFNlbGVjdGlvbigpYCwgYnV0IGFsc28gcmVjdXJzaXZlbHlcbiAqIHNlYXJjaGVzIHdpdGhpbiB0aGUgbmVzdGVkIFNoYWRvdyBET01zLlxuICpcbiAqIEBwYXJhbSB7IVdpbmRvd30gd2luXG4gKiBAcmV0dXJucyB7IVNlbGVjdGlvbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFNlbGVjdGlvbih3aW4pIHtcbiAgZnVuY3Rpb24gZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5KHNlbGVjdGlvbikge1xuICAgIGlmIChzZWxlY3Rpb24ucmFuZ2VDb3VudCA9PT0gMSkge1xuICAgICAgY29uc3QgcmFuZ2UgPSBzZWxlY3Rpb24uZ2V0UmFuZ2VBdCgwKTtcbiAgICAgIGlmIChyYW5nZS5zdGFydENvbnRhaW5lciA9PT0gcmFuZ2UuZW5kQ29udGFpbmVyKSB7XG4gICAgICAgIGNvbnN0IGNvbW1vbkFuY2VzdG9yQ29udGFpbmVyID0gcmFuZ2UuY29tbW9uQW5jZXN0b3JDb250YWluZXI7XG4gICAgICAgIGlmIChjb21tb25BbmNlc3RvckNvbnRhaW5lciBpbnN0YW5jZW9mIEVsZW1lbnQpIHtcbiAgICAgICAgICBpZiAoY29tbW9uQW5jZXN0b3JDb250YWluZXIuc2hhZG93Um9vdCkge1xuICAgICAgICAgICAgcmV0dXJuIGZpbmRTZWxlY3Rpb25SZWN1cnNpdmVseShjb21tb25BbmNlc3RvckNvbnRhaW5lci5zaGFkb3dSb290LmdldFNlbGVjdGlvbigpKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZWxlbWVudHNXaXRoU2hhZG93Um9vdCA9IEFycmF5LnByb3RvdHlwZS5maWx0ZXIuY2FsbChcbiAgICAgICAgICAgICAgY29tbW9uQW5jZXN0b3JDb250YWluZXIucXVlcnlTZWxlY3RvckFsbChcIipcIiksXG4gICAgICAgICAgICAgIChlbGVtZW50KSA9PiAhIWVsZW1lbnQuc2hhZG93Um9vdFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGlmIChlbGVtZW50c1dpdGhTaGFkb3dSb290Lmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICByZXR1cm4gZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5KGVsZW1lbnRzV2l0aFNoYWRvd1Jvb3RbMF0uc2hhZG93Um9vdC5nZXRTZWxlY3Rpb24oKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzZWxlY3Rpb247XG4gIH1cblxuICByZXR1cm4gZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5KHdpbi5nZXRTZWxlY3Rpb24oKSk7XG59XG5cbi8qKlxuICogQ2FsbHMgYGNocm9tZS5ydW50aW1lLlBvcnQucG9zdE1lc3NhZ2UoKWAgbWV0aG9kLlxuICpcbiAqIENhdGNoZXMgdGhlIGVycm9yIHRocm93biBmcm9tIGBjaHJvbWUucnVudGltZS5Qb3J0LnBvc3RNZXNzYWdlKClgIG1ldGhvZCBhbmRcbiAqIGxvZ3MgYSB3YXJuaW5nIG1lc3NhZ2UuXG4gKlxuICogYGNocm9tZS5ydW50aW1lLlBvcnQucG9zdE1lc3NhZ2UoKWAgdGhyb3dzIGFuIGVycm9yIGlmIHRoZSBvdGhlciBzaWRlIG9mIHRoZVxuICogcG9ydCBoYXMgYWxyZWFkeSBiZWVuIGNsb3NlZCwgYnV0IHRoZXJlIGlzIG5vIHdheSB0byBjaGVjayBpbiBhZHZhbmNlIHdoZXRoZXJcbiAqIHRoZSBwb3J0IGlzIHN0aWxsIG9wZW5lZCBvciBoYXMgYmVlbiBjbG9zZWQuXG4gKiBQb3J0IGRpc2Nvbm5lY3Rpb24gaXMgb25lIG9mIHRoZSBleHBlY3RlZCBjb25kaXRpb25zLCBldmVuIGluIGFuIGVkZ2UgY2FzZSxcbiAqIGFuZCBtb3N0IG9mIHRoZSB0aW1lIGl0IGlzIG5vdCBhbiBlcnJvciBjYXNlLlxuICogVGhlcmVmb3JlLCBpZiBhbiBlcnJvciBpcyB0aHJvd24gZnJvbSBgY2hyb21lLnJ1bnRpbWUuUG9ydC5wb3N0TWVzc2FnZSgpYFxuICogbWV0aG9kLCB0aGlzIGZ1bmN0aW9uIGFzc3VtZXMgdGhlIGNhdXNlIGlzIHBvcnQgZGlzY29ubmVjdGlvbiBhbmQgbG9ncyBpdCBhc1xuICogYSB3YXJuaW5nIGluc3RlYWQgb2YgYW4gZXJyb3IuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnJ1bnRpbWUuUG9ydH0gcG9ydFxuICogQHBhcmFtIHshKn0gbWVzc2FnZVxuICovXG5leHBvcnQgZnVuY3Rpb24gcG9zdE1lc3NhZ2UocG9ydCwgbWVzc2FnZSkge1xuICB0cnkge1xuICAgIHBvcnQucG9zdE1lc3NhZ2UobWVzc2FnZSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgbG9nZ2VyLndhcm4oXG4gICAgICBcIkl0IHNlZW1zIHRoYXQgdGhlIG1lc3NhZ2UgY291bGQgbm90IGJlIHNlbnQgYmVjYXVzZSB0aGUgb3RoZXIgc2lkZSBvZiB0aGUgcG9ydCBoYXMgYWxyZWFkeSBiZWVuIGNsb3NlZFwiLFxuICAgICAgeyBlcnJvciwgcG9ydCwgbWVzc2FnZSB9XG4gICAgKTtcbiAgfVxufVxuXG4vKipcbiAqIEdldHMgdGhlIGFjdGl2ZSB0YWIuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHJldHVybnMgeyFQcm9taXNlPCFjaHJvbWUudGFicy5UYWI+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWN0aXZlVGFiKCkge1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICByZXR1cm4gdGFiO1xufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgdGFiLlxuICpcbiAqICoqTm90ZToqKiBOb3QgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0cywgYXZhaWxhYmxlIG9ubHkgaW4gYmFja2dyb3VuZFxuICogc2VydmljZSB3b3JrZXIsIGFjdGlvbiBzY3JpcHRzIG9yIG9wdGlvbnMgc2NyaXB0LlxuICpcbiAqIEBwYXJhbSB7IWNocm9tZS50YWJzLlRhYn0gdGFiIEN1cnJlbnQgdGFiIGNhbGxpbmcgdGhpcyBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7P3t1cmw6P3N0cmluZz0sIGFjdGl2ZTo/Ym9vbGVhbj19PX0gcGFyYW1zXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVOZXdUYWIodGFiLCBwYXJhbXMpIHtcbiAgcmV0dXJuIGF3YWl0IGNocm9tZS50YWJzLmNyZWF0ZSh7XG4gICAgd2luZG93SWQ6IHRhYi53aW5kb3dJZCxcbiAgICBvcGVuZXJUYWJJZDogdGFiLmlkLFxuICAgIGluZGV4OiB0YWIuaW5kZXggKyAxLFxuICAgIHVybDogcGFyYW1zPy51cmwsXG4gICAgYWN0aXZlOiBwYXJhbXM/LmFjdGl2ZSA/PyB0cnVlLFxuICB9KTtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IHdpbmRvdy5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0gez97dXJsOj9zdHJpbmc9fT19IHBhcmFtc1xuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlTmV3V2luZG93KHBhcmFtcykge1xuICBjb25zdCBjdXJyZW50V2luZG93ID0gYXdhaXQgY2hyb21lLndpbmRvd3MuZ2V0Q3VycmVudCgpO1xuICByZXR1cm4gYXdhaXQgY2hyb21lLndpbmRvd3MuY3JlYXRlKHtcbiAgICBzdGF0ZTogY3VycmVudFdpbmRvdy5zdGF0ZSxcbiAgICB1cmw6IHBhcmFtcz8udXJsLFxuICB9KTtcbn1cblxuLyoqXG4gKiBJbnZva2VzIHNlYXJjaCBlbmdpbmUgdG8gZG8gcXVvdGVkIHNlYXJjaC5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0geyFjaHJvbWUudGFicy5UYWJ9IHRhYiBDdXJyZW50IHRhYiBjYWxsaW5nIHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0geyFzdHJpbmd9IHNlYXJjaFRleHQgVGV4dCB0byBzZWFyY2gsIG5vdCB0byBiZSBlbmNsb3NlZCBpbiBkb3VibGUgcXVvdGVzLlxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluay5LZXlTdGF0ZT19IGtleVN0YXRlXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkb1F1b3RlZFNlYXJjaCh0YWIsIHNlYXJjaFRleHQsIGtleVN0YXRlKSB7XG4gIGNvbnN0IGhvd1RvT3BlbkxpbmsgPSBIb3dUb09wZW5MaW5rLmRlY2lkZShrZXlTdGF0ZSwgbmV3IEhvd1RvT3Blbkxpbmsob3B0aW9ucy5kaXNwb3NpdGlvbiwgdHJ1ZSkpO1xuICBpZiAoaG93VG9PcGVuTGluay5kaXNwb3NpdGlvbiA9PT0gSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5ORVdfVEFCKSB7XG4gICAgY29uc3QgbmV3VGFiID0gYXdhaXQgY3JlYXRlTmV3VGFiKHRhYiwgeyBhY3RpdmU6IGZhbHNlIH0pO1xuICAgIGF3YWl0IGNocm9tZS5zZWFyY2gucXVlcnkoeyB0YWJJZDogbmV3VGFiLmlkLCB0ZXh0OiBxdW90ZVRleHQoc2VhcmNoVGV4dCkgfSk7XG4gICAgLy8gVG8gcHJldmVudCB0aGUgb21uaWJveCBmcm9tIHJlY2VpdmluZyBmb2N1cywgYWN0aXZhdGUgbmV3IHRhYiBhZnRlclxuICAgIC8vIGNyZWF0aW9uIGFuZCBzZWFyY2guXG4gICAgaWYgKGhvd1RvT3BlbkxpbmsuYWN0aXZlID8/IHRydWUpIHtcbiAgICAgIGF3YWl0IGNocm9tZS50YWJzLnVwZGF0ZShuZXdUYWIuaWQsIHsgYWN0aXZlOiB0cnVlIH0pO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBjaHJvbWUuc2VhcmNoLnF1ZXJ5KHsgZGlzcG9zaXRpb246IGhvd1RvT3BlbkxpbmsuZGlzcG9zaXRpb24sIHRleHQ6IHF1b3RlVGV4dChzZWFyY2hUZXh0KSB9KTtcbiAgfVxufVxuXG4vKipcbiAqIE9wZW5zIHRoZSB3ZWIgcGFnZSB3aXRoIHNwZWNpZmllZCBVUkwuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnRhYnMuVGFifSB0YWIgQ3VycmVudCB0YWIgY2FsbGluZyB0aGlzIGZ1bmN0aW9uLlxuICogQHBhcmFtIHshc3RyaW5nfSB1cmxcbiAqIEBwYXJhbSB7P0hvd1RvT3BlbkxpbmsuS2V5U3RhdGU9fSBrZXlTdGF0ZVxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluaz19IGRlZmF1bHRIb3dUb09wZW5MaW5rIFNwZWNpZmllcyB0aGUgZGVmYXVsdCBiZWhhdmlvclxuICogICAgaWYgbm8gY29udHJvbCBrZXkgaXMgcHJlc3NlZC5cbiAqIEByZXR1cm5zIHshUHJvbWlzZTx2b2lkPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5MaW5rKHRhYiwgdXJsLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspIHtcbiAgY29uc3QgaG93VG9PcGVuTGluayA9IEhvd1RvT3BlbkxpbmsuZGVjaWRlKGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluayk7XG4gIGlmIChob3dUb09wZW5MaW5rLmRpc3Bvc2l0aW9uID09PSBIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9uLkNVUlJFTlRfVEFCKSB7XG4gICAgYXdhaXQgY2hyb21lLnRhYnMudXBkYXRlKHRhYi5pZCwgeyB1cmw6IHVybCB9KTtcbiAgfSBlbHNlIGlmIChob3dUb09wZW5MaW5rLmRpc3Bvc2l0aW9uID09PSBIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9uLk5FV19XSU5ET1cpIHtcbiAgICBhd2FpdCBjcmVhdGVOZXdXaW5kb3coeyB1cmw6IHVybCB9KTtcbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBjcmVhdGVOZXdUYWIodGFiLCB7IHVybDogdXJsLCBhY3RpdmU6IGhvd1RvT3BlbkxpbmsuYWN0aXZlID8/IHRydWUgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBPcGVucyB0aGUgZXh0ZW5zaW9uJ3MgT3B0aW9ucyBwYWdlLlxuICpcbiAqICoqTm90ZToqKiBOb3QgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0cywgYXZhaWxhYmxlIG9ubHkgaW4gYmFja2dyb3VuZFxuICogc2VydmljZSB3b3JrZXIsIGFjdGlvbiBzY3JpcHRzIG9yIG9wdGlvbnMgc2NyaXB0LlxuICpcbiAqIEBwYXJhbSB7IWNocm9tZS50YWJzLlRhYn0gdGFiIEN1cnJlbnQgdGFiIGNhbGxpbmcgdGhpcyBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7P0hvd1RvT3BlbkxpbmsuS2V5U3RhdGU9fSBrZXlTdGF0ZVxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluaz19IGRlZmF1bHRIb3dUb09wZW5MaW5rIFNwZWNpZmllcyB0aGUgZGVmYXVsdCBiZWhhdmlvclxuICogICAgaWYgbm8gY29udHJvbCBrZXkgaXMgcHJlc3NlZC5cbiAqIEByZXR1cm5zIHshUHJvbWlzZTx2b2lkPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5PcHRpb25zUGFnZSh0YWIsIGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluaykge1xuICBjb25zdCB1cmwgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJvcHRpb25zLmh0bWxcIik7XG4gIGF3YWl0IG9wZW5MaW5rKHRhYiwgdXJsLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspO1xufVxuXG4vKipcbiAqIE9wZW5zIHNlYXJjaCBlbmdpbmUgc2V0dGluZ3MgcGFnZSBvZiB0aGUgYnJvd3Nlci5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0geyFjaHJvbWUudGFicy5UYWJ9IHRhYiBDdXJyZW50IHRhYiBjYWxsaW5nIHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rLktleVN0YXRlPX0ga2V5U3RhdGVcbiAqIEBwYXJhbSB7P0hvd1RvT3Blbkxpbms9fSBkZWZhdWx0SG93VG9PcGVuTGluayBTcGVjaWZpZXMgdGhlIGRlZmF1bHQgYmVoYXZpb3JcbiAqICAgIGlmIG5vIGNvbnRyb2wga2V5IGlzIHByZXNzZWQuXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuU2VhcmNoRW5naW5lU2V0dGluZ3ModGFiLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspIHtcbiAgY29uc3QgdXJsID0gXCJjaHJvbWU6Ly9zZXR0aW5ncy9zZWFyY2hcIjtcbiAgYXdhaXQgb3BlbkxpbmsodGFiLCB1cmwsIGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluayk7XG59XG5cbi8qKlxuICogT3BlbnMga2V5Ym9hcmQgc2hvcnRjdXRzIHNldHRpbmdzIHBhZ2Ugb2YgdGhlIGJyb3dzZXIuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnRhYnMuVGFifSB0YWIgQ3VycmVudCB0YWIgY2FsbGluZyB0aGlzIGZ1bmN0aW9uLlxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluay5LZXlTdGF0ZT19IGtleVN0YXRlXG4gKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rPX0gZGVmYXVsdEhvd1RvT3BlbkxpbmsgU3BlY2lmaWVzIHRoZSBkZWZhdWx0IGJlaGF2aW9yXG4gKiAgICBpZiBubyBjb250cm9sIGtleSBpcyBwcmVzc2VkLlxuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlblNob3J0Y3V0c1NldHRpbmdzKHRhYiwga2V5U3RhdGUsIGRlZmF1bHRIb3dUb09wZW5MaW5rKSB7XG4gIGNvbnN0IHVybCA9IFwiY2hyb21lOi8vZXh0ZW5zaW9ucy9zaG9ydGN1dHNcIjtcbiAgYXdhaXQgb3BlbkxpbmsodGFiLCB1cmwsIGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluayk7XG59XG4iLCJpbXBvcnQgeyBjb25maWcgfSBmcm9tIFwiLi9fX2NvbmZpZy5qc1wiO1xuaW1wb3J0IHsgU2NyaXB0SWQgfSBmcm9tIFwiLi9fX2NvbnN0YW50cy5qc1wiO1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSBcIi4vX19sb2dnZXIuanNcIjtcbmltcG9ydCB7IE9wdGlvbnMgfSBmcm9tIFwiLi9fX29wdGlvbnMuanNcIjtcblxuLyoqXG4gKiBMb2dnZXIgdXNlZCB1c2VkIHRocm91Z2hvdXQgdGhlIGV4dGVuc2lvbi5cbiAqXG4gKiBJdCB3aWxsIGJlIGluaXRpYWxpemVkIGluIHtAbGluayBpbml0KCl9IGZ1bmN0aW9uLlxuICpcbiAqIEB0eXBlIHtMb2dnZXJ9XG4gKi9cbmV4cG9ydCBsZXQgbG9nZ2VyO1xuXG4vKipcbiAqIE9wdGlvbnMgdXNlZCB1c2VkIHRocm91Z2hvdXQgdGhlIGV4dGVuc2lvbi5cbiAqXG4gKiBJdCB3aWxsIGJlIGluaXRpYWxpemVkIGluIHtAbGluayBpbml0KCl9IGZ1bmN0aW9uLlxuICpcbiAqIEB0eXBlIHtPcHRpb25zfVxuICovXG5leHBvcnQgbGV0IG9wdGlvbnM7XG5cbi8qKlxuICogSW5pdGlhbGl6ZXMgdGhlIG1vZHVsZS5cbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIG11c3QgYmUgY2FsbGVkIGZpcnN0IHRvIGluaXRpYWxpemUgZ2xvYmFsIHZhcmlhYmxlcyBiZWZvcmVcbiAqIHVzaW5nIHRoZW0gYW5kIGFueSBvdGhlciBmdW5jdGlvbnMgZGVwZW5kaW5nIHRoZXNlIGdsb2JhbCB2YXJpYWJsZXMuXG4gKlxuICogQHBhcmFtIHshc3RyaW5nfSBzY3JpcHRJZFxuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaW5pdChzY3JpcHRJZCkge1xuICBsb2dnZXIgPSBuZXcgTG9nZ2VyKHNjcmlwdElkKTtcbiAgbG9nZ2VyLnN0YXRlKFwiSW5pdGlhbGl6ZSBzY3JpcHRcIiwgeyBzY3JpcHRJZCB9KTtcblxuICBvcHRpb25zID0gbmV3IE9wdGlvbnMobG9nZ2VyKTtcbiAgYXdhaXQgb3B0aW9ucy5pbml0KCk7XG5cbiAgYXdhaXQgY2hlY2tPc0lzTWFjKHNjcmlwdElkKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2hlY2tPc0lzTWFjKHNjcmlwdElkKSB7XG4gIGNvbnN0IFNUT1JBR0VfS0VZID0gXCJpc01hY1wiO1xuICBjb25zdCBzdG9yYWdlID0gY2hyb21lLnN0b3JhZ2UubG9jYWw7XG4gIGlmIChzY3JpcHRJZCA9PT0gU2NyaXB0SWQuQkFDS0dST1VORCkge1xuICAgIGNvbmZpZy5pc01hYyA9IChhd2FpdCBjaHJvbWUucnVudGltZS5nZXRQbGF0Zm9ybUluZm8oKSkub3MgPT09IFwibWFjXCI7XG4gICAgYXdhaXQgc3RvcmFnZS5zZXQoeyBbU1RPUkFHRV9LRVldOiBjb25maWcuaXNNYWMgfSk7XG4gIH0gZWxzZSB7XG4gICAgY29uZmlnLmlzTWFjID0gISEoYXdhaXQgc3RvcmFnZS5nZXQoU1RPUkFHRV9LRVkpKVtTVE9SQUdFX0tFWV07XG4gIH1cbiAgbG9nZ2VyLnN0YXRlKFwiVXBkYXRlZCBgaXNNYWNgIGluIGNvbmZpZ1wiLCB7IFtcImNvbmZpZy5pc01hY1wiXTogY29uZmlnLmlzTWFjIH0pO1xufVxuIiwiaW1wb3J0IHsgY29uZmlnIH0gZnJvbSBcIi4vX19jb25maWcuanNcIjtcblxuLyoqXG4gKiBDb250cm9scyBob3cgdG8gb3BlbiBhIGxpbmsgYmFzZWQgb24gdGhlIHN0YXRlIG9mIGNvbnRyb2wga2V5cyBzdWNoIGFzIGBDdHJsYFxuICogYW5kIGBTaGlmdGAuXG4gKi9cbmV4cG9ydCBjbGFzcyBIb3dUb09wZW5MaW5rIHtcbiAgLyoqXG4gICAqIExvY2F0aW9uIHdoZXJlIGEgbGluayBzaG91bGQgYmUgb3BlbmVkLlxuICAgKlxuICAgKiBUaGUgdmFsdWVzIG9mIHRoaXMgZW51bSBhcmUgc2FtZSBhc1xuICAgKiBbY2hyb21lLnNlYXJjaC5EaXNwb3NpdGlvbl0oaHR0cHM6Ly9kZXZlbG9wZXIuY2hyb21lLmNvbS9kb2NzL2V4dGVuc2lvbnMvcmVmZXJlbmNlL3NlYXJjaC8jdHlwZS1EaXNwb3NpdGlvbikuXG4gICAqIFRoZXJlZm9yZSwgdGhleSBjYW4gYmUgdXNlZCBhcy1pcyBhcyBhIHBhcmFtZXRlciB0b1xuICAgKiBbY2hyb21lLnNlYXJjaC5xdWVyeSgpXShodHRwczovL2RldmVsb3Blci5jaHJvbWUuY29tL2RvY3MvZXh0ZW5zaW9ucy9yZWZlcmVuY2Uvc2VhcmNoLyNtZXRob2QtcXVlcnkpLlxuICAgKi9cbiAgc3RhdGljIERpc3Bvc2l0aW9uID0ge1xuICAgIENVUlJFTlRfVEFCOiBcIkNVUlJFTlRfVEFCXCIsXG4gICAgTkVXX1RBQjogXCJORVdfVEFCXCIsXG4gICAgTkVXX1dJTkRPVzogXCJORVdfV0lORE9XXCIsXG4gIH07XG5cbiAgc3RhdGljIEtleVN0YXRlID0gY2xhc3MgS2V5U3RhdGUge1xuICAgIGN0cmxLZXk7XG4gICAgc2hpZnRLZXk7XG5cbiAgICAvKipcbiAgICAgKiBAcGFyYW0geyFib29sZWFufSBjdHJsS2V5XG4gICAgICogQHBhcmFtIHshYm9vbGVhbn0gc2hpZnRLZXlcbiAgICAgKiBAcGFyYW0geyFib29sZWFuPX0gbWV0YUtleSBJZiBzcGVjaWZpZWQsIGBtZXRhS2V5YCBpcyB1c2VkIGluc3RlYWQgb2ZcbiAgICAgKiAgICBgY3RybEtleWAgd2hlbiBydW5uaW5nIG9uIE1BQy5cbiAgICAgKi9cbiAgICBjb25zdHJ1Y3RvcihjdHJsS2V5LCBzaGlmdEtleSwgbWV0YUtleSA9IGN0cmxLZXkpIHtcbiAgICAgIHRoaXMuY3RybEtleSA9IGNvbmZpZy5pc01hYyA/IG1ldGFLZXkgOiBjdHJsS2V5O1xuICAgICAgdGhpcy5zaGlmdEtleSA9IHNoaWZ0S2V5O1xuICAgIH1cblxuICAgIGVxdWFscyhvdGhlcikge1xuICAgICAgcmV0dXJuIG90aGVyICYmIHRoaXMuY3RybEtleSA9PT0gb3RoZXIuY3RybEtleSAmJiB0aGlzLnNoaWZ0S2V5ID09PSBvdGhlci5zaGlmdEtleTtcbiAgICB9XG5cbiAgICBzdGF0aWMgQ1VSUkVOVF9UQUIgPSBuZXcgS2V5U3RhdGUoZmFsc2UsIGZhbHNlKTtcbiAgICBzdGF0aWMgTkVXX1RBQl9BQ1RJVkUgPSBuZXcgS2V5U3RhdGUodHJ1ZSwgdHJ1ZSk7XG4gICAgc3RhdGljIE5FV19UQUJfSU5BQ1RJVkUgPSBuZXcgS2V5U3RhdGUodHJ1ZSwgZmFsc2UpO1xuICAgIHN0YXRpYyBORVdfV0lORE9XID0gbmV3IEtleVN0YXRlKGZhbHNlLCB0cnVlKTtcbiAgfTtcblxuICAvKipcbiAgICogQHR5cGUgeyFIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9ufVxuICAgKi9cbiAgZGlzcG9zaXRpb247XG5cbiAgLyoqXG4gICAqIEF2YWlsYWJsZSBvbmx5IGlmIGBkaXNwb3NpdGlvbiA9PT0gIE5FV19UQUJgLlxuICAgKlxuICAgKiBAdHlwZSB7Ym9vbGVhbj19XG4gICAqL1xuICBhY3RpdmU7XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7IUhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb259IGRpc3Bvc2l0aW9uXG4gICAqIEBwYXJhbSB7Ym9vbGVhbj19IGFjdGl2ZSBBdmFpbGFibGUgb25seSBpZiBgZGlzcG9zaXRpb24gPT09ICBORVdfVEFCYC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGRpc3Bvc2l0aW9uLCBhY3RpdmUgPSB0cnVlKSB7XG4gICAgdGhpcy5kaXNwb3NpdGlvbiA9IGRpc3Bvc2l0aW9uO1xuICAgIHRoaXMuYWN0aXZlID0gYWN0aXZlO1xuICB9XG5cbiAgc3RhdGljIENVUlJFTlRfVEFCID0gbmV3IEhvd1RvT3BlbkxpbmsoSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5DVVJSRU5UX1RBQik7XG4gIHN0YXRpYyBORVdfVEFCX0FDVElWRSA9IG5ldyBIb3dUb09wZW5MaW5rKEhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb24uTkVXX1RBQiwgdHJ1ZSk7XG4gIHN0YXRpYyBORVdfVEFCX0lOQUNUSVZFID0gbmV3IEhvd1RvT3BlbkxpbmsoSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5ORVdfVEFCLCBmYWxzZSk7XG4gIHN0YXRpYyBORVdfV0lORE9XID0gbmV3IEhvd1RvT3BlbkxpbmsoSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5ORVdfV0lORE9XKTtcblxuICAvKipcbiAgICogRGVjaWRlcyBsb2NhdGlvbiB3aGVyZSBhIGxpbmsgc2hvdWxkIGJlIG9wZW5lZC5cbiAgICpcbiAgICogQHBhcmFtIHs/SG93VG9PcGVuTGluay5LZXlTdGF0ZT19IGtleVN0YXRlXG4gICAqIEBwYXJhbSB7P0hvd1RvT3Blbkxpbms9fSBkZWZhdWx0SG93VG9PcGVuTGlua1xuICAgKiBAcmV0dXJucyB7IUhvd1RvT3Blbkxpbmt9XG4gICAqL1xuICBzdGF0aWMgZGVjaWRlKGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluaykge1xuICAgIGlmIChIb3dUb09wZW5MaW5rLktleVN0YXRlLk5FV19UQUJfQUNUSVZFLmVxdWFscyhrZXlTdGF0ZSkpIHJldHVybiBIb3dUb09wZW5MaW5rLk5FV19UQUJfQUNUSVZFO1xuICAgIGVsc2UgaWYgKEhvd1RvT3BlbkxpbmsuS2V5U3RhdGUuTkVXX1RBQl9JTkFDVElWRS5lcXVhbHMoa2V5U3RhdGUpKSByZXR1cm4gSG93VG9PcGVuTGluay5ORVdfVEFCX0lOQUNUSVZFO1xuICAgIGVsc2UgaWYgKEhvd1RvT3BlbkxpbmsuS2V5U3RhdGUuTkVXX1dJTkRPVy5lcXVhbHMoa2V5U3RhdGUpKSByZXR1cm4gSG93VG9PcGVuTGluay5ORVdfV0lORE9XO1xuICAgIGVsc2UgcmV0dXJuIGRlZmF1bHRIb3dUb09wZW5MaW5rID8/IEhvd1RvT3BlbkxpbmsuQ1VSUkVOVF9UQUI7XG4gIH1cbn1cbiIsImltcG9ydCB7IGNvbmZpZyB9IGZyb20gXCIuL19fY29uZmlnLmpzXCI7XG5cbi8qKlxuICogT3V0cHV0cyBsb2dzIG9ubHkgaWYgYGNvbmZpZy5sb2dFbmFibGVkYCBpcyB0cnVlLiBPdGhlcndpc2UsIGFsbCBvZiB0aGVcbiAqIGluc3RhbmNlIG1ldGhvZHMgb2YgdGhpcyBjbGFzcyBoYXZlIG5vIG9wZXJhdGlvbnMgKGllIGVtcHR5KS5cbiAqL1xuZXhwb3J0IGNsYXNzIExvZ2dlciB7XG4gICNpZDtcblxuICAvKipcbiAgICogQHBhcmFtIHshc3RyaW5nfSBpZCBBcHBlYXJzIGF0IHRoZSBiZWdpbm5pbmcgb2YgdGhlIGxvZyBtZXNzYWdlLCBlbmNsb3NlZFxuICAgKiAgICBpbiBzcXVhcmUgYnJhY2tldHMuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihpZCkge1xuICAgIHRoaXMuI2lkID0gaWQ7XG4gIH1cblxuICAvKipcbiAgICogQHBhcmFtIHshc3RyaW5nfSBpZFxuICAgKi9cbiAgc2V0SWQoaWQpIHtcbiAgICB0aGlzLiNpZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUuZGVidWcoKWAgd2l0aCB0aGUgaGVhZGVyIGBbSU5GT11gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBpbmZvKG1lc3NhZ2UsIC4uLmFyZ3MpIHtcbiAgICB0aGlzLiNvdXRwdXQoXCJkZWJ1Z1wiLCBcIltJTkZPXVwiLCBtZXNzYWdlLCBhcmdzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIGBjb25zb2xlLmRlYnVnKClgIHdpdGggdGhlIGhlYWRlciBgW1NUQVRFXWAgcHJlcGVuZGVkIHRvIHRoZSBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0geyFzdHJpbmd9IG1lc3NhZ2VcbiAgICogQHBhcmFtIHsuLi5hbnk9fSBhcmdzIGFyZ3VtZW50cyBmb3IgdGhlIHN1YnN0aXR1dGlvbnMgaWYgaW5jbHVkZWQgaW4gdGhlXG4gICAqICAgIG1lc3NhZ2UuIElmIHNwZWNpZnlpbmcgYW4gb2JqZWN0IChrZXktdmFsdWUgcGFpcnMpIGF0IHRoZSBlbmQsIGl0IHdpbGxcbiAgICogICAgYmUgZGVjb21wb3NlZCBhbmQgb3V0cHV0IGluIHRoZSBmb3JtIGBcXG4ke2tleX09ICR7dmFsdWV9YC5cbiAgICovXG4gIHN0YXRlKG1lc3NhZ2UsIC4uLmFyZ3MpIHtcbiAgICB0aGlzLiNvdXRwdXQoXCJkZWJ1Z1wiLCBcIltTVEFURV1cIiwgbWVzc2FnZSwgYXJncyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBgY29uc29sZS5kZWJ1ZygpYCB3aXRoIHRoZSBoZWFkZXIgYFtDQUxMQkFDS11gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBjYWxsYmFjayhtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiZGVidWdcIiwgXCJbQ0FMTEJBQ0tdXCIsIG1lc3NhZ2UsIGFyZ3MpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUud2FybigpYCB3aXRoIHRoZSBoZWFkZXIgYFtXQVJOXWAgcHJlcGVuZGVkIHRvIHRoZSBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0geyFzdHJpbmd9IG1lc3NhZ2VcbiAgICogQHBhcmFtIHsuLi5hbnk9fSBhcmdzIGFyZ3VtZW50cyBmb3IgdGhlIHN1YnN0aXR1dGlvbnMgaWYgaW5jbHVkZWQgaW4gdGhlXG4gICAqICAgIG1lc3NhZ2UuIElmIHNwZWNpZnlpbmcgYW4gb2JqZWN0IChrZXktdmFsdWUgcGFpcnMpIGF0IHRoZSBlbmQsIGl0IHdpbGxcbiAgICogICAgYmUgZGVjb21wb3NlZCBhbmQgb3V0cHV0IGluIHRoZSBmb3JtIGBcXG4ke2tleX09ICR7dmFsdWV9YC5cbiAgICovXG4gIHdhcm4obWVzc2FnZSwgLi4uYXJncykge1xuICAgIHRoaXMuI291dHB1dChcIndhcm5cIiwgXCJbV0FSTl1cIiwgbWVzc2FnZSwgYXJncyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBgY29uc29sZS5lcnJvcigpYCB3aXRoIHRoZSBoZWFkZXIgYFtFUlJPUl1gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBlcnJvcihtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiZXJyb3JcIiwgXCJbRVJST1JdXCIsIG1lc3NhZ2UsIGFyZ3MpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUuYXNzZXJ0KClgIHdpdGggdGhlIGhlYWRlciBgW0VSUk9SXWAgcHJlcGVuZGVkIHRvIHRoZSBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0geyFib29sZWFufSBhc3NlcnRpb25cbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBhc3NlcnQoYXNzZXJ0aW9uLCBtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiYXNzZXJ0XCIsIFwiW0VSUk9SXVwiLCBtZXNzYWdlLCBhcmdzLCBhc3NlcnRpb24pO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgQ29uc29sZSBBUEkgc3BlY2lmaWVkIGJ5IHRoZSBgbWV0aG9kYCBhcmd1bWVudC5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBjb25zb2xlQXBpIENvbnNvbGUgQVBJIHRvIGNhbGwuXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gaGVhZGVyXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gbWVzc2FnZVxuICAgKiBAcGFyYW0gez9hbnlbXT19IGFyZ3NcbiAgICogQHBhcmFtIHs/Ym9vbGVhbj19IGFzc2VydGlvbiBtdXN0IGJlIHNwZWNpZmllZCBpZiBgbWV0aG9kYCBpcyBcImFzc2VydFwiLCBvdGhlcndpc2UgaWdub3JlZC5cbiAgICovXG4gICNvdXRwdXQoY29uc29sZUFwaSwgaGVhZGVyLCBtZXNzYWdlLCBhcmdzLCBhc3NlcnRpb24pIHtcbiAgICBpZiAoIWNvbmZpZy5sb2dFbmFibGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3Qgb3B0aW9uYWxBcmdzID0gW107XG4gICAgaWYgKGFyZ3MgJiYgYXJncy5sZW5ndGggPiAwICYmIHR5cGVvZiBhcmdzLmF0KC0xKSA9PT0gXCJvYmplY3RcIikge1xuICAgICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoYXJncy5wb3AoKSkpIHtcbiAgICAgICAgb3B0aW9uYWxBcmdzLnB1c2goYFxcbiR7a2V5fT1gKTtcbiAgICAgICAgb3B0aW9uYWxBcmdzLnB1c2godmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnNvbGVbY29uc29sZUFwaV0oXG4gICAgICAuLi4oY29uc29sZUFwaSA9PT0gXCJhc3NlcnRcIiA/IFshIWFzc2VydGlvbl0gOiBbXSksXG4gICAgICBgWyR7dGhpcy4jaWR9XSAke2hlYWRlcn0gJHttZXNzYWdlfWAsXG4gICAgICAuLi5hcmdzLFxuICAgICAgLi4ub3B0aW9uYWxBcmdzXG4gICAgKTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgSG93VG9PcGVuTGluayB9IGZyb20gXCIuL19faG93X3RvX29wZW5fbGluay5qc1wiO1xuXG4vKipcbiAqIFVzZXItY3VzdG9taXphYmxlIGV4dGVuc2lvbiBvcHRpb25zLlxuICpcbiAqIE9wdGlvbnMgaXMgc3RvcmVkIGluIHRoZVxuICogW3N5bmNdKGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vZG9jcy9leHRlbnNpb25zL3JlZmVyZW5jZS9zdG9yYWdlLyNwcm9wZXJ0eS1zeW5jKVxuICogc3RvcmFnZSBhcmVhIHRoYXQgaXMgc3luY2VkIHVzaW5nIENocm9tZSBTeW5jLlxuICovXG5leHBvcnQgY2xhc3MgT3B0aW9ucyB7XG4gIHN0YXRpYyAjc3RvcmFnZSA9IGNocm9tZS5zdG9yYWdlLnN5bmM7XG5cbiAgc3RhdGljICNTVE9SQUdFX0tFWSA9IFwib3B0aW9uc1wiO1xuXG4gIHN0YXRpYyAjVVBEQVRFRF9BVF9LRVkgPSBcIl9fdXBkYXRlZEF0X19cIjtcblxuICBzdGF0aWMgI0RFRkFVTFRfVkFMVUVTID0ge1xuICAgIFtPcHRpb25zLiNVUERBVEVEX0FUX0tFWV06IDAsXG4gIH07XG5cbiAgc3RhdGljIERpc3Bvc2l0aW9uID0gSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbjtcblxuICBzdGF0aWMgSUNPTl9TSVpFX01JTiA9IDE7XG4gIHN0YXRpYyBJQ09OX1NJWkVfTUFYID0gNTtcblxuICAvLyBwcmV0dGllci1pZ25vcmVcbiAgLyoqXG4gICAqIERlZmluaXRpb24gb2Ygb3B0aW9ucy5cbiAgICpcbiAgICogSnVzdCBhZGQgYSByb3cgaW50byB0aGlzIHRhYmxlIHRvIGFkZCBhIG5ldyBvcHRpb24gaXRlbS4gVGhlIGNvZGUgbmVjZXNzYXJ5XG4gICAqIHRvIHJlYWQgYW5kIHdyaXRlIG9wdGlvbiB2YWx1ZXMgaXMgYXV0b21hdGljYWxseSBnZW5lcmF0ZWQuXG4gICAqXG4gICAqIEB0eXBlIHt7bmFtZTohc3RyaW5nLCBkZWZhdWx0VmFsdWU6ISosIHZhbGlkYXRvcjohZnVuY3Rpb24oPyopOmJvb2xlYW59W119XG4gICAqL1xuICBzdGF0aWMgI0lURU1TID0gW1xuICAgIHsgbmFtZTogXCJwb3B1cEljb25cIiAgICAgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImljb25TaXplXCIgICAgICAsIGRlZmF1bHRWYWx1ZTogMyAgICAgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiICYmIHZhbHVlID49IE9wdGlvbnMuSUNPTl9TSVpFX01JTiAmJiB2YWx1ZSA8PSBPcHRpb25zLklDT05fU0laRV9NQVggfSxcbiAgICB7IG5hbWU6IFwiYXZvaWRTZWxlY3Rpb25cIiwgZGVmYXVsdFZhbHVlOiBmYWxzZSAgICAgICAgICAgICAgICAgICAgICAsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgIHsgbmFtZTogXCJvcHRpb25zQnV0dG9uXCIgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImNvbnRleHRNZW51XCIgICAsIGRlZmF1bHRWYWx1ZTogdHJ1ZSAgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICB7IG5hbWU6IFwiZGlzcG9zaXRpb25cIiAgICwgZGVmYXVsdFZhbHVlOiBPcHRpb25zLkRpc3Bvc2l0aW9uLk5FV19UQUIsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIgJiYgT2JqZWN0LnZhbHVlcyhPcHRpb25zLkRpc3Bvc2l0aW9uKS5pbmNsdWRlcyh2YWx1ZSkgICAgICAgICAgICAgICB9LFxuICAgIHsgbmFtZTogXCJhdXRvQ29weVwiICAgICAgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImF1dG9FbnRlclwiICAgICAsIGRlZmF1bHRWYWx1ZTogdHJ1ZSAgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICB7IG5hbWU6IFwiYXV0b1N1cnJvdW5kXCIgICwgZGVmYXVsdFZhbHVlOiBmYWxzZSAgICAgICAgICAgICAgICAgICAgICAsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICBdO1xuXG4gIHN0YXRpYyAjZGVmaW5lT3B0aW9ucygpIHtcbiAgICBmb3IgKGNvbnN0IHsgbmFtZSwgZGVmYXVsdFZhbHVlLCB2YWxpZGF0b3IgfSBvZiBPcHRpb25zLiNJVEVNUykge1xuICAgICAgT3B0aW9ucy4jREVGQVVMVF9WQUxVRVNbbmFtZV0gPSBkZWZhdWx0VmFsdWU7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoT3B0aW9ucy5wcm90b3R5cGUsIG5hbWUsIHtcbiAgICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgICAgaWYgKCF2YWxpZGF0b3IodmFsdWUpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE9wdGlvbnM6IEludmFsaWQgdmFsdWUgZm9yICcke25hbWV9J1xcbnZhbHVlPSR7dmFsdWV9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh2YWx1ZSAhPT0gdGhpcy4jY2FjaGVbbmFtZV0pIHtcbiAgICAgICAgICAgIHRoaXMuI2NhY2hlW25hbWVdID0gdmFsdWU7XG4gICAgICAgICAgICAvKiBhc3luYyAqLyB0aGlzLiN1cGRhdGVTdG9yYWdlKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBnZXQoKSB7XG4gICAgICAgICAgcmV0dXJuIHZhbGlkYXRvcih0aGlzLiNjYWNoZVtuYW1lXSkgPyB0aGlzLiNjYWNoZVtuYW1lXSA6IGRlZmF1bHRWYWx1ZTtcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyB7XG4gICAgT3B0aW9ucy4jZGVmaW5lT3B0aW9ucygpO1xuICB9XG5cbiAgLyoqXG4gICAqIEZpcmVkIHdoZW4gb25lIG9yIG1vcmUgb3B0aW9ucyBhcmUgY2hhbmdlZCBleHRlcm5hbGx5LlxuICAgKi9cbiAgb25DaGFuZ2VkID0gbmV3IChjbGFzcyBvbkNoYW5nZWQge1xuICAgICNsaXN0ZW5lcnMgPSBbXTtcbiAgICAvKipcbiAgICAgKiBAcGFyYW0geyFmdW5jdGlvbighT3B0aW9ucyk6dm9pZH0gbGlzdGVuZXJcbiAgICAgKi9cbiAgICBhZGRMaXN0ZW5lcihsaXN0ZW5lcikge1xuICAgICAgdGhpcy4jbGlzdGVuZXJzLnB1c2gobGlzdGVuZXIpO1xuICAgIH1cbiAgICBfZmlyZSgpIHtcbiAgICAgIGZvciAoY29uc3QgbGlzdGVuZXIgb2YgdGhpcy4jbGlzdGVuZXJzKSB7XG4gICAgICAgIGxpc3RlbmVyKCk7XG4gICAgICB9XG4gICAgfVxuICB9KSgpO1xuXG4gICNsb2dnZXI7XG4gICNjYWNoZTtcblxuICAvKipcbiAgICogQHBhcmFtIHshTG9nZ2VyfSBsb2dnZXJcbiAgICovXG4gIGNvbnN0cnVjdG9yKGxvZ2dlcikge1xuICAgIHRoaXMuI2xvZ2dlciA9IGxvZ2dlcjtcbiAgICB0aGlzLiNjYWNoZSA9IE9iamVjdC5hc3NpZ24oe30sIE9wdGlvbnMuI0RFRkFVTFRfVkFMVUVTKTtcblxuICAgIE9wdGlvbnMuI3N0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhTmFtZSkgPT4ge1xuICAgICAgdGhpcy4jb25DaGFuZ2VkTGlzdGVuZXIoY2hhbmdlcywgYXJlYU5hbWUpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIExvYWQgb3B0aW9ucyBmcm9tIHRoZSBzdG9yYWdlLlxuICAgKi9cbiAgYXN5bmMgaW5pdCgpIHtcbiAgICBjb25zdCB2YWx1ZXMgPSBhd2FpdCBPcHRpb25zLiNzdG9yYWdlLmdldChPcHRpb25zLiNTVE9SQUdFX0tFWSk7XG4gICAgLy8gTWVyZ2UgcmF0aGVyIHRoYW4gYXNzaWduIHRvIGVuc3VyZSBjb21wbGV0ZW5lc3Mgb2Ygb3B0aW9ucyBpbiBjYXNlIG9mXG4gICAgLy8gbWlzc2luZyBkYXRhIGluIHRoZSBzdG9yYWdlLlxuICAgIE9iamVjdC5hc3NpZ24odGhpcy4jY2FjaGUsIHZhbHVlc1tPcHRpb25zLiNTVE9SQUdFX0tFWV0pO1xuICAgIHRoaXMuI2xvZ2dlci5zdGF0ZShcIk9wdGlvbnM6IEluaXRpYWxpemVkXCIsIHsgW1widGhpcy4jY2FjaGVcIl06IHRoaXMuI2NhY2hlIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlc2V0IGFsbCBvcHRpb25zIHRvIHJlc3RvcmUgZGVmYXVsdHMuXG4gICAqL1xuICByZXNldCgpIHtcbiAgICB0aGlzLiNjYWNoZSA9IE9iamVjdC5hc3NpZ24oe30sIE9wdGlvbnMuI0RFRkFVTFRfVkFMVUVTKTtcbiAgICAvKiBhc3luYyAqLyB0aGlzLiN1cGRhdGVTdG9yYWdlKCk7XG4gIH1cblxuICBhc3luYyAjdXBkYXRlU3RvcmFnZSgpIHtcbiAgICB0aGlzLiNjYWNoZVtPcHRpb25zLiNVUERBVEVEX0FUX0tFWV0gPSBEYXRlLm5vdygpO1xuICAgIGNvbnN0IHZhbHVlcyA9IHsgW09wdGlvbnMuI1NUT1JBR0VfS0VZXTogdGhpcy4jY2FjaGUgfTtcbiAgICB0aGlzLiNsb2dnZXIuc3RhdGUoXCJPcHRpb25zOiBVcGRhdGUgc3RvcmFnZVwiLCB7IHZhbHVlcyB9KTtcbiAgICBhd2FpdCBPcHRpb25zLiNzdG9yYWdlLnNldCh2YWx1ZXMpO1xuICB9XG5cbiAgI29uQ2hhbmdlZExpc3RlbmVyKGNoYW5nZXMsIGFyZWFOYW1lKSB7XG4gICAgdGhpcy4jbG9nZ2VyLmNhbGxiYWNrKFwiT3B0aW9uczogb25DaGFuZ2VkTGlzdGVuZXIoKVwiLCB7IGNoYW5nZXMsIGFyZWFOYW1lIH0pO1xuXG4gICAgaWYgKCFPYmplY3QuaGFzT3duKGNoYW5nZXMsIE9wdGlvbnMuI1NUT1JBR0VfS0VZKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChPYmplY3QuaGFzT3duKGNoYW5nZXNbT3B0aW9ucy4jU1RPUkFHRV9LRVldLCBcIm5ld1ZhbHVlXCIpKSB7XG4gICAgICBjb25zdCBuZXdWYWx1ZSA9IGNoYW5nZXNbT3B0aW9ucy4jU1RPUkFHRV9LRVldLm5ld1ZhbHVlO1xuICAgICAgaWYgKG5ld1ZhbHVlW09wdGlvbnMuI1VQREFURURfQVRfS0VZXSA8PSB0aGlzLiNjYWNoZVtPcHRpb25zLiNVUERBVEVEX0FUX0tFWV0pIHtcbiAgICAgICAgdGhpcy4jbG9nZ2VyLmluZm8oXCJPcHRpb25zOiBDYWNoZSB3YXMgbm90IG92ZXJ3cml0dGVuIGJlY2F1c2UgaXQgaXMgdXAgdG8gZGF0ZVwiLCB7XG4gICAgICAgICAgW1widGhpcy4jY2FjaGVcIl06IHRoaXMuI2NhY2hlLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBNZXJnZSByYXRoZXIgdGhhbiBhc3NpZ24gdG8gZW5zdXJlIGNvbXBsZXRlbmVzcyBvZiBvcHRpb25zIGluIGNhc2Ugb2ZcbiAgICAgIC8vIG1pc3NpbmcgZGF0YSBpbiB0aGUgc3RvcmFnZS5cbiAgICAgIE9iamVjdC5hc3NpZ24odGhpcy4jY2FjaGUsIG5ld1ZhbHVlKTtcbiAgICAgIHRoaXMuI2xvZ2dlci5zdGF0ZShcIk9wdGlvbnM6IENhY2hlIHdhcyBvdmVyd3JpdHRlbiBieSB2YWx1ZXMgaW4gc3RvcmFnZSB1cGRhdGVkIGJ5IG90aGVyXCIsIHtcbiAgICAgICAgW1widGhpcy4jY2FjaGVcIl06IHRoaXMuI2NhY2hlLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFRoZSBzdG9yYWdlIGhhcyBiZWVuIGNsZWFyZWQuXG5cbiAgICAgIHRoaXMuI2NhY2hlID0gT2JqZWN0LmFzc2lnbih7fSwgT3B0aW9ucy4jREVGQVVMVF9WQUxVRVMpO1xuICAgICAgdGhpcy4jbG9nZ2VyLnN0YXRlKFwiT3B0aW9uczogQ2FjaGUgd2FzIHJlc2V0IHRvIGRlZmF1bHQgdmFsdWVzIGJlY2F1c2UgdGhlIHN0b3JhZ2UgaGFzIGJlZW4gY2xlYXJlZFwiLCB7XG4gICAgICAgIFtcInRoaXMuI2NhY2hlXCJdOiB0aGlzLiNjYWNoZSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHRoaXMub25DaGFuZ2VkLl9maXJlKCk7XG4gIH1cbn1cbiIsIi8qKlxuICogQGZpbGUgQWdncmVnYXRlcyBtb2R1bGVzLlxuICovXG5cbmV4cG9ydCAqIGZyb20gXCIuL19fY29uZmlnLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9fX2NvbnN0YW50cy5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19mdW5jdGlvbnMuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL19fZ2xvYmFscy5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19ob3dfdG9fb3Blbl9saW5rLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9fX2xvZ2dlci5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19vcHRpb25zLmpzXCI7XG4iLCJpbXBvcnQgKiBhcyBxcXMgZnJvbSBcIi4vY29tbW9uLmpzXCI7XG5cbi8qKlxuICogSW1wbGVtZW50cyBQb3B1cCBJY29uIHJlbmRlcmVkIG9uIGFueSB3ZWIgcGFnZXMuXG4gKi9cbmV4cG9ydCBjbGFzcyBQb3B1cEljb24ge1xuICAjd2luO1xuICAjZG9tO1xuXG4gICNlZGl0YWJsZU5vZGU7XG4gICNlbmFibGVkID0gZmFsc2U7XG5cbiAgI21vdXNlTW92ZW1lbnQgPSB7IHByZXZYOiAwLCBwcmV2WTogMCwgaXNGb3J3YXJkOiB0cnVlIH07XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7IVdpbmRvd30gd2luXG4gICAqIEBwYXJhbSB7IWZ1bmN0aW9uKCFNb3VzZUV2ZW50KTp2b2lkfSBjYWxsYmFja09uQ2xpY2tTZWFyY2hcbiAgICogQHBhcmFtIHshZnVuY3Rpb24oIU1vdXNlRXZlbnQsIUhUTUxFbGVtZW50KTp2b2lkfSBjYWxsYmFja09uQ2xpY2tRdW90ZVxuICAgKiBAcGFyYW0geyFmdW5jdGlvbighTW91c2VFdmVudCk6dm9pZH0gY2FsbGJhY2tPbkNsaWNrT3B0aW9uc1xuICAgKi9cbiAgY29uc3RydWN0b3Iod2luLCBjYWxsYmFja09uQ2xpY2tTZWFyY2gsIGNhbGxiYWNrT25DbGlja1F1b3RlLCBjYWxsYmFja09uQ2xpY2tPcHRpb25zKSB7XG4gICAgdGhpcy4jd2luID0gd2luO1xuICAgIHRoaXMuI2RvbSA9IG5ldyBQb3B1cEljb25Eb20od2luLCBjYWxsYmFja09uQ2xpY2tTZWFyY2gsIGNhbGxiYWNrT25DbGlja1F1b3RlLCBjYWxsYmFja09uQ2xpY2tPcHRpb25zKTtcblxuICAgIHRoaXMuI3dpbi5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNlbW92ZVwiLCAoZSkgPT4gdGhpcy4jb25Nb3VzZU1vdmUoZSkpO1xuICAgIHRoaXMuI3dpbi5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcIm1vdXNldXBcIiwgKGUpID0+IHRoaXMuI29uTW91c2VVcChlKSk7XG4gICAgdGhpcy4jd2luLmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJzZWxlY3Rpb25jaGFuZ2VcIiwgKGUpID0+IHRoaXMuI29uU2VsZWN0aW9uQ2hhbmdlKGUpKTtcblxuICAgIHFxcy5vcHRpb25zLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcigoKSA9PiB0aGlzLiNvbk9wdGlvbnNDaGFuZ2VkKCkpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7IUhUTUxFbGVtZW50fSBlZGl0YWJsZU5vZGVcbiAgICovXG4gIHNldEVkaXRhYmxlTm9kZShlZGl0YWJsZU5vZGUpIHtcbiAgICB0aGlzLiNlZGl0YWJsZU5vZGUgPSBlZGl0YWJsZU5vZGU7XG4gIH1cblxuICAvKipcbiAgICogU2luY2UgUG9wdXAgSWNvbiBpcyBkaXNhYmxlZCBpbiB0aGUgaW5pdGlhbCBzdGF0ZSwgY2FsbCB0aGlzIG1ldGhvZCB0b1xuICAgKiBlbmFibGUgaXQgd2hlbiByZWFkeS5cbiAgICovXG4gIGVuYWJsZSgpIHtcbiAgICB0aGlzLiNlbmFibGVkID0gdHJ1ZTtcbiAgfVxuXG4gIGRpc2FibGUoKSB7XG4gICAgdGhpcy4jZW5hYmxlZCA9IGZhbHNlO1xuICAgIHRoaXMuI2RvbS5oaWRlKCk7XG4gIH1cblxuICAjb25Nb3VzZU1vdmUoZSkge1xuICAgIGNvbnN0IFRIUkVTSE9MRCA9IDMyO1xuICAgIGNvbnN0IG1vdmVtZW50WCA9IGUuY2xpZW50WCAtIHRoaXMuI21vdXNlTW92ZW1lbnQucHJldlg7XG4gICAgY29uc3QgbW92ZW1lbnRZID0gZS5jbGllbnRZIC0gdGhpcy4jbW91c2VNb3ZlbWVudC5wcmV2WTtcbiAgICBpZiAoTWF0aC5hYnMobW92ZW1lbnRYKSA+IFRIUkVTSE9MRCB8fCBNYXRoLmFicyhtb3ZlbWVudFkpID4gVEhSRVNIT0xEKSB7XG4gICAgICB0aGlzLiNtb3VzZU1vdmVtZW50LmlzRm9yd2FyZCA9IG1vdmVtZW50WCAhPT0gMCA/IG1vdmVtZW50WCA+IDAgOiBtb3ZlbWVudFkgPiAwO1xuICAgICAgdGhpcy4jbW91c2VNb3ZlbWVudC5wcmV2WCA9IGUuY2xpZW50WDtcbiAgICAgIHRoaXMuI21vdXNlTW92ZW1lbnQucHJldlkgPSBlLmNsaWVudFk7XG4gICAgfVxuICB9XG5cbiAgI29uTW91c2VVcChlKSB7XG4gICAgY29uc3QgTU9VU0VfTEVGVF9CVVRUT04gPSAwO1xuICAgIGlmIChlLmJ1dHRvbiA9PT0gTU9VU0VfTEVGVF9CVVRUT04pIHtcbiAgICAgIHRoaXMuI3Nob3coZS5jbGllbnRYLCBlLmNsaWVudFkpO1xuICAgIH1cbiAgfVxuXG4gICNvblNlbGVjdGlvbkNoYW5nZShfZSkge1xuICAgIGlmIChxcXMuZ2V0U2VsZWN0aW9uKHRoaXMuI3dpbikudG9TdHJpbmcoKSA9PT0gXCJcIikge1xuICAgICAgdGhpcy4jZG9tLmhpZGUoKTtcbiAgICB9XG4gIH1cblxuICAjb25PcHRpb25zQ2hhbmdlZCgpIHtcbiAgICB0aGlzLiNkb20ucmVmbGVjdE9wdGlvbnMoKTtcblxuICAgIGlmICghcXFzLm9wdGlvbnMucG9wdXBJY29uKSB7XG4gICAgICB0aGlzLiNkb20uaGlkZSgpO1xuICAgIH1cbiAgfVxuXG4gICNzaG93KG1vdXNlQ2xpZW50WCwgbW91c2VDbGllbnRZKSB7XG4gICAgLy8gRXhlY3V0ZXMgdGhpcyB0YXNrIGFmdGVyIGFsbCBVSSBldmVudHMgaW4gdGhlIHF1ZXVlIGlzIHByb2Nlc3NlZCwgYmVjYXVzZVxuICAgIC8vIHRleHQgbWF5IGJlIHNlbGVjdGVkIGFmdGVyIHRoaXMgbW91c2V1cCBldmVudCwgc3VjaCBhcyB3aGVuIGRvdWJsZS1jbGlja2VkLlxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgY29uc3Qgc2VsZWN0aW9uID0gcXFzLmdldFNlbGVjdGlvbih0aGlzLiN3aW4pO1xuICAgICAgY29uc3Qgc2VsZWN0aW9uVGV4dCA9IHFxcy5maWx0ZXJTZWxlY3Rpb25UZXh0KHNlbGVjdGlvbi50b1N0cmluZygpKTtcbiAgICAgIGlmIChcbiAgICAgICAgcXFzLm9wdGlvbnMucG9wdXBJY29uICYmXG4gICAgICAgIHRoaXMuI2VuYWJsZWQgJiZcbiAgICAgICAgcXFzLmlzTm9ybWFsaXplZFNlbGVjdGlvblRleHRWYWxpZChxcXMubm9ybWFsaXplU2VsZWN0aW9uVGV4dChzZWxlY3Rpb25UZXh0KSlcbiAgICAgICkge1xuICAgICAgICBpZiAoc2VsZWN0aW9uVGV4dCA9PT0gdGhpcy4jZG9tLmF0TW91c2V1cC5zZWxlY3Rpb25UZXh0IHx8IHRoaXMuI2RvbS5jbGlja2luZykge1xuICAgICAgICAgIC8vIFBvcHVwIEljb24gc2hvdWxkIG5vdCBtb3ZlIGJlY2F1c2UgY3VycmVudCBtb3VzZXVwIGV2ZW50IGlzIG5vdFxuICAgICAgICAgIC8vIGludGVuZGVkIHRvIGNoYW5nZSB0ZXh0IHNlbGVjdGlvbi5cbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLiNkb20uYXRNb3VzZXVwLnNlbGVjdGlvblRleHQgPSBzZWxlY3Rpb25UZXh0O1xuICAgICAgICB0aGlzLiNkb20uYXRNb3VzZXVwLmVkaXRhYmxlTm9kZSA9IHRoaXMuI2VkaXRhYmxlTm9kZTtcblxuICAgICAgICBjb25zdCBjbGllbnRSZWN0ID0gdGhpcy4jZG9tLnNob3coKTtcblxuICAgICAgICBjb25zdCBjbGllbnRMZWZ0ID0gKCgpID0+IHtcbiAgICAgICAgICBjb25zdCBHT09HTEVfVFJBTlNMQVRFX1BPUFVQX1NJWkUgPSAyNztcbiAgICAgICAgICBjb25zdCBsZWZ0T2Zmc2V0ID0gcXFzLm9wdGlvbnMuYXZvaWRTZWxlY3Rpb25cbiAgICAgICAgICAgID8gLy8gUHJldmVudHMgUG9wdXAgSWNvbiBmcm9tIG92ZXJsYXBwaW5nIHdpdGggR29vZ2xlIFRyYW5zbGF0ZVxuICAgICAgICAgICAgICAvLyBFeHRlbnNpb24ncyBvbmUuXG4gICAgICAgICAgICAgIEdPT0dMRV9UUkFOU0xBVEVfUE9QVVBfU0laRSArIGNsaWVudFJlY3Qud2lkdGggLyAyXG4gICAgICAgICAgICA6IC8vIFByZXZlbnRzIFBvcHVwIEljb24gZnJvbSBvdmVybGFwcGluZyB3aXRoIG1vdXNlIHBvaW50ZXIuXG4gICAgICAgICAgICAgIGNsaWVudFJlY3Qud2lkdGggKiAxLjI7XG5cbiAgICAgICAgICBjb25zdCBpc0ZvcndhcmQgPSB0aGlzLiNlZGl0YWJsZU5vZGVcbiAgICAgICAgICAgID8gdGhpcy4jZWRpdGFibGVOb2RlLnNlbGVjdGlvbkRpcmVjdGlvbiAhPT0gXCJiYWNrd2FyZFwiXG4gICAgICAgICAgICA6IHRoaXMuI21vdXNlTW92ZW1lbnQuaXNGb3J3YXJkO1xuXG4gICAgICAgICAgcmV0dXJuIG1vdXNlQ2xpZW50WCAtIGNsaWVudFJlY3Qud2lkdGggLyAyICsgKGlzRm9yd2FyZCA/IGxlZnRPZmZzZXQgOiAtbGVmdE9mZnNldCk7XG4gICAgICAgIH0pKCk7XG5cbiAgICAgICAgY29uc3QgY2xpZW50VG9wID0gKCgpID0+IHtcbiAgICAgICAgICBpZiAoIXFxcy5vcHRpb25zLmF2b2lkU2VsZWN0aW9uIHx8IHRoaXMuI2VkaXRhYmxlTm9kZSkge1xuICAgICAgICAgICAgcmV0dXJuIG1vdXNlQ2xpZW50WSAtIGNsaWVudFJlY3QuaGVpZ2h0IC8gMjtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3Qgc2VsZWN0aW9uQ2xpZW50UmVjdCA9IHNlbGVjdGlvbi5nZXRSYW5nZUF0KDApLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgY29uc3QgTUFSR0lOID0gMTtcbiAgICAgICAgICAgIHJldHVybiBtb3VzZUNsaWVudFkgPCBzZWxlY3Rpb25DbGllbnRSZWN0LnRvcCArIHNlbGVjdGlvbkNsaWVudFJlY3QuaGVpZ2h0IC8gMlxuICAgICAgICAgICAgICA/IHNlbGVjdGlvbkNsaWVudFJlY3QudG9wIC0gY2xpZW50UmVjdC5oZWlnaHQgLSBNQVJHSU5cbiAgICAgICAgICAgICAgOiBzZWxlY3Rpb25DbGllbnRSZWN0LmJvdHRvbSArIE1BUkdJTjtcbiAgICAgICAgICB9XG4gICAgICAgIH0pKCk7XG5cbiAgICAgICAgdGhpcy4jZG9tLnNldFBvc2l0aW9uKGNsaWVudExlZnQsIGNsaWVudFRvcCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLiNkb20uaGlkZSgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG5cbi8qKlxuICogSW1wbGVtZW50cyBET00tcmVsYXRlZCBwcm9jZXNzaW5nIGFtb25nIHRoZSBmdW5jdGlvbnMgb2YgUG9wdXAgSWNvbi5cbiAqL1xuY2xhc3MgUG9wdXBJY29uRG9tIHtcbiAgc3RhdGljICNGT05UX1NJWkVTID0ge1xuICAgIDE6IFwibWF4KDAuNjI1ZW0sIDEwcHgpXCIsXG4gICAgMjogXCJtYXgoMC43NWVtLCAxMnB4KVwiLFxuICAgIDM6IFwibWF4KDFlbSwgMTZweClcIixcbiAgICA0OiBcIm1heCgxLjI1ZW0sIDIwcHgpXCIsXG4gICAgNTogXCJtYXgoMS41ZW0sIDI0cHgpXCIsXG4gIH07XG5cbiAgI3dpbjtcblxuICAjcm9vdE5vZGU7XG4gICNwb3NpdGlvbiA9IHt9O1xuICAjZHJhZyA9IHt9O1xuXG4gIC8qKlxuICAgKiBTYXZlIHRoZSBzdGF0ZSBhdCBtb3VzZXVwIGV2ZW50IChpZSBhdCBzaG93aW5nIFBvcHVwIEljb24pLlxuICAgKi9cbiAgYXRNb3VzZXVwID0gbmV3IChjbGFzcyBBdE1vdXNldXAge1xuICAgICNvd25lcjtcbiAgICBzZWxlY3Rpb25UZXh0ID0gXCJcIjtcbiAgICAjX2VkaXRhYmxlTm9kZTtcbiAgICBjb25zdHJ1Y3Rvcihvd25lcikge1xuICAgICAgdGhpcy4jb3duZXIgPSBvd25lcjtcbiAgICB9XG4gICAgc2V0IGVkaXRhYmxlTm9kZSh2YWx1ZSkge1xuICAgICAgdGhpcy4jX2VkaXRhYmxlTm9kZSA9IHZhbHVlO1xuICAgICAgaWYgKHRoaXMuI19lZGl0YWJsZU5vZGUpIHtcbiAgICAgICAgdGhpcy4jb3duZXIuI3Jvb3ROb2RlLmNsYXNzTGlzdC5hZGQoXCJxcXMtZWRpdGFibGVcIik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLiNvd25lci4jcm9vdE5vZGUuY2xhc3NMaXN0LnJlbW92ZShcInFxcy1lZGl0YWJsZVwiKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZ2V0IGVkaXRhYmxlTm9kZSgpIHtcbiAgICAgIHJldHVybiB0aGlzLiNfZWRpdGFibGVOb2RlO1xuICAgIH1cbiAgICBfcmVzZXQoKSB7XG4gICAgICB0aGlzLnNlbGVjdGlvblRleHQgPSBcIlwiO1xuICAgICAgdGhpcy5lZGl0YWJsZU5vZGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuICB9KSh0aGlzKTtcblxuICAjX2NsaWNraW5nID0gZmFsc2U7XG4gIHNldCBjbGlja2luZyh2YWx1ZSkge1xuICAgIC8vIGBjbGlja2luZ2AgZmxhZyBwcmV2ZW50cyBQb3B1cCBJY29uIGZyb20gbW92aW5nIHVubmVjZXNzYXJpbHkgYW5kXG4gICAgLy8gaXMgdGhlbiBjbGVhcmVkIGF1dG9tYXRpY2FsbHkuXG4gICAgdGhpcy4jX2NsaWNraW5nID0gdmFsdWU7XG4gICAgaWYgKHRoaXMuI19jbGlja2luZykge1xuICAgICAgc2V0VGltZW91dCgoKSA9PiAodGhpcy4jX2NsaWNraW5nID0gZmFsc2UpKTtcbiAgICB9XG4gIH1cbiAgZ2V0IGNsaWNraW5nKCkge1xuICAgIHJldHVybiB0aGlzLiNfY2xpY2tpbmc7XG4gIH1cblxuICBjb25zdHJ1Y3Rvcih3aW4sIGNhbGxiYWNrT25DbGlja1NlYXJjaCwgY2FsbGJhY2tPbkNsaWNrUXVvdGUsIGNhbGxiYWNrT25DbGlja09wdGlvbnMpIHtcbiAgICB0aGlzLiN3aW4gPSB3aW47XG4gICAgdGhpcy4jY3JlYXRlKGNhbGxiYWNrT25DbGlja1NlYXJjaCwgY2FsbGJhY2tPbkNsaWNrUXVvdGUsIGNhbGxiYWNrT25DbGlja09wdGlvbnMpO1xuICB9XG5cbiAgI2NyZWF0ZShjYWxsYmFja09uQ2xpY2tTZWFyY2gsIGNhbGxiYWNrT25DbGlja1F1b3RlLCBjYWxsYmFja09uQ2xpY2tPcHRpb25zKSB7XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIENyZWF0ZXMgcm9vdCBIVE1MIGVsZW1lbnQgb2YgUG9wdXAgSWNvbi5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy4jcm9vdE5vZGUgPSB0aGlzLiN3aW4uZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICB0aGlzLiNyb290Tm9kZS5jbGFzc0xpc3QuYWRkKFwicXFzLXJvb3RcIiwgXCJxcXMtcG9wdXAtaWNvblwiKTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBDcmVhdGVzIGJ1dHRvbnMgaW4gUG9wdXAgSWNvbi5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgY29uc3QgY3JlYXRlQnV0dG9uID0gKGJ1dHRvbkNsYXNzLCBpbWFnZUNsYXNzLCBjbGlja0V2ZW50TGlzdGVuZXIpID0+IHtcbiAgICAgIGNvbnN0IGJ1dHRvbiA9IHRoaXMuI3Jvb3ROb2RlLmFwcGVuZENoaWxkKHRoaXMuI3dpbi5kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpKTtcbiAgICAgIGJ1dHRvbi5jbGFzc0xpc3QuYWRkKGJ1dHRvbkNsYXNzKTtcbiAgICAgIGJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgY2xpY2tFdmVudExpc3RlbmVyKTtcbiAgICAgIGNvbnN0IGltYWdlID0gYnV0dG9uLmFwcGVuZENoaWxkKHRoaXMuI3dpbi5kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaVwiKSk7XG4gICAgICBpbWFnZS5jbGFzc0xpc3QuYWRkKGltYWdlQ2xhc3MpO1xuICAgIH07XG5cbiAgICBjcmVhdGVCdXR0b24oXCJxcXMtc2VhcmNoLWJ1dHRvblwiLCBcInFxcy1zZWFyY2gtaWNvblwiLCAoZSkgPT4ge1xuICAgICAgdGhpcy5jbGlja2luZyA9IHRydWU7XG4gICAgICBjYWxsYmFja09uQ2xpY2tTZWFyY2goZSk7XG4gICAgfSk7XG5cbiAgICBjcmVhdGVCdXR0b24oXCJxcXMtcXVvdGUtYnV0dG9uXCIsIFwicXFzLXF1b3RlLWljb25cIiwgKGUpID0+IHtcbiAgICAgIHRoaXMuY2xpY2tpbmcgPSB0cnVlO1xuICAgICAgY2FsbGJhY2tPbkNsaWNrUXVvdGUoZSwgdGhpcy5hdE1vdXNldXAuZWRpdGFibGVOb2RlKTtcbiAgICB9KTtcblxuICAgIGNyZWF0ZUJ1dHRvbihcInFxcy1vcHRpb25zLWJ1dHRvblwiLCBcInFxcy1vcHRpb25zLWljb25cIiwgKGUpID0+IHtcbiAgICAgIHRoaXMuY2xpY2tpbmcgPSB0cnVlO1xuICAgICAgY2FsbGJhY2tPbkNsaWNrT3B0aW9ucyhlKTtcbiAgICB9KTtcblxuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBNYWtlcyBQb3B1cCBJY29uIGRyYWdnYWJsZS5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy4jcm9vdE5vZGUuc2V0QXR0cmlidXRlKFwiZHJhZ2dhYmxlXCIsIFwidHJ1ZVwiKTtcblxuICAgIGNvbnN0IERSQUdfVFlQRSA9IFwicXFzL3BvcHVwLWljb25cIjtcbiAgICB0aGlzLiN3aW4uZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJkcmFnb3ZlclwiLCAoZSkgPT4ge1xuICAgICAgaWYgKGUuZGF0YVRyYW5zZmVyLnR5cGVzLmluY2x1ZGVzKERSQUdfVFlQRSkpIHtcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdGhpcy4jcm9vdE5vZGUuYWRkRXZlbnRMaXN0ZW5lcihcImRyYWdzdGFydFwiLCAoZSkgPT4ge1xuICAgICAgZS5kYXRhVHJhbnNmZXIuc2V0RGF0YShEUkFHX1RZUEUsIFwiXCIpO1xuICAgICAgZS5kYXRhVHJhbnNmZXIuZWZmZWN0QWxsb3dlZCA9IFwibW92ZVwiO1xuXG4gICAgICBjb25zdCBjbGllbnRSZWN0ID0gdGhpcy4jcm9vdE5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICB0aGlzLiNkcmFnLm9mZnNldFggPSBjbGllbnRSZWN0LmxlZnQgLSBlLmNsaWVudFg7XG4gICAgICB0aGlzLiNkcmFnLm9mZnNldFkgPSBjbGllbnRSZWN0LnRvcCAtIGUuY2xpZW50WTtcbiAgICB9KTtcblxuICAgIHRoaXMuI3Jvb3ROb2RlLmFkZEV2ZW50TGlzdGVuZXIoXCJkcmFnZW5kXCIsIChlKSA9PiB7XG4gICAgICBjb25zdCBjbGllbnRMZWZ0ID0gZS5jbGllbnRYICsgdGhpcy4jZHJhZy5vZmZzZXRYO1xuICAgICAgY29uc3QgY2xpZW50VG9wID0gZS5jbGllbnRZICsgdGhpcy4jZHJhZy5vZmZzZXRZO1xuICAgICAgdGhpcy5zZXRQb3NpdGlvbihjbGllbnRMZWZ0LCBjbGllbnRUb3ApO1xuICAgIH0pO1xuXG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIC8vIFJlZmxlY3RzIG9wdGlvbnMgaW4gUG9wdXAgSWNvbiBzdHlsZS5cbiAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgdGhpcy5yZWZsZWN0T3B0aW9ucygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNob3dzIFBvcHVwIEljb24ncyBkb20gZWxlbWVudCwgYnV0IGl0cyBwb3NpdGlvbiBpcyBvZmYgc2NyZWVuLiBUaGlzIGlzXG4gICAqIG5lY2Vzc2FyeSB0byBnZXQgdGhlIHNpemUgb2YgUG9wdXAgSWNvbiBhbmQgdGhlIG9mZnNldHMgdG8gY2FsY3VsYXRlIGl0c1xuICAgKiBwb3NpdGlvbi4gQWZ0ZXIgY2FsY3VsYXRpbmcgdGhlIHBvc2l0aW9uIGF0IHdoaWNoIFBvcHVwIEljb24gc2hvdWxkIGFwcGVhcixcbiAgICogY2FsbCB7QGxpbmsgUG9wdXBJY29uRG9tLnNldFBvc2l0aW9uKCl9IHRvIGNvcnJlY3QgaXQuXG4gICAqXG4gICAqIEByZXR1cm5zIHshRE9NUmVjdH0gVGhlIHNpemUgb2YgUG9wdXAgSWNvbiwgdGhhdCBpcyByZXR1cm4gdmFsdWUgb2ZcbiAgICogICAgYEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KClgLlxuICAgKi9cbiAgc2hvdygpIHtcbiAgICBjb25zdCB0ZW1wUG9zaXRpb24gPSAtOTk5OTtcbiAgICB0aGlzLiNyb290Tm9kZS5zdHlsZS5sZWZ0ID0gdGVtcFBvc2l0aW9uICsgXCJweFwiO1xuICAgIHRoaXMuI3Jvb3ROb2RlLnN0eWxlLnRvcCA9IHRlbXBQb3NpdGlvbiArIFwicHhcIjtcbiAgICB0aGlzLiN3aW4uZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZCh0aGlzLiNyb290Tm9kZSk7XG5cbiAgICAvLyBDYWxjdWxhdGVzIG9mZnNldHMgdXNlZCBsYXRlciB0byBjb252ZXJ0IHRoZSBjbGllbnQgY29vcmRpbmF0ZXMgdG8gdGhlXG4gICAgLy8gcG9zaXRpb24gb2YgUG9wdXAgSWNvbi5cbiAgICBjb25zdCBjbGllbnRSZWN0ID0gdGhpcy4jcm9vdE5vZGUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgdGhpcy4jcG9zaXRpb24ub2Zmc2V0WCA9IHRlbXBQb3NpdGlvbiAtIChjbGllbnRSZWN0LmxlZnQgKyB0aGlzLiN3aW4uc2Nyb2xsWCk7XG4gICAgdGhpcy4jcG9zaXRpb24ub2Zmc2V0WSA9IHRlbXBQb3NpdGlvbiAtIChjbGllbnRSZWN0LnRvcCArIHRoaXMuI3dpbi5zY3JvbGxZKTtcblxuICAgIHJldHVybiBjbGllbnRSZWN0O1xuICB9XG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIHBvc2l0aW9uIG9mIFBvcHVwIEljb24uXG4gICAqXG4gICAqIFRoZSBwb3NpdGlvbiBtdXN0IGJlIHNwZWNpZmllZCBpbiB0aGUgXCJjbGllbnRcIiBjb29yZGluYXRlIHN5c3RlbS5cbiAgICpcbiAgICogQHNlZSBbQ29vcmRpbmF0ZSBzeXN0ZW1zXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9DU1MvQ1NTT01fVmlldy9Db29yZGluYXRlX3N5c3RlbXMpXG4gICAqIEBwYXJhbSB7IW51bWJlcn0gY2xpZW50TGVmdFxuICAgKiBAcGFyYW0geyFudW1iZXJ9IGNsaWVudFRvcFxuICAgKi9cbiAgc2V0UG9zaXRpb24oY2xpZW50TGVmdCwgY2xpZW50VG9wKSB7XG4gICAgLy8gUHJldmVudHMgUG9wdXAgSWNvbiBmcm9tIG92ZXJmbG93aW5nIHRoZSBsYXlvdXQgdmlld3BvcnQuXG4gICAgY29uc3QgeyB3aWR0aCwgaGVpZ2h0IH0gPSB0aGlzLiNyb290Tm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCBsZWZ0TWF4ID0gdGhpcy4jd2luLmlubmVyV2lkdGggLSB3aWR0aDtcbiAgICBjb25zdCB0b3BNYXggPSB0aGlzLiN3aW4uaW5uZXJIZWlnaHQgLSBoZWlnaHQ7XG4gICAgY29uc3QgY2xpZW50TGVmdENvcnJlY3RlZCA9IE1hdGgubWF4KDAsIE1hdGgubWluKGxlZnRNYXgsIGNsaWVudExlZnQpKTtcbiAgICBjb25zdCBjbGllbnRUb3BDb3JyZWN0ZWQgPSBNYXRoLm1heCgwLCBNYXRoLm1pbih0b3BNYXgsIGNsaWVudFRvcCkpO1xuXG4gICAgLy8gQ29udmVydHMgdGhlIGNsaWVudCBjb29yZGluYXRlcyB0byB0aGUgcG9zaXRpb24gcmVsYXRpdmUgdG8gdGhlIHRvcC1sZWZ0XG4gICAgLy8gY29ybmVyIG9mIHRoZSBjb250YWluaW5nIGJsb2NrLlxuICAgIGNvbnN0IGxlZnQgPSBjbGllbnRMZWZ0Q29ycmVjdGVkICsgdGhpcy4jd2luLnNjcm9sbFggKyB0aGlzLiNwb3NpdGlvbi5vZmZzZXRYO1xuICAgIGNvbnN0IHRvcCA9IGNsaWVudFRvcENvcnJlY3RlZCArIHRoaXMuI3dpbi5zY3JvbGxZICsgdGhpcy4jcG9zaXRpb24ub2Zmc2V0WTtcblxuICAgIHRoaXMuI3Jvb3ROb2RlLnN0eWxlLmxlZnQgPSBsZWZ0ICsgXCJweFwiO1xuICAgIHRoaXMuI3Jvb3ROb2RlLnN0eWxlLnRvcCA9IHRvcCArIFwicHhcIjtcbiAgfVxuXG4gIHJlZmxlY3RPcHRpb25zKCkge1xuICAgIHRoaXMuI3Jvb3ROb2RlLnN0eWxlLmZvbnRTaXplID0gUG9wdXBJY29uRG9tLiNGT05UX1NJWkVTW3Fxcy5vcHRpb25zLmljb25TaXplXTtcblxuICAgIGlmIChxcXMub3B0aW9ucy5vcHRpb25zQnV0dG9uKSB7XG4gICAgICB0aGlzLiNyb290Tm9kZS5jbGFzc0xpc3QuYWRkKFwicXFzLXNob3ctb3B0aW9ucy1idXR0b25cIik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuI3Jvb3ROb2RlLmNsYXNzTGlzdC5yZW1vdmUoXCJxcXMtc2hvdy1vcHRpb25zLWJ1dHRvblwiKTtcbiAgICB9XG4gIH1cblxuICBoaWRlKCkge1xuICAgIGlmICh0aGlzLiNyb290Tm9kZS5pc0Nvbm5lY3RlZCkge1xuICAgICAgdGhpcy4jcm9vdE5vZGUucGFyZW50Tm9kZS5yZW1vdmVDaGlsZCh0aGlzLiNyb290Tm9kZSk7XG4gICAgICB0aGlzLmF0TW91c2V1cC5fcmVzZXQoKTtcbiAgICB9XG4gIH1cbn1cbiIsImltcG9ydCAqIGFzIHFxcyBmcm9tIFwiLi9jb21tb24uanNcIjtcblxuLyoqXG4gKiBSZXByZXNlbnQgdGhlIGNvbm5lY3Rpb24gdG8gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciwgYW5kIHByb3ZpZGUgYWJpbGl0eSB0b1xuICogcmUtY29ubmVjdCB0byBpdCBhdXRvbWF0aWNhbGx5IGlmIGl0IGlzIGlkbGUgKGkuZS4gaXMgZGlzY29ubmVjdGVkKS5cbiAqL1xuZXhwb3J0IGNsYXNzIFBvcnRUb0JhY2tncm91bmQge1xuICAjcG9ydDtcblxuICAjcGFyYW1zID0ge1xuICAgIG5hbWU6IFwiXCIsXG4gICAgYXV0b0Nvbm5lY3Q6IGZhbHNlLFxuICAgIG9uQ29ubmVjdDogKCkgPT4ge30sXG4gICAgb25EaXNjb25uZWN0OiAoKSA9PiB7fSxcbiAgICBvbk1lc3NhZ2U6ICgpID0+IHt9LFxuICB9O1xuXG4gIC8qKlxuICAgKiBAcGFyYW0gez97bmFtZTo/c3RyaW5nPSxhdXRvQ29ubmVjdDo/Ym9vbGVhbj0sb25Db25uZWN0Oj9mdW5jdGlvbigpOnZvaWQ9LG9uRGlzY29ubmVjdDo/ZnVuY3Rpb24oKTp2b2lkPSxvbk1lc3NhZ2U6P2Z1bmN0aW9uKCEqKTp2b2lkPX09fSBwYXJhbXNcbiAgICovXG4gIGNvbnN0cnVjdG9yKHBhcmFtcykge1xuICAgIHRoaXMuI3BhcmFtcyA9IHFxcy5tZXJnZU9iamVjdCh0aGlzLiNwYXJhbXMsIHBhcmFtcyk7XG4gIH1cblxuICBjb25uZWN0KCkge1xuICAgIGlmICh0aGlzLiNwb3J0KSB7XG4gICAgICBxcXMubG9nZ2VyLndhcm4oXCJBbHJlYWR5IGNvbm5lY3RlZFwiLCB7IHBvcnQ6IHRoaXMuI3BvcnQgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuI3BvcnQgPSBjaHJvbWUucnVudGltZS5jb25uZWN0KHVuZGVmaW5lZCwgeyBuYW1lOiB0aGlzLiNwYXJhbXMubmFtZSB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gVGhlIGV4dGVuc2lvbiBtaWdodCBoYXZlIGJlZW4gcmVmcmVzaGVkLCBpbiB3aGljaCBjYXNlIGl0IHdpbGwgbmV2ZXIgYmVcbiAgICAgIC8vIGFibGUgdG8gY29ubmVjdCB0byBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGZyb20gdGhpcyBjb250ZXh0IGFnYWluLlxuICAgICAgcXFzLmxvZ2dlci5pbmZvKFxuICAgICAgICBcIuKaoCBUaGUgZXh0ZW5zaW9uIG1pZ2h0IGhhdmUgYmVlbiByZWZyZXNoZWQsIGluIHdoaWNoIGNhc2UgaXQgaXMgaW1wb3NzaWJsZSB0byBjb25uZWN0IHRvIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcIixcbiAgICAgICAgeyBlcnJvciB9XG4gICAgICApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBxcXMubG9nZ2VyLnN0YXRlKFwiQ29ubmVjdGVkIHRvIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcIiwgeyBwb3J0OiB0aGlzLiNwb3J0IH0pO1xuXG4gICAgdGhpcy4jcG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIoKHBvcnQpID0+IHRoaXMuI29uRGlzY29ubmVjdChwb3J0KSk7XG4gICAgdGhpcy4jcG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UsIHBvcnQpID0+IHRoaXMuI29uTWVzc2FnZShtZXNzYWdlLCBwb3J0KSk7XG5cbiAgICB0aGlzLiNwYXJhbXMub25Db25uZWN0KCk7XG4gIH1cblxuICBkaXNjb25uZWN0KCkge1xuICAgIGlmICh0aGlzLiNwb3J0KSB7XG4gICAgICB0aGlzLiNwb3J0LmRpc2Nvbm5lY3QoKTtcbiAgICAgIHRoaXMuI3BvcnQgPSB1bmRlZmluZWQ7XG4gICAgICBxcXMubG9nZ2VyLnN0YXRlKFwiRGlzY29ubmVjdGVkIGZyb20gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlclwiKTtcbiAgICB9XG4gIH1cblxuICByZWNvbm5lY3QoKSB7XG4gICAgdGhpcy5kaXNjb25uZWN0KCk7XG4gICAgdGhpcy5jb25uZWN0KCk7XG4gIH1cblxuICAvKipcbiAgICogQHJldHVybnMgeyFjaHJvbWUucnVudGltZS5Qb3J0fVxuICAgKi9cbiAgZ2V0IHBvcnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuI3BvcnQ7XG4gIH1cblxuICAvKipcbiAgICogQHBhcmFtIHshKn0gbWVzc2FnZVxuICAgKi9cbiAgcG9zdE1lc3NhZ2UobWVzc2FnZSkge1xuICAgIGlmICghdGhpcy4jY2hlY2tDb25uZWN0aW9uKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBxcXMucG9zdE1lc3NhZ2UodGhpcy4jcG9ydCwgbWVzc2FnZSk7XG4gIH1cblxuICAjY2hlY2tDb25uZWN0aW9uKCkge1xuICAgIGlmICghdGhpcy4jcG9ydCkge1xuICAgICAgaWYgKHRoaXMuI3BhcmFtcy5hdXRvQ29ubmVjdCkge1xuICAgICAgICB0aGlzLmNvbm5lY3QoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHFxcy5sb2dnZXIud2FybihcIkNvdWxkIG5vdCBzZW5kIG1lc3NhZ2UgdG8gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBiZWNhdXNlIHRoZSBwb3J0IGhhcyBhbHJlYWR5IGJlZW4gY2xvc2VkXCIpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gISF0aGlzLiNwb3J0O1xuICB9XG5cbiAgI29uRGlzY29ubmVjdChwb3J0KSB7XG4gICAgcXFzLmxvZ2dlci5jYWxsYmFjayhcIm9uRGlzY29ubmVjdCgpXCIsIHsgcG9ydCB9KTtcblxuICAgIHRoaXMuI3BvcnQgPSB1bmRlZmluZWQ7XG4gICAgcXFzLmxvZ2dlci5zdGF0ZShcIlBvcnQgdG8gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBoYXMgYmVlbiBjbG9zZWQgYnkgdGhlIG90aGVyIGVuZFwiKTtcblxuICAgIHRoaXMuI3BhcmFtcy5vbkRpc2Nvbm5lY3QoKTtcbiAgfVxuXG4gICNvbk1lc3NhZ2UobWVzc2FnZSwgcG9ydCkge1xuICAgIHFxcy5sb2dnZXIuY2FsbGJhY2soXCJvbk1lc3NhZ2UoKVwiLCB7IG1lc3NhZ2UsIHBvcnQgfSk7XG5cbiAgICB0aGlzLiNwYXJhbXMub25NZXNzYWdlKG1lc3NhZ2UpO1xuICB9XG59XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbl9fd2VicGFja19yZXF1aXJlX18ubiA9IChtb2R1bGUpID0+IHtcblx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG5cdFx0KCkgPT4gKG1vZHVsZVsnZGVmYXVsdCddKSA6XG5cdFx0KCkgPT4gKG1vZHVsZSk7XG5cdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsIHsgYTogZ2V0dGVyIH0pO1xuXHRyZXR1cm4gZ2V0dGVyO1xufTsiLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSAob2JqLCBwcm9wKSA9PiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwgcHJvcCkpIiwiLy8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gKGV4cG9ydHMpID0+IHtcblx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG5cdH1cblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbn07IiwiXCJ1c2Ugc3RyaWN0XCI7XG5cbmltcG9ydCAqIGFzIHFxcyBmcm9tIFwiLi9tb2R1bGVzL2NvbW1vbi5qc1wiO1xuaW1wb3J0IHsgUG9ydFRvQmFja2dyb3VuZCB9IGZyb20gXCIuL21vZHVsZXMvcG9ydF90b19iYWNrZ3JvdW5kLmpzXCI7XG5pbXBvcnQgeyBQb3B1cEljb24gfSBmcm9tIFwiLi9tb2R1bGVzL3BvcHVwX2ljb24uanNcIjtcblxuKGFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBJbml0aWFsaXplIGNvbW1vbiBtb2R1bGVzXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gIGF3YWl0IHFxcy5pbml0KHFxcy5TY3JpcHRJZC5DT05URU5UKTtcblxuICBpZiAoZG9jdW1lbnQuY29udGVudFR5cGUgIT09IFwidGV4dC9odG1sXCIgfHwgIWRvY3VtZW50LmJvZHkpIHtcbiAgICAvLyBDb250ZW50IHNjcmlwdHMgbWF5IGJlIGluamVjdGVkIGludG8gbm9uLUhUTUwgY29udGVudC4gKGUuZy4gaW1hZ2Uvc3ZnK3htbClcbiAgICBxcXMubG9nZ2VyLmluZm8oXCJFeGl0IHRoZSBjb250ZW50IHNjcmlwdHMgYmVjYXVzZSB0aGlzIGRvY3VtZW50IGlzIG5vdCBIVE1MXCIsIHtcbiAgICAgIGNvbnRlbnRUeXBlOiBkb2N1bWVudC5jb250ZW50VHlwZSxcbiAgICAgIGJvZHk6IGRvY3VtZW50LmJvZHksXG4gICAgfSk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIENvbnN0YW50c1xuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBjb25zdCBFRElUQUJMRV9OT0RFX1NFTEVDVE9SID0gXCJpbnB1dCwgdGV4dGFyZWFcIjtcblxuICAvLyBwcmV0dGllci1pZ25vcmVcbiAgY29uc3QgU0VBUkNIX0VOR0lORVMgPSBbXG4gICAgeyBob3N0bmFtZVBhdHRlcm46IC9ed3d3XFwuZ29vZ2xlXFwuW2Etel0rKFxcLlthLXpdKyk/JC9pICAgICAgICAgICAgLCBpbnB1dE5hbWU6IFwicVwiLCBmb3JtQWN0aW9uUGF0dGVybjogL15cXC9zZWFyY2gkLyAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgIHsgaG9zdG5hbWVQYXR0ZXJuOiAvXnNjaG9sYXJcXC5nb29nbGVcXC5bYS16XSsoXFwuW2Etel0rKT8kL2kgICAgICAgICwgaW5wdXROYW1lOiBcInFcIiwgZm9ybUFjdGlvblBhdHRlcm46IC9eXFwvc2Nob2xhciQvICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICB7IGhvc3RuYW1lUGF0dGVybjogL153d3dcXC5iaW5nXFwuY29tJC9pICAgICAgICAgICAgICAgICAgICAgICAgICAgICwgaW5wdXROYW1lOiBcInFcIiwgZm9ybUFjdGlvblBhdHRlcm46IC9eXFwvc2VhcmNoJC8gICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICB7IGhvc3RuYW1lUGF0dGVybjogL14od3d3fFthLXpdK3woW2Etel0rXFwuKT9zZWFyY2gpXFwueWFob29cXC5jb20kL2ksIGlucHV0TmFtZTogXCJwXCIsIGZvcm1BY3Rpb25QYXR0ZXJuOiAvXihodHRwczpcXC9cXC9bXi9dKyk/XFwvc2VhcmNoKDsuKyk/JC8gfSxcbiAgICB7IGhvc3RuYW1lUGF0dGVybjogL14od3d3fHNlYXJjaClcXC55YWhvb1xcLmNvXFwuanAkL2kgICAgICAgICAgICAgICAsIGlucHV0TmFtZTogXCJwXCIsIGZvcm1BY3Rpb25QYXR0ZXJuOiAvXihodHRwczpcXC9cXC9bXi9dKyk/XFwvc2VhcmNoJC8gICAgICAgfSxcbiAgICB7IGhvc3RuYW1lUGF0dGVybjogL15kdWNrZHVja2dvXFwuY29tJC9pICAgICAgICAgICAgICAgICAgICAgICAgICAgLCBpbnB1dE5hbWU6IFwicVwiLCBmb3JtQWN0aW9uUGF0dGVybjogL15cXC8kLyAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICBdO1xuXG4gIGNvbnN0IE1FU1NBR0VfSEFORExFUlMgPSB7XG4gICAgW3Fxcy5NZXNzYWdlVHlwZS5XRUxDT01FXTogb25XZWxjb21lLFxuICAgIFtxcXMuTWVzc2FnZVR5cGUuUFVUX1FVT1RFU106IG9uUHV0UXVvdGVzLFxuICB9O1xuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBWYXJpYWJsZXNcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgY29uc3QgY29udGVudElkID0ge1xuICAgIHRhYklkOiBOYU4sXG4gICAgZnJhbWVJZDogTmFOLFxuICAgIGluaXRpYWxpemUodGFiSWQsIGZyYW1lSWQpIHtcbiAgICAgIHRoaXMudGFiSWQgPSB0YWJJZDtcbiAgICAgIHRoaXMuZnJhbWVJZCA9IGZyYW1lSWQ7XG4gICAgfSxcbiAgICBpc0luaXRpYWxpemVkKCkge1xuICAgICAgcmV0dXJuIE51bWJlci5pc0ludGVnZXIodGhpcy50YWJJZCkgJiYgTnVtYmVyLmlzSW50ZWdlcih0aGlzLmZyYW1lSWQpO1xuICAgIH0sXG4gICAgdG9TdHJpbmcoKSB7XG4gICAgICByZXR1cm4gdGhpcy5pc0luaXRpYWxpemVkKCkgPyB0aGlzLnRhYklkICsgXCItXCIgKyB0aGlzLmZyYW1lSWQgOiBcIi1cIjtcbiAgICB9LFxuICB9O1xuXG4gIGNvbnN0IHBvcnRUb0JhY2tncm91bmQgPSBuZXcgUG9ydFRvQmFja2dyb3VuZCh7XG4gICAgbmFtZTogKHdpbmRvdyA9PT0gd2luZG93LnBhcmVudCA/IFwiXCIgOiBcIihpbiBmcmFtZSkgXCIpICsgZG9jdW1lbnQuVVJMLFxuICAgIGF1dG9Db25uZWN0OiB0cnVlLFxuICAgIG9uQ29ubmVjdDogb25Qb3J0VG9CYWNrZ3JvdW5kQ29ubmVjdCxcbiAgICBvbkRpc2Nvbm5lY3Q6IG9uUG9ydFRvQmFja2dyb3VuZERpc2Nvbm5lY3QsXG4gICAgb25NZXNzYWdlOiBvblBvcnRUb0JhY2tncm91bmRNZXNzYWdlLFxuICB9KTtcblxuICBjb25zdCBwb3B1cEljb24gPSBuZXcgUG9wdXBJY29uKHdpbmRvdywgb25DbGlja1BvcHVwSWNvblNlYXJjaCwgb25DbGlja1BvcHVwSWNvblF1b3RlLCBvbkNsaWNrUG9wdXBJY29uT3B0aW9ucyk7XG5cbiAgbGV0IGVkaXRhYmxlTm9kZVdpdGhTZWxlY3Rpb247XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIFN0YXJ0dXAgT3BlcmF0aW9uc1xuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBwb3J0VG9CYWNrZ3JvdW5kLmNvbm5lY3QoKTtcblxuICBjaHJvbWUucnVudGltZS5vbkNvbm5lY3QuYWRkTGlzdGVuZXIob25Db25uZWN0KTtcblxuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImZvY3VzXCIsIG9uV2luZG93Rm9jdXMpO1xuICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImJsdXJcIiwgb25XaW5kb3dCbHVyKTtcbiAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInNlbGVjdGlvbmNoYW5nZVwiLCBvblNlbGVjdGlvbkNoYW5nZSk7XG5cbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihvbk11dGF0aW9uKTtcbiAgb2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQsIHsgc3VidHJlZTogdHJ1ZSwgY2hpbGRMaXN0OiB0cnVlIH0pO1xuICBmb3IgKGNvbnN0IG5vZGUgb2YgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChFRElUQUJMRV9OT0RFX1NFTEVDVE9SKSkge1xuICAgIGFkZEV2ZW50TGlzdGVuZXJUb0VkaXRhYmxlTm9kZShub2RlKTtcbiAgfVxuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBFdmVudCBMaXN0ZW5lcnMgKEJhY2tncm91bmQgc2VydmljZSB3b3JrZXIpXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gIGZ1bmN0aW9uIG9uUG9ydFRvQmFja2dyb3VuZENvbm5lY3QoKSB7XG4gICAgcG9ydFRvQmFja2dyb3VuZC5wb3N0TWVzc2FnZSh7IHR5cGU6IHFxcy5NZXNzYWdlVHlwZS5IRUxMTyB9KTtcblxuICAgIHBvcHVwSWNvbi5lbmFibGUoKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uUG9ydFRvQmFja2dyb3VuZERpc2Nvbm5lY3QoKSB7XG4gICAgcG9wdXBJY29uLmRpc2FibGUoKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uUG9ydFRvQmFja2dyb3VuZE1lc3NhZ2UobWVzc2FnZSkge1xuICAgIE1FU1NBR0VfSEFORExFUlNbbWVzc2FnZS50eXBlXShtZXNzYWdlLCBwb3J0VG9CYWNrZ3JvdW5kLnBvcnQpO1xuICB9XG5cbiAgZnVuY3Rpb24gb25Db25uZWN0KHBvcnQpIHtcbiAgICBxcXMubG9nZ2VyLmNhbGxiYWNrKFwib25Db25uZWN0KClcIiwgeyBwb3J0IH0pO1xuXG4gICAgcG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uTWVzc2FnZShtZXNzYWdlLCBwb3J0KSB7XG4gICAgcXFzLmxvZ2dlci5jYWxsYmFjayhcIm9uTWVzc2FnZSgpXCIsIHsgbWVzc2FnZSwgcG9ydCB9KTtcblxuICAgIE1FU1NBR0VfSEFORExFUlNbbWVzc2FnZS50eXBlXShtZXNzYWdlLCBwb3J0KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uV2VsY29tZShtZXNzYWdlLCBfcG9ydCkge1xuICAgIGNvbnRlbnRJZC5pbml0aWFsaXplKG1lc3NhZ2UuaWRlbnRpdHkudGFiLmlkLCBtZXNzYWdlLmlkZW50aXR5LmZyYW1lSWQpO1xuICAgIHFxcy5sb2dnZXIuc2V0SWQoY29udGVudElkLnRvU3RyaW5nKCkpO1xuICAgIHFxcy5sb2dnZXIuc3RhdGUoXCJVcGRhdGUgY29udGVudCBpZGVudGlmaWVyXCIsIHsgY29udGVudElkIH0pO1xuICAgIG5vdGlmeVNlbGVjdGlvblVwZGF0ZWQoXCJjb250ZW50SWQuaW5pdGlhbGl6ZVwiKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uUHV0UXVvdGVzKF9tZXNzYWdlLCBfcG9ydCkge1xuICAgIGlmICghZWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbikge1xuICAgICAgcXFzLmxvZ2dlci5pbmZvKGBJZ25vcmUgJHtxcXMuQ29tbWFuZFR5cGUuUFVUX1FVT1RFU30gY29tbWFuZCBkdWUgdG8gbm8gZWRpdGFibGUgbm9kZSBzZWxlY3RlZCBgKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcHV0UXVvdGVzQXJvdW5kU2VsZWN0aW9uVGV4dChlZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uKTtcbiAgfVxuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBFdmVudCBMaXN0ZW5lcnMgKERPTSlcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgZnVuY3Rpb24gb25XaW5kb3dGb2N1cyhfZSkge1xuICAgIC8vIFJlY29ubmVjdCB0byByZWZyZXNoIHBvcnRcbiAgICBwb3J0VG9CYWNrZ3JvdW5kLnJlY29ubmVjdCgpO1xuXG4gICAgbm90aWZ5U2VsZWN0aW9uVXBkYXRlZChcIndpbmRvdy5mb2N1c1wiKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uV2luZG93Qmx1cihfZSkge1xuICAgIG5vdGlmeVNlbGVjdGlvblVwZGF0ZWQoXCJ3aW5kb3cuYmx1clwiKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uU2VsZWN0aW9uQ2hhbmdlKF9lKSB7XG4gICAgbm90aWZ5U2VsZWN0aW9uVXBkYXRlZChcImRvY3VtZW50LnNlbGVjdGlvbmNoYW5nZVwiKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uTXV0YXRpb24obXV0YXRpb25MaXN0LCBfb2JzZXJ2ZXIpIHtcbiAgICBmb3IgKGNvbnN0IG11dGF0aW9uIG9mIG11dGF0aW9uTGlzdCkge1xuICAgICAgaWYgKG11dGF0aW9uLnR5cGUgPT09IFwiY2hpbGRMaXN0XCIpIHtcbiAgICAgICAgZm9yIChjb25zdCBub2RlIG9mIG11dGF0aW9uLmFkZGVkTm9kZXMpIHtcbiAgICAgICAgICBpZiAobm9kZS5pc0Nvbm5lY3RlZCAmJiBub2RlIGluc3RhbmNlb2YgRWxlbWVudCkge1xuICAgICAgICAgICAgaWYgKG5vZGUubWF0Y2hlcyhFRElUQUJMRV9OT0RFX1NFTEVDVE9SKSkge1xuICAgICAgICAgICAgICBxcXMubG9nZ2VyLmluZm8oXCJFZGl0YWJsZSBub2RlIGhhcyBiZWVuIGFkZGVkXCIsIHsgbm9kZSB9KTtcbiAgICAgICAgICAgICAgYWRkRXZlbnRMaXN0ZW5lclRvRWRpdGFibGVOb2RlKG5vZGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yIChjb25zdCBkZXNjZW5kYW50Tm9kZSBvZiBub2RlLnF1ZXJ5U2VsZWN0b3JBbGwoRURJVEFCTEVfTk9ERV9TRUxFQ1RPUikpIHtcbiAgICAgICAgICAgICAgcXFzLmxvZ2dlci5pbmZvKFwiRWRpdGFibGUgbm9kZSBoYXMgYmVlbiBhZGRlZFwiLCB7IGRlc2NlbmRhbnROb2RlIH0pO1xuICAgICAgICAgICAgICBhZGRFdmVudExpc3RlbmVyVG9FZGl0YWJsZU5vZGUoZGVzY2VuZGFudE5vZGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIGFkZEV2ZW50TGlzdGVuZXJUb0VkaXRhYmxlTm9kZShlZGl0YWJsZU5vZGUpIHtcbiAgICBpZiAodHlwZW9mIGVkaXRhYmxlTm9kZS5zZWxlY3Rpb25TdGFydCAhPT0gXCJudW1iZXJcIikge1xuICAgICAgLy8gQW4gaW5wdXQgZmllbGQgdGhhdCBkb2VzIG5vdCBzdXBwb3J0IHNlbGVjdGlvbiBmZWF0dXJlIGlzIG5vdCBjb25zaWRlcmVkIGFzIGFuIFwiZWRpdGFibGUgbm9kZVwiLlxuICAgICAgLy8gU2VlIGFsc286IGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL2lucHV0Lmh0bWwjY29uY2VwdC1pbnB1dC1hcHBseVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChlZGl0YWJsZU5vZGUubWF0Y2hlcyhcIjpmb2N1c1wiKSkge1xuICAgICAgdXBkYXRlRWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbihlZGl0YWJsZU5vZGUsIFwiZWRpdGFibGUuaW5pdGlhbFwiKTtcbiAgICB9XG5cbiAgICBlZGl0YWJsZU5vZGUuYWRkRXZlbnRMaXN0ZW5lcihcImZvY3VzXCIsIChfZSkgPT4ge1xuICAgICAgdXBkYXRlRWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbihlZGl0YWJsZU5vZGUsIFwiZWRpdGFibGUuZm9jdXNcIik7XG4gICAgfSk7XG5cbiAgICBlZGl0YWJsZU5vZGUuYWRkRXZlbnRMaXN0ZW5lcihcImJsdXJcIiwgKF9lKSA9PiB7XG4gICAgICBpZiAoZG9jdW1lbnQuYWN0aXZlRWxlbWVudCAhPT0gZWRpdGFibGVOb2RlICYmIGVkaXRhYmxlTm9kZVdpdGhTZWxlY3Rpb24gPT09IGVkaXRhYmxlTm9kZSkge1xuICAgICAgICB1cGRhdGVFZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uKHVuZGVmaW5lZCwgXCJlZGl0YWJsZS5ibHVyXCIpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgZWRpdGFibGVOb2RlLmFkZEV2ZW50TGlzdGVuZXIoXCJzZWxlY3RcIiwgKF9lKSA9PiB7XG4gICAgICB1cGRhdGVFZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uKGVkaXRhYmxlTm9kZSwgXCJlZGl0YWJsZS5zZWxlY3RcIik7XG4gICAgfSk7XG5cbiAgICBlZGl0YWJsZU5vZGUuYWRkRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgKGUpID0+IHtcbiAgICAgIGlmIChcbiAgICAgICAgcXFzLm9wdGlvbnMuYXV0b1N1cnJvdW5kICYmXG4gICAgICAgIGUua2V5ID09PSAnXCInICYmXG4gICAgICAgIGUuY2FuY2VsYWJsZSAmJlxuICAgICAgICAhZS5pc0NvbXBvc2luZyAmJlxuICAgICAgICAhZS5jdHJsS2V5ICYmXG4gICAgICAgICFlLmFsdEtleSAmJlxuICAgICAgICAhZS5tZXRhS2V5ICYmXG4gICAgICAgICFlLnJlcGVhdFxuICAgICAgKSB7XG4gICAgICAgIGlmIChwdXRRdW90ZXNBcm91bmRTZWxlY3Rpb25UZXh0KGVkaXRhYmxlTm9kZSkpIHtcbiAgICAgICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBFdmVudCBMaXN0ZW5lcnMgKFBvcHVwSWNvbilcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgZnVuY3Rpb24gb25DbGlja1BvcHVwSWNvblNlYXJjaChlKSB7XG4gICAgcG9ydFRvQmFja2dyb3VuZC5wb3N0TWVzc2FnZSh7XG4gICAgICB0eXBlOiBxcXMuTWVzc2FnZVR5cGUuRE9fUVVPVEVEX1NFQVJDSCxcbiAgICAgIGtleVN0YXRlOiBuZXcgcXFzLkhvd1RvT3BlbkxpbmsuS2V5U3RhdGUoZS5jdHJsS2V5LCBlLnNoaWZ0S2V5LCBlLm1ldGFLZXkpLFxuICAgICAgc2VsZWN0aW9uVGV4dDogcXFzLmZpbHRlclNlbGVjdGlvblRleHQocXFzLmdldFNlbGVjdGlvbih3aW5kb3cpLnRvU3RyaW5nKCkpLFxuICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gb25DbGlja1BvcHVwSWNvblF1b3RlKF9lLCBlZGl0YWJsZU5vZGUpIHtcbiAgICAvLyBVc2VzIGBlZGl0YWJsZU5vZGVgIHNwZWNpZmllZCBhcyBhbiBhcmd1bWVudCBvZiB0aGUgZXZlbnQgaW5zdGVhZCBvZlxuICAgIC8vIGBlZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uYCwgYmVjYXVzZSBgZWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbmAgbWF5IGJlXG4gICAgLy8gYWxyZWFkeSBjbGVhcmVkIG9uIGBibHVyYCBldmVudCBjYXVzZWQgYnkgY2xpY2tpbmcgdGhlIGJ1dHRvbi5cbiAgICBpZiAoIWVkaXRhYmxlTm9kZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBwdXRRdW90ZXNBcm91bmRTZWxlY3Rpb25UZXh0KGVkaXRhYmxlTm9kZSk7XG4gIH1cblxuICBmdW5jdGlvbiBvbkNsaWNrUG9wdXBJY29uT3B0aW9ucyhlKSB7XG4gICAgcG9ydFRvQmFja2dyb3VuZC5wb3N0TWVzc2FnZSh7XG4gICAgICB0eXBlOiBxcXMuTWVzc2FnZVR5cGUuT1BFTl9PUFRJT05TX1BBR0UsXG4gICAgICBrZXlTdGF0ZTogbmV3IHFxcy5Ib3dUb09wZW5MaW5rLktleVN0YXRlKGUuY3RybEtleSwgZS5zaGlmdEtleSwgZS5tZXRhS2V5KSxcbiAgICAgIGRlZmF1bHRIb3dUb09wZW5MaW5rOiBxcXMuSG93VG9PcGVuTGluay5ORVdfVEFCX0FDVElWRSxcbiAgICB9KTtcbiAgfVxuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBGdW5jdGlvbnNcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgZnVuY3Rpb24gdXBkYXRlRWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbihlZGl0YWJsZU5vZGUsIHJlYXNvbikge1xuICAgIGVkaXRhYmxlTm9kZVdpdGhTZWxlY3Rpb24gPVxuICAgICAgZWRpdGFibGVOb2RlICYmXG4gICAgICBlZGl0YWJsZU5vZGUubWF0Y2hlcyhcIjpmb2N1c1wiKSAmJlxuICAgICAgIWVkaXRhYmxlTm9kZS5kaXNhYmxlZCAmJlxuICAgICAgIWVkaXRhYmxlTm9kZS5yZWFkT25seSAmJlxuICAgICAgZWRpdGFibGVOb2RlLnZhbHVlLnN1YnN0cmluZyhlZGl0YWJsZU5vZGUuc2VsZWN0aW9uU3RhcnQsIGVkaXRhYmxlTm9kZS5zZWxlY3Rpb25FbmQpID09PVxuICAgICAgICBxcXMuZ2V0U2VsZWN0aW9uKHdpbmRvdykudG9TdHJpbmcoKVxuICAgICAgICA/IGVkaXRhYmxlTm9kZVxuICAgICAgICA6IHVuZGVmaW5lZDtcblxuICAgIHFxcy5sb2dnZXIuc3RhdGUoXCJVcGRhdGUgZWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvblwiLCB7XG4gICAgICByZWFzb24sXG4gICAgICBlZGl0YWJsZTogISFlZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uLFxuICAgICAgdGV4dDogZWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbiA/IHFxcy5maWx0ZXJTZWxlY3Rpb25UZXh0KGVkaXRhYmxlTm9kZVdpdGhTZWxlY3Rpb24udmFsdWUpIDogXCJOL0FcIixcbiAgICAgIHNlbGVjdGlvblN0YXJ0OiBlZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uID8gZWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbi5zZWxlY3Rpb25TdGFydCA6IFwiTi9BXCIsXG4gICAgICBzZWxlY3Rpb25EaXJlY3Rpb246IGVkaXRhYmxlTm9kZVdpdGhTZWxlY3Rpb24gPyBlZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uLnNlbGVjdGlvbkRpcmVjdGlvbiA6IFwiTi9BXCIsXG4gICAgICBlZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uLFxuICAgIH0pO1xuXG4gICAgcG9wdXBJY29uLnNldEVkaXRhYmxlTm9kZShlZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uKTtcblxuICAgIG5vdGlmeVNlbGVjdGlvblVwZGF0ZWQocmVhc29uKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG5vdGlmeVNlbGVjdGlvblVwZGF0ZWQocmVhc29uKSB7XG4gICAgY29uc3QgYmx1ciA9IHJlYXNvbi5lbmRzV2l0aChcIi5ibHVyXCIpO1xuICAgIGlmIChjb250ZW50SWQuaXNJbml0aWFsaXplZCgpICYmIChibHVyIHx8IGRvY3VtZW50Lmhhc0ZvY3VzKCkpKSB7XG4gICAgICBjb25zdCBtZXNzYWdlID0ge1xuICAgICAgICB0eXBlOiBxcXMuTWVzc2FnZVR5cGUuTk9USUZZX1NFTEVDVElPTl9VUERBVEVELFxuICAgICAgICByZWFzb246IHJlYXNvbixcbiAgICAgICAgc2VsZWN0aW9uOiB7XG4gICAgICAgICAgdGV4dDogcXFzLmZpbHRlclNlbGVjdGlvblRleHQocXFzLmdldFNlbGVjdGlvbih3aW5kb3cpLnRvU3RyaW5nKCkpLFxuICAgICAgICAgIGVkaXRhYmxlOiAhIWVkaXRhYmxlTm9kZVdpdGhTZWxlY3Rpb24sXG4gICAgICAgICAgc2VhcmNoYWJsZTogaXNTZWFyY2hhYmxlKGVkaXRhYmxlTm9kZVdpdGhTZWxlY3Rpb24pLFxuICAgICAgICAgIGJsdXI6IGJsdXIsXG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgICAgcG9ydFRvQmFja2dyb3VuZC5wb3N0TWVzc2FnZShtZXNzYWdlKTtcbiAgICAgIHFxcy5sb2dnZXIuaW5mbyhgU2VuZCAnJHttZXNzYWdlLnR5cGV9JyBtZXNzYWdlIHRvIGJhY2tncm91bmQgc2VydmljZSB3b3JrZXJgLCB7IG1lc3NhZ2UgfSk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gcHV0UXVvdGVzQXJvdW5kU2VsZWN0aW9uVGV4dChlZGl0YWJsZU5vZGUpIHtcbiAgICBpZiAoZWRpdGFibGVOb2RlLmRpc2FibGVkIHx8IGVkaXRhYmxlTm9kZS5yZWFkT25seSkge1xuICAgICAgcXFzLmxvZ2dlci5pbmZvKGBJZ25vcmUgJHtxcXMuQ29tbWFuZFR5cGUuUFVUX1FVT1RFU30gY29tbWFuZCBiZWNhdXNlIHRoZSBpbnB1dCBmaWVsZCBjYW4gbm90IGJlIGNoYW5nZWRgLCB7XG4gICAgICAgIGRpc2FibGVkOiBlZGl0YWJsZU5vZGUuZGlzYWJsZWQsXG4gICAgICAgIHJlYWRPbmx5OiBlZGl0YWJsZU5vZGUucmVhZE9ubHksXG4gICAgICB9KTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG5cbiAgICBjb25zdCBzZWxlY3Rpb25UZXh0ID0gcXFzLmZpbHRlclNlbGVjdGlvblRleHQoXG4gICAgICBlZGl0YWJsZU5vZGUudmFsdWUuc3Vic3RyaW5nKGVkaXRhYmxlTm9kZS5zZWxlY3Rpb25TdGFydCwgZWRpdGFibGVOb2RlLnNlbGVjdGlvbkVuZClcbiAgICApO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0ID0gcXFzLm5vcm1hbGl6ZVNlbGVjdGlvblRleHQoc2VsZWN0aW9uVGV4dCk7XG4gICAgaWYgKCFxcXMuaXNOb3JtYWxpemVkU2VsZWN0aW9uVGV4dFZhbGlkKG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0KSkge1xuICAgICAgcXFzLmxvZ2dlci5pbmZvKGBJZ25vcmUgJHtxcXMuQ29tbWFuZFR5cGUuUFVUX1FVT1RFU30gY29tbWFuZCBkdWUgdG8gdW5leHBlY3RlZCBzZWxlY3Rpb24gdGV4dGAsIHtcbiAgICAgICAgc2VsZWN0aW9uVGV4dCxcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxuICAgIHJlcGxhY2VTZWxlY3Rpb25UZXh0KGVkaXRhYmxlTm9kZSwgcXFzLnF1b3RlVGV4dChub3JtYWxpemVkU2VsZWN0aW9uVGV4dCkpO1xuXG4gICAgaWYgKHFxcy5vcHRpb25zLmF1dG9FbnRlciAmJiBpc1NlYXJjaGFibGUoZWRpdGFibGVOb2RlKSkge1xuICAgICAgaWYgKHFxcy5vcHRpb25zLmF1dG9Db3B5KSB7XG4gICAgICAgIHdpbmRvdy5uYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dChub3JtYWxpemVkU2VsZWN0aW9uVGV4dCk7XG4gICAgICB9XG4gICAgICBlZGl0YWJsZU5vZGUuZm9ybS5zdWJtaXQoKTtcbiAgICB9XG5cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIGZ1bmN0aW9uIHJlcGxhY2VTZWxlY3Rpb25UZXh0KGVkaXRhYmxlTm9kZSwgcmVwbGFjZW1lbnQpIHtcbiAgICBxcXMubG9nZ2VyLmFzc2VydChcbiAgICAgIHJlcGxhY2VtZW50Lmxlbmd0aCA+PSAzICYmIHJlcGxhY2VtZW50LmNoYXJBdCgwKSA9PT0gJ1wiJyAmJiByZXBsYWNlbWVudC5jaGFyQXQocmVwbGFjZW1lbnQubGVuZ3RoIC0gMSkgPT09ICdcIicsXG4gICAgICBcIlJlcGxhY2VtZW50IGZvciBzZWxlY3Rpb24gdGV4dCBpcyB1bmV4cGVjdGVkXCIsXG4gICAgICB7IHJlcGxhY2VtZW50IH1cbiAgICApO1xuXG4gICAgY29uc3Qgc3BhY2VQYXR0ZXJuID0gL1xccy87XG5cbiAgICBjb25zdCB0ZXh0ID0gZWRpdGFibGVOb2RlLnZhbHVlO1xuICAgIGxldCBvbGRTZWxlY3Rpb25TdGFydCA9IGVkaXRhYmxlTm9kZS5zZWxlY3Rpb25TdGFydDtcbiAgICBsZXQgb2xkU2VsZWN0aW9uRW5kID0gZWRpdGFibGVOb2RlLnNlbGVjdGlvbkVuZDtcbiAgICBpZiAoXG4gICAgICBvbGRTZWxlY3Rpb25TdGFydCA+IDAgJiZcbiAgICAgIHFxcy5RVU9UQVRJT05fTUFSS1MuaW5jbHVkZXModGV4dC5jaGFyQXQob2xkU2VsZWN0aW9uU3RhcnQgLSAxKSkgJiZcbiAgICAgICFzcGFjZVBhdHRlcm4udGVzdCh0ZXh0LmNoYXJBdChvbGRTZWxlY3Rpb25TdGFydCkpXG4gICAgKSB7XG4gICAgICBvbGRTZWxlY3Rpb25TdGFydC0tO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICBvbGRTZWxlY3Rpb25FbmQgPCB0ZXh0Lmxlbmd0aCAmJlxuICAgICAgcXFzLlFVT1RBVElPTl9NQVJLUy5pbmNsdWRlcyh0ZXh0LmNoYXJBdChvbGRTZWxlY3Rpb25FbmQpKSAmJlxuICAgICAgIXNwYWNlUGF0dGVybi50ZXN0KHRleHQuY2hhckF0KG9sZFNlbGVjdGlvbkVuZCAtIDEpKVxuICAgICkge1xuICAgICAgb2xkU2VsZWN0aW9uRW5kKys7XG4gICAgfVxuXG4gICAgbGV0IHRlbXBSZXBsYWNlbWVudCA9IHJlcGxhY2VtZW50O1xuICAgIGxldCBzZWxlY3Rpb25TdGFydERlbHRhID0gMTtcbiAgICBsZXQgc2VsZWN0aW9uRW5kRGVsdGEgPSAtMTtcbiAgICBpZiAob2xkU2VsZWN0aW9uU3RhcnQgPiAwICYmICFzcGFjZVBhdHRlcm4udGVzdCh0ZXh0LmNoYXJBdChvbGRTZWxlY3Rpb25TdGFydCAtIDEpKSkge1xuICAgICAgdGVtcFJlcGxhY2VtZW50ID0gXCIgXCIgKyB0ZW1wUmVwbGFjZW1lbnQ7XG4gICAgICBzZWxlY3Rpb25TdGFydERlbHRhKys7XG4gICAgfVxuICAgIGlmIChvbGRTZWxlY3Rpb25FbmQgPCB0ZXh0Lmxlbmd0aCAmJiAhc3BhY2VQYXR0ZXJuLnRlc3QodGV4dC5jaGFyQXQob2xkU2VsZWN0aW9uRW5kKSkpIHtcbiAgICAgIHRlbXBSZXBsYWNlbWVudCA9IHRlbXBSZXBsYWNlbWVudCArIFwiIFwiO1xuICAgICAgc2VsZWN0aW9uRW5kRGVsdGEtLTtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdTZWxlY3Rpb25TdGFydCA9IG9sZFNlbGVjdGlvblN0YXJ0ICsgc2VsZWN0aW9uU3RhcnREZWx0YTtcbiAgICBjb25zdCBuZXdTZWxlY3Rpb25FbmQgPSBvbGRTZWxlY3Rpb25TdGFydCArIHRlbXBSZXBsYWNlbWVudC5sZW5ndGggKyBzZWxlY3Rpb25FbmREZWx0YTtcblxuICAgIGVkaXRhYmxlTm9kZS5mb2N1cygpO1xuICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAvLyBBdm9pZCBDaHJvbWl1bSBjcmFzaGluZ1xuICAgIC8vICAgaHR0cHM6Ly9naXRodWIuY29tL2hpZ2FtYXlhL2Nocm9tZS1idWctMjAyMjEwMThcbiAgICAvLyAgIGh0dHBzOi8vYnVncy5jaHJvbWl1bS5vcmcvcC9jaHJvbWl1bS9pc3N1ZXMvZGV0YWlsP2lkPTEzNzYwMzdcbiAgICAvL1xuICAgIC8vZWRpdGFibGVOb2RlLnNldFJhbmdlVGV4dCh0ZW1wUmVwbGFjZW1lbnQsIG9sZFNlbGVjdGlvblN0YXJ0LCBvbGRTZWxlY3Rpb25FbmQpO1xuICAgIGVkaXRhYmxlTm9kZS52YWx1ZSA9IHRleHQuc3Vic3RyaW5nKDAsIG9sZFNlbGVjdGlvblN0YXJ0KSArIHRlbXBSZXBsYWNlbWVudCArIHRleHQuc3Vic3RyaW5nKG9sZFNlbGVjdGlvbkVuZCk7XG4gICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgIGVkaXRhYmxlTm9kZS5zZXRTZWxlY3Rpb25SYW5nZShuZXdTZWxlY3Rpb25TdGFydCwgbmV3U2VsZWN0aW9uRW5kLCBlZGl0YWJsZU5vZGUuc2VsZWN0aW9uRGlyZWN0aW9uKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGlzU2VhcmNoYWJsZShlZGl0YWJsZU5vZGUpIHtcbiAgICBpZiAoIWVkaXRhYmxlTm9kZSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBlZGl0YWJsZU5vZGUucXFzID8/PSB7fTtcbiAgICBpZiAoIU9iamVjdC5oYXNPd24oZWRpdGFibGVOb2RlLnFxcywgXCJpc1NlYXJjaGFibGVcIikpIHtcbiAgICAgIGVkaXRhYmxlTm9kZS5xcXMuaXNTZWFyY2hhYmxlID0gKCgpID0+IHtcbiAgICAgICAgaWYgKGVkaXRhYmxlTm9kZSBpbnN0YW5jZW9mIEhUTUxJbnB1dEVsZW1lbnQpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IHNlYXJjaEVuZ2luZSBvZiBTRUFSQ0hfRU5HSU5FUykge1xuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICBzZWFyY2hFbmdpbmUuaG9zdG5hbWVQYXR0ZXJuLnRlc3Qod2luZG93LmxvY2F0aW9uLmhvc3RuYW1lKSAmJlxuICAgICAgICAgICAgICBzZWFyY2hFbmdpbmUuaW5wdXROYW1lID09PSBlZGl0YWJsZU5vZGUubmFtZSAmJlxuICAgICAgICAgICAgICBzZWFyY2hFbmdpbmUuZm9ybUFjdGlvblBhdHRlcm4udGVzdChlZGl0YWJsZU5vZGUuZm9ybT8uZ2V0QXR0cmlidXRlKFwiYWN0aW9uXCIpKVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9KSgpO1xuICAgIH1cbiAgICByZXR1cm4gZWRpdGFibGVOb2RlLnFxcy5pc1NlYXJjaGFibGU7XG4gIH1cbn0pKCk7XG4iLCIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCB7fTsiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsImNvbmZpZyIsIlNjcmlwdElkIiwiQUNUSU9OIiwiQkFDS0dST1VORCIsIkNPTlRFTlQiLCJPUFRJT05TIiwiQ29tbWFuZFR5cGUiLCJET19RVU9URURfU0VBUkNIIiwiUFVUX1FVT1RFUyIsIk1lc3NhZ2VUeXBlIiwiSEVMTE8iLCJOT1RJRllfU0VMRUNUSU9OX1VQREFURUQiLCJPUEVOX09QVElPTlNfUEFHRSIsIldFTENPTUUiLCJHRVRfU0VMRUNUSU9OIiwiTk9USUZZX1NFTEVDVElPTiIsIlFVT1RBVElPTl9NQVJLUyIsIlNFTEVDVElPTl9URVhUX01BWF9MRU5HVEgiLCJTRUxFQ1RJT05fVEVYVF9UT09fTE9OR19NQVJLRVIiLCJsb2dnZXIiLCJvcHRpb25zIiwiSG93VG9PcGVuTGluayIsImZpbHRlclNlbGVjdGlvblRleHQiLCJzZWxlY3Rpb25UZXh0IiwibGVuZ3RoIiwibm9ybWFsaXplU2VsZWN0aW9uVGV4dCIsInJlcGxhY2VBbGwiLCJSZWdFeHAiLCJ0cmltIiwiaXNOb3JtYWxpemVkU2VsZWN0aW9uVGV4dFZhbGlkIiwibm9ybWFsaXplZFNlbGVjdGlvblRleHQiLCJxdW90ZVRleHQiLCJ0ZXh0IiwiY2xvbmVEdG8iLCJvYmoiLCJKU09OIiwicGFyc2UiLCJzdHJpbmdpZnkiLCJtZXJnZU9iamVjdCIsInRhcmdldCIsInNvdXJjZSIsIk9iamVjdCIsImZyb21FbnRyaWVzIiwiZW50cmllcyIsImZpbHRlciIsInYiLCJ1bmRlZmluZWQiLCJhZGRET01Db250ZW50TG9hZGVkRXZlbnRMaXN0ZW5lciIsIndpbiIsImxpc3RlbmVyIiwiZG9jdW1lbnQiLCJyZWFkeVN0YXRlIiwiYWRkRXZlbnRMaXN0ZW5lciIsInF1ZXVlTWljcm90YXNrIiwiYWRkTG9hZENvbXBsZXRlZEV2ZW50TGlzdGVuZXIiLCJpbmplY3RJMThOTWVzc2FnZXNJbkh0bWwiLCJkb2MiLCJJMThOX1RBUkdFVFMiLCJlbGVtZW50IiwicXVlcnlTZWxlY3RvckFsbCIsInN1YnN0aXR1dGlvbnMiLCJyZXN1bHQiLCJhcmdzIiwiZGF0YXNldCIsImkxOG5BcmdzIiwiaWRzIiwic3BsaXQiLCJpZCIsImFyZ0VsZW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsImFyZ1RhcmdldCIsImkxOG5UYXJnZXQiLCJhc3NlcnQiLCJpbmNsdWRlcyIsInB1c2giLCJjaHJvbWUiLCJpMThuIiwiZ2V0TWVzc2FnZSIsImkxOG5OYW1lIiwiZ2V0U2VsZWN0aW9uIiwiZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5Iiwic2VsZWN0aW9uIiwicmFuZ2VDb3VudCIsInJhbmdlIiwiZ2V0UmFuZ2VBdCIsInN0YXJ0Q29udGFpbmVyIiwiZW5kQ29udGFpbmVyIiwiY29tbW9uQW5jZXN0b3JDb250YWluZXIiLCJFbGVtZW50Iiwic2hhZG93Um9vdCIsImVsZW1lbnRzV2l0aFNoYWRvd1Jvb3QiLCJBcnJheSIsInByb3RvdHlwZSIsImNhbGwiLCJwb3N0TWVzc2FnZSIsInBvcnQiLCJtZXNzYWdlIiwiZXJyb3IiLCJ3YXJuIiwiZ2V0QWN0aXZlVGFiIiwidGFiIiwidGFicyIsInF1ZXJ5IiwiYWN0aXZlIiwiY3VycmVudFdpbmRvdyIsImNyZWF0ZU5ld1RhYiIsInBhcmFtcyIsImNyZWF0ZSIsIndpbmRvd0lkIiwib3BlbmVyVGFiSWQiLCJpbmRleCIsInVybCIsImNyZWF0ZU5ld1dpbmRvdyIsIndpbmRvd3MiLCJnZXRDdXJyZW50Iiwic3RhdGUiLCJkb1F1b3RlZFNlYXJjaCIsInNlYXJjaFRleHQiLCJrZXlTdGF0ZSIsImhvd1RvT3BlbkxpbmsiLCJkZWNpZGUiLCJkaXNwb3NpdGlvbiIsIkRpc3Bvc2l0aW9uIiwiTkVXX1RBQiIsIm5ld1RhYiIsInNlYXJjaCIsInRhYklkIiwidXBkYXRlIiwib3BlbkxpbmsiLCJkZWZhdWx0SG93VG9PcGVuTGluayIsIkNVUlJFTlRfVEFCIiwiTkVXX1dJTkRPVyIsIm9wZW5PcHRpb25zUGFnZSIsInJ1bnRpbWUiLCJnZXRVUkwiLCJvcGVuU2VhcmNoRW5naW5lU2V0dGluZ3MiLCJvcGVuU2hvcnRjdXRzU2V0dGluZ3MiLCJMb2dnZXIiLCJPcHRpb25zIiwiaW5pdCIsInNjcmlwdElkIiwiY2hlY2tPc0lzTWFjIiwiU1RPUkFHRV9LRVkiLCJzdG9yYWdlIiwibG9jYWwiLCJpc01hYyIsImdldFBsYXRmb3JtSW5mbyIsIm9zIiwic2V0IiwiZ2V0IiwiS2V5U3RhdGUiLCJjdHJsS2V5Iiwic2hpZnRLZXkiLCJjb25zdHJ1Y3RvciIsIm1ldGFLZXkiLCJlcXVhbHMiLCJvdGhlciIsIk5FV19UQUJfQUNUSVZFIiwiTkVXX1RBQl9JTkFDVElWRSIsInNldElkIiwiaW5mbyIsIm91dHB1dCIsImNhbGxiYWNrIiwiYXNzZXJ0aW9uIiwiY29uc29sZUFwaSIsImhlYWRlciIsImxvZ0VuYWJsZWQiLCJvcHRpb25hbEFyZ3MiLCJhdCIsImtleSIsInZhbHVlIiwicG9wIiwiY29uc29sZSIsInN5bmMiLCJVUERBVEVEX0FUX0tFWSIsIkRFRkFVTFRfVkFMVUVTIiwiSUNPTl9TSVpFX01JTiIsIklDT05fU0laRV9NQVgiLCJJVEVNUyIsIm5hbWUiLCJkZWZhdWx0VmFsdWUiLCJ2YWxpZGF0b3IiLCJ2YWx1ZXMiLCJkZWZpbmVPcHRpb25zIiwiZGVmaW5lUHJvcGVydHkiLCJFcnJvciIsImNhY2hlIiwidXBkYXRlU3RvcmFnZSIsIm9uQ2hhbmdlZCIsImxpc3RlbmVycyIsImFkZExpc3RlbmVyIiwiX2ZpcmUiLCJhc3NpZ24iLCJjaGFuZ2VzIiwiYXJlYU5hbWUiLCJvbkNoYW5nZWRMaXN0ZW5lciIsInJlc2V0IiwiRGF0ZSIsIm5vdyIsImhhc093biIsIm5ld1ZhbHVlIiwicXFzIiwiUG9wdXBJY29uIiwiZG9tIiwiZWRpdGFibGVOb2RlIiwiZW5hYmxlZCIsIm1vdXNlTW92ZW1lbnQiLCJwcmV2WCIsInByZXZZIiwiaXNGb3J3YXJkIiwiY2FsbGJhY2tPbkNsaWNrU2VhcmNoIiwiY2FsbGJhY2tPbkNsaWNrUXVvdGUiLCJjYWxsYmFja09uQ2xpY2tPcHRpb25zIiwiUG9wdXBJY29uRG9tIiwiZG9jdW1lbnRFbGVtZW50IiwiZSIsIm9uTW91c2VNb3ZlIiwib25Nb3VzZVVwIiwib25TZWxlY3Rpb25DaGFuZ2UiLCJvbk9wdGlvbnNDaGFuZ2VkIiwic2V0RWRpdGFibGVOb2RlIiwiZW5hYmxlIiwiZGlzYWJsZSIsImhpZGUiLCJUSFJFU0hPTEQiLCJtb3ZlbWVudFgiLCJjbGllbnRYIiwibW92ZW1lbnRZIiwiY2xpZW50WSIsIk1hdGgiLCJhYnMiLCJNT1VTRV9MRUZUX0JVVFRPTiIsImJ1dHRvbiIsInNob3ciLCJfZSIsInRvU3RyaW5nIiwicmVmbGVjdE9wdGlvbnMiLCJwb3B1cEljb24iLCJtb3VzZUNsaWVudFgiLCJtb3VzZUNsaWVudFkiLCJzZXRUaW1lb3V0IiwiYXRNb3VzZXVwIiwiY2xpY2tpbmciLCJjbGllbnRSZWN0IiwiY2xpZW50TGVmdCIsIkdPT0dMRV9UUkFOU0xBVEVfUE9QVVBfU0laRSIsImxlZnRPZmZzZXQiLCJhdm9pZFNlbGVjdGlvbiIsIndpZHRoIiwic2VsZWN0aW9uRGlyZWN0aW9uIiwiY2xpZW50VG9wIiwiaGVpZ2h0Iiwic2VsZWN0aW9uQ2xpZW50UmVjdCIsImdldEJvdW5kaW5nQ2xpZW50UmVjdCIsIk1BUkdJTiIsInRvcCIsImJvdHRvbSIsInNldFBvc2l0aW9uIiwiRk9OVF9TSVpFUyIsInJvb3ROb2RlIiwicG9zaXRpb24iLCJkcmFnIiwiQXRNb3VzZXVwIiwib3duZXIiLCJfZWRpdGFibGVOb2RlIiwiY2xhc3NMaXN0IiwiYWRkIiwicmVtb3ZlIiwiX3Jlc2V0IiwiX2NsaWNraW5nIiwiY3JlYXRlRWxlbWVudCIsImNyZWF0ZUJ1dHRvbiIsImJ1dHRvbkNsYXNzIiwiaW1hZ2VDbGFzcyIsImNsaWNrRXZlbnRMaXN0ZW5lciIsImFwcGVuZENoaWxkIiwiaW1hZ2UiLCJzZXRBdHRyaWJ1dGUiLCJEUkFHX1RZUEUiLCJkYXRhVHJhbnNmZXIiLCJ0eXBlcyIsInByZXZlbnREZWZhdWx0Iiwic2V0RGF0YSIsImVmZmVjdEFsbG93ZWQiLCJvZmZzZXRYIiwibGVmdCIsIm9mZnNldFkiLCJ0ZW1wUG9zaXRpb24iLCJzdHlsZSIsImJvZHkiLCJzY3JvbGxYIiwic2Nyb2xsWSIsImxlZnRNYXgiLCJpbm5lcldpZHRoIiwidG9wTWF4IiwiaW5uZXJIZWlnaHQiLCJjbGllbnRMZWZ0Q29ycmVjdGVkIiwibWF4IiwibWluIiwiY2xpZW50VG9wQ29ycmVjdGVkIiwiZm9udFNpemUiLCJpY29uU2l6ZSIsIm9wdGlvbnNCdXR0b24iLCJpc0Nvbm5lY3RlZCIsInBhcmVudE5vZGUiLCJyZW1vdmVDaGlsZCIsIlBvcnRUb0JhY2tncm91bmQiLCJhdXRvQ29ubmVjdCIsIm9uQ29ubmVjdCIsIm9uRGlzY29ubmVjdCIsIm9uTWVzc2FnZSIsImNvbm5lY3QiLCJkaXNjb25uZWN0IiwicmVjb25uZWN0IiwiY2hlY2tDb25uZWN0aW9uIiwibWFpbiIsImNvbnRlbnRUeXBlIiwiRURJVEFCTEVfTk9ERV9TRUxFQ1RPUiIsIlNFQVJDSF9FTkdJTkVTIiwiaG9zdG5hbWVQYXR0ZXJuIiwiaW5wdXROYW1lIiwiZm9ybUFjdGlvblBhdHRlcm4iLCJNRVNTQUdFX0hBTkRMRVJTIiwib25XZWxjb21lIiwib25QdXRRdW90ZXMiLCJjb250ZW50SWQiLCJOYU4iLCJmcmFtZUlkIiwiaW5pdGlhbGl6ZSIsImlzSW5pdGlhbGl6ZWQiLCJOdW1iZXIiLCJpc0ludGVnZXIiLCJwb3J0VG9CYWNrZ3JvdW5kIiwid2luZG93IiwicGFyZW50IiwiVVJMIiwib25Qb3J0VG9CYWNrZ3JvdW5kQ29ubmVjdCIsIm9uUG9ydFRvQmFja2dyb3VuZERpc2Nvbm5lY3QiLCJvblBvcnRUb0JhY2tncm91bmRNZXNzYWdlIiwib25DbGlja1BvcHVwSWNvblNlYXJjaCIsIm9uQ2xpY2tQb3B1cEljb25RdW90ZSIsIm9uQ2xpY2tQb3B1cEljb25PcHRpb25zIiwiZWRpdGFibGVOb2RlV2l0aFNlbGVjdGlvbiIsIm9uV2luZG93Rm9jdXMiLCJvbldpbmRvd0JsdXIiLCJvYnNlcnZlciIsIk11dGF0aW9uT2JzZXJ2ZXIiLCJvbk11dGF0aW9uIiwib2JzZXJ2ZSIsInN1YnRyZWUiLCJjaGlsZExpc3QiLCJub2RlIiwiYWRkRXZlbnRMaXN0ZW5lclRvRWRpdGFibGVOb2RlIiwidHlwZSIsIl9wb3J0IiwiaWRlbnRpdHkiLCJub3RpZnlTZWxlY3Rpb25VcGRhdGVkIiwiX21lc3NhZ2UiLCJwdXRRdW90ZXNBcm91bmRTZWxlY3Rpb25UZXh0IiwibXV0YXRpb25MaXN0IiwiX29ic2VydmVyIiwibXV0YXRpb24iLCJhZGRlZE5vZGVzIiwibWF0Y2hlcyIsImRlc2NlbmRhbnROb2RlIiwic2VsZWN0aW9uU3RhcnQiLCJ1cGRhdGVFZGl0YWJsZU5vZGVXaXRoU2VsZWN0aW9uIiwiYWN0aXZlRWxlbWVudCIsImF1dG9TdXJyb3VuZCIsImNhbmNlbGFibGUiLCJpc0NvbXBvc2luZyIsImFsdEtleSIsInJlcGVhdCIsInJlYXNvbiIsImRpc2FibGVkIiwicmVhZE9ubHkiLCJzdWJzdHJpbmciLCJzZWxlY3Rpb25FbmQiLCJlZGl0YWJsZSIsImJsdXIiLCJlbmRzV2l0aCIsImhhc0ZvY3VzIiwic2VhcmNoYWJsZSIsImlzU2VhcmNoYWJsZSIsInJlcGxhY2VTZWxlY3Rpb25UZXh0IiwiYXV0b0VudGVyIiwiYXV0b0NvcHkiLCJuYXZpZ2F0b3IiLCJjbGlwYm9hcmQiLCJ3cml0ZVRleHQiLCJmb3JtIiwic3VibWl0IiwicmVwbGFjZW1lbnQiLCJjaGFyQXQiLCJzcGFjZVBhdHRlcm4iLCJvbGRTZWxlY3Rpb25TdGFydCIsIm9sZFNlbGVjdGlvbkVuZCIsInRlc3QiLCJ0ZW1wUmVwbGFjZW1lbnQiLCJzZWxlY3Rpb25TdGFydERlbHRhIiwic2VsZWN0aW9uRW5kRGVsdGEiLCJuZXdTZWxlY3Rpb25TdGFydCIsIm5ld1NlbGVjdGlvbkVuZCIsImZvY3VzIiwic2V0U2VsZWN0aW9uUmFuZ2UiLCJIVE1MSW5wdXRFbGVtZW50Iiwic2VhcmNoRW5naW5lIiwibG9jYXRpb24iLCJob3N0bmFtZSIsImdldEF0dHJpYnV0ZSJdLCJzb3VyY2VSb290IjoiIn0=