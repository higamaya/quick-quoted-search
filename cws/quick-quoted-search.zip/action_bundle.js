/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "../node_modules/@material/base/component.js":
/*!***************************************************!*\
  !*** ../node_modules/@material/base/component.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MDCComponent": () => (/* binding */ MDCComponent),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _foundation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./foundation */ "../node_modules/@material/base/foundation.js");
/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */


var MDCComponent = /** @class */function () {
  function MDCComponent(root, foundation) {
    var args = [];
    for (var _i = 2; _i < arguments.length; _i++) {
      args[_i - 2] = arguments[_i];
    }
    this.root = root;
    this.initialize.apply(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__spreadArray)([], (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__read)(args)));
    // Note that we initialize foundation here and not within the constructor's
    // default param so that this.root is defined and can be used within the
    // foundation class.
    this.foundation = foundation === undefined ? this.getDefaultFoundation() : foundation;
    this.foundation.init();
    this.initialSyncWithDOM();
  }
  MDCComponent.attachTo = function (root) {
    // Subclasses which extend MDCBase should provide an attachTo() method that takes a root element and
    // returns an instantiated component with its root set to that element. Also note that in the cases of
    // subclasses, an explicit foundation class will not have to be passed in; it will simply be initialized
    // from getDefaultFoundation().
    return new MDCComponent(root, new _foundation__WEBPACK_IMPORTED_MODULE_1__.MDCFoundation({}));
  };
  /* istanbul ignore next: method param only exists for typing purposes; it does not need to be unit tested */
  MDCComponent.prototype.initialize = function () {
    var _args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      _args[_i] = arguments[_i];
    }
    // Subclasses can override this to do any additional setup work that would be considered part of a
    // "constructor". Essentially, it is a hook into the parent constructor before the foundation is
    // initialized. Any additional arguments besides root and foundation will be passed in here.
  };

  MDCComponent.prototype.getDefaultFoundation = function () {
    // Subclasses must override this method to return a properly configured foundation class for the
    // component.
    throw new Error('Subclasses must override getDefaultFoundation to return a properly configured ' + 'foundation class');
  };
  MDCComponent.prototype.initialSyncWithDOM = function () {
    // Subclasses should override this method if they need to perform work to synchronize with a host DOM
    // object. An example of this would be a form control wrapper that needs to synchronize its internal state
    // to some property or attribute of the host DOM. Please note: this is *not* the place to perform DOM
    // reads/writes that would cause layout / paint, as this is called synchronously from within the constructor.
  };
  MDCComponent.prototype.destroy = function () {
    // Subclasses may implement this method to release any resources / deregister any listeners they have
    // attached. An example of this might be deregistering a resize event from the window object.
    this.foundation.destroy();
  };
  MDCComponent.prototype.listen = function (evtType, handler, options) {
    this.root.addEventListener(evtType, handler, options);
  };
  MDCComponent.prototype.unlisten = function (evtType, handler, options) {
    this.root.removeEventListener(evtType, handler, options);
  };
  /**
   * Fires a cross-browser-compatible custom event from the component root of the given type, with the given data.
   */
  MDCComponent.prototype.emit = function (evtType, evtData, shouldBubble) {
    if (shouldBubble === void 0) {
      shouldBubble = false;
    }
    var evt;
    if (typeof CustomEvent === 'function') {
      evt = new CustomEvent(evtType, {
        bubbles: shouldBubble,
        detail: evtData
      });
    } else {
      evt = document.createEvent('CustomEvent');
      evt.initCustomEvent(evtType, shouldBubble, false, evtData);
    }
    this.root.dispatchEvent(evt);
  };
  return MDCComponent;
}();

// tslint:disable-next-line:no-default-export Needed for backward compatibility with MDC Web v0.44.0 and earlier.
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MDCComponent);

/***/ }),

/***/ "../node_modules/@material/base/foundation.js":
/*!****************************************************!*\
  !*** ../node_modules/@material/base/foundation.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MDCFoundation": () => (/* binding */ MDCFoundation),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
var MDCFoundation = /** @class */function () {
  function MDCFoundation(adapter) {
    if (adapter === void 0) {
      adapter = {};
    }
    this.adapter = adapter;
  }
  Object.defineProperty(MDCFoundation, "cssClasses", {
    get: function () {
      // Classes extending MDCFoundation should implement this method to return an object which exports every
      // CSS class the foundation class needs as a property. e.g. {ACTIVE: 'mdc-component--active'}
      return {};
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(MDCFoundation, "strings", {
    get: function () {
      // Classes extending MDCFoundation should implement this method to return an object which exports all
      // semantic strings as constants. e.g. {ARIA_ROLE: 'tablist'}
      return {};
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(MDCFoundation, "numbers", {
    get: function () {
      // Classes extending MDCFoundation should implement this method to return an object which exports all
      // of its semantic numbers as constants. e.g. {ANIMATION_DELAY_MS: 350}
      return {};
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(MDCFoundation, "defaultAdapter", {
    get: function () {
      // Classes extending MDCFoundation may choose to implement this getter in order to provide a convenient
      // way of viewing the necessary methods of an adapter. In the future, this could also be used for adapter
      // validation.
      return {};
    },
    enumerable: false,
    configurable: true
  });
  MDCFoundation.prototype.init = function () {
    // Subclasses should override this method to perform initialization routines (registering events, etc.)
  };
  MDCFoundation.prototype.destroy = function () {
    // Subclasses should override this method to perform de-initialization routines (de-registering events, etc.)
  };
  return MDCFoundation;
}();

// tslint:disable-next-line:no-default-export Needed for backward compatibility with MDC Web v0.44.0 and earlier.
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MDCFoundation);

/***/ }),

/***/ "../node_modules/@material/dom/events.js":
/*!***********************************************!*\
  !*** ../node_modules/@material/dom/events.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "applyPassive": () => (/* binding */ applyPassive)
/* harmony export */ });
/**
 * @license
 * Copyright 2019 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/**
 * Determine whether the current browser supports passive event listeners, and
 * if so, use them.
 */
function applyPassive(globalObj) {
  if (globalObj === void 0) {
    globalObj = window;
  }
  return supportsPassiveOption(globalObj) ? {
    passive: true
  } : false;
}
function supportsPassiveOption(globalObj) {
  if (globalObj === void 0) {
    globalObj = window;
  }
  // See
  // https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener
  var passiveSupported = false;
  try {
    var options = {
      // This function will be called when the browser
      // attempts to access the passive property.
      get passive() {
        passiveSupported = true;
        return false;
      }
    };
    var handler = function () {};
    globalObj.document.addEventListener('test', handler, options);
    globalObj.document.removeEventListener('test', handler, options);
  } catch (err) {
    passiveSupported = false;
  }
  return passiveSupported;
}

/***/ }),

/***/ "../node_modules/@material/dom/ponyfill.js":
/*!*************************************************!*\
  !*** ../node_modules/@material/dom/ponyfill.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "closest": () => (/* binding */ closest),
/* harmony export */   "estimateScrollWidth": () => (/* binding */ estimateScrollWidth),
/* harmony export */   "matches": () => (/* binding */ matches)
/* harmony export */ });
/**
 * @license
 * Copyright 2018 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
/**
 * @fileoverview A "ponyfill" is a polyfill that doesn't modify the global prototype chain.
 * This makes ponyfills safer than traditional polyfills, especially for libraries like MDC.
 */
function closest(element, selector) {
  if (element.closest) {
    return element.closest(selector);
  }
  var el = element;
  while (el) {
    if (matches(el, selector)) {
      return el;
    }
    el = el.parentElement;
  }
  return null;
}
function matches(element, selector) {
  var nativeMatches = element.matches || element.webkitMatchesSelector || element.msMatchesSelector;
  return nativeMatches.call(element, selector);
}
/**
 * Used to compute the estimated scroll width of elements. When an element is
 * hidden due to display: none; being applied to a parent element, the width is
 * returned as 0. However, the element will have a true width once no longer
 * inside a display: none context. This method computes an estimated width when
 * the element is hidden or returns the true width when the element is visble.
 * @param {Element} element the element whose width to estimate
 */
function estimateScrollWidth(element) {
  // Check the offsetParent. If the element inherits display: none from any
  // parent, the offsetParent property will be null (see
  // https://developer.mozilla.org/en-US/docs/Web/API/HTMLElement/offsetParent).
  // This check ensures we only clone the node when necessary.
  var htmlEl = element;
  if (htmlEl.offsetParent !== null) {
    return htmlEl.scrollWidth;
  }
  var clone = htmlEl.cloneNode(true);
  clone.style.setProperty('position', 'absolute');
  clone.style.setProperty('transform', 'translate(-9999px, -9999px)');
  document.documentElement.appendChild(clone);
  var scrollWidth = clone.scrollWidth;
  document.documentElement.removeChild(clone);
  return scrollWidth;
}

/***/ }),

/***/ "../node_modules/@material/ripple/component.js":
/*!*****************************************************!*\
  !*** ../node_modules/@material/ripple/component.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MDCRipple": () => (/* binding */ MDCRipple)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _material_base_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material/base/component */ "../node_modules/@material/base/component.js");
/* harmony import */ var _material_dom_events__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material/dom/events */ "../node_modules/@material/dom/events.js");
/* harmony import */ var _material_dom_ponyfill__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material/dom/ponyfill */ "../node_modules/@material/dom/ponyfill.js");
/* harmony import */ var _foundation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./foundation */ "../node_modules/@material/ripple/foundation.js");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./util */ "../node_modules/@material/ripple/util.js");
/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */






var MDCRipple = /** @class */function (_super) {
  (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(MDCRipple, _super);
  function MDCRipple() {
    var _this = _super !== null && _super.apply(this, arguments) || this;
    _this.disabled = false;
    return _this;
  }
  MDCRipple.attachTo = function (root, opts) {
    if (opts === void 0) {
      opts = {
        isUnbounded: undefined
      };
    }
    var ripple = new MDCRipple(root);
    // Only override unbounded behavior if option is explicitly specified
    if (opts.isUnbounded !== undefined) {
      ripple.unbounded = opts.isUnbounded;
    }
    return ripple;
  };
  MDCRipple.createAdapter = function (instance) {
    return {
      addClass: function (className) {
        return instance.root.classList.add(className);
      },
      browserSupportsCssVars: function () {
        return _util__WEBPACK_IMPORTED_MODULE_1__.supportsCssVariables(window);
      },
      computeBoundingRect: function () {
        return instance.root.getBoundingClientRect();
      },
      containsEventTarget: function (target) {
        return instance.root.contains(target);
      },
      deregisterDocumentInteractionHandler: function (evtType, handler) {
        return document.documentElement.removeEventListener(evtType, handler, (0,_material_dom_events__WEBPACK_IMPORTED_MODULE_2__.applyPassive)());
      },
      deregisterInteractionHandler: function (evtType, handler) {
        return instance.root.removeEventListener(evtType, handler, (0,_material_dom_events__WEBPACK_IMPORTED_MODULE_2__.applyPassive)());
      },
      deregisterResizeHandler: function (handler) {
        return window.removeEventListener('resize', handler);
      },
      getWindowPageOffset: function () {
        return {
          x: window.pageXOffset,
          y: window.pageYOffset
        };
      },
      isSurfaceActive: function () {
        return (0,_material_dom_ponyfill__WEBPACK_IMPORTED_MODULE_3__.matches)(instance.root, ':active');
      },
      isSurfaceDisabled: function () {
        return Boolean(instance.disabled);
      },
      isUnbounded: function () {
        return Boolean(instance.unbounded);
      },
      registerDocumentInteractionHandler: function (evtType, handler) {
        return document.documentElement.addEventListener(evtType, handler, (0,_material_dom_events__WEBPACK_IMPORTED_MODULE_2__.applyPassive)());
      },
      registerInteractionHandler: function (evtType, handler) {
        return instance.root.addEventListener(evtType, handler, (0,_material_dom_events__WEBPACK_IMPORTED_MODULE_2__.applyPassive)());
      },
      registerResizeHandler: function (handler) {
        return window.addEventListener('resize', handler);
      },
      removeClass: function (className) {
        return instance.root.classList.remove(className);
      },
      updateCssVariable: function (varName, value) {
        return instance.root.style.setProperty(varName, value);
      }
    };
  };
  Object.defineProperty(MDCRipple.prototype, "unbounded", {
    get: function () {
      return Boolean(this.isUnbounded);
    },
    set: function (unbounded) {
      this.isUnbounded = Boolean(unbounded);
      this.setUnbounded();
    },
    enumerable: false,
    configurable: true
  });
  MDCRipple.prototype.activate = function () {
    this.foundation.activate();
  };
  MDCRipple.prototype.deactivate = function () {
    this.foundation.deactivate();
  };
  MDCRipple.prototype.layout = function () {
    this.foundation.layout();
  };
  MDCRipple.prototype.getDefaultFoundation = function () {
    return new _foundation__WEBPACK_IMPORTED_MODULE_4__.MDCRippleFoundation(MDCRipple.createAdapter(this));
  };
  MDCRipple.prototype.initialSyncWithDOM = function () {
    var root = this.root;
    this.isUnbounded = 'mdcRippleIsUnbounded' in root.dataset;
  };
  /**
   * Closure Compiler throws an access control error when directly accessing a
   * protected or private property inside a getter/setter, like unbounded above.
   * By accessing the protected property inside a method, we solve that problem.
   * That's why this function exists.
   */
  MDCRipple.prototype.setUnbounded = function () {
    this.foundation.setUnbounded(Boolean(this.isUnbounded));
  };
  return MDCRipple;
}(_material_base_component__WEBPACK_IMPORTED_MODULE_5__.MDCComponent);


/***/ }),

/***/ "../node_modules/@material/ripple/constants.js":
/*!*****************************************************!*\
  !*** ../node_modules/@material/ripple/constants.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cssClasses": () => (/* binding */ cssClasses),
/* harmony export */   "numbers": () => (/* binding */ numbers),
/* harmony export */   "strings": () => (/* binding */ strings)
/* harmony export */ });
/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
var cssClasses = {
  // Ripple is a special case where the "root" component is really a "mixin" of sorts,
  // given that it's an 'upgrade' to an existing component. That being said it is the root
  // CSS class that all other CSS classes derive from.
  BG_FOCUSED: 'mdc-ripple-upgraded--background-focused',
  FG_ACTIVATION: 'mdc-ripple-upgraded--foreground-activation',
  FG_DEACTIVATION: 'mdc-ripple-upgraded--foreground-deactivation',
  ROOT: 'mdc-ripple-upgraded',
  UNBOUNDED: 'mdc-ripple-upgraded--unbounded'
};
var strings = {
  VAR_FG_SCALE: '--mdc-ripple-fg-scale',
  VAR_FG_SIZE: '--mdc-ripple-fg-size',
  VAR_FG_TRANSLATE_END: '--mdc-ripple-fg-translate-end',
  VAR_FG_TRANSLATE_START: '--mdc-ripple-fg-translate-start',
  VAR_LEFT: '--mdc-ripple-left',
  VAR_TOP: '--mdc-ripple-top'
};
var numbers = {
  DEACTIVATION_TIMEOUT_MS: 225,
  FG_DEACTIVATION_MS: 150,
  INITIAL_ORIGIN_SCALE: 0.6,
  PADDING: 10,
  TAP_DELAY_MS: 300 // Delay between touch and simulated mouse events on touch devices
};

/***/ }),

/***/ "../node_modules/@material/ripple/foundation.js":
/*!******************************************************!*\
  !*** ../node_modules/@material/ripple/foundation.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MDCRippleFoundation": () => (/* binding */ MDCRippleFoundation),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "../node_modules/tslib/tslib.es6.js");
/* harmony import */ var _material_base_foundation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material/base/foundation */ "../node_modules/@material/base/foundation.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./constants */ "../node_modules/@material/ripple/constants.js");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./util */ "../node_modules/@material/ripple/util.js");
/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */




// Activation events registered on the root element of each instance for activation
var ACTIVATION_EVENT_TYPES = ['touchstart', 'pointerdown', 'mousedown', 'keydown'];
// Deactivation events registered on documentElement when a pointer-related down event occurs
var POINTER_DEACTIVATION_EVENT_TYPES = ['touchend', 'pointerup', 'mouseup', 'contextmenu'];
// simultaneous nested activations
var activatedTargets = [];
var MDCRippleFoundation = /** @class */function (_super) {
  (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__extends)(MDCRippleFoundation, _super);
  function MDCRippleFoundation(adapter) {
    var _this = _super.call(this, (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, MDCRippleFoundation.defaultAdapter), adapter)) || this;
    _this.activationAnimationHasEnded = false;
    _this.activationTimer = 0;
    _this.fgDeactivationRemovalTimer = 0;
    _this.fgScale = '0';
    _this.frame = {
      width: 0,
      height: 0
    };
    _this.initialSize = 0;
    _this.layoutFrame = 0;
    _this.maxRadius = 0;
    _this.unboundedCoords = {
      left: 0,
      top: 0
    };
    _this.activationState = _this.defaultActivationState();
    _this.activationTimerCallback = function () {
      _this.activationAnimationHasEnded = true;
      _this.runDeactivationUXLogicIfReady();
    };
    _this.activateHandler = function (e) {
      _this.activateImpl(e);
    };
    _this.deactivateHandler = function () {
      _this.deactivateImpl();
    };
    _this.focusHandler = function () {
      _this.handleFocus();
    };
    _this.blurHandler = function () {
      _this.handleBlur();
    };
    _this.resizeHandler = function () {
      _this.layout();
    };
    return _this;
  }
  Object.defineProperty(MDCRippleFoundation, "cssClasses", {
    get: function () {
      return _constants__WEBPACK_IMPORTED_MODULE_1__.cssClasses;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(MDCRippleFoundation, "strings", {
    get: function () {
      return _constants__WEBPACK_IMPORTED_MODULE_1__.strings;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(MDCRippleFoundation, "numbers", {
    get: function () {
      return _constants__WEBPACK_IMPORTED_MODULE_1__.numbers;
    },
    enumerable: false,
    configurable: true
  });
  Object.defineProperty(MDCRippleFoundation, "defaultAdapter", {
    get: function () {
      return {
        addClass: function () {
          return undefined;
        },
        browserSupportsCssVars: function () {
          return true;
        },
        computeBoundingRect: function () {
          return {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            width: 0,
            height: 0
          };
        },
        containsEventTarget: function () {
          return true;
        },
        deregisterDocumentInteractionHandler: function () {
          return undefined;
        },
        deregisterInteractionHandler: function () {
          return undefined;
        },
        deregisterResizeHandler: function () {
          return undefined;
        },
        getWindowPageOffset: function () {
          return {
            x: 0,
            y: 0
          };
        },
        isSurfaceActive: function () {
          return true;
        },
        isSurfaceDisabled: function () {
          return true;
        },
        isUnbounded: function () {
          return true;
        },
        registerDocumentInteractionHandler: function () {
          return undefined;
        },
        registerInteractionHandler: function () {
          return undefined;
        },
        registerResizeHandler: function () {
          return undefined;
        },
        removeClass: function () {
          return undefined;
        },
        updateCssVariable: function () {
          return undefined;
        }
      };
    },
    enumerable: false,
    configurable: true
  });
  MDCRippleFoundation.prototype.init = function () {
    var _this = this;
    var supportsPressRipple = this.supportsPressRipple();
    this.registerRootHandlers(supportsPressRipple);
    if (supportsPressRipple) {
      var _a = MDCRippleFoundation.cssClasses,
        ROOT_1 = _a.ROOT,
        UNBOUNDED_1 = _a.UNBOUNDED;
      requestAnimationFrame(function () {
        _this.adapter.addClass(ROOT_1);
        if (_this.adapter.isUnbounded()) {
          _this.adapter.addClass(UNBOUNDED_1);
          // Unbounded ripples need layout logic applied immediately to set coordinates for both shade and ripple
          _this.layoutInternal();
        }
      });
    }
  };
  MDCRippleFoundation.prototype.destroy = function () {
    var _this = this;
    if (this.supportsPressRipple()) {
      if (this.activationTimer) {
        clearTimeout(this.activationTimer);
        this.activationTimer = 0;
        this.adapter.removeClass(MDCRippleFoundation.cssClasses.FG_ACTIVATION);
      }
      if (this.fgDeactivationRemovalTimer) {
        clearTimeout(this.fgDeactivationRemovalTimer);
        this.fgDeactivationRemovalTimer = 0;
        this.adapter.removeClass(MDCRippleFoundation.cssClasses.FG_DEACTIVATION);
      }
      var _a = MDCRippleFoundation.cssClasses,
        ROOT_2 = _a.ROOT,
        UNBOUNDED_2 = _a.UNBOUNDED;
      requestAnimationFrame(function () {
        _this.adapter.removeClass(ROOT_2);
        _this.adapter.removeClass(UNBOUNDED_2);
        _this.removeCssVars();
      });
    }
    this.deregisterRootHandlers();
    this.deregisterDeactivationHandlers();
  };
  /**
   * @param evt Optional event containing position information.
   */
  MDCRippleFoundation.prototype.activate = function (evt) {
    this.activateImpl(evt);
  };
  MDCRippleFoundation.prototype.deactivate = function () {
    this.deactivateImpl();
  };
  MDCRippleFoundation.prototype.layout = function () {
    var _this = this;
    if (this.layoutFrame) {
      cancelAnimationFrame(this.layoutFrame);
    }
    this.layoutFrame = requestAnimationFrame(function () {
      _this.layoutInternal();
      _this.layoutFrame = 0;
    });
  };
  MDCRippleFoundation.prototype.setUnbounded = function (unbounded) {
    var UNBOUNDED = MDCRippleFoundation.cssClasses.UNBOUNDED;
    if (unbounded) {
      this.adapter.addClass(UNBOUNDED);
    } else {
      this.adapter.removeClass(UNBOUNDED);
    }
  };
  MDCRippleFoundation.prototype.handleFocus = function () {
    var _this = this;
    requestAnimationFrame(function () {
      return _this.adapter.addClass(MDCRippleFoundation.cssClasses.BG_FOCUSED);
    });
  };
  MDCRippleFoundation.prototype.handleBlur = function () {
    var _this = this;
    requestAnimationFrame(function () {
      return _this.adapter.removeClass(MDCRippleFoundation.cssClasses.BG_FOCUSED);
    });
  };
  /**
   * We compute this property so that we are not querying information about the client
   * until the point in time where the foundation requests it. This prevents scenarios where
   * client-side feature-detection may happen too early, such as when components are rendered on the server
   * and then initialized at mount time on the client.
   */
  MDCRippleFoundation.prototype.supportsPressRipple = function () {
    return this.adapter.browserSupportsCssVars();
  };
  MDCRippleFoundation.prototype.defaultActivationState = function () {
    return {
      activationEvent: undefined,
      hasDeactivationUXRun: false,
      isActivated: false,
      isProgrammatic: false,
      wasActivatedByPointer: false,
      wasElementMadeActive: false
    };
  };
  /**
   * supportsPressRipple Passed from init to save a redundant function call
   */
  MDCRippleFoundation.prototype.registerRootHandlers = function (supportsPressRipple) {
    var e_1, _a;
    if (supportsPressRipple) {
      try {
        for (var ACTIVATION_EVENT_TYPES_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(ACTIVATION_EVENT_TYPES), ACTIVATION_EVENT_TYPES_1_1 = ACTIVATION_EVENT_TYPES_1.next(); !ACTIVATION_EVENT_TYPES_1_1.done; ACTIVATION_EVENT_TYPES_1_1 = ACTIVATION_EVENT_TYPES_1.next()) {
          var evtType = ACTIVATION_EVENT_TYPES_1_1.value;
          this.adapter.registerInteractionHandler(evtType, this.activateHandler);
        }
      } catch (e_1_1) {
        e_1 = {
          error: e_1_1
        };
      } finally {
        try {
          if (ACTIVATION_EVENT_TYPES_1_1 && !ACTIVATION_EVENT_TYPES_1_1.done && (_a = ACTIVATION_EVENT_TYPES_1.return)) _a.call(ACTIVATION_EVENT_TYPES_1);
        } finally {
          if (e_1) throw e_1.error;
        }
      }
      if (this.adapter.isUnbounded()) {
        this.adapter.registerResizeHandler(this.resizeHandler);
      }
    }
    this.adapter.registerInteractionHandler('focus', this.focusHandler);
    this.adapter.registerInteractionHandler('blur', this.blurHandler);
  };
  MDCRippleFoundation.prototype.registerDeactivationHandlers = function (evt) {
    var e_2, _a;
    if (evt.type === 'keydown') {
      this.adapter.registerInteractionHandler('keyup', this.deactivateHandler);
    } else {
      try {
        for (var POINTER_DEACTIVATION_EVENT_TYPES_1 = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(POINTER_DEACTIVATION_EVENT_TYPES), POINTER_DEACTIVATION_EVENT_TYPES_1_1 = POINTER_DEACTIVATION_EVENT_TYPES_1.next(); !POINTER_DEACTIVATION_EVENT_TYPES_1_1.done; POINTER_DEACTIVATION_EVENT_TYPES_1_1 = POINTER_DEACTIVATION_EVENT_TYPES_1.next()) {
          var evtType = POINTER_DEACTIVATION_EVENT_TYPES_1_1.value;
          this.adapter.registerDocumentInteractionHandler(evtType, this.deactivateHandler);
        }
      } catch (e_2_1) {
        e_2 = {
          error: e_2_1
        };
      } finally {
        try {
          if (POINTER_DEACTIVATION_EVENT_TYPES_1_1 && !POINTER_DEACTIVATION_EVENT_TYPES_1_1.done && (_a = POINTER_DEACTIVATION_EVENT_TYPES_1.return)) _a.call(POINTER_DEACTIVATION_EVENT_TYPES_1);
        } finally {
          if (e_2) throw e_2.error;
        }
      }
    }
  };
  MDCRippleFoundation.prototype.deregisterRootHandlers = function () {
    var e_3, _a;
    try {
      for (var ACTIVATION_EVENT_TYPES_2 = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(ACTIVATION_EVENT_TYPES), ACTIVATION_EVENT_TYPES_2_1 = ACTIVATION_EVENT_TYPES_2.next(); !ACTIVATION_EVENT_TYPES_2_1.done; ACTIVATION_EVENT_TYPES_2_1 = ACTIVATION_EVENT_TYPES_2.next()) {
        var evtType = ACTIVATION_EVENT_TYPES_2_1.value;
        this.adapter.deregisterInteractionHandler(evtType, this.activateHandler);
      }
    } catch (e_3_1) {
      e_3 = {
        error: e_3_1
      };
    } finally {
      try {
        if (ACTIVATION_EVENT_TYPES_2_1 && !ACTIVATION_EVENT_TYPES_2_1.done && (_a = ACTIVATION_EVENT_TYPES_2.return)) _a.call(ACTIVATION_EVENT_TYPES_2);
      } finally {
        if (e_3) throw e_3.error;
      }
    }
    this.adapter.deregisterInteractionHandler('focus', this.focusHandler);
    this.adapter.deregisterInteractionHandler('blur', this.blurHandler);
    if (this.adapter.isUnbounded()) {
      this.adapter.deregisterResizeHandler(this.resizeHandler);
    }
  };
  MDCRippleFoundation.prototype.deregisterDeactivationHandlers = function () {
    var e_4, _a;
    this.adapter.deregisterInteractionHandler('keyup', this.deactivateHandler);
    try {
      for (var POINTER_DEACTIVATION_EVENT_TYPES_2 = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__values)(POINTER_DEACTIVATION_EVENT_TYPES), POINTER_DEACTIVATION_EVENT_TYPES_2_1 = POINTER_DEACTIVATION_EVENT_TYPES_2.next(); !POINTER_DEACTIVATION_EVENT_TYPES_2_1.done; POINTER_DEACTIVATION_EVENT_TYPES_2_1 = POINTER_DEACTIVATION_EVENT_TYPES_2.next()) {
        var evtType = POINTER_DEACTIVATION_EVENT_TYPES_2_1.value;
        this.adapter.deregisterDocumentInteractionHandler(evtType, this.deactivateHandler);
      }
    } catch (e_4_1) {
      e_4 = {
        error: e_4_1
      };
    } finally {
      try {
        if (POINTER_DEACTIVATION_EVENT_TYPES_2_1 && !POINTER_DEACTIVATION_EVENT_TYPES_2_1.done && (_a = POINTER_DEACTIVATION_EVENT_TYPES_2.return)) _a.call(POINTER_DEACTIVATION_EVENT_TYPES_2);
      } finally {
        if (e_4) throw e_4.error;
      }
    }
  };
  MDCRippleFoundation.prototype.removeCssVars = function () {
    var _this = this;
    var rippleStrings = MDCRippleFoundation.strings;
    var keys = Object.keys(rippleStrings);
    keys.forEach(function (key) {
      if (key.indexOf('VAR_') === 0) {
        _this.adapter.updateCssVariable(rippleStrings[key], null);
      }
    });
  };
  MDCRippleFoundation.prototype.activateImpl = function (evt) {
    var _this = this;
    if (this.adapter.isSurfaceDisabled()) {
      return;
    }
    var activationState = this.activationState;
    if (activationState.isActivated) {
      return;
    }
    // Avoid reacting to follow-on events fired by touch device after an already-processed user interaction
    var previousActivationEvent = this.previousActivationEvent;
    var isSameInteraction = previousActivationEvent && evt !== undefined && previousActivationEvent.type !== evt.type;
    if (isSameInteraction) {
      return;
    }
    activationState.isActivated = true;
    activationState.isProgrammatic = evt === undefined;
    activationState.activationEvent = evt;
    activationState.wasActivatedByPointer = activationState.isProgrammatic ? false : evt !== undefined && (evt.type === 'mousedown' || evt.type === 'touchstart' || evt.type === 'pointerdown');
    var hasActivatedChild = evt !== undefined && activatedTargets.length > 0 && activatedTargets.some(function (target) {
      return _this.adapter.containsEventTarget(target);
    });
    if (hasActivatedChild) {
      // Immediately reset activation state, while preserving logic that prevents touch follow-on events
      this.resetActivationState();
      return;
    }
    if (evt !== undefined) {
      activatedTargets.push(evt.target);
      this.registerDeactivationHandlers(evt);
    }
    activationState.wasElementMadeActive = this.checkElementMadeActive(evt);
    if (activationState.wasElementMadeActive) {
      this.animateActivation();
    }
    requestAnimationFrame(function () {
      // Reset array on next frame after the current event has had a chance to bubble to prevent ancestor ripples
      activatedTargets = [];
      if (!activationState.wasElementMadeActive && evt !== undefined && (evt.key === ' ' || evt.keyCode === 32)) {
        // If space was pressed, try again within an rAF call to detect :active, because different UAs report
        // active states inconsistently when they're called within event handling code:
        // - https://bugs.chromium.org/p/chromium/issues/detail?id=635971
        // - https://bugzilla.mozilla.org/show_bug.cgi?id=1293741
        // We try first outside rAF to support Edge, which does not exhibit this problem, but will crash if a CSS
        // variable is set within a rAF callback for a submit button interaction (#2241).
        activationState.wasElementMadeActive = _this.checkElementMadeActive(evt);
        if (activationState.wasElementMadeActive) {
          _this.animateActivation();
        }
      }
      if (!activationState.wasElementMadeActive) {
        // Reset activation state immediately if element was not made active.
        _this.activationState = _this.defaultActivationState();
      }
    });
  };
  MDCRippleFoundation.prototype.checkElementMadeActive = function (evt) {
    return evt !== undefined && evt.type === 'keydown' ? this.adapter.isSurfaceActive() : true;
  };
  MDCRippleFoundation.prototype.animateActivation = function () {
    var _this = this;
    var _a = MDCRippleFoundation.strings,
      VAR_FG_TRANSLATE_START = _a.VAR_FG_TRANSLATE_START,
      VAR_FG_TRANSLATE_END = _a.VAR_FG_TRANSLATE_END;
    var _b = MDCRippleFoundation.cssClasses,
      FG_DEACTIVATION = _b.FG_DEACTIVATION,
      FG_ACTIVATION = _b.FG_ACTIVATION;
    var DEACTIVATION_TIMEOUT_MS = MDCRippleFoundation.numbers.DEACTIVATION_TIMEOUT_MS;
    this.layoutInternal();
    var translateStart = '';
    var translateEnd = '';
    if (!this.adapter.isUnbounded()) {
      var _c = this.getFgTranslationCoordinates(),
        startPoint = _c.startPoint,
        endPoint = _c.endPoint;
      translateStart = startPoint.x + "px, " + startPoint.y + "px";
      translateEnd = endPoint.x + "px, " + endPoint.y + "px";
    }
    this.adapter.updateCssVariable(VAR_FG_TRANSLATE_START, translateStart);
    this.adapter.updateCssVariable(VAR_FG_TRANSLATE_END, translateEnd);
    // Cancel any ongoing activation/deactivation animations
    clearTimeout(this.activationTimer);
    clearTimeout(this.fgDeactivationRemovalTimer);
    this.rmBoundedActivationClasses();
    this.adapter.removeClass(FG_DEACTIVATION);
    // Force layout in order to re-trigger the animation.
    this.adapter.computeBoundingRect();
    this.adapter.addClass(FG_ACTIVATION);
    this.activationTimer = setTimeout(function () {
      _this.activationTimerCallback();
    }, DEACTIVATION_TIMEOUT_MS);
  };
  MDCRippleFoundation.prototype.getFgTranslationCoordinates = function () {
    var _a = this.activationState,
      activationEvent = _a.activationEvent,
      wasActivatedByPointer = _a.wasActivatedByPointer;
    var startPoint;
    if (wasActivatedByPointer) {
      startPoint = (0,_util__WEBPACK_IMPORTED_MODULE_2__.getNormalizedEventCoords)(activationEvent, this.adapter.getWindowPageOffset(), this.adapter.computeBoundingRect());
    } else {
      startPoint = {
        x: this.frame.width / 2,
        y: this.frame.height / 2
      };
    }
    // Center the element around the start point.
    startPoint = {
      x: startPoint.x - this.initialSize / 2,
      y: startPoint.y - this.initialSize / 2
    };
    var endPoint = {
      x: this.frame.width / 2 - this.initialSize / 2,
      y: this.frame.height / 2 - this.initialSize / 2
    };
    return {
      startPoint: startPoint,
      endPoint: endPoint
    };
  };
  MDCRippleFoundation.prototype.runDeactivationUXLogicIfReady = function () {
    var _this = this;
    // This method is called both when a pointing device is released, and when the activation animation ends.
    // The deactivation animation should only run after both of those occur.
    var FG_DEACTIVATION = MDCRippleFoundation.cssClasses.FG_DEACTIVATION;
    var _a = this.activationState,
      hasDeactivationUXRun = _a.hasDeactivationUXRun,
      isActivated = _a.isActivated;
    var activationHasEnded = hasDeactivationUXRun || !isActivated;
    if (activationHasEnded && this.activationAnimationHasEnded) {
      this.rmBoundedActivationClasses();
      this.adapter.addClass(FG_DEACTIVATION);
      this.fgDeactivationRemovalTimer = setTimeout(function () {
        _this.adapter.removeClass(FG_DEACTIVATION);
      }, _constants__WEBPACK_IMPORTED_MODULE_1__.numbers.FG_DEACTIVATION_MS);
    }
  };
  MDCRippleFoundation.prototype.rmBoundedActivationClasses = function () {
    var FG_ACTIVATION = MDCRippleFoundation.cssClasses.FG_ACTIVATION;
    this.adapter.removeClass(FG_ACTIVATION);
    this.activationAnimationHasEnded = false;
    this.adapter.computeBoundingRect();
  };
  MDCRippleFoundation.prototype.resetActivationState = function () {
    var _this = this;
    this.previousActivationEvent = this.activationState.activationEvent;
    this.activationState = this.defaultActivationState();
    // Touch devices may fire additional events for the same interaction within a short time.
    // Store the previous event until it's safe to assume that subsequent events are for new interactions.
    setTimeout(function () {
      return _this.previousActivationEvent = undefined;
    }, MDCRippleFoundation.numbers.TAP_DELAY_MS);
  };
  MDCRippleFoundation.prototype.deactivateImpl = function () {
    var _this = this;
    var activationState = this.activationState;
    // This can happen in scenarios such as when you have a keyup event that blurs the element.
    if (!activationState.isActivated) {
      return;
    }
    var state = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__assign)({}, activationState);
    if (activationState.isProgrammatic) {
      requestAnimationFrame(function () {
        _this.animateDeactivation(state);
      });
      this.resetActivationState();
    } else {
      this.deregisterDeactivationHandlers();
      requestAnimationFrame(function () {
        _this.activationState.hasDeactivationUXRun = true;
        _this.animateDeactivation(state);
        _this.resetActivationState();
      });
    }
  };
  MDCRippleFoundation.prototype.animateDeactivation = function (_a) {
    var wasActivatedByPointer = _a.wasActivatedByPointer,
      wasElementMadeActive = _a.wasElementMadeActive;
    if (wasActivatedByPointer || wasElementMadeActive) {
      this.runDeactivationUXLogicIfReady();
    }
  };
  MDCRippleFoundation.prototype.layoutInternal = function () {
    var _this = this;
    this.frame = this.adapter.computeBoundingRect();
    var maxDim = Math.max(this.frame.height, this.frame.width);
    // Surface diameter is treated differently for unbounded vs. bounded ripples.
    // Unbounded ripple diameter is calculated smaller since the surface is expected to already be padded appropriately
    // to extend the hitbox, and the ripple is expected to meet the edges of the padded hitbox (which is typically
    // square). Bounded ripples, on the other hand, are fully expected to expand beyond the surface's longest diameter
    // (calculated based on the diagonal plus a constant padding), and are clipped at the surface's border via
    // `overflow: hidden`.
    var getBoundedRadius = function () {
      var hypotenuse = Math.sqrt(Math.pow(_this.frame.width, 2) + Math.pow(_this.frame.height, 2));
      return hypotenuse + MDCRippleFoundation.numbers.PADDING;
    };
    this.maxRadius = this.adapter.isUnbounded() ? maxDim : getBoundedRadius();
    // Ripple is sized as a fraction of the largest dimension of the surface, then scales up using a CSS scale transform
    var initialSize = Math.floor(maxDim * MDCRippleFoundation.numbers.INITIAL_ORIGIN_SCALE);
    // Unbounded ripple size should always be even number to equally center align.
    if (this.adapter.isUnbounded() && initialSize % 2 !== 0) {
      this.initialSize = initialSize - 1;
    } else {
      this.initialSize = initialSize;
    }
    this.fgScale = "" + this.maxRadius / this.initialSize;
    this.updateLayoutCssVars();
  };
  MDCRippleFoundation.prototype.updateLayoutCssVars = function () {
    var _a = MDCRippleFoundation.strings,
      VAR_FG_SIZE = _a.VAR_FG_SIZE,
      VAR_LEFT = _a.VAR_LEFT,
      VAR_TOP = _a.VAR_TOP,
      VAR_FG_SCALE = _a.VAR_FG_SCALE;
    this.adapter.updateCssVariable(VAR_FG_SIZE, this.initialSize + "px");
    this.adapter.updateCssVariable(VAR_FG_SCALE, this.fgScale);
    if (this.adapter.isUnbounded()) {
      this.unboundedCoords = {
        left: Math.round(this.frame.width / 2 - this.initialSize / 2),
        top: Math.round(this.frame.height / 2 - this.initialSize / 2)
      };
      this.adapter.updateCssVariable(VAR_LEFT, this.unboundedCoords.left + "px");
      this.adapter.updateCssVariable(VAR_TOP, this.unboundedCoords.top + "px");
    }
  };
  return MDCRippleFoundation;
}(_material_base_foundation__WEBPACK_IMPORTED_MODULE_3__.MDCFoundation);

// tslint:disable-next-line:no-default-export Needed for backward compatibility with MDC Web v0.44.0 and earlier.
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MDCRippleFoundation);

/***/ }),

/***/ "../node_modules/@material/ripple/util.js":
/*!************************************************!*\
  !*** ../node_modules/@material/ripple/util.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "getNormalizedEventCoords": () => (/* binding */ getNormalizedEventCoords),
/* harmony export */   "supportsCssVariables": () => (/* binding */ supportsCssVariables)
/* harmony export */ });
/**
 * Stores result from supportsCssVariables to avoid redundant processing to
 * detect CSS custom variable support.
 */
var supportsCssVariables_;
function supportsCssVariables(windowObj, forceRefresh) {
  if (forceRefresh === void 0) {
    forceRefresh = false;
  }
  var CSS = windowObj.CSS;
  var supportsCssVars = supportsCssVariables_;
  if (typeof supportsCssVariables_ === 'boolean' && !forceRefresh) {
    return supportsCssVariables_;
  }
  var supportsFunctionPresent = CSS && typeof CSS.supports === 'function';
  if (!supportsFunctionPresent) {
    return false;
  }
  var explicitlySupportsCssVars = CSS.supports('--css-vars', 'yes');
  // See: https://bugs.webkit.org/show_bug.cgi?id=154669
  // See: README section on Safari
  var weAreFeatureDetectingSafari10plus = CSS.supports('(--css-vars: yes)') && CSS.supports('color', '#00000000');
  supportsCssVars = explicitlySupportsCssVars || weAreFeatureDetectingSafari10plus;
  if (!forceRefresh) {
    supportsCssVariables_ = supportsCssVars;
  }
  return supportsCssVars;
}
function getNormalizedEventCoords(evt, pageOffset, clientRect) {
  if (!evt) {
    return {
      x: 0,
      y: 0
    };
  }
  var x = pageOffset.x,
    y = pageOffset.y;
  var documentX = x + clientRect.left;
  var documentY = y + clientRect.top;
  var normalizedX;
  var normalizedY;
  // Determine touch point relative to the ripple container.
  if (evt.type === 'touchstart') {
    var touchEvent = evt;
    normalizedX = touchEvent.changedTouches[0].pageX - documentX;
    normalizedY = touchEvent.changedTouches[0].pageY - documentY;
  } else {
    var mouseEvent = evt;
    normalizedX = mouseEvent.pageX - documentX;
    normalizedY = mouseEvent.pageY - documentY;
  }
  return {
    x: normalizedX,
    y: normalizedY
  };
}

/***/ }),

/***/ "../node_modules/tslib/tslib.es6.js":
/*!******************************************!*\
  !*** ../node_modules/tslib/tslib.es6.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__assign": () => (/* binding */ __assign),
/* harmony export */   "__asyncDelegator": () => (/* binding */ __asyncDelegator),
/* harmony export */   "__asyncGenerator": () => (/* binding */ __asyncGenerator),
/* harmony export */   "__asyncValues": () => (/* binding */ __asyncValues),
/* harmony export */   "__await": () => (/* binding */ __await),
/* harmony export */   "__awaiter": () => (/* binding */ __awaiter),
/* harmony export */   "__classPrivateFieldGet": () => (/* binding */ __classPrivateFieldGet),
/* harmony export */   "__classPrivateFieldIn": () => (/* binding */ __classPrivateFieldIn),
/* harmony export */   "__classPrivateFieldSet": () => (/* binding */ __classPrivateFieldSet),
/* harmony export */   "__createBinding": () => (/* binding */ __createBinding),
/* harmony export */   "__decorate": () => (/* binding */ __decorate),
/* harmony export */   "__exportStar": () => (/* binding */ __exportStar),
/* harmony export */   "__extends": () => (/* binding */ __extends),
/* harmony export */   "__generator": () => (/* binding */ __generator),
/* harmony export */   "__importDefault": () => (/* binding */ __importDefault),
/* harmony export */   "__importStar": () => (/* binding */ __importStar),
/* harmony export */   "__makeTemplateObject": () => (/* binding */ __makeTemplateObject),
/* harmony export */   "__metadata": () => (/* binding */ __metadata),
/* harmony export */   "__param": () => (/* binding */ __param),
/* harmony export */   "__read": () => (/* binding */ __read),
/* harmony export */   "__rest": () => (/* binding */ __rest),
/* harmony export */   "__spread": () => (/* binding */ __spread),
/* harmony export */   "__spreadArray": () => (/* binding */ __spreadArray),
/* harmony export */   "__spreadArrays": () => (/* binding */ __spreadArrays),
/* harmony export */   "__values": () => (/* binding */ __values)
/* harmony export */ });
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function (d, b) {
  extendStatics = Object.setPrototypeOf || {
    __proto__: []
  } instanceof Array && function (d, b) {
    d.__proto__ = b;
  } || function (d, b) {
    for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function () {
  __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __rest(s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
    if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
  }
  return t;
}
function __decorate(decorators, target, key, desc) {
  var c = arguments.length,
    r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
    d;
  if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
  return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function __param(paramIndex, decorator) {
  return function (target, key) {
    decorator(target, key, paramIndex);
  };
}
function __metadata(metadataKey, metadataValue) {
  if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}
function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function (resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function (resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator(thisArg, body) {
  var _ = {
      label: 0,
      sent: function () {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
    f,
    y,
    t,
    g;
  return g = {
    next: verb(0),
    "throw": verb(1),
    "return": verb(2)
  }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
    return this;
  }), g;
  function verb(n) {
    return function (v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return {
            value: op[1],
            done: false
          };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return {
      value: op[0] ? op[1] : void 0,
      done: true
    };
  }
}
var __createBinding = Object.create ? function (o, m, k, k2) {
  if (k2 === undefined) k2 = k;
  var desc = Object.getOwnPropertyDescriptor(m, k);
  if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
    desc = {
      enumerable: true,
      get: function () {
        return m[k];
      }
    };
  }
  Object.defineProperty(o, k2, desc);
} : function (o, m, k, k2) {
  if (k2 === undefined) k2 = k;
  o[k2] = m[k];
};
function __exportStar(m, o) {
  for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}
function __values(o) {
  var s = typeof Symbol === "function" && Symbol.iterator,
    m = s && o[s],
    i = 0;
  if (m) return m.call(o);
  if (o && typeof o.length === "number") return {
    next: function () {
      if (o && i >= o.length) o = void 0;
      return {
        value: o && o[i++],
        done: !o
      };
    }
  };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o),
    r,
    ar = [],
    e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = {
      error: error
    };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
}

/** @deprecated */
function __spread() {
  for (var ar = [], i = 0; i < arguments.length; i++) ar = ar.concat(__read(arguments[i]));
  return ar;
}

/** @deprecated */
function __spreadArrays() {
  for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
  for (var r = Array(s), k = 0, i = 0; i < il; i++) for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) r[k] = a[j];
  return r;
}
function __spreadArray(to, from, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
    if (ar || !(i in from)) {
      if (!ar) ar = Array.prototype.slice.call(from, 0, i);
      ar[i] = from[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from));
}
function __await(v) {
  return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var g = generator.apply(thisArg, _arguments || []),
    i,
    q = [];
  return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
    return this;
  }, i;
  function verb(n) {
    if (g[n]) i[n] = function (v) {
      return new Promise(function (a, b) {
        q.push([n, v, a, b]) > 1 || resume(n, v);
      });
    };
  }
  function resume(n, v) {
    try {
      step(g[n](v));
    } catch (e) {
      settle(q[0][3], e);
    }
  }
  function step(r) {
    r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
  }
  function fulfill(value) {
    resume("next", value);
  }
  function reject(value) {
    resume("throw", value);
  }
  function settle(f, v) {
    if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
  }
}
function __asyncDelegator(o) {
  var i, p;
  return i = {}, verb("next"), verb("throw", function (e) {
    throw e;
  }), verb("return"), i[Symbol.iterator] = function () {
    return this;
  }, i;
  function verb(n, f) {
    i[n] = o[n] ? function (v) {
      return (p = !p) ? {
        value: __await(o[n](v)),
        done: n === "return"
      } : f ? f(v) : v;
    } : f;
  }
}
function __asyncValues(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator],
    i;
  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
    return this;
  }, i);
  function verb(n) {
    i[n] = o[n] && function (v) {
      return new Promise(function (resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }
  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function (v) {
      resolve({
        value: v,
        done: d
      });
    }, reject);
  }
}
function __makeTemplateObject(cooked, raw) {
  if (Object.defineProperty) {
    Object.defineProperty(cooked, "raw", {
      value: raw
    });
  } else {
    cooked.raw = raw;
  }
  return cooked;
}
;
var __setModuleDefault = Object.create ? function (o, v) {
  Object.defineProperty(o, "default", {
    enumerable: true,
    value: v
  });
} : function (o, v) {
  o["default"] = v;
};
function __importStar(mod) {
  if (mod && mod.__esModule) return mod;
  var result = {};
  if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
  __setModuleDefault(result, mod);
  return result;
}
function __importDefault(mod) {
  return mod && mod.__esModule ? mod : {
    default: mod
  };
}
function __classPrivateFieldGet(receiver, state, kind, f) {
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}
function __classPrivateFieldSet(receiver, state, value, kind, f) {
  if (kind === "m") throw new TypeError("Private method is not writable");
  if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}
function __classPrivateFieldIn(state, receiver) {
  if (receiver === null || typeof receiver !== "object" && typeof receiver !== "function") throw new TypeError("Cannot use 'in' operator on non-object");
  return typeof state === "function" ? receiver === state : state.has(receiver);
}

/***/ }),

/***/ "./modules/__config.js":
/*!*****************************!*\
  !*** ./modules/__config.js ***!
  \*****************************/
/***/ ((module) => {

module.exports = {
  config: {
    "logEnabled": true,
    "privateOptionEnabled": true,
    "isMac": false
  }
};

/***/ }),

/***/ "./action.js":
/*!*******************!*\
  !*** ./action.js ***!
  \*******************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _modules_common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modules/common.js */ "./modules/common.js");
/* harmony import */ var _modules_port_to_background_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modules/port_to_background.js */ "./modules/port_to_background.js");
/* harmony import */ var _modules_modifier_keys_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modules/modifier_keys.js */ "./modules/modifier_keys.js");
/* harmony import */ var _material_ripple__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material/ripple */ "../node_modules/@material/ripple/component.js");






(async function main() {
  //////////////////////////////////////////////////////////////////////////////
  // Initialize common modules
  //////////////////////////////////////////////////////////////////////////////

  await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.init(_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.ScriptId.ACTION);

  //////////////////////////////////////////////////////////////////////////////
  // Constants
  //////////////////////////////////////////////////////////////////////////////

  const MESSAGE_HANDLERS = {
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.NOTIFY_SELECTION]: onNotifySelection
  };

  //////////////////////////////////////////////////////////////////////////////
  // Variables
  //////////////////////////////////////////////////////////////////////////////

  const portToBackground = new _modules_port_to_background_js__WEBPACK_IMPORTED_MODULE_1__.PortToBackground({
    name: document.URL,
    autoConnect: true,
    onMessage
  });
  const parentTab = await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.getActiveTab();
  _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Get active tab as the parent one", {
    parentTab
  });
  const modifierKeys = new _modules_modifier_keys_js__WEBPACK_IMPORTED_MODULE_2__.ModifierKeys(window);

  //////////////////////////////////////////////////////////////////////////////
  // Startup Operations
  //////////////////////////////////////////////////////////////////////////////

  _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.addDOMContentLoadedEventListener(window, onDOMContentLoaded);

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (Background service worker)
  //////////////////////////////////////////////////////////////////////////////

  function onMessage(message, port) {
    MESSAGE_HANDLERS[message.type](message, port);
  }
  function onNotifySelection(message, _port) {
    if (message.selection) {
      const normalizedSelectionText = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.normalizeSelectionText(message.selection.text);
      if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.isNormalizedSelectionTextValid(normalizedSelectionText)) {
        const textField = document.getElementById("qqs-search-bar-text");
        textField.value = normalizedSelectionText;
        textField.setSelectionRange(0, textField.value.length, "forward");
      }
    }
  }

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (DOM)
  //////////////////////////////////////////////////////////////////////////////

  async function onDOMContentLoaded() {
    portToBackground.postMessage({
      type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.GET_SELECTION,
      tab: parentTab
    });
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.injectI18NMessagesInHtml(document);
    await fillShortcutsTable();
    document.getElementById("qqs-search-form").addEventListener("submit", onSearchFormSubmit);
    document.getElementById("qqs-shortcuts-settings-link").addEventListener("click", onShortcutsSettingsLinkClick);
    const optionsPageButton = document.getElementById("qqs-options-page");
    optionsPageButton.addEventListener("click", onOptionsPageButtonClick);
    const optionsPageButtonRipple = new _material_ripple__WEBPACK_IMPORTED_MODULE_3__.MDCRipple(optionsPageButton);
    optionsPageButtonRipple.unbounded = true;
  }
  async function onSearchFormSubmit(e) {
    e.preventDefault();
    const normalizedSelectionText = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.normalizeSelectionText(_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.filterSelectionText(document.getElementById("qqs-search-bar-text").value));
    if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.isNormalizedSelectionTextValid(normalizedSelectionText)) {
      if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.autoCopy) {
        window.navigator.clipboard.writeText(normalizedSelectionText);
      }
      await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.doQuotedSearch(parentTab, normalizedSelectionText, modifierKeys.keyState);
    }
  }
  async function onShortcutsSettingsLinkClick(e) {
    e.preventDefault();
    await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.openShortcutsSettings(parentTab, new _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.KeyState(e.ctrlKey, e.shiftKey, e.metaKey), _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.NEW_TAB_ACTIVE);
  }
  async function onOptionsPageButtonClick(e) {
    await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.openOptionsPage(parentTab, new _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.KeyState(e.ctrlKey, e.shiftKey, e.metaKey), _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.NEW_TAB_ACTIVE);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Functions
  //////////////////////////////////////////////////////////////////////////////

  async function fillShortcutsTable() {
    const divShortcuts = document.getElementById("qqs-shortcuts");
    const commands = await chrome.commands.getAll();
    for (const {
      name,
      shortcut,
      description
    } of commands) {
      const divShortcutKey = divShortcuts.appendChild(document.createElement("div"));
      divShortcutKey.dataset.shortcutName = name;
      divShortcutKey.classList.add("shortcuts__key");
      const spanShortcutKey = divShortcutKey.appendChild(document.createElement("span"));
      if (shortcut) {
        spanShortcutKey.innerText = shortcut.replaceAll(/\+/g, " + ");
      } else {
        divShortcutKey.classList.add("shortcuts__key--not-set");
        spanShortcutKey.innerText = chrome.i18n.getMessage("msg_action_shortcut_key_not_set");
      }
      const divShortcutDescription = divShortcuts.appendChild(document.createElement("div"));
      divShortcutDescription.dataset.shortcutName = name;
      divShortcutDescription.classList.add("shortcuts__description");
      const spanShortcutDescription = divShortcutDescription.appendChild(document.createElement("span"));
      spanShortcutDescription.innerText = description;
    }
  }
})();

/***/ }),

/***/ "./modules/__constants.js":
/*!********************************!*\
  !*** ./modules/__constants.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommandType": () => (/* binding */ CommandType),
/* harmony export */   "MessageType": () => (/* binding */ MessageType),
/* harmony export */   "QUOTATION_MARKS": () => (/* binding */ QUOTATION_MARKS),
/* harmony export */   "SELECTION_TEXT_MAX_LENGTH": () => (/* binding */ SELECTION_TEXT_MAX_LENGTH),
/* harmony export */   "SELECTION_TEXT_TOO_LONG_MARKER": () => (/* binding */ SELECTION_TEXT_TOO_LONG_MARKER),
/* harmony export */   "ScriptId": () => (/* binding */ ScriptId)
/* harmony export */ });
/**
 * Script id.
 */
const ScriptId = {
  ACTION: "ACTION",
  BACKGROUND: "BACKGROUND",
  CONTENT: "-",
  OPTIONS: "OPTIONS"
};

/**
 * Command IDs for keyboard shortcuts and context menus.
 */
const CommandType = {
  DO_QUOTED_SEARCH: "do_quoted_search",
  PUT_QUOTES: "put_quotes"
};

/**
 * Message types.
 */
const MessageType = {
  // ---------------------------------------------------------------------------
  // Content scripts --> Background service worker
  // ---------------------------------------------------------------------------
  HELLO: "hello",
  NOTIFY_SELECTION_UPDATED: "notify_selection_updated",
  DO_QUOTED_SEARCH: "do_quoted_search",
  OPEN_OPTIONS_PAGE: "open_options_page",
  // ---------------------------------------------------------------------------
  // Content scripts <-- Background service worker
  // ---------------------------------------------------------------------------
  WELCOME: "welcome",
  PUT_QUOTES: "put_quotes",
  // ---------------------------------------------------------------------------
  // Action scripts --> Background service worker
  // ---------------------------------------------------------------------------
  GET_SELECTION: "get_selection",
  // ---------------------------------------------------------------------------
  // Action scripts <-- Background service worker
  // ---------------------------------------------------------------------------
  NOTIFY_SELECTION: "notify_selection"
};

/**
 * Various double quotes.
 *
 * If you surround your search phrase with characters in this string, Google
 * Search will give you an exact match. In other words, these are the characters
 * that Google Search recognizes as valid double quotes for an exact match.
 *
 * Text containing double quotes cannot be enclosed in double quotes, so those
 * characters must be removed if they are included in the selected text when
 * searching for an exact match.
 */
const QUOTATION_MARKS = "\u0022\u201c\u201d\u201e\u201f\u2033\u301d\u301e\u301f\uff02"; // "“”„‟″〝〞〟＂

/**
 * The maximum length of the selected text to be processed.
 */
const SELECTION_TEXT_MAX_LENGTH = 1024;

/**
 * Indicates that the length of the selected text exceeds the limit.
 *
 * A very large text may be selected, in which case this string is preserved
 * instead of the original string as the selected text to avoid wasting memory
 * and making logs noisy.
 */
const SELECTION_TEXT_TOO_LONG_MARKER = "### Too Long! ### yoBjv^F7%sg#NMxCrqvYKMgD85sRXRiG";

/***/ }),

/***/ "./modules/__functions.js":
/*!********************************!*\
  !*** ./modules/__functions.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addDOMContentLoadedEventListener": () => (/* binding */ addDOMContentLoadedEventListener),
/* harmony export */   "addLoadCompletedEventListener": () => (/* binding */ addLoadCompletedEventListener),
/* harmony export */   "cloneDto": () => (/* binding */ cloneDto),
/* harmony export */   "createNewTab": () => (/* binding */ createNewTab),
/* harmony export */   "createNewWindow": () => (/* binding */ createNewWindow),
/* harmony export */   "doQuotedSearch": () => (/* binding */ doQuotedSearch),
/* harmony export */   "filterSelectionText": () => (/* binding */ filterSelectionText),
/* harmony export */   "getActiveTab": () => (/* binding */ getActiveTab),
/* harmony export */   "getSelection": () => (/* binding */ getSelection),
/* harmony export */   "injectI18NMessagesInHtml": () => (/* binding */ injectI18NMessagesInHtml),
/* harmony export */   "isNormalizedSelectionTextValid": () => (/* binding */ isNormalizedSelectionTextValid),
/* harmony export */   "mergeObject": () => (/* binding */ mergeObject),
/* harmony export */   "normalizeSelectionText": () => (/* binding */ normalizeSelectionText),
/* harmony export */   "openLink": () => (/* binding */ openLink),
/* harmony export */   "openOptionsPage": () => (/* binding */ openOptionsPage),
/* harmony export */   "openSearchEngineSettings": () => (/* binding */ openSearchEngineSettings),
/* harmony export */   "openShortcutsSettings": () => (/* binding */ openShortcutsSettings),
/* harmony export */   "postMessage": () => (/* binding */ postMessage),
/* harmony export */   "quoteText": () => (/* binding */ quoteText)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _globals_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__globals.js */ "./modules/__globals.js");
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");




/**
 * Filters the selected text obtained from external sources.
 *
 * For security purposes, be sure to pass the selected text obtained from
 * external sources through this filter before using it.
 *
 * @param {?string} selectionText
 * @returns {!string}
 */
function filterSelectionText(selectionText) {
  selectionText ??= "";
  return selectionText.length > _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_MAX_LENGTH ? _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER : selectionText;
}

/**
 * Normalizes the selected text.
 *
 * The normalization includes:
 *
 * - Replace double quotes with a space.
 * - Collapse consecutive whitespace characters into single space.
 * - Remove whitespace from both ends of the string.
 *
 * @param {?string} selectionText
 * @returns {!string}
 */
function normalizeSelectionText(selectionText) {
  selectionText = filterSelectionText(selectionText);
  return selectionText === _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER ? selectionText : selectionText.replaceAll(new RegExp(`[\\s${_constants_js__WEBPACK_IMPORTED_MODULE_0__.QUOTATION_MARKS}]+`, "g"), " ").trim();
}

/**
 * Checks if the normalized selection text is valid for processing.
 *
 * @param {?string} normalizedSelectionText
 * @returns {!boolean}
 */
function isNormalizedSelectionTextValid(normalizedSelectionText) {
  normalizedSelectionText ??= "";
  return normalizedSelectionText !== _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER && normalizedSelectionText.length > 0 && normalizedSelectionText.length <= _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_MAX_LENGTH;
}

/**
 * Puts double quotes around the string.
 *
 * @param {?string} text
 * @returns {!string}
 */
function quoteText(text) {
  return '"' + (text ?? "") + '"';
}

/**
 * Clones an object treated as a DTO.
 *
 * If you need pass an object whose contents may be changed later to an
 * asynchronous method, pass an object cloned by this function instead of the
 * origin object.
 *
 * @param {?object} obj
 * @returns {!object}
 */
function cloneDto(obj) {
  return JSON.parse(JSON.stringify(obj ?? {}));
}

/**
 * Merges `rhs` to `lhs`, ignoring properties with a value of `undefined`.
 *
 * @param {?object} target
 * @param {?object} source
 * @returns {!object}
 */
function mergeObject(target, source) {
  return {
    ...target,
    ...Object.fromEntries(Object.entries(source ?? {}).filter(([, v]) => v !== undefined))
  };
}

/**
 * Sets up an event listener for `DOMContentLoaded` event.
 *
 * This function checks `Document.readyState` and sets up the event listener as
 * a microtasks if the event has already been fired.
 *
 * @param {!Window} win
 * @param {!function():void} listener
 */
function addDOMContentLoadedEventListener(win, listener) {
  if (win.document.readyState === "loading") {
    win.document.addEventListener("DOMContentLoaded", listener);
  } else {
    queueMicrotask(listener);
  }
}

/**
 * Sets up an event listener for `load` event.
 *
 * This function checks `Document.readyState` and sets up the event listener as
 * a microtasks if the event has already been fired.
 *
 * @param {!Window} win
 * @param {!function():void} listener
 */
function addLoadCompletedEventListener(win, listener) {
  if (win.document.readyState !== "complete") {
    win.addEventListener("load", listener);
  } else {
    queueMicrotask(listener);
  }
}

/**
 * Injects localized strings into HTML document.
 *
 * @param {!Document} doc
 */
function injectI18NMessagesInHtml(doc) {
  const I18N_TARGETS = ["outerHTML", "innerHTML", "outerText", "innerText", "value"];
  for (const element of doc.querySelectorAll("[data-group~='i18n'")) {
    const substitutions = (() => {
      const result = [];
      const args = element.dataset.i18nArgs;
      if (!args) {
        return result;
      }
      const ids = args.split(" ");
      for (const id of ids) {
        const argElement = doc.getElementById(id);
        const argTarget = argElement.dataset.i18nTarget;
        _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.assert(I18N_TARGETS.includes(argTarget), "Unexpected target", {
          argTarget,
          argElement
        });
        result.push(argElement[argTarget]);
      }
      return result;
    })();
    const target = element.dataset.i18nTarget;
    _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.assert(I18N_TARGETS.includes(target), "Unexpected target", {
      target,
      element
    });
    element[target] = chrome.i18n.getMessage(element.dataset.i18nName, substitutions);
  }
}

/**
 * Gets `Selection` object.
 *
 * This function not only calls `Window.getSelection()`, but also recursively
 * searches within the nested Shadow DOMs.
 *
 * @param {!Window} win
 * @returns {!Selection}
 */
function getSelection(win) {
  function findSelectionRecursively(selection) {
    if (selection.rangeCount === 1) {
      const range = selection.getRangeAt(0);
      if (range.startContainer === range.endContainer) {
        const commonAncestorContainer = range.commonAncestorContainer;
        if (commonAncestorContainer instanceof Element) {
          if (commonAncestorContainer.shadowRoot) {
            return findSelectionRecursively(commonAncestorContainer.shadowRoot.getSelection());
          } else {
            const elementsWithShadowRoot = Array.prototype.filter.call(commonAncestorContainer.querySelectorAll("*"), element => !!element.shadowRoot);
            if (elementsWithShadowRoot.length === 1) {
              return findSelectionRecursively(elementsWithShadowRoot[0].shadowRoot.getSelection());
            }
          }
        }
      }
    }
    return selection;
  }
  return findSelectionRecursively(win.getSelection());
}

/**
 * Calls `chrome.runtime.Port.postMessage()` method.
 *
 * Catches the error thrown from `chrome.runtime.Port.postMessage()` method and
 * logs a warning message.
 *
 * `chrome.runtime.Port.postMessage()` throws an error if the other side of the
 * port has already been closed, but there is no way to check in advance whether
 * the port is still opened or has been closed.
 * Port disconnection is one of the expected conditions, even in an edge case,
 * and most of the time it is not an error case.
 * Therefore, if an error is thrown from `chrome.runtime.Port.postMessage()`
 * method, this function assumes the cause is port disconnection and logs it as
 * a warning instead of an error.
 *
 * @param {!chrome.runtime.Port} port
 * @param {!*} message
 */
function postMessage(port, message) {
  try {
    port.postMessage(message);
  } catch (error) {
    _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.warn("It seems that the message could not be sent because the other side of the port has already been closed", {
      error,
      port,
      message
    });
  }
}

/**
 * Gets the active tab.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @returns {!Promise<!chrome.tabs.Tab>}
 */
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });
  return tab;
}

/**
 * Creates a new tab.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?{url:?string=, active:?boolean=}=} params
 * @returns {!Promise<void>}
 */
async function createNewTab(tab, params) {
  return await chrome.tabs.create({
    windowId: tab.windowId,
    openerTabId: tab.id,
    index: tab.index + 1,
    url: params?.url,
    active: params?.active ?? true
  });
}

/**
 * Creates a new window.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {?{url:?string=}=} params
 * @returns {!Promise<void>}
 */
async function createNewWindow(params) {
  const currentWindow = await chrome.windows.getCurrent();
  return await chrome.windows.create({
    state: currentWindow.state,
    url: params?.url
  });
}

/**
 * Invokes search engine to do quoted search.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {!string} searchText Text to search, not to be enclosed in double quotes.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @returns {!Promise<void>}
 */
async function doQuotedSearch(tab, searchText, keyState) {
  const howToOpenLink = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.decide(keyState, new _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink(_globals_js__WEBPACK_IMPORTED_MODULE_1__.options.disposition, true));
  if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.NEW_TAB) {
    const newTab = await createNewTab(tab, {
      active: false
    });
    await chrome.search.query({
      tabId: newTab.id,
      text: quoteText(searchText)
    });
    // To prevent the omnibox from receiving focus, activate new tab after
    // creation and search.
    if (howToOpenLink.active ?? true) {
      await chrome.tabs.update(newTab.id, {
        active: true
      });
    }
  } else {
    await chrome.search.query({
      disposition: howToOpenLink.disposition,
      text: quoteText(searchText)
    });
  }
}

/**
 * Opens the web page with specified URL.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {!string} url
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openLink(tab, url, keyState, defaultHowToOpenLink) {
  const howToOpenLink = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.decide(keyState, defaultHowToOpenLink);
  if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.CURRENT_TAB) {
    await chrome.tabs.update(tab.id, {
      url: url
    });
  } else if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.NEW_WINDOW) {
    await createNewWindow({
      url: url
    });
  } else {
    await createNewTab(tab, {
      url: url,
      active: howToOpenLink.active ?? true
    });
  }
}

/**
 * Opens the extension's Options page.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openOptionsPage(tab, keyState, defaultHowToOpenLink) {
  const url = chrome.runtime.getURL("options.html");
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/**
 * Opens search engine settings page of the browser.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openSearchEngineSettings(tab, keyState, defaultHowToOpenLink) {
  const url = "chrome://settings/search";
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/**
 * Opens keyboard shortcuts settings page of the browser.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openShortcutsSettings(tab, keyState, defaultHowToOpenLink) {
  const url = "chrome://extensions/shortcuts";
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/***/ }),

/***/ "./modules/__globals.js":
/*!******************************!*\
  !*** ./modules/__globals.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "init": () => (/* binding */ init),
/* harmony export */   "logger": () => (/* binding */ logger),
/* harmony export */   "options": () => (/* binding */ options)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__logger.js */ "./modules/__logger.js");
/* harmony import */ var _options_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./__options.js */ "./modules/__options.js");





/**
 * Logger used used throughout the extension.
 *
 * It will be initialized in {@link init()} function.
 *
 * @type {Logger}
 */
let logger;

/**
 * Options used used throughout the extension.
 *
 * It will be initialized in {@link init()} function.
 *
 * @type {Options}
 */
let options;

/**
 * Initializes the module.
 *
 * This function must be called first to initialize global variables before
 * using them and any other functions depending these global variables.
 *
 * @param {!string} scriptId
 * @returns {!Promise<void>}
 */
async function init(scriptId) {
  logger = new _logger_js__WEBPACK_IMPORTED_MODULE_2__.Logger(scriptId);
  logger.state("Initialize script", {
    scriptId
  });
  options = new _options_js__WEBPACK_IMPORTED_MODULE_3__.Options(logger);
  await options.init();
  await checkOsIsMac(scriptId);
}
async function checkOsIsMac(scriptId) {
  const STORAGE_KEY = "isMac";
  const storage = chrome.storage.local;
  if (scriptId === _constants_js__WEBPACK_IMPORTED_MODULE_1__.ScriptId.BACKGROUND) {
    _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac = (await chrome.runtime.getPlatformInfo()).os === "mac";
    await storage.set({
      [STORAGE_KEY]: _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac
    });
  } else {
    _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac = !!(await storage.get(STORAGE_KEY))[STORAGE_KEY];
  }
  logger.state("Updated `isMac` in config", {
    ["config.isMac"]: _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac
  });
}

/***/ }),

/***/ "./modules/__how_to_open_link.js":
/*!***************************************!*\
  !*** ./modules/__how_to_open_link.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HowToOpenLink": () => (/* binding */ HowToOpenLink)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Controls how to open a link based on the state of control keys such as `Ctrl`
 * and `Shift`.
 */
class HowToOpenLink {
  /**
   * Location where a link should be opened.
   *
   * The values of this enum are same as
   * [chrome.search.Disposition](https://developer.chrome.com/docs/extensions/reference/search/#type-Disposition).
   * Therefore, they can be used as-is as a parameter to
   * [chrome.search.query()](https://developer.chrome.com/docs/extensions/reference/search/#method-query).
   */
  static Disposition = {
    CURRENT_TAB: "CURRENT_TAB",
    NEW_TAB: "NEW_TAB",
    NEW_WINDOW: "NEW_WINDOW"
  };
  static KeyState = class KeyState {
    ctrlKey;
    shiftKey;

    /**
     * @param {!boolean} ctrlKey
     * @param {!boolean} shiftKey
     * @param {!boolean=} metaKey If specified, `metaKey` is used instead of
     *    `ctrlKey` when running on MAC.
     */
    constructor(ctrlKey, shiftKey, metaKey = ctrlKey) {
      this.ctrlKey = _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac ? metaKey : ctrlKey;
      this.shiftKey = shiftKey;
    }
    equals(other) {
      return other && this.ctrlKey === other.ctrlKey && this.shiftKey === other.shiftKey;
    }
    static CURRENT_TAB = new KeyState(false, false);
    static NEW_TAB_ACTIVE = new KeyState(true, true);
    static NEW_TAB_INACTIVE = new KeyState(true, false);
    static NEW_WINDOW = new KeyState(false, true);
  };

  /**
   * @type {!HowToOpenLink.Disposition}
   */
  disposition;

  /**
   * Available only if `disposition ===  NEW_TAB`.
   *
   * @type {boolean=}
   */
  active;

  /**
   * @param {!HowToOpenLink.Disposition} disposition
   * @param {boolean=} active Available only if `disposition ===  NEW_TAB`.
   */
  constructor(disposition, active = true) {
    this.disposition = disposition;
    this.active = active;
  }
  static CURRENT_TAB = new HowToOpenLink(HowToOpenLink.Disposition.CURRENT_TAB);
  static NEW_TAB_ACTIVE = new HowToOpenLink(HowToOpenLink.Disposition.NEW_TAB, true);
  static NEW_TAB_INACTIVE = new HowToOpenLink(HowToOpenLink.Disposition.NEW_TAB, false);
  static NEW_WINDOW = new HowToOpenLink(HowToOpenLink.Disposition.NEW_WINDOW);

  /**
   * Decides location where a link should be opened.
   *
   * @param {?HowToOpenLink.KeyState=} keyState
   * @param {?HowToOpenLink=} defaultHowToOpenLink
   * @returns {!HowToOpenLink}
   */
  static decide(keyState, defaultHowToOpenLink) {
    if (HowToOpenLink.KeyState.NEW_TAB_ACTIVE.equals(keyState)) return HowToOpenLink.NEW_TAB_ACTIVE;else if (HowToOpenLink.KeyState.NEW_TAB_INACTIVE.equals(keyState)) return HowToOpenLink.NEW_TAB_INACTIVE;else if (HowToOpenLink.KeyState.NEW_WINDOW.equals(keyState)) return HowToOpenLink.NEW_WINDOW;else return defaultHowToOpenLink ?? HowToOpenLink.CURRENT_TAB;
  }
}

/***/ }),

/***/ "./modules/__logger.js":
/*!*****************************!*\
  !*** ./modules/__logger.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Logger": () => (/* binding */ Logger)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Outputs logs only if `config.logEnabled` is true. Otherwise, all of the
 * instance methods of this class have no operations (ie empty).
 */
class Logger {
  #id;

  /**
   * @param {!string} id Appears at the beginning of the log message, enclosed
   *    in square brackets.
   */
  constructor(id) {
    this.#id = id;
  }

  /**
   * @param {!string} id
   */
  setId(id) {
    this.#id = id;
  }

  /**
   * Call `console.debug()` with the header `[INFO]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  info(message, ...args) {
    this.#output("debug", "[INFO]", message, args);
  }

  /**
   * Call `console.debug()` with the header `[STATE]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  state(message, ...args) {
    this.#output("debug", "[STATE]", message, args);
  }

  /**
   * Call `console.debug()` with the header `[CALLBACK]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  callback(message, ...args) {
    this.#output("debug", "[CALLBACK]", message, args);
  }

  /**
   * Call `console.warn()` with the header `[WARN]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  warn(message, ...args) {
    this.#output("warn", "[WARN]", message, args);
  }

  /**
   * Call `console.error()` with the header `[ERROR]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  error(message, ...args) {
    this.#output("error", "[ERROR]", message, args);
  }

  /**
   * Call `console.assert()` with the header `[ERROR]` prepended to the message.
   *
   * @param {!boolean} assertion
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  assert(assertion, message, ...args) {
    this.#output("assert", "[ERROR]", message, args, assertion);
  }

  /**
   * Call Console API specified by the `method` argument.
   *
   * @param {!string} consoleApi Console API to call.
   * @param {!string} header
   * @param {!string} message
   * @param {?any[]=} args
   * @param {?boolean=} assertion must be specified if `method` is "assert", otherwise ignored.
   */
  #output(consoleApi, header, message, args, assertion) {
    if (!_config_js__WEBPACK_IMPORTED_MODULE_0__.config.logEnabled) {
      return;
    }
    const optionalArgs = [];
    if (args && args.length > 0 && typeof args.at(-1) === "object") {
      for (const [key, value] of Object.entries(args.pop())) {
        optionalArgs.push(`\n${key}=`);
        optionalArgs.push(value);
      }
    }
    console[consoleApi](...(consoleApi === "assert" ? [!!assertion] : []), `[${this.#id}] ${header} ${message}`, ...args, ...optionalArgs);
  }
}

/***/ }),

/***/ "./modules/__options.js":
/*!******************************!*\
  !*** ./modules/__options.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Options": () => (/* binding */ Options)
/* harmony export */ });
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");


/**
 * User-customizable extension options.
 *
 * Options is stored in the
 * [sync](https://developer.chrome.com/docs/extensions/reference/storage/#property-sync)
 * storage area that is synced using Chrome Sync.
 */
class Options {
  static #storage = chrome.storage.sync;
  static #STORAGE_KEY = "options";
  static #UPDATED_AT_KEY = "__updatedAt__";
  static #DEFAULT_VALUES = {
    [Options.#UPDATED_AT_KEY]: 0
  };
  static Disposition = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.Disposition;
  static ICON_SIZE_MIN = 1;
  static ICON_SIZE_MAX = 5;

  // prettier-ignore
  /**
   * Definition of options.
   *
   * Just add a row into this table to add a new option item. The code necessary
   * to read and write option values is automatically generated.
   *
   * @type {{name:!string, defaultValue:!*, validator:!function(?*):boolean}[]}
   */
  static #ITEMS = [{
    name: "popupIcon",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "iconSize",
    defaultValue: 3,
    validator: value => typeof value === "number" && value >= Options.ICON_SIZE_MIN && value <= Options.ICON_SIZE_MAX
  }, {
    name: "avoidSelection",
    defaultValue: false,
    validator: value => typeof value === "boolean"
  }, {
    name: "optionsButton",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "contextMenu",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "disposition",
    defaultValue: Options.Disposition.NEW_TAB,
    validator: value => typeof value === "string" && Object.values(Options.Disposition).includes(value)
  }, {
    name: "autoCopy",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "autoEnter",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "autoSurround",
    defaultValue: false,
    validator: value => typeof value === "boolean"
  }];
  static #defineOptions() {
    for (const {
      name,
      defaultValue,
      validator
    } of Options.#ITEMS) {
      Options.#DEFAULT_VALUES[name] = defaultValue;
      Object.defineProperty(Options.prototype, name, {
        set(value) {
          if (!validator(value)) {
            throw new Error(`Options: Invalid value for '${name}'\nvalue=${value}`);
          }
          if (value !== this.#cache[name]) {
            this.#cache[name] = value;
            /* async */
            this.#updateStorage();
          }
        },
        get() {
          return validator(this.#cache[name]) ? this.#cache[name] : defaultValue;
        }
      });
    }
  }
  static #_ = Options.#defineOptions();
  /**
   * Fired when one or more options are changed externally.
   */
  onChanged = new class onChanged {
    #listeners = [];
    /**
     * @param {!function(!Options):void} listener
     */
    addListener(listener) {
      this.#listeners.push(listener);
    }
    _fire() {
      for (const listener of this.#listeners) {
        listener();
      }
    }
  }();
  #logger;
  #cache;

  /**
   * @param {!Logger} logger
   */
  constructor(logger) {
    this.#logger = logger;
    this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
    Options.#storage.onChanged.addListener((changes, areaName) => {
      this.#onChangedListener(changes, areaName);
    });
  }

  /**
   * Load options from the storage.
   */
  async init() {
    const values = await Options.#storage.get(Options.#STORAGE_KEY);
    // Merge rather than assign to ensure completeness of options in case of
    // missing data in the storage.
    Object.assign(this.#cache, values[Options.#STORAGE_KEY]);
    this.#logger.state("Options: Initialized", {
      ["this.#cache"]: this.#cache
    });
  }

  /**
   * Reset all options to restore defaults.
   */
  reset() {
    this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
    /* async */
    this.#updateStorage();
  }
  async #updateStorage() {
    this.#cache[Options.#UPDATED_AT_KEY] = Date.now();
    const values = {
      [Options.#STORAGE_KEY]: this.#cache
    };
    this.#logger.state("Options: Update storage", {
      values
    });
    await Options.#storage.set(values);
  }
  #onChangedListener(changes, areaName) {
    this.#logger.callback("Options: onChangedListener()", {
      changes,
      areaName
    });
    if (!Object.hasOwn(changes, Options.#STORAGE_KEY)) {
      return;
    }
    if (Object.hasOwn(changes[Options.#STORAGE_KEY], "newValue")) {
      const newValue = changes[Options.#STORAGE_KEY].newValue;
      if (newValue[Options.#UPDATED_AT_KEY] <= this.#cache[Options.#UPDATED_AT_KEY]) {
        this.#logger.info("Options: Cache was not overwritten because it is up to date", {
          ["this.#cache"]: this.#cache
        });
        return;
      }

      // Merge rather than assign to ensure completeness of options in case of
      // missing data in the storage.
      Object.assign(this.#cache, newValue);
      this.#logger.state("Options: Cache was overwritten by values in storage updated by other", {
        ["this.#cache"]: this.#cache
      });
    } else {
      // The storage has been cleared.

      this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
      this.#logger.state("Options: Cache was reset to default values because the storage has been cleared", {
        ["this.#cache"]: this.#cache
      });
    }
    this.onChanged._fire();
  }
}

/***/ }),

/***/ "./modules/common.js":
/*!***************************!*\
  !*** ./modules/common.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommandType": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.CommandType),
/* harmony export */   "HowToOpenLink": () => (/* reexport safe */ _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_4__.HowToOpenLink),
/* harmony export */   "Logger": () => (/* reexport safe */ _logger_js__WEBPACK_IMPORTED_MODULE_5__.Logger),
/* harmony export */   "MessageType": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.MessageType),
/* harmony export */   "Options": () => (/* reexport safe */ _options_js__WEBPACK_IMPORTED_MODULE_6__.Options),
/* harmony export */   "QUOTATION_MARKS": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.QUOTATION_MARKS),
/* harmony export */   "SELECTION_TEXT_MAX_LENGTH": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.SELECTION_TEXT_MAX_LENGTH),
/* harmony export */   "SELECTION_TEXT_TOO_LONG_MARKER": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.SELECTION_TEXT_TOO_LONG_MARKER),
/* harmony export */   "ScriptId": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.ScriptId),
/* harmony export */   "addDOMContentLoadedEventListener": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.addDOMContentLoadedEventListener),
/* harmony export */   "addLoadCompletedEventListener": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.addLoadCompletedEventListener),
/* harmony export */   "cloneDto": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.cloneDto),
/* harmony export */   "createNewTab": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.createNewTab),
/* harmony export */   "createNewWindow": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.createNewWindow),
/* harmony export */   "doQuotedSearch": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.doQuotedSearch),
/* harmony export */   "filterSelectionText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.filterSelectionText),
/* harmony export */   "getActiveTab": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.getActiveTab),
/* harmony export */   "getSelection": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.getSelection),
/* harmony export */   "init": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.init),
/* harmony export */   "injectI18NMessagesInHtml": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.injectI18NMessagesInHtml),
/* harmony export */   "isNormalizedSelectionTextValid": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.isNormalizedSelectionTextValid),
/* harmony export */   "logger": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.logger),
/* harmony export */   "mergeObject": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.mergeObject),
/* harmony export */   "normalizeSelectionText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.normalizeSelectionText),
/* harmony export */   "openLink": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openLink),
/* harmony export */   "openOptionsPage": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openOptionsPage),
/* harmony export */   "openSearchEngineSettings": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openSearchEngineSettings),
/* harmony export */   "openShortcutsSettings": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openShortcutsSettings),
/* harmony export */   "options": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.options),
/* harmony export */   "postMessage": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.postMessage),
/* harmony export */   "quoteText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.quoteText)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _config_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _config_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _functions_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__functions.js */ "./modules/__functions.js");
/* harmony import */ var _globals_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./__globals.js */ "./modules/__globals.js");
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./__logger.js */ "./modules/__logger.js");
/* harmony import */ var _options_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./__options.js */ "./modules/__options.js");
/**
 * @file Aggregates modules.
 */









/***/ }),

/***/ "./modules/modifier_keys.js":
/*!**********************************!*\
  !*** ./modules/modifier_keys.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModifierKeys": () => (/* binding */ ModifierKeys)
/* harmony export */ });
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common.js */ "./modules/common.js");


/**
 * Capturing state of modifier keys.
 */
class ModifierKeys {
  /**
   * @type {!HowToOpenLink.KeyState}
   */
  #keyState = new _common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.KeyState(false, false, false);

  /**
   *  @param {!Window} win
   */
  constructor(win) {
    ["keydown", "keyup", "click"].forEach(type => {
      win.document.documentElement.addEventListener(type, e => this.#keyState = new _common_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.KeyState(e.ctrlKey, e.shiftKey, e.metaKey));
    });
  }

  /**
   * @returns {!HowToOpenLink.KeyState}
   */
  get keyState() {
    return this.#keyState;
  }
}

/***/ }),

/***/ "./modules/port_to_background.js":
/*!***************************************!*\
  !*** ./modules/port_to_background.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PortToBackground": () => (/* binding */ PortToBackground)
/* harmony export */ });
/* harmony import */ var _common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./common.js */ "./modules/common.js");


/**
 * Represent the connection to Background service worker, and provide ability to
 * re-connect to it automatically if it is idle (i.e. is disconnected).
 */
class PortToBackground {
  #port;
  #params = {
    name: "",
    autoConnect: false,
    onConnect: () => {},
    onDisconnect: () => {},
    onMessage: () => {}
  };

  /**
   * @param {?{name:?string=,autoConnect:?boolean=,onConnect:?function():void=,onDisconnect:?function():void=,onMessage:?function(!*):void=}=} params
   */
  constructor(params) {
    this.#params = _common_js__WEBPACK_IMPORTED_MODULE_0__.mergeObject(this.#params, params);
  }
  connect() {
    if (this.#port) {
      _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.warn("Already connected", {
        port: this.#port
      });
      return;
    }
    try {
      this.#port = chrome.runtime.connect(undefined, {
        name: this.#params.name
      });
    } catch (error) {
      // The extension might have been refreshed, in which case it will never be
      // able to connect to Background service worker from this context again.
      _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("⚠ The extension might have been refreshed, in which case it is impossible to connect to Background service worker", {
        error
      });
      return;
    }
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Connected to Background service worker", {
      port: this.#port
    });
    this.#port.onDisconnect.addListener(port => this.#onDisconnect(port));
    this.#port.onMessage.addListener((message, port) => this.#onMessage(message, port));
    this.#params.onConnect();
  }
  disconnect() {
    if (this.#port) {
      this.#port.disconnect();
      this.#port = undefined;
      _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Disconnected from Background service worker");
    }
  }
  reconnect() {
    this.disconnect();
    this.connect();
  }

  /**
   * @returns {!chrome.runtime.Port}
   */
  get port() {
    return this.#port;
  }

  /**
   * @param {!*} message
   */
  postMessage(message) {
    if (!this.#checkConnection()) {
      return;
    }
    _common_js__WEBPACK_IMPORTED_MODULE_0__.postMessage(this.#port, message);
  }
  #checkConnection() {
    if (!this.#port) {
      if (this.#params.autoConnect) {
        this.connect();
      } else {
        _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.warn("Could not send message to Background service worker because the port has already been closed");
      }
    }
    return !!this.#port;
  }
  #onDisconnect(port) {
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onDisconnect()", {
      port
    });
    this.#port = undefined;
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Port to Background service worker has been closed by the other end");
    this.#params.onDisconnect();
  }
  #onMessage(message, port) {
    _common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onMessage()", {
      message,
      port
    });
    this.#params.onMessage(message);
  }
}

/***/ }),

/***/ "./action.scss":
/*!*********************!*\
  !*** ./action.scss ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
// extracted by mini-css-extract-plugin


/***/ }),

/***/ "./action.html":
/*!*********************!*\
  !*** ./action.html ***!
  \*********************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
module.exports = __webpack_require__.p + "action.html";

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript)
/******/ 				scriptUrl = document.currentScript.src
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) scriptUrl = scripts[scripts.length - 1].src
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	__webpack_require__("./action.js");
/******/ 	__webpack_require__("./action.scss");
/******/ 	// This entry module doesn't tell about it's top-level declarations so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./action.html");
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWN0aW9uX2J1bmRsZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVCMEM7QUFHMUM7RUFXRSxzQkFDV0MsSUFBYSxFQUFFQyxVQUEyQjtJQUFFO1NBQUEsVUFBa0IsRUFBbEJDLHFCQUFrQixFQUFsQkEsSUFBa0I7TUFBbEJDOztJQUE1QyxTQUFJLEdBQUpILElBQUk7SUFDYixJQUFJLENBQUNJLFVBQVUsT0FBZixJQUFJLHlHQUFlRCxJQUFJO0lBQ3ZCO0lBQ0E7SUFDQTtJQUNBLElBQUksQ0FBQ0YsVUFBVSxHQUNYQSxVQUFVLEtBQUtJLFNBQVMsR0FBRyxJQUFJLENBQUNDLG9CQUFvQixFQUFFLEdBQUdMLFVBQVU7SUFDdkUsSUFBSSxDQUFDQSxVQUFVLENBQUNNLElBQUksRUFBRTtJQUN0QixJQUFJLENBQUNDLGtCQUFrQixFQUFFO0VBQzNCO0VBcEJPQyxxQkFBUSxHQUFmLFVBQWdCVCxJQUFhO0lBQzNCO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsT0FBTyxJQUFJUyxZQUFZLENBQUNULElBQUksRUFBRSxJQUFJRCxzREFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQ3RELENBQUM7RUFnQkQ7RUFDQVUsaUNBQVUsR0FBVjtJQUFXO1NBQUEsVUFBd0IsRUFBeEJQLHFCQUF3QixFQUF4QkEsSUFBd0I7TUFBeEJROztJQUNUO0lBQ0E7SUFDQTtFQUNGLENBQUM7O0VBRURELDJDQUFvQixHQUFwQjtJQUNFO0lBQ0E7SUFDQSxNQUFNLElBQUlFLEtBQUssQ0FBQyxnRkFBZ0YsR0FDNUYsa0JBQWtCLENBQUM7RUFDekIsQ0FBQztFQUVERix5Q0FBa0IsR0FBbEI7SUFDRTtJQUNBO0lBQ0E7SUFDQTtFQUFBLENBQ0Q7RUFFREEsOEJBQU8sR0FBUDtJQUNFO0lBQ0E7SUFDQSxJQUFJLENBQUNSLFVBQVUsQ0FBQ1csT0FBTyxFQUFFO0VBQzNCLENBQUM7RUFVREgsNkJBQU0sR0FBTixVQUFPSSxPQUFlLEVBQUVDLE9BQXNCLEVBQUVDLE9BQTJDO0lBQ3pGLElBQUksQ0FBQ2YsSUFBSSxDQUFDZ0IsZ0JBQWdCLENBQUNILE9BQU8sRUFBRUMsT0FBTyxFQUFFQyxPQUFPLENBQUM7RUFDdkQsQ0FBQztFQVVETiwrQkFBUSxHQUFSLFVBQVNJLE9BQWUsRUFBRUMsT0FBc0IsRUFBRUMsT0FBMkM7SUFDM0YsSUFBSSxDQUFDZixJQUFJLENBQUNpQixtQkFBbUIsQ0FBQ0osT0FBTyxFQUFFQyxPQUFPLEVBQUVDLE9BQU8sQ0FBQztFQUMxRCxDQUFDO0VBRUQ7OztFQUdBTiwyQkFBSSxHQUFKLFVBQXVCSSxPQUFlLEVBQUVLLE9BQVUsRUFBRUMsWUFBb0I7SUFBcEI7TUFBQUEsb0JBQW9CO0lBQUE7SUFDdEUsSUFBSUMsR0FBbUI7SUFDdkIsSUFBSSxPQUFPQyxXQUFXLEtBQUssVUFBVSxFQUFFO01BQ3JDRCxHQUFHLEdBQUcsSUFBSUMsV0FBVyxDQUFJUixPQUFPLEVBQUU7UUFDaENTLE9BQU8sRUFBRUgsWUFBWTtRQUNyQkksTUFBTSxFQUFFTDtPQUNULENBQUM7S0FDSCxNQUFNO01BQ0xFLEdBQUcsR0FBR0ksUUFBUSxDQUFDQyxXQUFXLENBQUMsYUFBYSxDQUFDO01BQ3pDTCxHQUFHLENBQUNNLGVBQWUsQ0FBQ2IsT0FBTyxFQUFFTSxZQUFZLEVBQUUsS0FBSyxFQUFFRCxPQUFPLENBQUM7O0lBRzVELElBQUksQ0FBQ2xCLElBQUksQ0FBQzJCLGFBQWEsQ0FBQ1AsR0FBRyxDQUFDO0VBQzlCLENBQUM7RUFDSCxtQkFBQztBQUFELENBQUMsRUEzRkQ7O0FBNkZBO0FBQ0EsaUVBQWVYLFlBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4SDNCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJBO0VBMEJFLHVCQUFzQm1CLE9BQXdDO0lBQXhDO01BQUFBLFVBQXVCLEVBQWlCO0lBQUE7SUFBeEMsWUFBTyxHQUFQQSxPQUFPO0VBQW9DO0VBekJqRUMsc0JBQVc5QiwyQkFBVTtTQUFyQjtNQUNFO01BQ0E7TUFDQSxPQUFPLEVBQUU7SUFDWCxDQUFDOzs7O0VBRUQ4QixzQkFBVzlCLHdCQUFPO1NBQWxCO01BQ0U7TUFDQTtNQUNBLE9BQU8sRUFBRTtJQUNYLENBQUM7Ozs7RUFFRDhCLHNCQUFXOUIsd0JBQU87U0FBbEI7TUFDRTtNQUNBO01BQ0EsT0FBTyxFQUFFO0lBQ1gsQ0FBQzs7OztFQUVEOEIsc0JBQVc5QiwrQkFBYztTQUF6QjtNQUNFO01BQ0E7TUFDQTtNQUNBLE9BQU8sRUFBRTtJQUNYLENBQUM7Ozs7RUFJREEsNEJBQUksR0FBSjtJQUNFO0VBQUEsQ0FDRDtFQUVEQSwrQkFBTyxHQUFQO0lBQ0U7RUFBQSxDQUNEO0VBQ0gsb0JBQUM7QUFBRCxDQUFDLEVBbkNEOztBQWdFQTtBQUNBLGlFQUFlQSxhQUFhOzs7Ozs7Ozs7Ozs7Ozs7QUN4RjVCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJBOzs7O0FBSU0sU0FBVStCLFlBQVksQ0FBQ0MsU0FBMEI7RUFBMUI7SUFBQUEsa0JBQTBCO0VBQUE7RUFFckQsT0FBT0MscUJBQXFCLENBQUNELFNBQVMsQ0FBQyxHQUNuQztJQUFDRSxPQUFPLEVBQUU7RUFBSSxDQUE0QixHQUMxQyxLQUFLO0FBQ1g7QUFFQSxTQUFTRCxxQkFBcUIsQ0FBQ0QsU0FBMEI7RUFBMUI7SUFBQUEsa0JBQTBCO0VBQUE7RUFDdkQ7RUFDQTtFQUNBLElBQUlHLGdCQUFnQixHQUFHLEtBQUs7RUFFNUIsSUFBSTtJQUNGLElBQU1uQixPQUFPLEdBQUc7TUFDZDtNQUNBO01BQ0EsSUFBSWtCLE9BQU87UUFDVEMsZ0JBQWdCLEdBQUcsSUFBSTtRQUN2QixPQUFPLEtBQUs7TUFDZDtLQUNEO0lBRUQsSUFBTXBCLE9BQU8sR0FBRyxhQUFPLENBQUM7SUFDeEJpQixTQUFTLENBQUNQLFFBQVEsQ0FBQ1IsZ0JBQWdCLENBQUMsTUFBTSxFQUFFRixPQUFPLEVBQUVDLE9BQU8sQ0FBQztJQUM3RGdCLFNBQVMsQ0FBQ1AsUUFBUSxDQUFDUCxtQkFBbUIsQ0FDbEMsTUFBTSxFQUFFSCxPQUFPLEVBQUVDLE9BQStCLENBQUM7R0FDdEQsQ0FBQyxPQUFPb0IsR0FBRyxFQUFFO0lBQ1pELGdCQUFnQixHQUFHLEtBQUs7O0VBRzFCLE9BQU9BLGdCQUFnQjtBQUN6Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxREE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF1QkE7Ozs7QUFLTSxTQUFVRSxPQUFPLENBQUNDLE9BQWdCLEVBQUVDLFFBQWdCO0VBQ3hELElBQUlELE9BQU8sQ0FBQ0QsT0FBTyxFQUFFO0lBQ25CLE9BQU9DLE9BQU8sQ0FBQ0QsT0FBTyxDQUFDRSxRQUFRLENBQUM7O0VBR2xDLElBQUlDLEVBQUUsR0FBbUJGLE9BQU87RUFDaEMsT0FBT0UsRUFBRSxFQUFFO0lBQ1QsSUFBSUMsT0FBTyxDQUFDRCxFQUFFLEVBQUVELFFBQVEsQ0FBQyxFQUFFO01BQ3pCLE9BQU9DLEVBQUU7O0lBRVhBLEVBQUUsR0FBR0EsRUFBRSxDQUFDRSxhQUFhOztFQUV2QixPQUFPLElBQUk7QUFDYjtBQUVNLFNBQVVELE9BQU8sQ0FBQ0gsT0FBZ0IsRUFBRUMsUUFBZ0I7RUFDeEQsSUFBTUksYUFBYSxHQUFHTCxPQUFPLENBQUNHLE9BQU8sSUFDOUJILE9BQU8sQ0FBQ00scUJBQXFCLElBQzVCTixPQUFlLENBQUNPLGlCQUFpQjtFQUN6QyxPQUFPRixhQUFhLENBQUNHLElBQUksQ0FBQ1IsT0FBTyxFQUFFQyxRQUFRLENBQUM7QUFDOUM7QUFFQTs7Ozs7Ozs7QUFRTSxTQUFVUSxtQkFBbUIsQ0FBQ1QsT0FBZ0I7RUFDbEQ7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFNVSxNQUFNLEdBQUdWLE9BQXNCO0VBQ3JDLElBQUlVLE1BQU0sQ0FBQ0MsWUFBWSxLQUFLLElBQUksRUFBRTtJQUNoQyxPQUFPRCxNQUFNLENBQUNFLFdBQVc7O0VBRzNCLElBQU1DLEtBQUssR0FBR0gsTUFBTSxDQUFDSSxTQUFTLENBQUMsSUFBSSxDQUFnQjtFQUNuREQsS0FBSyxDQUFDRSxLQUFLLENBQUNDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDO0VBQy9DSCxLQUFLLENBQUNFLEtBQUssQ0FBQ0MsV0FBVyxDQUFDLFdBQVcsRUFBRSw2QkFBNkIsQ0FBQztFQUNuRTdCLFFBQVEsQ0FBQzhCLGVBQWUsQ0FBQ0MsV0FBVyxDQUFDTCxLQUFLLENBQUM7RUFDM0MsSUFBTUQsV0FBVyxHQUFHQyxLQUFLLENBQUNELFdBQVc7RUFDckN6QixRQUFRLENBQUM4QixlQUFlLENBQUNFLFdBQVcsQ0FBQ04sS0FBSyxDQUFDO0VBQzNDLE9BQU9ELFdBQVc7QUFDcEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBSDNFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF1QnFEO0FBQ0o7QUFDSDtBQUVFO0FBRWxCO0FBSTlCO0VBQStCVSxnREFBQUE7RUFBL0I7SUFBQTtJQTZDRUMsY0FBUSxHQUFHLEtBQUs7O0VBMkNsQjtFQXZGa0JDLGtCQUFRLEdBQXhCLFVBQXlCN0QsSUFBYSxFQUFFOEQsSUFFdkM7SUFGdUM7TUFBQUE7UUFDdENDLFdBQVcsRUFBRTFEO09BQ2Q7SUFBQTtJQUNDLElBQU0yRCxNQUFNLEdBQUcsSUFBSUgsU0FBUyxDQUFDN0QsSUFBSSxDQUFDO0lBQ2xDO0lBQ0EsSUFBSThELElBQUksQ0FBQ0MsV0FBVyxLQUFLMUQsU0FBUyxFQUFFO01BQ2xDMkQsTUFBTSxDQUFDQyxTQUFTLEdBQUdILElBQUksQ0FBQ0MsV0FBVzs7SUFFckMsT0FBT0MsTUFBTTtFQUNmLENBQUM7RUFFTUgsdUJBQWEsR0FBcEIsVUFBcUJLLFFBQWlDO0lBQ3BELE9BQU87TUFDTEMsUUFBUSxFQUFFLFVBQUNDLFNBQVM7UUFBSyxlQUFRLENBQUNwRSxJQUFJLENBQUNxRSxTQUFTLENBQUNDLEdBQUcsQ0FBQ0YsU0FBUyxDQUFDO01BQXRDLENBQXNDO01BQy9ERyxzQkFBc0IsRUFBRTtRQUFNLDhEQUF5QixDQUFDRSxNQUFNLENBQUM7TUFBakMsQ0FBaUM7TUFDL0RDLG1CQUFtQixFQUFFO1FBQU0sZUFBUSxDQUFDMUUsSUFBSSxDQUFDMkUscUJBQXFCLEVBQUU7TUFBckMsQ0FBcUM7TUFDaEVDLG1CQUFtQixFQUFFLFVBQUNDLE1BQU07UUFBSyxlQUFRLENBQUM3RSxJQUFJLENBQUM4RSxRQUFRLENBQUNELE1BQWMsQ0FBQztNQUF0QyxDQUFzQztNQUN2RUUsb0NBQW9DLEVBQUUsVUFBQ2xFLE9BQU8sRUFBRUMsT0FBTztRQUNuRCxlQUFRLENBQUN3QyxlQUFlLENBQUNyQyxtQkFBbUIsQ0FDeENKLE9BQU8sRUFBRUMsT0FBTyxFQUFFZ0Isa0VBQVksRUFBRSxDQUFDO01BRHJDLENBQ3FDO01BQ3pDa0QsNEJBQTRCLEVBQUUsVUFBQ25FLE9BQU8sRUFBRUMsT0FBTztRQUMzQyxPQUFDb0QsUUFBUSxDQUFDbEUsSUFBb0IsQ0FDekJpQixtQkFBbUIsQ0FBQ0osT0FBTyxFQUFFQyxPQUFPLEVBQUVnQixrRUFBWSxFQUFFLENBQUM7TUFEMUQsQ0FDMEQ7TUFDOURtRCx1QkFBdUIsRUFBRSxVQUFDbkUsT0FBTztRQUM3QixhQUFNLENBQUNHLG1CQUFtQixDQUFDLFFBQVEsRUFBRUgsT0FBTyxDQUFDO01BQTdDLENBQTZDO01BQ2pEb0UsbUJBQW1CLEVBQUU7UUFDakIsT0FBQztVQUFDQyxDQUFDLEVBQUVWLE1BQU0sQ0FBQ1csV0FBVztVQUFFQyxDQUFDLEVBQUVaLE1BQU0sQ0FBQ2E7UUFBVyxDQUFDO01BQS9DLENBQWdEO01BQ3BEQyxlQUFlLEVBQUU7UUFBTSxzRUFBTyxDQUFDckIsUUFBUSxDQUFDbEUsSUFBSSxFQUFFLFNBQVMsQ0FBQztNQUFqQyxDQUFpQztNQUN4RHdGLGlCQUFpQixFQUFFO1FBQU0sY0FBTyxDQUFDdEIsUUFBUSxDQUFDdUIsUUFBUSxDQUFDO01BQTFCLENBQTBCO01BQ25EMUIsV0FBVyxFQUFFO1FBQU0sY0FBTyxDQUFDRyxRQUFRLENBQUNELFNBQVMsQ0FBQztNQUEzQixDQUEyQjtNQUM5Q3lCLGtDQUFrQyxFQUFFLFVBQUM3RSxPQUFPLEVBQUVDLE9BQU87UUFDakQsZUFBUSxDQUFDd0MsZUFBZSxDQUFDdEMsZ0JBQWdCLENBQ3JDSCxPQUFPLEVBQUVDLE9BQU8sRUFBRWdCLGtFQUFZLEVBQUUsQ0FBQztNQURyQyxDQUNxQztNQUN6QzZELDBCQUEwQixFQUFFLFVBQUM5RSxPQUFPLEVBQUVDLE9BQU87UUFDekMsT0FBQ29ELFFBQVEsQ0FBQ2xFLElBQW9CLENBQ3pCZ0IsZ0JBQWdCLENBQUNILE9BQU8sRUFBRUMsT0FBTyxFQUFFZ0Isa0VBQVksRUFBRSxDQUFDO01BRHZELENBQ3VEO01BQzNEOEQscUJBQXFCLEVBQUUsVUFBQzlFLE9BQU87UUFDM0IsYUFBTSxDQUFDRSxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUVGLE9BQU8sQ0FBQztNQUExQyxDQUEwQztNQUM5QytFLFdBQVcsRUFBRSxVQUFDekIsU0FBUztRQUFLLGVBQVEsQ0FBQ3BFLElBQUksQ0FBQ3FFLFNBQVMsQ0FBQ3lCLE1BQU0sQ0FBQzFCLFNBQVMsQ0FBQztNQUF6QyxDQUF5QztNQUNyRTJCLGlCQUFpQixFQUFFLFVBQUNDLE9BQU8sRUFBRUMsS0FBSztRQUM5QixPQUFDL0IsUUFBUSxDQUFDbEUsSUFBb0IsQ0FBQ29ELEtBQUssQ0FBQ0MsV0FBVyxDQUFDMkMsT0FBTyxFQUFFQyxLQUFLLENBQUM7TUFBaEU7S0FDTDtFQUNILENBQUM7RUFNRHBFLHNCQUFJZ0MsZ0NBQVM7U0FBYjtNQUNFLE9BQU9xQyxPQUFPLENBQUMsSUFBSSxDQUFDbkMsV0FBVyxDQUFDO0lBQ2xDLENBQUM7U0FFRCxVQUFjRSxTQUFrQjtNQUM5QixJQUFJLENBQUNGLFdBQVcsR0FBR21DLE9BQU8sQ0FBQ2pDLFNBQVMsQ0FBQztNQUNyQyxJQUFJLENBQUNrQyxZQUFZLEVBQUU7SUFDckIsQ0FBQzs7OztFQUVEdEMsNEJBQVEsR0FBUjtJQUNFLElBQUksQ0FBQzVELFVBQVUsQ0FBQ21HLFFBQVEsRUFBRTtFQUM1QixDQUFDO0VBRUR2Qyw4QkFBVSxHQUFWO0lBQ0UsSUFBSSxDQUFDNUQsVUFBVSxDQUFDb0csVUFBVSxFQUFFO0VBQzlCLENBQUM7RUFFRHhDLDBCQUFNLEdBQU47SUFDRSxJQUFJLENBQUM1RCxVQUFVLENBQUNxRyxNQUFNLEVBQUU7RUFDMUIsQ0FBQztFQUVRekMsd0NBQW9CLEdBQTdCO0lBQ0UsT0FBTyxJQUFJSiw0REFBbUIsQ0FBQ0ksU0FBUyxDQUFDMEMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO0VBQy9ELENBQUM7RUFFUTFDLHNDQUFrQixHQUEzQjtJQUNFLElBQU03RCxJQUFJLEdBQUcsSUFBSSxDQUFDQSxJQUFtQjtJQUNyQyxJQUFJLENBQUMrRCxXQUFXLEdBQUcsc0JBQXNCLElBQUkvRCxJQUFJLENBQUN3RyxPQUFPO0VBQzNELENBQUM7RUFFRDs7Ozs7O0VBTVEzQyxnQ0FBWSxHQUFwQjtJQUNFLElBQUksQ0FBQzVELFVBQVUsQ0FBQ2tHLFlBQVksQ0FBQ0QsT0FBTyxDQUFDLElBQUksQ0FBQ25DLFdBQVcsQ0FBQyxDQUFDO0VBQ3pELENBQUM7RUFDSCxnQkFBQztBQUFELENBQUMsQ0F4RjhCdEQsa0VBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7OztBSWpDM0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF1Qk8sSUFBTWdHLFVBQVUsR0FBRztFQUN4QjtFQUNBO0VBQ0E7RUFDQUMsVUFBVSxFQUFFLHlDQUF5QztFQUNyREMsYUFBYSxFQUFFLDRDQUE0QztFQUMzREMsZUFBZSxFQUFFLDhDQUE4QztFQUMvREMsSUFBSSxFQUFFLHFCQUFxQjtFQUMzQkMsU0FBUyxFQUFFO0NBQ1o7QUFFTSxJQUFNQyxPQUFPLEdBQUc7RUFDckJDLFlBQVksRUFBRSx1QkFBdUI7RUFDckNDLFdBQVcsRUFBRSxzQkFBc0I7RUFDbkNDLG9CQUFvQixFQUFFLCtCQUErQjtFQUNyREMsc0JBQXNCLEVBQUUsaUNBQWlDO0VBQ3pEQyxRQUFRLEVBQUUsbUJBQW1CO0VBQzdCQyxPQUFPLEVBQUU7Q0FDVjtBQUVNLElBQU1DLE9BQU8sR0FBRztFQUNyQkMsdUJBQXVCLEVBQUUsR0FBRztFQUM1QkMsa0JBQWtCLEVBQUUsR0FBRztFQUN2QkMsb0JBQW9CLEVBQUUsR0FBRztFQUN6QkMsT0FBTyxFQUFFLEVBQUU7RUFDWEMsWUFBWSxFQUFFLEdBQUcsQ0FBRTtDQUNwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUhqREQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJ1RDtBQUVDO0FBRVQ7QUE0Qi9DO0FBQ0EsSUFBTUUsc0JBQXNCLEdBQTBCLENBQ3BELFlBQVksRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLFNBQVMsQ0FDcEQ7QUFFRDtBQUNBLElBQU1DLGdDQUFnQyxHQUE0QixDQUNoRSxVQUFVLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxhQUFhLENBQ2xEO0FBRUQ7QUFDQSxJQUFJQyxnQkFBZ0IsR0FBOEIsRUFBRTtBQUVwRDtFQUF5Q3BFLGdEQUFBQTtFQXVEdkMsNkJBQVkvQixPQUFtQztJQUEvQyxZQUNFb0csa0JBQUFBLCtDQUFBQSxDQUFBQSwrQ0FBQUEsS0FBVXZFLG1CQUFtQixDQUFDd0UsY0FBYyxHQUFLckcsT0FBTyxFQUFFO0lBckJwRGdDLGlDQUEyQixHQUFHLEtBQUs7SUFFbkNBLHFCQUFlLEdBQUcsQ0FBQztJQUNuQkEsZ0NBQTBCLEdBQUcsQ0FBQztJQUM5QkEsYUFBTyxHQUFHLEdBQUc7SUFDYkEsV0FBSyxHQUFHO01BQUNzRSxLQUFLLEVBQUUsQ0FBQztNQUFFQyxNQUFNLEVBQUU7SUFBQyxDQUFDO0lBQzdCdkUsaUJBQVcsR0FBRyxDQUFDO0lBQ2ZBLGlCQUFXLEdBQUcsQ0FBQztJQUNmQSxlQUFTLEdBQUcsQ0FBQztJQUNiQSxxQkFBZSxHQUFnQjtNQUFDd0UsSUFBSSxFQUFFLENBQUM7TUFBRUMsR0FBRyxFQUFFO0lBQUMsQ0FBQztJQWN0RHpFLEtBQUksQ0FBQzBFLGVBQWUsR0FBRzFFLEtBQUksQ0FBQzJFLHNCQUFzQixFQUFFO0lBRXBEM0UsS0FBSSxDQUFDNEUsdUJBQXVCLEdBQUc7TUFDN0I1RSxLQUFJLENBQUM2RSwyQkFBMkIsR0FBRyxJQUFJO01BQ3ZDN0UsS0FBSSxDQUFDOEUsNkJBQTZCLEVBQUU7SUFDdEMsQ0FBQztJQUNEOUUsS0FBSSxDQUFDK0UsZUFBZSxHQUFHLFVBQUNDLENBQUM7TUFDdkJoRixLQUFJLENBQUNpRixZQUFZLENBQUNELENBQUMsQ0FBQztJQUN0QixDQUFDO0lBQ0RoRixLQUFJLENBQUNrRixpQkFBaUIsR0FBRztNQUN2QmxGLEtBQUksQ0FBQ21GLGNBQWMsRUFBRTtJQUN2QixDQUFDO0lBQ0RuRixLQUFJLENBQUNvRixZQUFZLEdBQUc7TUFDbEJwRixLQUFJLENBQUNxRixXQUFXLEVBQUU7SUFDcEIsQ0FBQztJQUNEckYsS0FBSSxDQUFDc0YsV0FBVyxHQUFHO01BQ2pCdEYsS0FBSSxDQUFDdUYsVUFBVSxFQUFFO0lBQ25CLENBQUM7SUFDRHZGLEtBQUksQ0FBQ3dGLGFBQWEsR0FBRztNQUNuQnhGLEtBQUksQ0FBQzBDLE1BQU0sRUFBRTtJQUNmLENBQUM7O0VBQ0g7RUE5RUF6RSxzQkFBb0I0QixpQ0FBVTtTQUE5QjtNQUNFLE9BQU9nRCxrREFBVTtJQUNuQixDQUFDOzs7O0VBRUQ1RSxzQkFBb0I0Qiw4QkFBTztTQUEzQjtNQUNFLE9BQU9zRCwrQ0FBTztJQUNoQixDQUFDOzs7O0VBRURsRixzQkFBb0I0Qiw4QkFBTztTQUEzQjtNQUNFLE9BQU82RCwrQ0FBTztJQUNoQixDQUFDOzs7O0VBRUR6RixzQkFBb0I0QixxQ0FBYztTQUFsQztNQUNFLE9BQU87UUFDTFUsUUFBUSxFQUFFO1VBQU0sZ0JBQVM7UUFBVCxDQUFTO1FBQ3pCSSxzQkFBc0IsRUFBRTtVQUFNLFdBQUk7UUFBSixDQUFJO1FBQ2xDRyxtQkFBbUIsRUFBRTtVQUNqQixPQUFDO1lBQUMyRCxHQUFHLEVBQUUsQ0FBQztZQUFFZ0IsS0FBSyxFQUFFLENBQUM7WUFBRUMsTUFBTSxFQUFFLENBQUM7WUFBRWxCLElBQUksRUFBRSxDQUFDO1lBQUVGLEtBQUssRUFBRSxDQUFDO1lBQUVDLE1BQU0sRUFBRTtVQUFDLENBQVM7UUFBcEUsQ0FBb0U7UUFDeEV2RCxtQkFBbUIsRUFBRTtVQUFNLFdBQUk7UUFBSixDQUFJO1FBQy9CRyxvQ0FBb0MsRUFBRTtVQUFNLGdCQUFTO1FBQVQsQ0FBUztRQUNyREMsNEJBQTRCLEVBQUU7VUFBTSxnQkFBUztRQUFULENBQVM7UUFDN0NDLHVCQUF1QixFQUFFO1VBQU0sZ0JBQVM7UUFBVCxDQUFTO1FBQ3hDQyxtQkFBbUIsRUFBRTtVQUFNLE9BQUM7WUFBQ0MsQ0FBQyxFQUFFLENBQUM7WUFBRUUsQ0FBQyxFQUFFO1VBQUMsQ0FBQztRQUFiLENBQWM7UUFDekNFLGVBQWUsRUFBRTtVQUFNLFdBQUk7UUFBSixDQUFJO1FBQzNCQyxpQkFBaUIsRUFBRTtVQUFNLFdBQUk7UUFBSixDQUFJO1FBQzdCekIsV0FBVyxFQUFFO1VBQU0sV0FBSTtRQUFKLENBQUk7UUFDdkIyQixrQ0FBa0MsRUFBRTtVQUFNLGdCQUFTO1FBQVQsQ0FBUztRQUNuREMsMEJBQTBCLEVBQUU7VUFBTSxnQkFBUztRQUFULENBQVM7UUFDM0NDLHFCQUFxQixFQUFFO1VBQU0sZ0JBQVM7UUFBVCxDQUFTO1FBQ3RDQyxXQUFXLEVBQUU7VUFBTSxnQkFBUztRQUFULENBQVM7UUFDNUJFLGlCQUFpQixFQUFFO1VBQU0sZ0JBQVM7UUFBVDtPQUMxQjtJQUNILENBQUM7Ozs7RUFnRFF0QyxrQ0FBSSxHQUFiO0lBQUE7SUFDRSxJQUFNOEYsbUJBQW1CLEdBQUcsSUFBSSxDQUFDQSxtQkFBbUIsRUFBRTtJQUV0RCxJQUFJLENBQUNDLG9CQUFvQixDQUFDRCxtQkFBbUIsQ0FBQztJQUU5QyxJQUFJQSxtQkFBbUIsRUFBRTtNQUNqQixTQUFvQjlGLG1CQUFtQixDQUFDZ0QsVUFBVTtRQUFqRGdELE1BQUk7UUFBRUMsV0FBUyxlQUFrQztNQUN4REMscUJBQXFCLENBQUM7UUFDcEIvRixLQUFJLENBQUNoQyxPQUFPLENBQUN1QyxRQUFRLENBQUNzRixNQUFJLENBQUM7UUFDM0IsSUFBSTdGLEtBQUksQ0FBQ2hDLE9BQU8sQ0FBQ21DLFdBQVcsRUFBRSxFQUFFO1VBQzlCSCxLQUFJLENBQUNoQyxPQUFPLENBQUN1QyxRQUFRLENBQUN1RixXQUFTLENBQUM7VUFDaEM7VUFDQTlGLEtBQUksQ0FBQ2dHLGNBQWMsRUFBRTs7TUFFekIsQ0FBQyxDQUFDOztFQUVOLENBQUM7RUFFUW5HLHFDQUFPLEdBQWhCO0lBQUE7SUFDRSxJQUFJLElBQUksQ0FBQzhGLG1CQUFtQixFQUFFLEVBQUU7TUFDOUIsSUFBSSxJQUFJLENBQUNNLGVBQWUsRUFBRTtRQUN4QkMsWUFBWSxDQUFDLElBQUksQ0FBQ0QsZUFBZSxDQUFDO1FBQ2xDLElBQUksQ0FBQ0EsZUFBZSxHQUFHLENBQUM7UUFDeEIsSUFBSSxDQUFDakksT0FBTyxDQUFDaUUsV0FBVyxDQUFDcEMsbUJBQW1CLENBQUNnRCxVQUFVLENBQUNFLGFBQWEsQ0FBQzs7TUFHeEUsSUFBSSxJQUFJLENBQUNvRCwwQkFBMEIsRUFBRTtRQUNuQ0QsWUFBWSxDQUFDLElBQUksQ0FBQ0MsMEJBQTBCLENBQUM7UUFDN0MsSUFBSSxDQUFDQSwwQkFBMEIsR0FBRyxDQUFDO1FBQ25DLElBQUksQ0FBQ25JLE9BQU8sQ0FBQ2lFLFdBQVcsQ0FDcEJwQyxtQkFBbUIsQ0FBQ2dELFVBQVUsQ0FBQ0csZUFBZSxDQUFDOztNQUcvQyxTQUFvQm5ELG1CQUFtQixDQUFDZ0QsVUFBVTtRQUFqRHVELE1BQUk7UUFBRUMsV0FBUyxlQUFrQztNQUN4RE4scUJBQXFCLENBQUM7UUFDcEIvRixLQUFJLENBQUNoQyxPQUFPLENBQUNpRSxXQUFXLENBQUNtRSxNQUFJLENBQUM7UUFDOUJwRyxLQUFJLENBQUNoQyxPQUFPLENBQUNpRSxXQUFXLENBQUNvRSxXQUFTLENBQUM7UUFDbkNyRyxLQUFJLENBQUNzRyxhQUFhLEVBQUU7TUFDdEIsQ0FBQyxDQUFDOztJQUdKLElBQUksQ0FBQ0Msc0JBQXNCLEVBQUU7SUFDN0IsSUFBSSxDQUFDQyw4QkFBOEIsRUFBRTtFQUN2QyxDQUFDO0VBRUQ7OztFQUdBM0csc0NBQVEsR0FBUixVQUFTckMsR0FBVztJQUNsQixJQUFJLENBQUN5SCxZQUFZLENBQUN6SCxHQUFHLENBQUM7RUFDeEIsQ0FBQztFQUVEcUMsd0NBQVUsR0FBVjtJQUNFLElBQUksQ0FBQ3NGLGNBQWMsRUFBRTtFQUN2QixDQUFDO0VBRUR0RixvQ0FBTSxHQUFOO0lBQUE7SUFDRSxJQUFJLElBQUksQ0FBQzRHLFdBQVcsRUFBRTtNQUNwQkMsb0JBQW9CLENBQUMsSUFBSSxDQUFDRCxXQUFXLENBQUM7O0lBRXhDLElBQUksQ0FBQ0EsV0FBVyxHQUFHVixxQkFBcUIsQ0FBQztNQUN2Qy9GLEtBQUksQ0FBQ2dHLGNBQWMsRUFBRTtNQUNyQmhHLEtBQUksQ0FBQ3lHLFdBQVcsR0FBRyxDQUFDO0lBQ3RCLENBQUMsQ0FBQztFQUNKLENBQUM7RUFFRDVHLDBDQUFZLEdBQVosVUFBYVEsU0FBa0I7SUFDdEIsYUFBUyxHQUFJUixtQkFBbUIsQ0FBQ2dELFVBQVUsVUFBbEM7SUFDaEIsSUFBSXhDLFNBQVMsRUFBRTtNQUNiLElBQUksQ0FBQ3JDLE9BQU8sQ0FBQ3VDLFFBQVEsQ0FBQzJDLFNBQVMsQ0FBQztLQUNqQyxNQUFNO01BQ0wsSUFBSSxDQUFDbEYsT0FBTyxDQUFDaUUsV0FBVyxDQUFDaUIsU0FBUyxDQUFDOztFQUV2QyxDQUFDO0VBRURyRCx5Q0FBVyxHQUFYO0lBQUE7SUFDRWtHLHFCQUFxQixDQUNqQjtNQUFNLFlBQUksQ0FBQy9ILE9BQU8sQ0FBQ3VDLFFBQVEsQ0FBQ1YsbUJBQW1CLENBQUNnRCxVQUFVLENBQUNDLFVBQVUsQ0FBQztJQUFoRSxDQUFnRSxDQUFDO0VBQzdFLENBQUM7RUFFRGpELHdDQUFVLEdBQVY7SUFBQTtJQUNFa0cscUJBQXFCLENBQ2pCO01BQU0sWUFBSSxDQUFDL0gsT0FBTyxDQUFDaUUsV0FBVyxDQUMxQnBDLG1CQUFtQixDQUFDZ0QsVUFBVSxDQUFDQyxVQUFVLENBQUM7SUFEeEMsQ0FDd0MsQ0FBQztFQUNyRCxDQUFDO0VBRUQ7Ozs7OztFQU1RakQsaURBQW1CLEdBQTNCO0lBQ0UsT0FBTyxJQUFJLENBQUM3QixPQUFPLENBQUMyQyxzQkFBc0IsRUFBRTtFQUM5QyxDQUFDO0VBRU9kLG9EQUFzQixHQUE5QjtJQUNFLE9BQU87TUFDTDhHLGVBQWUsRUFBRWxLLFNBQVM7TUFDMUJtSyxvQkFBb0IsRUFBRSxLQUFLO01BQzNCQyxXQUFXLEVBQUUsS0FBSztNQUNsQkMsY0FBYyxFQUFFLEtBQUs7TUFDckJDLHFCQUFxQixFQUFFLEtBQUs7TUFDNUJDLG9CQUFvQixFQUFFO0tBQ3ZCO0VBQ0gsQ0FBQztFQUVEOzs7RUFHUW5ILGtEQUFvQixHQUE1QixVQUE2QjhGLG1CQUE0Qjs7SUFDdkQsSUFBSUEsbUJBQW1CLEVBQUU7O1FBQ3ZCLEtBQXNCLHFHQUFzQixpS0FBRTtVQUF6QyxJQUFNMUksT0FBTztVQUNoQixJQUFJLENBQUNlLE9BQU8sQ0FBQytELDBCQUEwQixDQUFDOUUsT0FBTyxFQUFFLElBQUksQ0FBQzhILGVBQWUsQ0FBQzs7Ozs7Ozs7Ozs7OztNQUV4RSxJQUFJLElBQUksQ0FBQy9HLE9BQU8sQ0FBQ21DLFdBQVcsRUFBRSxFQUFFO1FBQzlCLElBQUksQ0FBQ25DLE9BQU8sQ0FBQ2dFLHFCQUFxQixDQUFDLElBQUksQ0FBQ3dELGFBQWEsQ0FBQzs7O0lBSTFELElBQUksQ0FBQ3hILE9BQU8sQ0FBQytELDBCQUEwQixDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUNxRCxZQUFZLENBQUM7SUFDbkUsSUFBSSxDQUFDcEgsT0FBTyxDQUFDK0QsMEJBQTBCLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQ3VELFdBQVcsQ0FBQztFQUNuRSxDQUFDO0VBRU96RiwwREFBNEIsR0FBcEMsVUFBcUNyQyxHQUFVOztJQUM3QyxJQUFJQSxHQUFHLENBQUN5SixJQUFJLEtBQUssU0FBUyxFQUFFO01BQzFCLElBQUksQ0FBQ2pKLE9BQU8sQ0FBQytELDBCQUEwQixDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUNtRCxpQkFBaUIsQ0FBQztLQUN6RSxNQUFNOztRQUNMLEtBQXNCLHlIQUFnQyxtTkFBRTtVQUFuRCxJQUFNakksT0FBTztVQUNoQixJQUFJLENBQUNlLE9BQU8sQ0FBQzhELGtDQUFrQyxDQUMzQzdFLE9BQU8sRUFBRSxJQUFJLENBQUNpSSxpQkFBaUIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7RUFHMUMsQ0FBQztFQUVPckYsb0RBQXNCLEdBQTlCOzs7TUFDRSxLQUFzQixxR0FBc0IsaUtBQUU7UUFBekMsSUFBTTVDLE9BQU87UUFDaEIsSUFBSSxDQUFDZSxPQUFPLENBQUNvRCw0QkFBNEIsQ0FBQ25FLE9BQU8sRUFBRSxJQUFJLENBQUM4SCxlQUFlLENBQUM7Ozs7Ozs7Ozs7Ozs7SUFFMUUsSUFBSSxDQUFDL0csT0FBTyxDQUFDb0QsNEJBQTRCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQ2dFLFlBQVksQ0FBQztJQUNyRSxJQUFJLENBQUNwSCxPQUFPLENBQUNvRCw0QkFBNEIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDa0UsV0FBVyxDQUFDO0lBRW5FLElBQUksSUFBSSxDQUFDdEgsT0FBTyxDQUFDbUMsV0FBVyxFQUFFLEVBQUU7TUFDOUIsSUFBSSxDQUFDbkMsT0FBTyxDQUFDcUQsdUJBQXVCLENBQUMsSUFBSSxDQUFDbUUsYUFBYSxDQUFDOztFQUU1RCxDQUFDO0VBRU8zRiw0REFBOEIsR0FBdEM7O0lBQ0UsSUFBSSxDQUFDN0IsT0FBTyxDQUFDb0QsNEJBQTRCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQzhELGlCQUFpQixDQUFDOztNQUMxRSxLQUFzQix5SEFBZ0MsbU5BQUU7UUFBbkQsSUFBTWpJLE9BQU87UUFDaEIsSUFBSSxDQUFDZSxPQUFPLENBQUNtRCxvQ0FBb0MsQ0FDN0NsRSxPQUFPLEVBQUUsSUFBSSxDQUFDaUksaUJBQWlCLENBQUM7Ozs7Ozs7Ozs7Ozs7RUFFeEMsQ0FBQztFQUVPckYsMkNBQWEsR0FBckI7SUFBQTtJQUNFLElBQU1xSCxhQUFhLEdBQUdySCxtQkFBbUIsQ0FBQ3NELE9BQU87SUFDakQsSUFBTWdFLElBQUksR0FBR2xKLE1BQU0sQ0FBQ2tKLElBQUksQ0FBQ0QsYUFBYSxDQUFzQztJQUM1RUMsSUFBSSxDQUFDQyxPQUFPLENBQUMsVUFBQ0MsR0FBRztNQUNmLElBQUlBLEdBQUcsQ0FBQ0MsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRTtRQUM3QnRILEtBQUksQ0FBQ2hDLE9BQU8sQ0FBQ21FLGlCQUFpQixDQUFDK0UsYUFBYSxDQUFDRyxHQUFHLENBQUMsRUFBRSxJQUFJLENBQUM7O0lBRTVELENBQUMsQ0FBQztFQUNKLENBQUM7RUFFT3hILDBDQUFZLEdBQXBCLFVBQXFCckMsR0FBVztJQUFoQztJQUNFLElBQUksSUFBSSxDQUFDUSxPQUFPLENBQUM0RCxpQkFBaUIsRUFBRSxFQUFFO01BQ3BDOztJQUdGLElBQU04QyxlQUFlLEdBQUcsSUFBSSxDQUFDQSxlQUFlO0lBQzVDLElBQUlBLGVBQWUsQ0FBQ21DLFdBQVcsRUFBRTtNQUMvQjs7SUFHRjtJQUNBLElBQU1VLHVCQUF1QixHQUFHLElBQUksQ0FBQ0EsdUJBQXVCO0lBQzVELElBQU1DLGlCQUFpQixHQUFHRCx1QkFBdUIsSUFBSS9KLEdBQUcsS0FBS2YsU0FBUyxJQUFJOEssdUJBQXVCLENBQUNOLElBQUksS0FBS3pKLEdBQUcsQ0FBQ3lKLElBQUk7SUFDbkgsSUFBSU8saUJBQWlCLEVBQUU7TUFDckI7O0lBR0Y5QyxlQUFlLENBQUNtQyxXQUFXLEdBQUcsSUFBSTtJQUNsQ25DLGVBQWUsQ0FBQ29DLGNBQWMsR0FBR3RKLEdBQUcsS0FBS2YsU0FBUztJQUNsRGlJLGVBQWUsQ0FBQ2lDLGVBQWUsR0FBR25KLEdBQUc7SUFDckNrSCxlQUFlLENBQUNxQyxxQkFBcUIsR0FBR3JDLGVBQWUsQ0FBQ29DLGNBQWMsR0FBRyxLQUFLLEdBQUd0SixHQUFHLEtBQUtmLFNBQVMsS0FDOUZlLEdBQUcsQ0FBQ3lKLElBQUksS0FBSyxXQUFXLElBQUl6SixHQUFHLENBQUN5SixJQUFJLEtBQUssWUFBWSxJQUFJekosR0FBRyxDQUFDeUosSUFBSSxLQUFLLGFBQWEsQ0FDdEY7SUFFRCxJQUFNUSxpQkFBaUIsR0FBR2pLLEdBQUcsS0FBS2YsU0FBUyxJQUN2QzBILGdCQUFnQixDQUFDdUQsTUFBTSxHQUFHLENBQUMsSUFDM0J2RCxnQkFBZ0IsQ0FBQ3dELElBQUksQ0FDakIsVUFBQzFHLE1BQU07TUFBSyxZQUFJLENBQUNqRCxPQUFPLENBQUNnRCxtQkFBbUIsQ0FBQ0MsTUFBTSxDQUFDO0lBQXhDLENBQXdDLENBQUM7SUFDN0QsSUFBSXdHLGlCQUFpQixFQUFFO01BQ3JCO01BQ0EsSUFBSSxDQUFDRyxvQkFBb0IsRUFBRTtNQUMzQjs7SUFHRixJQUFJcEssR0FBRyxLQUFLZixTQUFTLEVBQUU7TUFDckIwSCxnQkFBZ0IsQ0FBQzBELElBQUksQ0FBQ3JLLEdBQUcsQ0FBQ3lELE1BQU0sQ0FBQztNQUNqQyxJQUFJLENBQUM2Ryw0QkFBNEIsQ0FBQ3RLLEdBQUcsQ0FBQzs7SUFHeENrSCxlQUFlLENBQUNzQyxvQkFBb0IsR0FBRyxJQUFJLENBQUNlLHNCQUFzQixDQUFDdkssR0FBRyxDQUFDO0lBQ3ZFLElBQUlrSCxlQUFlLENBQUNzQyxvQkFBb0IsRUFBRTtNQUN4QyxJQUFJLENBQUNnQixpQkFBaUIsRUFBRTs7SUFHMUJqQyxxQkFBcUIsQ0FBQztNQUNwQjtNQUNBNUIsZ0JBQWdCLEdBQUcsRUFBRTtNQUVyQixJQUFJLENBQUNPLGVBQWUsQ0FBQ3NDLG9CQUFvQixJQUNsQ3hKLEdBQUcsS0FBS2YsU0FBUyxLQUNmZSxHQUFxQixDQUFDNkosR0FBRyxLQUFLLEdBQUcsSUFBSzdKLEdBQXFCLENBQUN5SyxPQUFPLEtBQUssRUFBRSxDQUFDLEVBQUU7UUFDcEY7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0F2RCxlQUFlLENBQUNzQyxvQkFBb0IsR0FBR2hILEtBQUksQ0FBQytILHNCQUFzQixDQUFDdkssR0FBRyxDQUFDO1FBQ3ZFLElBQUlrSCxlQUFlLENBQUNzQyxvQkFBb0IsRUFBRTtVQUN4Q2hILEtBQUksQ0FBQ2dJLGlCQUFpQixFQUFFOzs7TUFJNUIsSUFBSSxDQUFDdEQsZUFBZSxDQUFDc0Msb0JBQW9CLEVBQUU7UUFDekM7UUFDQWhILEtBQUksQ0FBQzBFLGVBQWUsR0FBRzFFLEtBQUksQ0FBQzJFLHNCQUFzQixFQUFFOztJQUV4RCxDQUFDLENBQUM7RUFDSixDQUFDO0VBRU85RSxvREFBc0IsR0FBOUIsVUFBK0JyQyxHQUFXO0lBQ3hDLE9BQVFBLEdBQUcsS0FBS2YsU0FBUyxJQUFJZSxHQUFHLENBQUN5SixJQUFJLEtBQUssU0FBUyxHQUMvQyxJQUFJLENBQUNqSixPQUFPLENBQUMyRCxlQUFlLEVBQUUsR0FDOUIsSUFBSTtFQUNWLENBQUM7RUFFTzlCLCtDQUFpQixHQUF6QjtJQUFBO0lBQ1EsU0FBaURBLG1CQUFtQixDQUFDc0QsT0FBTztNQUEzRUksc0JBQXNCO01BQUVELG9CQUFvQiwwQkFBK0I7SUFDNUUsU0FBbUN6RCxtQkFBbUIsQ0FBQ2dELFVBQVU7TUFBaEVHLGVBQWU7TUFBRUQsYUFBYSxtQkFBa0M7SUFDaEUsMkJBQXVCLEdBQUlsRCxtQkFBbUIsQ0FBQzZELE9BQU8sd0JBQS9CO0lBRTlCLElBQUksQ0FBQ3NDLGNBQWMsRUFBRTtJQUVyQixJQUFJa0MsY0FBYyxHQUFHLEVBQUU7SUFDdkIsSUFBSUMsWUFBWSxHQUFHLEVBQUU7SUFFckIsSUFBSSxDQUFDLElBQUksQ0FBQ25LLE9BQU8sQ0FBQ21DLFdBQVcsRUFBRSxFQUFFO01BQ3pCLFNBQXlCLElBQUksQ0FBQ2lJLDJCQUEyQixFQUFFO1FBQTFEQyxVQUFVO1FBQUVDLFFBQVEsY0FBc0M7TUFDakVKLGNBQWMsR0FBTUcsVUFBVSxDQUFDOUcsQ0FBQyxZQUFPOEcsVUFBVSxDQUFDNUcsQ0FBQyxPQUFJO01BQ3ZEMEcsWUFBWSxHQUFNRyxRQUFRLENBQUMvRyxDQUFDLFlBQU8rRyxRQUFRLENBQUM3RyxDQUFDLE9BQUk7O0lBR25ELElBQUksQ0FBQ3pELE9BQU8sQ0FBQ21FLGlCQUFpQixDQUFDb0Isc0JBQXNCLEVBQUUyRSxjQUFjLENBQUM7SUFDdEUsSUFBSSxDQUFDbEssT0FBTyxDQUFDbUUsaUJBQWlCLENBQUNtQixvQkFBb0IsRUFBRTZFLFlBQVksQ0FBQztJQUNsRTtJQUNBakMsWUFBWSxDQUFDLElBQUksQ0FBQ0QsZUFBZSxDQUFDO0lBQ2xDQyxZQUFZLENBQUMsSUFBSSxDQUFDQywwQkFBMEIsQ0FBQztJQUM3QyxJQUFJLENBQUNvQywwQkFBMEIsRUFBRTtJQUNqQyxJQUFJLENBQUN2SyxPQUFPLENBQUNpRSxXQUFXLENBQUNlLGVBQWUsQ0FBQztJQUV6QztJQUNBLElBQUksQ0FBQ2hGLE9BQU8sQ0FBQzhDLG1CQUFtQixFQUFFO0lBQ2xDLElBQUksQ0FBQzlDLE9BQU8sQ0FBQ3VDLFFBQVEsQ0FBQ3dDLGFBQWEsQ0FBQztJQUNwQyxJQUFJLENBQUNrRCxlQUFlLEdBQUd1QyxVQUFVLENBQUM7TUFDaEN4SSxLQUFJLENBQUM0RSx1QkFBdUIsRUFBRTtJQUNoQyxDQUFDLEVBQUVqQix1QkFBdUIsQ0FBQztFQUM3QixDQUFDO0VBRU85RCx5REFBMkIsR0FBbkM7SUFDUSxTQUEyQyxJQUFJLENBQUM2RSxlQUFlO01BQTlEaUMsZUFBZTtNQUFFSSxxQkFBcUIsMkJBQXdCO0lBRXJFLElBQUlzQixVQUFVO0lBQ2QsSUFBSXRCLHFCQUFxQixFQUFFO01BQ3pCc0IsVUFBVSxHQUFHckUsK0RBQXdCLENBQ2pDMkMsZUFBZSxFQUNmLElBQUksQ0FBQzNJLE9BQU8sQ0FBQ3NELG1CQUFtQixFQUFFLEVBQ2xDLElBQUksQ0FBQ3RELE9BQU8sQ0FBQzhDLG1CQUFtQixFQUFFLENBQ3JDO0tBQ0YsTUFBTTtNQUNMdUgsVUFBVSxHQUFHO1FBQ1g5RyxDQUFDLEVBQUUsSUFBSSxDQUFDa0gsS0FBSyxDQUFDbkUsS0FBSyxHQUFHLENBQUM7UUFDdkI3QyxDQUFDLEVBQUUsSUFBSSxDQUFDZ0gsS0FBSyxDQUFDbEUsTUFBTSxHQUFHO09BQ3hCOztJQUVIO0lBQ0E4RCxVQUFVLEdBQUc7TUFDWDlHLENBQUMsRUFBRThHLFVBQVUsQ0FBQzlHLENBQUMsR0FBSSxJQUFJLENBQUNtSCxXQUFXLEdBQUcsQ0FBRTtNQUN4Q2pILENBQUMsRUFBRTRHLFVBQVUsQ0FBQzVHLENBQUMsR0FBSSxJQUFJLENBQUNpSCxXQUFXLEdBQUc7S0FDdkM7SUFFRCxJQUFNSixRQUFRLEdBQUc7TUFDZi9HLENBQUMsRUFBRyxJQUFJLENBQUNrSCxLQUFLLENBQUNuRSxLQUFLLEdBQUcsQ0FBQyxHQUFLLElBQUksQ0FBQ29FLFdBQVcsR0FBRyxDQUFFO01BQ2xEakgsQ0FBQyxFQUFHLElBQUksQ0FBQ2dILEtBQUssQ0FBQ2xFLE1BQU0sR0FBRyxDQUFDLEdBQUssSUFBSSxDQUFDbUUsV0FBVyxHQUFHO0tBQ2xEO0lBRUQsT0FBTztNQUFDTCxVQUFVO01BQUVDLFFBQVE7SUFBQSxDQUFDO0VBQy9CLENBQUM7RUFFT3pJLDJEQUE2QixHQUFyQztJQUFBO0lBQ0U7SUFDQTtJQUNPLG1CQUFlLEdBQUlBLG1CQUFtQixDQUFDZ0QsVUFBVSxnQkFBbEM7SUFDaEIsU0FBc0MsSUFBSSxDQUFDNkIsZUFBZTtNQUF6RGtDLG9CQUFvQjtNQUFFQyxXQUFXLGlCQUF3QjtJQUNoRSxJQUFNOEIsa0JBQWtCLEdBQUcvQixvQkFBb0IsSUFBSSxDQUFDQyxXQUFXO0lBRS9ELElBQUk4QixrQkFBa0IsSUFBSSxJQUFJLENBQUM5RCwyQkFBMkIsRUFBRTtNQUMxRCxJQUFJLENBQUMwRCwwQkFBMEIsRUFBRTtNQUNqQyxJQUFJLENBQUN2SyxPQUFPLENBQUN1QyxRQUFRLENBQUN5QyxlQUFlLENBQUM7TUFDdEMsSUFBSSxDQUFDbUQsMEJBQTBCLEdBQUdxQyxVQUFVLENBQUM7UUFDM0N4SSxLQUFJLENBQUNoQyxPQUFPLENBQUNpRSxXQUFXLENBQUNlLGVBQWUsQ0FBQztNQUMzQyxDQUFDLEVBQUVVLGtFQUEwQixDQUFDOztFQUVsQyxDQUFDO0VBRU83RCx3REFBMEIsR0FBbEM7SUFDUyxpQkFBYSxHQUFJQSxtQkFBbUIsQ0FBQ2dELFVBQVUsY0FBbEM7SUFDcEIsSUFBSSxDQUFDN0UsT0FBTyxDQUFDaUUsV0FBVyxDQUFDYyxhQUFhLENBQUM7SUFDdkMsSUFBSSxDQUFDOEIsMkJBQTJCLEdBQUcsS0FBSztJQUN4QyxJQUFJLENBQUM3RyxPQUFPLENBQUM4QyxtQkFBbUIsRUFBRTtFQUNwQyxDQUFDO0VBRU9qQixrREFBb0IsR0FBNUI7SUFBQTtJQUNFLElBQUksQ0FBQzBILHVCQUF1QixHQUFHLElBQUksQ0FBQzdDLGVBQWUsQ0FBQ2lDLGVBQWU7SUFDbkUsSUFBSSxDQUFDakMsZUFBZSxHQUFHLElBQUksQ0FBQ0Msc0JBQXNCLEVBQUU7SUFDcEQ7SUFDQTtJQUNBNkQsVUFBVSxDQUNOO01BQU0sWUFBSSxDQUFDakIsdUJBQXVCLEdBQUc5SyxTQUFTO0lBQXhDLENBQXdDLEVBQzlDb0QsbUJBQW1CLENBQUM2RCxPQUFPLENBQUNLLFlBQVksQ0FBQztFQUMvQyxDQUFDO0VBRU9sRSw0Q0FBYyxHQUF0QjtJQUFBO0lBQ0UsSUFBTTZFLGVBQWUsR0FBRyxJQUFJLENBQUNBLGVBQWU7SUFDNUM7SUFDQSxJQUFJLENBQUNBLGVBQWUsQ0FBQ21DLFdBQVcsRUFBRTtNQUNoQzs7SUFHRixJQUFNK0IsS0FBSyx1REFBNEJsRSxlQUFlLENBQUM7SUFFdkQsSUFBSUEsZUFBZSxDQUFDb0MsY0FBYyxFQUFFO01BQ2xDZixxQkFBcUIsQ0FBQztRQUNwQi9GLEtBQUksQ0FBQzZJLG1CQUFtQixDQUFDRCxLQUFLLENBQUM7TUFDakMsQ0FBQyxDQUFDO01BQ0YsSUFBSSxDQUFDaEIsb0JBQW9CLEVBQUU7S0FDNUIsTUFBTTtNQUNMLElBQUksQ0FBQ3BCLDhCQUE4QixFQUFFO01BQ3JDVCxxQkFBcUIsQ0FBQztRQUNwQi9GLEtBQUksQ0FBQzBFLGVBQWUsQ0FBQ2tDLG9CQUFvQixHQUFHLElBQUk7UUFDaEQ1RyxLQUFJLENBQUM2SSxtQkFBbUIsQ0FBQ0QsS0FBSyxDQUFDO1FBQy9CNUksS0FBSSxDQUFDNEgsb0JBQW9CLEVBQUU7TUFDN0IsQ0FBQyxDQUFDOztFQUVOLENBQUM7RUFFTy9ILGlEQUFtQixHQUEzQixVQUE0QmlKLEVBQ3VCO1FBRHRCL0IscUJBQXFCO01BQUVDLG9CQUFvQjtJQUV0RSxJQUFJRCxxQkFBcUIsSUFBSUMsb0JBQW9CLEVBQUU7TUFDakQsSUFBSSxDQUFDbEMsNkJBQTZCLEVBQUU7O0VBRXhDLENBQUM7RUFFT2pGLDRDQUFjLEdBQXRCO0lBQUE7SUFDRSxJQUFJLENBQUM0SSxLQUFLLEdBQUcsSUFBSSxDQUFDekssT0FBTyxDQUFDOEMsbUJBQW1CLEVBQUU7SUFDL0MsSUFBTWlJLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxHQUFHLENBQUMsSUFBSSxDQUFDUixLQUFLLENBQUNsRSxNQUFNLEVBQUUsSUFBSSxDQUFDa0UsS0FBSyxDQUFDbkUsS0FBSyxDQUFDO0lBRTVEO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQU00RSxnQkFBZ0IsR0FBRztNQUN2QixJQUFNQyxVQUFVLEdBQUdILElBQUksQ0FBQ0ksSUFBSSxDQUN4QkosSUFBSSxDQUFDSyxHQUFHLENBQUNySixLQUFJLENBQUN5SSxLQUFLLENBQUNuRSxLQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcwRSxJQUFJLENBQUNLLEdBQUcsQ0FBQ3JKLEtBQUksQ0FBQ3lJLEtBQUssQ0FBQ2xFLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztNQUNuRSxPQUFPNEUsVUFBVSxHQUFHdEosbUJBQW1CLENBQUM2RCxPQUFPLENBQUNJLE9BQU87SUFDekQsQ0FBQztJQUVELElBQUksQ0FBQ3dGLFNBQVMsR0FBRyxJQUFJLENBQUN0TCxPQUFPLENBQUNtQyxXQUFXLEVBQUUsR0FBRzRJLE1BQU0sR0FBR0csZ0JBQWdCLEVBQUU7SUFFekU7SUFDQSxJQUFNUixXQUFXLEdBQUdNLElBQUksQ0FBQ08sS0FBSyxDQUFDUixNQUFNLEdBQUdsSixtQkFBbUIsQ0FBQzZELE9BQU8sQ0FBQ0csb0JBQW9CLENBQUM7SUFDekY7SUFDQSxJQUFJLElBQUksQ0FBQzdGLE9BQU8sQ0FBQ21DLFdBQVcsRUFBRSxJQUFJdUksV0FBVyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7TUFDdkQsSUFBSSxDQUFDQSxXQUFXLEdBQUdBLFdBQVcsR0FBRyxDQUFDO0tBQ25DLE1BQU07TUFDTCxJQUFJLENBQUNBLFdBQVcsR0FBR0EsV0FBVzs7SUFFaEMsSUFBSSxDQUFDYyxPQUFPLEdBQUcsS0FBRyxJQUFJLENBQUNGLFNBQVMsR0FBRyxJQUFJLENBQUNaLFdBQWE7SUFFckQsSUFBSSxDQUFDZSxtQkFBbUIsRUFBRTtFQUM1QixDQUFDO0VBRU81SixpREFBbUIsR0FBM0I7SUFDUSxTQUVGQSxtQkFBbUIsQ0FBQ3NELE9BQU87TUFEN0JFLFdBQVc7TUFBRUcsUUFBUTtNQUFFQyxPQUFPO01BQUVMLFlBQVksa0JBQ2Y7SUFFL0IsSUFBSSxDQUFDcEYsT0FBTyxDQUFDbUUsaUJBQWlCLENBQUNrQixXQUFXLEVBQUssSUFBSSxDQUFDcUYsV0FBVyxPQUFJLENBQUM7SUFDcEUsSUFBSSxDQUFDMUssT0FBTyxDQUFDbUUsaUJBQWlCLENBQUNpQixZQUFZLEVBQUUsSUFBSSxDQUFDb0csT0FBTyxDQUFDO0lBRTFELElBQUksSUFBSSxDQUFDeEwsT0FBTyxDQUFDbUMsV0FBVyxFQUFFLEVBQUU7TUFDOUIsSUFBSSxDQUFDdUosZUFBZSxHQUFHO1FBQ3JCbEYsSUFBSSxFQUFFd0UsSUFBSSxDQUFDVyxLQUFLLENBQUUsSUFBSSxDQUFDbEIsS0FBSyxDQUFDbkUsS0FBSyxHQUFHLENBQUMsR0FBSyxJQUFJLENBQUNvRSxXQUFXLEdBQUcsQ0FBRSxDQUFDO1FBQ2pFakUsR0FBRyxFQUFFdUUsSUFBSSxDQUFDVyxLQUFLLENBQUUsSUFBSSxDQUFDbEIsS0FBSyxDQUFDbEUsTUFBTSxHQUFHLENBQUMsR0FBSyxJQUFJLENBQUNtRSxXQUFXLEdBQUcsQ0FBRTtPQUNqRTtNQUVELElBQUksQ0FBQzFLLE9BQU8sQ0FBQ21FLGlCQUFpQixDQUMxQnFCLFFBQVEsRUFBSyxJQUFJLENBQUNrRyxlQUFlLENBQUNsRixJQUFJLE9BQUksQ0FBQztNQUMvQyxJQUFJLENBQUN4RyxPQUFPLENBQUNtRSxpQkFBaUIsQ0FBQ3NCLE9BQU8sRUFBSyxJQUFJLENBQUNpRyxlQUFlLENBQUNqRixHQUFHLE9BQUksQ0FBQzs7RUFFNUUsQ0FBQztFQUNILDBCQUFDO0FBQUQsQ0FBQyxDQWxmd0N0SSxvRUFBYTs7QUFvZnREO0FBQ0EsaUVBQWUwRCxtQkFBbUI7Ozs7Ozs7Ozs7Ozs7Ozs7QUlqaUJsQzs7OztBQUlBLElBQUkrSixxQkFBMEM7QUFFeEMsU0FBVWhKLG9CQUFvQixDQUFDaUosU0FBNEIsRUFBRUMsWUFBb0I7RUFBcEI7SUFBQUEsb0JBQW9CO0VBQUE7RUFDOUUsT0FBRyxHQUFJRCxTQUFTLElBQWI7RUFDVixJQUFJRSxlQUFlLEdBQUdILHFCQUFxQjtFQUMzQyxJQUFJLE9BQU9BLHFCQUFxQixLQUFLLFNBQVMsSUFBSSxDQUFDRSxZQUFZLEVBQUU7SUFDL0QsT0FBT0YscUJBQXFCOztFQUc5QixJQUFNSSx1QkFBdUIsR0FBR0MsR0FBRyxJQUFJLE9BQU9BLEdBQUcsQ0FBQ0MsUUFBUSxLQUFLLFVBQVU7RUFDekUsSUFBSSxDQUFDRix1QkFBdUIsRUFBRTtJQUM1QixPQUFPLEtBQUs7O0VBR2QsSUFBTUcseUJBQXlCLEdBQUdGLEdBQUcsQ0FBQ0MsUUFBUSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUM7RUFDbkU7RUFDQTtFQUNBLElBQU1FLGlDQUFpQyxHQUNuQ0gsR0FBRyxDQUFDQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsSUFDakNELEdBQUcsQ0FBQ0MsUUFBUSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQ3BDO0VBRURILGVBQWUsR0FDWEkseUJBQXlCLElBQUlDLGlDQUFpQztFQUVsRSxJQUFJLENBQUNOLFlBQVksRUFBRTtJQUNqQkYscUJBQXFCLEdBQUdHLGVBQWU7O0VBRXpDLE9BQU9BLGVBQWU7QUFDeEI7QUFFTSxTQUFVL0Ysd0JBQXdCLENBQUN4RyxHQUFzQixFQUFFNk0sVUFBMEIsRUFBRUMsVUFBbUI7RUFFOUcsSUFBSSxDQUFDOU0sR0FBRyxFQUFFO0lBQ1IsT0FBTztNQUFDK0QsQ0FBQyxFQUFFLENBQUM7TUFBRUUsQ0FBQyxFQUFFO0lBQUMsQ0FBQzs7RUFFZCxLQUFDLEdBQU80SSxVQUFVLEVBQWpCO0lBQUU1SSxDQUFDLEdBQUk0SSxVQUFVLEVBQWQ7RUFDWCxJQUFNRSxTQUFTLEdBQUdoSixDQUFDLEdBQUcrSSxVQUFVLENBQUM5RixJQUFJO0VBQ3JDLElBQU1nRyxTQUFTLEdBQUcvSSxDQUFDLEdBQUc2SSxVQUFVLENBQUM3RixHQUFHO0VBRXBDLElBQUlnRyxXQUFXO0VBQ2YsSUFBSUMsV0FBVztFQUNmO0VBQ0EsSUFBSWxOLEdBQUcsQ0FBQ3lKLElBQUksS0FBSyxZQUFZLEVBQUU7SUFDN0IsSUFBTTBELFVBQVUsR0FBR25OLEdBQWlCO0lBQ3BDaU4sV0FBVyxHQUFHRSxVQUFVLENBQUNDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQ0MsS0FBSyxHQUFHTixTQUFTO0lBQzVERyxXQUFXLEdBQUdDLFVBQVUsQ0FBQ0MsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDRSxLQUFLLEdBQUdOLFNBQVM7R0FDN0QsTUFBTTtJQUNMLElBQU1PLFVBQVUsR0FBR3ZOLEdBQWlCO0lBQ3BDaU4sV0FBVyxHQUFHTSxVQUFVLENBQUNGLEtBQUssR0FBR04sU0FBUztJQUMxQ0csV0FBVyxHQUFHSyxVQUFVLENBQUNELEtBQUssR0FBR04sU0FBUzs7RUFHNUMsT0FBTztJQUFDakosQ0FBQyxFQUFFa0osV0FBVztJQUFFaEosQ0FBQyxFQUFFaUo7RUFBVyxDQUFDO0FBQ3pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLElBQUlNLGFBQWEsR0FBRyxVQUFTQyxDQUFDLEVBQUVDLENBQUMsRUFBRTtFQUMvQkYsYUFBYSxHQUFHL00sTUFBTSxDQUFDa04sY0FBYyxJQUNoQztJQUFFQyxTQUFTLEVBQUU7RUFBRyxDQUFDLFlBQVlDLEtBQUssSUFBSSxVQUFVSixDQUFDLEVBQUVDLENBQUMsRUFBRTtJQUFFRCxDQUFDLENBQUNHLFNBQVMsR0FBR0YsQ0FBQztFQUFFLENBQUUsSUFDNUUsVUFBVUQsQ0FBQyxFQUFFQyxDQUFDLEVBQUU7SUFBRSxLQUFLLElBQUlJLENBQUMsSUFBSUosQ0FBQyxFQUFFLElBQUlqTixNQUFNLENBQUNzTixTQUFTLENBQUNDLGNBQWMsQ0FBQ3ZNLElBQUksQ0FBQ2lNLENBQUMsRUFBRUksQ0FBQyxDQUFDLEVBQUVMLENBQUMsQ0FBQ0ssQ0FBQyxDQUFDLEdBQUdKLENBQUMsQ0FBQ0ksQ0FBQyxDQUFDO0VBQUUsQ0FBQztFQUNyRyxPQUFPTixhQUFhLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxDQUFDO0FBQzlCLENBQUM7QUFFTSxTQUFTbkwsU0FBUyxDQUFDa0wsQ0FBQyxFQUFFQyxDQUFDLEVBQUU7RUFDNUIsSUFBSSxPQUFPQSxDQUFDLEtBQUssVUFBVSxJQUFJQSxDQUFDLEtBQUssSUFBSSxFQUNyQyxNQUFNLElBQUlPLFNBQVMsQ0FBQyxzQkFBc0IsR0FBR0MsTUFBTSxDQUFDUixDQUFDLENBQUMsR0FBRywrQkFBK0IsQ0FBQztFQUM3RkYsYUFBYSxDQUFDQyxDQUFDLEVBQUVDLENBQUMsQ0FBQztFQUNuQixTQUFTUyxFQUFFLEdBQUc7SUFBRSxJQUFJLENBQUNDLFdBQVcsR0FBR1gsQ0FBQztFQUFFO0VBQ3RDQSxDQUFDLENBQUNNLFNBQVMsR0FBR0wsQ0FBQyxLQUFLLElBQUksR0FBR2pOLE1BQU0sQ0FBQzROLE1BQU0sQ0FBQ1gsQ0FBQyxDQUFDLElBQUlTLEVBQUUsQ0FBQ0osU0FBUyxHQUFHTCxDQUFDLENBQUNLLFNBQVMsRUFBRSxJQUFJSSxFQUFFLEVBQUUsQ0FBQztBQUN4RjtBQUVPLElBQUlHLFFBQVEsR0FBRyxZQUFXO0VBQzdCQSxRQUFRLEdBQUc3TixNQUFNLENBQUM4TixNQUFNLElBQUksU0FBU0QsUUFBUSxDQUFDRSxDQUFDLEVBQUU7SUFDN0MsS0FBSyxJQUFJQyxDQUFDLEVBQUVDLENBQUMsR0FBRyxDQUFDLEVBQUVDLENBQUMsR0FBR0MsU0FBUyxDQUFDMUUsTUFBTSxFQUFFd0UsQ0FBQyxHQUFHQyxDQUFDLEVBQUVELENBQUMsRUFBRSxFQUFFO01BQ2pERCxDQUFDLEdBQUdHLFNBQVMsQ0FBQ0YsQ0FBQyxDQUFDO01BQ2hCLEtBQUssSUFBSVosQ0FBQyxJQUFJVyxDQUFDLEVBQUUsSUFBSWhPLE1BQU0sQ0FBQ3NOLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDdk0sSUFBSSxDQUFDZ04sQ0FBQyxFQUFFWCxDQUFDLENBQUMsRUFBRVUsQ0FBQyxDQUFDVixDQUFDLENBQUMsR0FBR1csQ0FBQyxDQUFDWCxDQUFDLENBQUM7SUFDaEY7SUFDQSxPQUFPVSxDQUFDO0VBQ1osQ0FBQztFQUNELE9BQU9GLFFBQVEsQ0FBQ08sS0FBSyxDQUFDLElBQUksRUFBRUQsU0FBUyxDQUFDO0FBQzFDLENBQUM7QUFFTSxTQUFTRSxNQUFNLENBQUNMLENBQUMsRUFBRWpILENBQUMsRUFBRTtFQUN6QixJQUFJZ0gsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNWLEtBQUssSUFBSVYsQ0FBQyxJQUFJVyxDQUFDLEVBQUUsSUFBSWhPLE1BQU0sQ0FBQ3NOLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDdk0sSUFBSSxDQUFDZ04sQ0FBQyxFQUFFWCxDQUFDLENBQUMsSUFBSXRHLENBQUMsQ0FBQ3NDLE9BQU8sQ0FBQ2dFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFDL0VVLENBQUMsQ0FBQ1YsQ0FBQyxDQUFDLEdBQUdXLENBQUMsQ0FBQ1gsQ0FBQyxDQUFDO0VBQ2YsSUFBSVcsQ0FBQyxJQUFJLElBQUksSUFBSSxPQUFPaE8sTUFBTSxDQUFDc08scUJBQXFCLEtBQUssVUFBVSxFQUMvRCxLQUFLLElBQUlMLENBQUMsR0FBRyxDQUFDLEVBQUVaLENBQUMsR0FBR3JOLE1BQU0sQ0FBQ3NPLHFCQUFxQixDQUFDTixDQUFDLENBQUMsRUFBRUMsQ0FBQyxHQUFHWixDQUFDLENBQUM1RCxNQUFNLEVBQUV3RSxDQUFDLEVBQUUsRUFBRTtJQUNwRSxJQUFJbEgsQ0FBQyxDQUFDc0MsT0FBTyxDQUFDZ0UsQ0FBQyxDQUFDWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSWpPLE1BQU0sQ0FBQ3NOLFNBQVMsQ0FBQ2lCLG9CQUFvQixDQUFDdk4sSUFBSSxDQUFDZ04sQ0FBQyxFQUFFWCxDQUFDLENBQUNZLENBQUMsQ0FBQyxDQUFDLEVBQzFFRixDQUFDLENBQUNWLENBQUMsQ0FBQ1ksQ0FBQyxDQUFDLENBQUMsR0FBR0QsQ0FBQyxDQUFDWCxDQUFDLENBQUNZLENBQUMsQ0FBQyxDQUFDO0VBQ3pCO0VBQ0osT0FBT0YsQ0FBQztBQUNaO0FBRU8sU0FBU1MsVUFBVSxDQUFDQyxVQUFVLEVBQUV6TCxNQUFNLEVBQUVvRyxHQUFHLEVBQUVzRixJQUFJLEVBQUU7RUFDdEQsSUFBSUMsQ0FBQyxHQUFHUixTQUFTLENBQUMxRSxNQUFNO0lBQUVtRixDQUFDLEdBQUdELENBQUMsR0FBRyxDQUFDLEdBQUczTCxNQUFNLEdBQUcwTCxJQUFJLEtBQUssSUFBSSxHQUFHQSxJQUFJLEdBQUcxTyxNQUFNLENBQUM2Tyx3QkFBd0IsQ0FBQzdMLE1BQU0sRUFBRW9HLEdBQUcsQ0FBQyxHQUFHc0YsSUFBSTtJQUFFMUIsQ0FBQztFQUM1SCxJQUFJLE9BQU84QixPQUFPLEtBQUssUUFBUSxJQUFJLE9BQU9BLE9BQU8sQ0FBQ0MsUUFBUSxLQUFLLFVBQVUsRUFBRUgsQ0FBQyxHQUFHRSxPQUFPLENBQUNDLFFBQVEsQ0FBQ04sVUFBVSxFQUFFekwsTUFBTSxFQUFFb0csR0FBRyxFQUFFc0YsSUFBSSxDQUFDLENBQUMsS0FDMUgsS0FBSyxJQUFJVCxDQUFDLEdBQUdRLFVBQVUsQ0FBQ2hGLE1BQU0sR0FBRyxDQUFDLEVBQUV3RSxDQUFDLElBQUksQ0FBQyxFQUFFQSxDQUFDLEVBQUUsRUFBRSxJQUFJakIsQ0FBQyxHQUFHeUIsVUFBVSxDQUFDUixDQUFDLENBQUMsRUFBRVcsQ0FBQyxHQUFHLENBQUNELENBQUMsR0FBRyxDQUFDLEdBQUczQixDQUFDLENBQUM0QixDQUFDLENBQUMsR0FBR0QsQ0FBQyxHQUFHLENBQUMsR0FBRzNCLENBQUMsQ0FBQ2hLLE1BQU0sRUFBRW9HLEdBQUcsRUFBRXdGLENBQUMsQ0FBQyxHQUFHNUIsQ0FBQyxDQUFDaEssTUFBTSxFQUFFb0csR0FBRyxDQUFDLEtBQUt3RixDQUFDO0VBQ2pKLE9BQU9ELENBQUMsR0FBRyxDQUFDLElBQUlDLENBQUMsSUFBSTVPLE1BQU0sQ0FBQ2dQLGNBQWMsQ0FBQ2hNLE1BQU0sRUFBRW9HLEdBQUcsRUFBRXdGLENBQUMsQ0FBQyxFQUFFQSxDQUFDO0FBQ2pFO0FBRU8sU0FBU0ssT0FBTyxDQUFDQyxVQUFVLEVBQUVDLFNBQVMsRUFBRTtFQUMzQyxPQUFPLFVBQVVuTSxNQUFNLEVBQUVvRyxHQUFHLEVBQUU7SUFBRStGLFNBQVMsQ0FBQ25NLE1BQU0sRUFBRW9HLEdBQUcsRUFBRThGLFVBQVUsQ0FBQztFQUFFLENBQUM7QUFDekU7QUFFTyxTQUFTRSxVQUFVLENBQUNDLFdBQVcsRUFBRUMsYUFBYSxFQUFFO0VBQ25ELElBQUksT0FBT1IsT0FBTyxLQUFLLFFBQVEsSUFBSSxPQUFPQSxPQUFPLENBQUNTLFFBQVEsS0FBSyxVQUFVLEVBQUUsT0FBT1QsT0FBTyxDQUFDUyxRQUFRLENBQUNGLFdBQVcsRUFBRUMsYUFBYSxDQUFDO0FBQ2xJO0FBRU8sU0FBU0UsU0FBUyxDQUFDQyxPQUFPLEVBQUVDLFVBQVUsRUFBRUMsQ0FBQyxFQUFFQyxTQUFTLEVBQUU7RUFDekQsU0FBU0MsS0FBSyxDQUFDekwsS0FBSyxFQUFFO0lBQUUsT0FBT0EsS0FBSyxZQUFZdUwsQ0FBQyxHQUFHdkwsS0FBSyxHQUFHLElBQUl1TCxDQUFDLENBQUMsVUFBVUcsT0FBTyxFQUFFO01BQUVBLE9BQU8sQ0FBQzFMLEtBQUssQ0FBQztJQUFFLENBQUMsQ0FBQztFQUFFO0VBQzNHLE9BQU8sS0FBS3VMLENBQUMsS0FBS0EsQ0FBQyxHQUFHSSxPQUFPLENBQUMsRUFBRSxVQUFVRCxPQUFPLEVBQUVFLE1BQU0sRUFBRTtJQUN2RCxTQUFTQyxTQUFTLENBQUM3TCxLQUFLLEVBQUU7TUFBRSxJQUFJO1FBQUU4TCxJQUFJLENBQUNOLFNBQVMsQ0FBQ08sSUFBSSxDQUFDL0wsS0FBSyxDQUFDLENBQUM7TUFBRSxDQUFDLENBQUMsT0FBTzJDLENBQUMsRUFBRTtRQUFFaUosTUFBTSxDQUFDakosQ0FBQyxDQUFDO01BQUU7SUFBRTtJQUMxRixTQUFTcUosUUFBUSxDQUFDaE0sS0FBSyxFQUFFO01BQUUsSUFBSTtRQUFFOEwsSUFBSSxDQUFDTixTQUFTLENBQUMsT0FBTyxDQUFDLENBQUN4TCxLQUFLLENBQUMsQ0FBQztNQUFFLENBQUMsQ0FBQyxPQUFPMkMsQ0FBQyxFQUFFO1FBQUVpSixNQUFNLENBQUNqSixDQUFDLENBQUM7TUFBRTtJQUFFO0lBQzdGLFNBQVNtSixJQUFJLENBQUNHLE1BQU0sRUFBRTtNQUFFQSxNQUFNLENBQUNDLElBQUksR0FBR1IsT0FBTyxDQUFDTyxNQUFNLENBQUNqTSxLQUFLLENBQUMsR0FBR3lMLEtBQUssQ0FBQ1EsTUFBTSxDQUFDak0sS0FBSyxDQUFDLENBQUNtTSxJQUFJLENBQUNOLFNBQVMsRUFBRUcsUUFBUSxDQUFDO0lBQUU7SUFDN0dGLElBQUksQ0FBQyxDQUFDTixTQUFTLEdBQUdBLFNBQVMsQ0FBQ3hCLEtBQUssQ0FBQ3FCLE9BQU8sRUFBRUMsVUFBVSxJQUFJLEVBQUUsQ0FBQyxFQUFFUyxJQUFJLEVBQUUsQ0FBQztFQUN6RSxDQUFDLENBQUM7QUFDTjtBQUVPLFNBQVNLLFdBQVcsQ0FBQ2YsT0FBTyxFQUFFZ0IsSUFBSSxFQUFFO0VBQ3ZDLElBQUlDLENBQUMsR0FBRztNQUFFQyxLQUFLLEVBQUUsQ0FBQztNQUFFQyxJQUFJLEVBQUUsWUFBVztRQUFFLElBQUk3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLE1BQU1BLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFBRSxPQUFPQSxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUUsQ0FBQztNQUFFOEMsSUFBSSxFQUFFLEVBQUU7TUFBRUMsR0FBRyxFQUFFO0lBQUcsQ0FBQztJQUFFQyxDQUFDO0lBQUV2TixDQUFDO0lBQUV1SyxDQUFDO0lBQUVpRCxDQUFDO0VBQ2hILE9BQU9BLENBQUMsR0FBRztJQUFFYixJQUFJLEVBQUVjLElBQUksQ0FBQyxDQUFDLENBQUM7SUFBRSxPQUFPLEVBQUVBLElBQUksQ0FBQyxDQUFDLENBQUM7SUFBRSxRQUFRLEVBQUVBLElBQUksQ0FBQyxDQUFDO0VBQUUsQ0FBQyxFQUFFLE9BQU9DLE1BQU0sS0FBSyxVQUFVLEtBQUtGLENBQUMsQ0FBQ0UsTUFBTSxDQUFDQyxRQUFRLENBQUMsR0FBRyxZQUFXO0lBQUUsT0FBTyxJQUFJO0VBQUUsQ0FBQyxDQUFDLEVBQUVILENBQUM7RUFDeEosU0FBU0MsSUFBSSxDQUFDL0MsQ0FBQyxFQUFFO0lBQUUsT0FBTyxVQUFVa0QsQ0FBQyxFQUFFO01BQUUsT0FBT2xCLElBQUksQ0FBQyxDQUFDaEMsQ0FBQyxFQUFFa0QsQ0FBQyxDQUFDLENBQUM7SUFBRSxDQUFDO0VBQUU7RUFDakUsU0FBU2xCLElBQUksQ0FBQ21CLEVBQUUsRUFBRTtJQUNkLElBQUlOLENBQUMsRUFBRSxNQUFNLElBQUl2RCxTQUFTLENBQUMsaUNBQWlDLENBQUM7SUFDN0QsT0FBT3dELENBQUMsS0FBS0EsQ0FBQyxHQUFHLENBQUMsRUFBRUssRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLWCxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRUEsQ0FBQyxFQUFFLElBQUk7TUFDMUMsSUFBSUssQ0FBQyxHQUFHLENBQUMsRUFBRXZOLENBQUMsS0FBS3VLLENBQUMsR0FBR3NELEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUc3TixDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUc2TixFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUc3TixDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQ3VLLENBQUMsR0FBR3ZLLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBS3VLLENBQUMsQ0FBQy9NLElBQUksQ0FBQ3dDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHQSxDQUFDLENBQUMyTSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUNwQyxDQUFDLEdBQUdBLENBQUMsQ0FBQy9NLElBQUksQ0FBQ3dDLENBQUMsRUFBRTZOLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFZixJQUFJLEVBQUUsT0FBT3ZDLENBQUM7TUFDNUosSUFBSXZLLENBQUMsR0FBRyxDQUFDLEVBQUV1SyxDQUFDLEVBQUVzRCxFQUFFLEdBQUcsQ0FBQ0EsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRXRELENBQUMsQ0FBQzNKLEtBQUssQ0FBQztNQUN2QyxRQUFRaU4sRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNULEtBQUssQ0FBQztRQUFFLEtBQUssQ0FBQztVQUFFdEQsQ0FBQyxHQUFHc0QsRUFBRTtVQUFFO1FBQ3hCLEtBQUssQ0FBQztVQUFFWCxDQUFDLENBQUNDLEtBQUssRUFBRTtVQUFFLE9BQU87WUFBRXZNLEtBQUssRUFBRWlOLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFBRWYsSUFBSSxFQUFFO1VBQU0sQ0FBQztRQUN2RCxLQUFLLENBQUM7VUFBRUksQ0FBQyxDQUFDQyxLQUFLLEVBQUU7VUFBRW5OLENBQUMsR0FBRzZOLEVBQUUsQ0FBQyxDQUFDLENBQUM7VUFBRUEsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1VBQUU7UUFDeEMsS0FBSyxDQUFDO1VBQUVBLEVBQUUsR0FBR1gsQ0FBQyxDQUFDSSxHQUFHLENBQUNRLEdBQUcsRUFBRTtVQUFFWixDQUFDLENBQUNHLElBQUksQ0FBQ1MsR0FBRyxFQUFFO1VBQUU7UUFDeEM7VUFDSSxJQUFJLEVBQUV2RCxDQUFDLEdBQUcyQyxDQUFDLENBQUNHLElBQUksRUFBRTlDLENBQUMsR0FBR0EsQ0FBQyxDQUFDdEUsTUFBTSxHQUFHLENBQUMsSUFBSXNFLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDdEUsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs0SCxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJQSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUU7WUFBRVgsQ0FBQyxHQUFHLENBQUM7WUFBRTtVQUFVO1VBQzNHLElBQUlXLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQ3RELENBQUMsSUFBS3NELEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBR3RELENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSXNELEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBR3RELENBQUMsQ0FBQyxDQUFDLENBQUUsQ0FBQyxFQUFFO1lBQUUyQyxDQUFDLENBQUNDLEtBQUssR0FBR1UsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUFFO1VBQU87VUFDckYsSUFBSUEsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSVgsQ0FBQyxDQUFDQyxLQUFLLEdBQUc1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFBRTJDLENBQUMsQ0FBQ0MsS0FBSyxHQUFHNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFQSxDQUFDLEdBQUdzRCxFQUFFO1lBQUU7VUFBTztVQUNwRSxJQUFJdEQsQ0FBQyxJQUFJMkMsQ0FBQyxDQUFDQyxLQUFLLEdBQUc1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFBRTJDLENBQUMsQ0FBQ0MsS0FBSyxHQUFHNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFFMkMsQ0FBQyxDQUFDSSxHQUFHLENBQUNsSCxJQUFJLENBQUN5SCxFQUFFLENBQUM7WUFBRTtVQUFPO1VBQ2xFLElBQUl0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUyQyxDQUFDLENBQUNJLEdBQUcsQ0FBQ1EsR0FBRyxFQUFFO1VBQ3JCWixDQUFDLENBQUNHLElBQUksQ0FBQ1MsR0FBRyxFQUFFO1VBQUU7TUFBUztNQUUvQkQsRUFBRSxHQUFHWixJQUFJLENBQUN6UCxJQUFJLENBQUN5TyxPQUFPLEVBQUVpQixDQUFDLENBQUM7SUFDOUIsQ0FBQyxDQUFDLE9BQU8zSixDQUFDLEVBQUU7TUFBRXNLLEVBQUUsR0FBRyxDQUFDLENBQUMsRUFBRXRLLENBQUMsQ0FBQztNQUFFdkQsQ0FBQyxHQUFHLENBQUM7SUFBRSxDQUFDLFNBQVM7TUFBRXVOLENBQUMsR0FBR2hELENBQUMsR0FBRyxDQUFDO0lBQUU7SUFDekQsSUFBSXNELEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsTUFBTUEsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUFFLE9BQU87TUFBRWpOLEtBQUssRUFBRWlOLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBR0EsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztNQUFFZixJQUFJLEVBQUU7SUFBSyxDQUFDO0VBQ3BGO0FBQ0o7QUFFTyxJQUFJaUIsZUFBZSxHQUFHdlIsTUFBTSxDQUFDNE4sTUFBTSxHQUFJLFVBQVM0RCxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxFQUFFLEVBQUU7RUFDaEUsSUFBSUEsRUFBRSxLQUFLblQsU0FBUyxFQUFFbVQsRUFBRSxHQUFHRCxDQUFDO0VBQzVCLElBQUloRCxJQUFJLEdBQUcxTyxNQUFNLENBQUM2Tyx3QkFBd0IsQ0FBQzRDLENBQUMsRUFBRUMsQ0FBQyxDQUFDO0VBQ2hELElBQUksQ0FBQ2hELElBQUksS0FBSyxLQUFLLElBQUlBLElBQUksR0FBRyxDQUFDK0MsQ0FBQyxDQUFDRyxVQUFVLEdBQUdsRCxJQUFJLENBQUNtRCxRQUFRLElBQUluRCxJQUFJLENBQUNvRCxZQUFZLENBQUMsRUFBRTtJQUMvRXBELElBQUksR0FBRztNQUFFcUQsVUFBVSxFQUFFLElBQUk7TUFBRUMsR0FBRyxFQUFFLFlBQVc7UUFBRSxPQUFPUCxDQUFDLENBQUNDLENBQUMsQ0FBQztNQUFFO0lBQUUsQ0FBQztFQUNqRTtFQUNBMVIsTUFBTSxDQUFDZ1AsY0FBYyxDQUFDd0MsQ0FBQyxFQUFFRyxFQUFFLEVBQUVqRCxJQUFJLENBQUM7QUFDdEMsQ0FBQyxHQUFLLFVBQVM4QyxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxFQUFFLEVBQUU7RUFDeEIsSUFBSUEsRUFBRSxLQUFLblQsU0FBUyxFQUFFbVQsRUFBRSxHQUFHRCxDQUFDO0VBQzVCRixDQUFDLENBQUNHLEVBQUUsQ0FBQyxHQUFHRixDQUFDLENBQUNDLENBQUMsQ0FBQztBQUNoQixDQUFFO0FBRUssU0FBU08sWUFBWSxDQUFDUixDQUFDLEVBQUVELENBQUMsRUFBRTtFQUMvQixLQUFLLElBQUluRSxDQUFDLElBQUlvRSxDQUFDLEVBQUUsSUFBSXBFLENBQUMsS0FBSyxTQUFTLElBQUksQ0FBQ3JOLE1BQU0sQ0FBQ3NOLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDdk0sSUFBSSxDQUFDd1EsQ0FBQyxFQUFFbkUsQ0FBQyxDQUFDLEVBQUVrRSxlQUFlLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxFQUFFcEUsQ0FBQyxDQUFDO0FBQ2pIO0FBRU8sU0FBUzZFLFFBQVEsQ0FBQ1YsQ0FBQyxFQUFFO0VBQ3hCLElBQUl4RCxDQUFDLEdBQUcsT0FBT2tELE1BQU0sS0FBSyxVQUFVLElBQUlBLE1BQU0sQ0FBQ0MsUUFBUTtJQUFFTSxDQUFDLEdBQUd6RCxDQUFDLElBQUl3RCxDQUFDLENBQUN4RCxDQUFDLENBQUM7SUFBRUMsQ0FBQyxHQUFHLENBQUM7RUFDN0UsSUFBSXdELENBQUMsRUFBRSxPQUFPQSxDQUFDLENBQUN6USxJQUFJLENBQUN3USxDQUFDLENBQUM7RUFDdkIsSUFBSUEsQ0FBQyxJQUFJLE9BQU9BLENBQUMsQ0FBQy9ILE1BQU0sS0FBSyxRQUFRLEVBQUUsT0FBTztJQUMxQzBHLElBQUksRUFBRSxZQUFZO01BQ2QsSUFBSXFCLENBQUMsSUFBSXZELENBQUMsSUFBSXVELENBQUMsQ0FBQy9ILE1BQU0sRUFBRStILENBQUMsR0FBRyxLQUFLLENBQUM7TUFDbEMsT0FBTztRQUFFcE4sS0FBSyxFQUFFb04sQ0FBQyxJQUFJQSxDQUFDLENBQUN2RCxDQUFDLEVBQUUsQ0FBQztRQUFFcUMsSUFBSSxFQUFFLENBQUNrQjtNQUFFLENBQUM7SUFDM0M7RUFDSixDQUFDO0VBQ0QsTUFBTSxJQUFJaEUsU0FBUyxDQUFDUSxDQUFDLEdBQUcseUJBQXlCLEdBQUcsaUNBQWlDLENBQUM7QUFDMUY7QUFFTyxTQUFTbUUsTUFBTSxDQUFDWCxDQUFDLEVBQUV0RCxDQUFDLEVBQUU7RUFDekIsSUFBSXVELENBQUMsR0FBRyxPQUFPUCxNQUFNLEtBQUssVUFBVSxJQUFJTSxDQUFDLENBQUNOLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDO0VBQzFELElBQUksQ0FBQ00sQ0FBQyxFQUFFLE9BQU9ELENBQUM7RUFDaEIsSUFBSXZELENBQUMsR0FBR3dELENBQUMsQ0FBQ3pRLElBQUksQ0FBQ3dRLENBQUMsQ0FBQztJQUFFNUMsQ0FBQztJQUFFd0QsRUFBRSxHQUFHLEVBQUU7SUFBRXJMLENBQUM7RUFDaEMsSUFBSTtJQUNBLE9BQU8sQ0FBQ21ILENBQUMsS0FBSyxLQUFLLENBQUMsSUFBSUEsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQ1UsQ0FBQyxHQUFHWCxDQUFDLENBQUNrQyxJQUFJLEVBQUUsRUFBRUcsSUFBSSxFQUFFOEIsRUFBRSxDQUFDeEksSUFBSSxDQUFDZ0YsQ0FBQyxDQUFDeEssS0FBSyxDQUFDO0VBQzlFLENBQUMsQ0FDRCxPQUFPaU8sS0FBSyxFQUFFO0lBQUV0TCxDQUFDLEdBQUc7TUFBRXNMLEtBQUssRUFBRUE7SUFBTSxDQUFDO0VBQUUsQ0FBQyxTQUMvQjtJQUNKLElBQUk7TUFDQSxJQUFJekQsQ0FBQyxJQUFJLENBQUNBLENBQUMsQ0FBQzBCLElBQUksS0FBS21CLENBQUMsR0FBR3hELENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFd0QsQ0FBQyxDQUFDelEsSUFBSSxDQUFDaU4sQ0FBQyxDQUFDO0lBQ3BELENBQUMsU0FDTztNQUFFLElBQUlsSCxDQUFDLEVBQUUsTUFBTUEsQ0FBQyxDQUFDc0wsS0FBSztJQUFFO0VBQ3BDO0VBQ0EsT0FBT0QsRUFBRTtBQUNiOztBQUVBO0FBQ08sU0FBU0UsUUFBUSxHQUFHO0VBQ3ZCLEtBQUssSUFBSUYsRUFBRSxHQUFHLEVBQUUsRUFBRW5FLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR0UsU0FBUyxDQUFDMUUsTUFBTSxFQUFFd0UsQ0FBQyxFQUFFLEVBQzlDbUUsRUFBRSxHQUFHQSxFQUFFLENBQUNHLE1BQU0sQ0FBQ0osTUFBTSxDQUFDaEUsU0FBUyxDQUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ3hDLE9BQU9tRSxFQUFFO0FBQ2I7O0FBRUE7QUFDTyxTQUFTSSxjQUFjLEdBQUc7RUFDN0IsS0FBSyxJQUFJeEUsQ0FBQyxHQUFHLENBQUMsRUFBRUMsQ0FBQyxHQUFHLENBQUMsRUFBRXdFLEVBQUUsR0FBR3RFLFNBQVMsQ0FBQzFFLE1BQU0sRUFBRXdFLENBQUMsR0FBR3dFLEVBQUUsRUFBRXhFLENBQUMsRUFBRSxFQUFFRCxDQUFDLElBQUlHLFNBQVMsQ0FBQ0YsQ0FBQyxDQUFDLENBQUN4RSxNQUFNO0VBQ25GLEtBQUssSUFBSW1GLENBQUMsR0FBR3hCLEtBQUssQ0FBQ1ksQ0FBQyxDQUFDLEVBQUUwRCxDQUFDLEdBQUcsQ0FBQyxFQUFFekQsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHd0UsRUFBRSxFQUFFeEUsQ0FBQyxFQUFFLEVBQzVDLEtBQUssSUFBSXlFLENBQUMsR0FBR3ZFLFNBQVMsQ0FBQ0YsQ0FBQyxDQUFDLEVBQUUwRSxDQUFDLEdBQUcsQ0FBQyxFQUFFQyxFQUFFLEdBQUdGLENBQUMsQ0FBQ2pKLE1BQU0sRUFBRWtKLENBQUMsR0FBR0MsRUFBRSxFQUFFRCxDQUFDLEVBQUUsRUFBRWpCLENBQUMsRUFBRSxFQUM3RDlDLENBQUMsQ0FBQzhDLENBQUMsQ0FBQyxHQUFHZ0IsQ0FBQyxDQUFDQyxDQUFDLENBQUM7RUFDbkIsT0FBTy9ELENBQUM7QUFDWjtBQUVPLFNBQVNpRSxhQUFhLENBQUNDLEVBQUUsRUFBRUMsSUFBSSxFQUFFQyxJQUFJLEVBQUU7RUFDMUMsSUFBSUEsSUFBSSxJQUFJN0UsU0FBUyxDQUFDMUUsTUFBTSxLQUFLLENBQUMsRUFBRSxLQUFLLElBQUl3RSxDQUFDLEdBQUcsQ0FBQyxFQUFFZ0YsQ0FBQyxHQUFHRixJQUFJLENBQUN0SixNQUFNLEVBQUUySSxFQUFFLEVBQUVuRSxDQUFDLEdBQUdnRixDQUFDLEVBQUVoRixDQUFDLEVBQUUsRUFBRTtJQUNqRixJQUFJbUUsRUFBRSxJQUFJLEVBQUVuRSxDQUFDLElBQUk4RSxJQUFJLENBQUMsRUFBRTtNQUNwQixJQUFJLENBQUNYLEVBQUUsRUFBRUEsRUFBRSxHQUFHaEYsS0FBSyxDQUFDRSxTQUFTLENBQUM0RixLQUFLLENBQUNsUyxJQUFJLENBQUMrUixJQUFJLEVBQUUsQ0FBQyxFQUFFOUUsQ0FBQyxDQUFDO01BQ3BEbUUsRUFBRSxDQUFDbkUsQ0FBQyxDQUFDLEdBQUc4RSxJQUFJLENBQUM5RSxDQUFDLENBQUM7SUFDbkI7RUFDSjtFQUNBLE9BQU82RSxFQUFFLENBQUNQLE1BQU0sQ0FBQ0gsRUFBRSxJQUFJaEYsS0FBSyxDQUFDRSxTQUFTLENBQUM0RixLQUFLLENBQUNsUyxJQUFJLENBQUMrUixJQUFJLENBQUMsQ0FBQztBQUM1RDtBQUVPLFNBQVNJLE9BQU8sQ0FBQy9CLENBQUMsRUFBRTtFQUN2QixPQUFPLElBQUksWUFBWStCLE9BQU8sSUFBSSxJQUFJLENBQUMvQixDQUFDLEdBQUdBLENBQUMsRUFBRSxJQUFJLElBQUksSUFBSStCLE9BQU8sQ0FBQy9CLENBQUMsQ0FBQztBQUN4RTtBQUVPLFNBQVNnQyxnQkFBZ0IsQ0FBQzNELE9BQU8sRUFBRUMsVUFBVSxFQUFFRSxTQUFTLEVBQUU7RUFDN0QsSUFBSSxDQUFDc0IsTUFBTSxDQUFDbUMsYUFBYSxFQUFFLE1BQU0sSUFBSTdGLFNBQVMsQ0FBQyxzQ0FBc0MsQ0FBQztFQUN0RixJQUFJd0QsQ0FBQyxHQUFHcEIsU0FBUyxDQUFDeEIsS0FBSyxDQUFDcUIsT0FBTyxFQUFFQyxVQUFVLElBQUksRUFBRSxDQUFDO0lBQUV6QixDQUFDO0lBQUVxRixDQUFDLEdBQUcsRUFBRTtFQUM3RCxPQUFPckYsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFZ0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFQSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUVBLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRWhELENBQUMsQ0FBQ2lELE1BQU0sQ0FBQ21DLGFBQWEsQ0FBQyxHQUFHLFlBQVk7SUFBRSxPQUFPLElBQUk7RUFBRSxDQUFDLEVBQUVwRixDQUFDO0VBQ3JILFNBQVNnRCxJQUFJLENBQUMvQyxDQUFDLEVBQUU7SUFBRSxJQUFJOEMsQ0FBQyxDQUFDOUMsQ0FBQyxDQUFDLEVBQUVELENBQUMsQ0FBQ0MsQ0FBQyxDQUFDLEdBQUcsVUFBVWtELENBQUMsRUFBRTtNQUFFLE9BQU8sSUFBSXJCLE9BQU8sQ0FBQyxVQUFVMkMsQ0FBQyxFQUFFekYsQ0FBQyxFQUFFO1FBQUVxRyxDQUFDLENBQUMxSixJQUFJLENBQUMsQ0FBQ3NFLENBQUMsRUFBRWtELENBQUMsRUFBRXNCLENBQUMsRUFBRXpGLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJc0csTUFBTSxDQUFDckYsQ0FBQyxFQUFFa0QsQ0FBQyxDQUFDO01BQUUsQ0FBQyxDQUFDO0lBQUUsQ0FBQztFQUFFO0VBQ3pJLFNBQVNtQyxNQUFNLENBQUNyRixDQUFDLEVBQUVrRCxDQUFDLEVBQUU7SUFBRSxJQUFJO01BQUVsQixJQUFJLENBQUNjLENBQUMsQ0FBQzlDLENBQUMsQ0FBQyxDQUFDa0QsQ0FBQyxDQUFDLENBQUM7SUFBRSxDQUFDLENBQUMsT0FBT3JLLENBQUMsRUFBRTtNQUFFeU0sTUFBTSxDQUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUV2TSxDQUFDLENBQUM7SUFBRTtFQUFFO0VBQ2pGLFNBQVNtSixJQUFJLENBQUN0QixDQUFDLEVBQUU7SUFBRUEsQ0FBQyxDQUFDeEssS0FBSyxZQUFZK08sT0FBTyxHQUFHcEQsT0FBTyxDQUFDRCxPQUFPLENBQUNsQixDQUFDLENBQUN4SyxLQUFLLENBQUNnTixDQUFDLENBQUMsQ0FBQ2IsSUFBSSxDQUFDa0QsT0FBTyxFQUFFekQsTUFBTSxDQUFDLEdBQUd3RCxNQUFNLENBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTFFLENBQUMsQ0FBQztFQUFFO0VBQ3ZILFNBQVM2RSxPQUFPLENBQUNyUCxLQUFLLEVBQUU7SUFBRW1QLE1BQU0sQ0FBQyxNQUFNLEVBQUVuUCxLQUFLLENBQUM7RUFBRTtFQUNqRCxTQUFTNEwsTUFBTSxDQUFDNUwsS0FBSyxFQUFFO0lBQUVtUCxNQUFNLENBQUMsT0FBTyxFQUFFblAsS0FBSyxDQUFDO0VBQUU7RUFDakQsU0FBU29QLE1BQU0sQ0FBQ3pDLENBQUMsRUFBRUssQ0FBQyxFQUFFO0lBQUUsSUFBSUwsQ0FBQyxDQUFDSyxDQUFDLENBQUMsRUFBRWtDLENBQUMsQ0FBQ0ksS0FBSyxFQUFFLEVBQUVKLENBQUMsQ0FBQzdKLE1BQU0sRUFBRThKLE1BQU0sQ0FBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFBRTtBQUNyRjtBQUVPLFNBQVNLLGdCQUFnQixDQUFDbkMsQ0FBQyxFQUFFO0VBQ2hDLElBQUl2RCxDQUFDLEVBQUVaLENBQUM7RUFDUixPQUFPWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUVnRCxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUVBLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVWxLLENBQUMsRUFBRTtJQUFFLE1BQU1BLENBQUM7RUFBRSxDQUFDLENBQUMsRUFBRWtLLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRWhELENBQUMsQ0FBQ2lELE1BQU0sQ0FBQ0MsUUFBUSxDQUFDLEdBQUcsWUFBWTtJQUFFLE9BQU8sSUFBSTtFQUFFLENBQUMsRUFBRWxELENBQUM7RUFDM0ksU0FBU2dELElBQUksQ0FBQy9DLENBQUMsRUFBRTZDLENBQUMsRUFBRTtJQUFFOUMsQ0FBQyxDQUFDQyxDQUFDLENBQUMsR0FBR3NELENBQUMsQ0FBQ3RELENBQUMsQ0FBQyxHQUFHLFVBQVVrRCxDQUFDLEVBQUU7TUFBRSxPQUFPLENBQUMvRCxDQUFDLEdBQUcsQ0FBQ0EsQ0FBQyxJQUFJO1FBQUVqSixLQUFLLEVBQUUrTyxPQUFPLENBQUMzQixDQUFDLENBQUN0RCxDQUFDLENBQUMsQ0FBQ2tELENBQUMsQ0FBQyxDQUFDO1FBQUVkLElBQUksRUFBRXBDLENBQUMsS0FBSztNQUFTLENBQUMsR0FBRzZDLENBQUMsR0FBR0EsQ0FBQyxDQUFDSyxDQUFDLENBQUMsR0FBR0EsQ0FBQztJQUFFLENBQUMsR0FBR0wsQ0FBQztFQUFFO0FBQ2xKO0FBRU8sU0FBUzZDLGFBQWEsQ0FBQ3BDLENBQUMsRUFBRTtFQUM3QixJQUFJLENBQUNOLE1BQU0sQ0FBQ21DLGFBQWEsRUFBRSxNQUFNLElBQUk3RixTQUFTLENBQUMsc0NBQXNDLENBQUM7RUFDdEYsSUFBSWlFLENBQUMsR0FBR0QsQ0FBQyxDQUFDTixNQUFNLENBQUNtQyxhQUFhLENBQUM7SUFBRXBGLENBQUM7RUFDbEMsT0FBT3dELENBQUMsR0FBR0EsQ0FBQyxDQUFDelEsSUFBSSxDQUFDd1EsQ0FBQyxDQUFDLElBQUlBLENBQUMsR0FBRyxPQUFPVSxRQUFRLEtBQUssVUFBVSxHQUFHQSxRQUFRLENBQUNWLENBQUMsQ0FBQyxHQUFHQSxDQUFDLENBQUNOLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDLEVBQUUsRUFBRWxELENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRWdELElBQUksQ0FBQyxNQUFNLENBQUMsRUFBRUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFQSxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUVoRCxDQUFDLENBQUNpRCxNQUFNLENBQUNtQyxhQUFhLENBQUMsR0FBRyxZQUFZO0lBQUUsT0FBTyxJQUFJO0VBQUUsQ0FBQyxFQUFFcEYsQ0FBQyxDQUFDO0VBQ2hOLFNBQVNnRCxJQUFJLENBQUMvQyxDQUFDLEVBQUU7SUFBRUQsQ0FBQyxDQUFDQyxDQUFDLENBQUMsR0FBR3NELENBQUMsQ0FBQ3RELENBQUMsQ0FBQyxJQUFJLFVBQVVrRCxDQUFDLEVBQUU7TUFBRSxPQUFPLElBQUlyQixPQUFPLENBQUMsVUFBVUQsT0FBTyxFQUFFRSxNQUFNLEVBQUU7UUFBRW9CLENBQUMsR0FBR0ksQ0FBQyxDQUFDdEQsQ0FBQyxDQUFDLENBQUNrRCxDQUFDLENBQUMsRUFBRW9DLE1BQU0sQ0FBQzFELE9BQU8sRUFBRUUsTUFBTSxFQUFFb0IsQ0FBQyxDQUFDZCxJQUFJLEVBQUVjLENBQUMsQ0FBQ2hOLEtBQUssQ0FBQztNQUFFLENBQUMsQ0FBQztJQUFFLENBQUM7RUFBRTtFQUMvSixTQUFTb1AsTUFBTSxDQUFDMUQsT0FBTyxFQUFFRSxNQUFNLEVBQUVoRCxDQUFDLEVBQUVvRSxDQUFDLEVBQUU7SUFBRXJCLE9BQU8sQ0FBQ0QsT0FBTyxDQUFDc0IsQ0FBQyxDQUFDLENBQUNiLElBQUksQ0FBQyxVQUFTYSxDQUFDLEVBQUU7TUFBRXRCLE9BQU8sQ0FBQztRQUFFMUwsS0FBSyxFQUFFZ04sQ0FBQztRQUFFZCxJQUFJLEVBQUV0RDtNQUFFLENBQUMsQ0FBQztJQUFFLENBQUMsRUFBRWdELE1BQU0sQ0FBQztFQUFFO0FBQy9IO0FBRU8sU0FBUzZELG9CQUFvQixDQUFDQyxNQUFNLEVBQUVDLEdBQUcsRUFBRTtFQUM5QyxJQUFJL1QsTUFBTSxDQUFDZ1AsY0FBYyxFQUFFO0lBQUVoUCxNQUFNLENBQUNnUCxjQUFjLENBQUM4RSxNQUFNLEVBQUUsS0FBSyxFQUFFO01BQUUxUCxLQUFLLEVBQUUyUDtJQUFJLENBQUMsQ0FBQztFQUFFLENBQUMsTUFBTTtJQUFFRCxNQUFNLENBQUNDLEdBQUcsR0FBR0EsR0FBRztFQUFFO0VBQzlHLE9BQU9ELE1BQU07QUFDakI7QUFBQztBQUVELElBQUlFLGtCQUFrQixHQUFHaFUsTUFBTSxDQUFDNE4sTUFBTSxHQUFJLFVBQVM0RCxDQUFDLEVBQUVKLENBQUMsRUFBRTtFQUNyRHBSLE1BQU0sQ0FBQ2dQLGNBQWMsQ0FBQ3dDLENBQUMsRUFBRSxTQUFTLEVBQUU7SUFBRU8sVUFBVSxFQUFFLElBQUk7SUFBRTNOLEtBQUssRUFBRWdOO0VBQUUsQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsR0FBSSxVQUFTSSxDQUFDLEVBQUVKLENBQUMsRUFBRTtFQUNoQkksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHSixDQUFDO0FBQ3BCLENBQUM7QUFFTSxTQUFTNkMsWUFBWSxDQUFDQyxHQUFHLEVBQUU7RUFDOUIsSUFBSUEsR0FBRyxJQUFJQSxHQUFHLENBQUN0QyxVQUFVLEVBQUUsT0FBT3NDLEdBQUc7RUFDckMsSUFBSTdELE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDZixJQUFJNkQsR0FBRyxJQUFJLElBQUksRUFBRSxLQUFLLElBQUl4QyxDQUFDLElBQUl3QyxHQUFHLEVBQUUsSUFBSXhDLENBQUMsS0FBSyxTQUFTLElBQUkxUixNQUFNLENBQUNzTixTQUFTLENBQUNDLGNBQWMsQ0FBQ3ZNLElBQUksQ0FBQ2tULEdBQUcsRUFBRXhDLENBQUMsQ0FBQyxFQUFFSCxlQUFlLENBQUNsQixNQUFNLEVBQUU2RCxHQUFHLEVBQUV4QyxDQUFDLENBQUM7RUFDeElzQyxrQkFBa0IsQ0FBQzNELE1BQU0sRUFBRTZELEdBQUcsQ0FBQztFQUMvQixPQUFPN0QsTUFBTTtBQUNqQjtBQUVPLFNBQVM4RCxlQUFlLENBQUNELEdBQUcsRUFBRTtFQUNqQyxPQUFRQSxHQUFHLElBQUlBLEdBQUcsQ0FBQ3RDLFVBQVUsR0FBSXNDLEdBQUcsR0FBRztJQUFFRSxPQUFPLEVBQUVGO0VBQUksQ0FBQztBQUMzRDtBQUVPLFNBQVNHLHNCQUFzQixDQUFDQyxRQUFRLEVBQUUzSixLQUFLLEVBQUU0SixJQUFJLEVBQUV4RCxDQUFDLEVBQUU7RUFDN0QsSUFBSXdELElBQUksS0FBSyxHQUFHLElBQUksQ0FBQ3hELENBQUMsRUFBRSxNQUFNLElBQUl2RCxTQUFTLENBQUMsK0NBQStDLENBQUM7RUFDNUYsSUFBSSxPQUFPN0MsS0FBSyxLQUFLLFVBQVUsR0FBRzJKLFFBQVEsS0FBSzNKLEtBQUssSUFBSSxDQUFDb0csQ0FBQyxHQUFHLENBQUNwRyxLQUFLLENBQUM2SixHQUFHLENBQUNGLFFBQVEsQ0FBQyxFQUFFLE1BQU0sSUFBSTlHLFNBQVMsQ0FBQywwRUFBMEUsQ0FBQztFQUNsTCxPQUFPK0csSUFBSSxLQUFLLEdBQUcsR0FBR3hELENBQUMsR0FBR3dELElBQUksS0FBSyxHQUFHLEdBQUd4RCxDQUFDLENBQUMvUCxJQUFJLENBQUNzVCxRQUFRLENBQUMsR0FBR3ZELENBQUMsR0FBR0EsQ0FBQyxDQUFDM00sS0FBSyxHQUFHdUcsS0FBSyxDQUFDcUgsR0FBRyxDQUFDc0MsUUFBUSxDQUFDO0FBQ2pHO0FBRU8sU0FBU0csc0JBQXNCLENBQUNILFFBQVEsRUFBRTNKLEtBQUssRUFBRXZHLEtBQUssRUFBRW1RLElBQUksRUFBRXhELENBQUMsRUFBRTtFQUNwRSxJQUFJd0QsSUFBSSxLQUFLLEdBQUcsRUFBRSxNQUFNLElBQUkvRyxTQUFTLENBQUMsZ0NBQWdDLENBQUM7RUFDdkUsSUFBSStHLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQ3hELENBQUMsRUFBRSxNQUFNLElBQUl2RCxTQUFTLENBQUMsK0NBQStDLENBQUM7RUFDNUYsSUFBSSxPQUFPN0MsS0FBSyxLQUFLLFVBQVUsR0FBRzJKLFFBQVEsS0FBSzNKLEtBQUssSUFBSSxDQUFDb0csQ0FBQyxHQUFHLENBQUNwRyxLQUFLLENBQUM2SixHQUFHLENBQUNGLFFBQVEsQ0FBQyxFQUFFLE1BQU0sSUFBSTlHLFNBQVMsQ0FBQyx5RUFBeUUsQ0FBQztFQUNqTCxPQUFRK0csSUFBSSxLQUFLLEdBQUcsR0FBR3hELENBQUMsQ0FBQy9QLElBQUksQ0FBQ3NULFFBQVEsRUFBRWxRLEtBQUssQ0FBQyxHQUFHMk0sQ0FBQyxHQUFHQSxDQUFDLENBQUMzTSxLQUFLLEdBQUdBLEtBQUssR0FBR3VHLEtBQUssQ0FBQytKLEdBQUcsQ0FBQ0osUUFBUSxFQUFFbFEsS0FBSyxDQUFDLEVBQUdBLEtBQUs7QUFDN0c7QUFFTyxTQUFTdVEscUJBQXFCLENBQUNoSyxLQUFLLEVBQUUySixRQUFRLEVBQUU7RUFDbkQsSUFBSUEsUUFBUSxLQUFLLElBQUksSUFBSyxPQUFPQSxRQUFRLEtBQUssUUFBUSxJQUFJLE9BQU9BLFFBQVEsS0FBSyxVQUFXLEVBQUUsTUFBTSxJQUFJOUcsU0FBUyxDQUFDLHdDQUF3QyxDQUFDO0VBQ3hKLE9BQU8sT0FBTzdDLEtBQUssS0FBSyxVQUFVLEdBQUcySixRQUFRLEtBQUszSixLQUFLLEdBQUdBLEtBQUssQ0FBQzZKLEdBQUcsQ0FBQ0YsUUFBUSxDQUFDO0FBQ2pGOzs7Ozs7Ozs7O0FDdlBBTSxNQUFNLENBQUNDLE9BQU8sR0FBRztFQUFFQyxNQUFNLEVBQUU7SUFBQyxZQUFZLEVBQUMsSUFBSTtJQUFDLHNCQUFzQixFQUFDLElBQUk7SUFBQyxPQUFPLEVBQUM7RUFBSztBQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBN0U7O0FBRThCO0FBQ3dCO0FBQ1Q7QUFFYjtBQUU3QyxDQUFDLGVBQWVJLElBQUksR0FBRztFQUNyQjtFQUNBO0VBQ0E7O0VBRUEsTUFBTUgsb0RBQVEsQ0FBQ0EsK0RBQW1CLENBQUM7O0VBRW5DO0VBQ0E7RUFDQTs7RUFFQSxNQUFNTSxnQkFBZ0IsR0FBRztJQUN2QixDQUFDTiw0RUFBZ0MsR0FBR1M7RUFDdEMsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7O0VBRUEsTUFBTUMsZ0JBQWdCLEdBQUcsSUFBSVQsNEVBQWdCLENBQUM7SUFBRVUsSUFBSSxFQUFFL1YsUUFBUSxDQUFDZ1csR0FBRztJQUFFQyxXQUFXLEVBQUUsSUFBSTtJQUFFQztFQUFVLENBQUMsQ0FBQztFQUVuRyxNQUFNQyxTQUFTLEdBQUcsTUFBTWYsNERBQWdCLEVBQUU7RUFDMUNBLDJEQUFlLENBQUMsa0NBQWtDLEVBQUU7SUFBRWU7RUFBVSxDQUFDLENBQUM7RUFFbEUsTUFBTUksWUFBWSxHQUFHLElBQUlqQixtRUFBWSxDQUFDclMsTUFBTSxDQUFDOztFQUU3QztFQUNBO0VBQ0E7O0VBRUFtUyxnRkFBb0MsQ0FBQ25TLE1BQU0sRUFBRXdULGtCQUFrQixDQUFDOztFQUVoRTtFQUNBO0VBQ0E7O0VBRUEsU0FBU1AsU0FBUyxDQUFDUSxPQUFPLEVBQUVDLElBQUksRUFBRTtJQUNoQ2pCLGdCQUFnQixDQUFDZ0IsT0FBTyxDQUFDck4sSUFBSSxDQUFDLENBQUNxTixPQUFPLEVBQUVDLElBQUksQ0FBQztFQUMvQztFQUVBLFNBQVNkLGlCQUFpQixDQUFDYSxPQUFPLEVBQUVFLEtBQUssRUFBRTtJQUN6QyxJQUFJRixPQUFPLENBQUNHLFNBQVMsRUFBRTtNQUNyQixNQUFNQyx1QkFBdUIsR0FBRzFCLHNFQUEwQixDQUFDc0IsT0FBTyxDQUFDRyxTQUFTLENBQUNHLElBQUksQ0FBQztNQUNsRixJQUFJNUIsOEVBQWtDLENBQUMwQix1QkFBdUIsQ0FBQyxFQUFFO1FBQy9ELE1BQU1JLFNBQVMsR0FBR2xYLFFBQVEsQ0FBQ21YLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQztRQUNoRUQsU0FBUyxDQUFDelMsS0FBSyxHQUFHcVMsdUJBQXVCO1FBQ3pDSSxTQUFTLENBQUNFLGlCQUFpQixDQUFDLENBQUMsRUFBRUYsU0FBUyxDQUFDelMsS0FBSyxDQUFDcUYsTUFBTSxFQUFFLFNBQVMsQ0FBQztNQUNuRTtJQUNGO0VBQ0Y7O0VBRUE7RUFDQTtFQUNBOztFQUVBLGVBQWUyTSxrQkFBa0IsR0FBRztJQUNsQ1gsZ0JBQWdCLENBQUN1QixXQUFXLENBQUM7TUFBRWhPLElBQUksRUFBRStMLHlFQUE2QjtNQUFFbUMsR0FBRyxFQUFFcEI7SUFBVSxDQUFDLENBQUM7SUFFckZmLHdFQUE0QixDQUFDcFYsUUFBUSxDQUFDO0lBRXRDLE1BQU15WCxrQkFBa0IsRUFBRTtJQUUxQnpYLFFBQVEsQ0FBQ21YLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDM1gsZ0JBQWdCLENBQUMsUUFBUSxFQUFFa1ksa0JBQWtCLENBQUM7SUFFekYxWCxRQUFRLENBQUNtWCxjQUFjLENBQUMsNkJBQTZCLENBQUMsQ0FBQzNYLGdCQUFnQixDQUFDLE9BQU8sRUFBRW1ZLDRCQUE0QixDQUFDO0lBRTlHLE1BQU1DLGlCQUFpQixHQUFHNVgsUUFBUSxDQUFDbVgsY0FBYyxDQUFDLGtCQUFrQixDQUFDO0lBQ3JFUyxpQkFBaUIsQ0FBQ3BZLGdCQUFnQixDQUFDLE9BQU8sRUFBRXFZLHdCQUF3QixDQUFDO0lBQ3JFLE1BQU1DLHVCQUF1QixHQUFHLElBQUl6Vix1REFBUyxDQUFDdVYsaUJBQWlCLENBQUM7SUFDaEVFLHVCQUF1QixDQUFDclYsU0FBUyxHQUFHLElBQUk7RUFDMUM7RUFFQSxlQUFlaVYsa0JBQWtCLENBQUN0USxDQUFDLEVBQUU7SUFDbkNBLENBQUMsQ0FBQzJRLGNBQWMsRUFBRTtJQUNsQixNQUFNakIsdUJBQXVCLEdBQUcxQixzRUFBMEIsQ0FDeERBLG1FQUF1QixDQUFDcFYsUUFBUSxDQUFDbVgsY0FBYyxDQUFDLHFCQUFxQixDQUFDLENBQUMxUyxLQUFLLENBQUMsQ0FDOUU7SUFDRCxJQUFJMlEsOEVBQWtDLENBQUMwQix1QkFBdUIsQ0FBQyxFQUFFO01BQy9ELElBQUkxQixnRUFBb0IsRUFBRTtRQUN4Qm5TLE1BQU0sQ0FBQ2lWLFNBQVMsQ0FBQ0MsU0FBUyxDQUFDQyxTQUFTLENBQUN0Qix1QkFBdUIsQ0FBQztNQUMvRDtNQUNBLE1BQU0xQiw4REFBa0IsQ0FBQ2UsU0FBUyxFQUFFVyx1QkFBdUIsRUFBRVAsWUFBWSxDQUFDK0IsUUFBUSxDQUFDO0lBQ3JGO0VBQ0Y7RUFFQSxlQUFlWCw0QkFBNEIsQ0FBQ3ZRLENBQUMsRUFBRTtJQUM3Q0EsQ0FBQyxDQUFDMlEsY0FBYyxFQUFFO0lBQ2xCLE1BQU0zQyxxRUFBeUIsQ0FDN0JlLFNBQVMsRUFDVCxJQUFJZixzRUFBMEIsQ0FBQ2hPLENBQUMsQ0FBQ3NSLE9BQU8sRUFBRXRSLENBQUMsQ0FBQ3VSLFFBQVEsRUFBRXZSLENBQUMsQ0FBQ3dSLE9BQU8sQ0FBQyxFQUNoRXhELDRFQUFnQyxDQUNqQztFQUNIO0VBRUEsZUFBZXlDLHdCQUF3QixDQUFDelEsQ0FBQyxFQUFFO0lBQ3pDLE1BQU1nTywrREFBbUIsQ0FDdkJlLFNBQVMsRUFDVCxJQUFJZixzRUFBMEIsQ0FBQ2hPLENBQUMsQ0FBQ3NSLE9BQU8sRUFBRXRSLENBQUMsQ0FBQ3VSLFFBQVEsRUFBRXZSLENBQUMsQ0FBQ3dSLE9BQU8sQ0FBQyxFQUNoRXhELDRFQUFnQyxDQUNqQztFQUNIOztFQUVBO0VBQ0E7RUFDQTs7RUFFQSxlQUFlcUMsa0JBQWtCLEdBQUc7SUFDbEMsTUFBTXNCLFlBQVksR0FBRy9ZLFFBQVEsQ0FBQ21YLGNBQWMsQ0FBQyxlQUFlLENBQUM7SUFDN0QsTUFBTTZCLFFBQVEsR0FBRyxNQUFNQyxNQUFNLENBQUNELFFBQVEsQ0FBQ0UsTUFBTSxFQUFFO0lBQy9DLEtBQUssTUFBTTtNQUFFbkQsSUFBSTtNQUFFb0QsUUFBUTtNQUFFQztJQUFZLENBQUMsSUFBSUosUUFBUSxFQUFFO01BQ3RELE1BQU1LLGNBQWMsR0FBR04sWUFBWSxDQUFDaFgsV0FBVyxDQUFDL0IsUUFBUSxDQUFDc1osYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO01BQzlFRCxjQUFjLENBQUNyVSxPQUFPLENBQUN1VSxZQUFZLEdBQUd4RCxJQUFJO01BQzFDc0QsY0FBYyxDQUFDeFcsU0FBUyxDQUFDQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7TUFDOUMsTUFBTTBXLGVBQWUsR0FBR0gsY0FBYyxDQUFDdFgsV0FBVyxDQUFDL0IsUUFBUSxDQUFDc1osYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO01BQ2xGLElBQUlILFFBQVEsRUFBRTtRQUNaSyxlQUFlLENBQUNDLFNBQVMsR0FBR04sUUFBUSxDQUFDTyxVQUFVLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQztNQUMvRCxDQUFDLE1BQU07UUFDTEwsY0FBYyxDQUFDeFcsU0FBUyxDQUFDQyxHQUFHLENBQUMseUJBQXlCLENBQUM7UUFDdkQwVyxlQUFlLENBQUNDLFNBQVMsR0FBR1IsTUFBTSxDQUFDVSxJQUFJLENBQUNDLFVBQVUsQ0FBQyxpQ0FBaUMsQ0FBQztNQUN2RjtNQUVBLE1BQU1DLHNCQUFzQixHQUFHZCxZQUFZLENBQUNoWCxXQUFXLENBQUMvQixRQUFRLENBQUNzWixhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7TUFDdEZPLHNCQUFzQixDQUFDN1UsT0FBTyxDQUFDdVUsWUFBWSxHQUFHeEQsSUFBSTtNQUNsRDhELHNCQUFzQixDQUFDaFgsU0FBUyxDQUFDQyxHQUFHLENBQUMsd0JBQXdCLENBQUM7TUFDOUQsTUFBTWdYLHVCQUF1QixHQUFHRCxzQkFBc0IsQ0FBQzlYLFdBQVcsQ0FBQy9CLFFBQVEsQ0FBQ3NaLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztNQUNsR1EsdUJBQXVCLENBQUNMLFNBQVMsR0FBR0wsV0FBVztJQUNqRDtFQUNGO0FBQ0YsQ0FBQyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hJSjtBQUNBO0FBQ0E7QUFDTyxNQUFNNUQsUUFBUSxHQUFHO0VBQ3RCQyxNQUFNLEVBQUUsUUFBUTtFQUNoQnNFLFVBQVUsRUFBRSxZQUFZO0VBQ3hCQyxPQUFPLEVBQUUsR0FBRztFQUNaQyxPQUFPLEVBQUU7QUFDWCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNPLE1BQU1DLFdBQVcsR0FBRztFQUN6QkMsZ0JBQWdCLEVBQUUsa0JBQWtCO0VBQ3BDQyxVQUFVLEVBQUU7QUFDZCxDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNPLE1BQU16RSxXQUFXLEdBQUc7RUFDekI7RUFDQTtFQUNBO0VBQ0EwRSxLQUFLLEVBQUUsT0FBTztFQUNkQyx3QkFBd0IsRUFBRSwwQkFBMEI7RUFDcERILGdCQUFnQixFQUFFLGtCQUFrQjtFQUNwQ0ksaUJBQWlCLEVBQUUsbUJBQW1CO0VBRXRDO0VBQ0E7RUFDQTtFQUNBQyxPQUFPLEVBQUUsU0FBUztFQUNsQkosVUFBVSxFQUFFLFlBQVk7RUFFeEI7RUFDQTtFQUNBO0VBQ0E5QyxhQUFhLEVBQUUsZUFBZTtFQUU5QjtFQUNBO0VBQ0E7RUFDQTFCLGdCQUFnQixFQUFFO0FBQ3BCLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU02RSxlQUFlLEdBQUcsOERBQThELENBQUMsQ0FBQzs7QUFFL0Y7QUFDQTtBQUNBO0FBQ08sTUFBTUMseUJBQXlCLEdBQUcsSUFBSTs7QUFFN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQyw4QkFBOEIsR0FBRyxvREFBb0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hFWTtBQUM3RDtBQUNPOztBQUV4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTM0MsbUJBQW1CLENBQUM0QyxhQUFhLEVBQUU7RUFDakRBLGFBQWEsS0FBSyxFQUFFO0VBQ3BCLE9BQU9BLGFBQWEsQ0FBQzlRLE1BQU0sR0FBRzRRLG9FQUF5QixHQUFHQyx5RUFBOEIsR0FBR0MsYUFBYTtBQUMxRzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTN0Qsc0JBQXNCLENBQUM2RCxhQUFhLEVBQUU7RUFDcERBLGFBQWEsR0FBRzVDLG1CQUFtQixDQUFDNEMsYUFBYSxDQUFDO0VBQ2xELE9BQU9BLGFBQWEsS0FBS0QseUVBQThCLEdBQ25EQyxhQUFhLEdBQ2JBLGFBQWEsQ0FBQ2xCLFVBQVUsQ0FBQyxJQUFJbUIsTUFBTSxDQUFFLE9BQU1KLDBEQUFnQixJQUFHLEVBQUUsR0FBRyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUNLLElBQUksRUFBRTtBQUN2Rjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTN0QsOEJBQThCLENBQUNILHVCQUF1QixFQUFFO0VBQ3RFQSx1QkFBdUIsS0FBSyxFQUFFO0VBQzlCLE9BQ0VBLHVCQUF1QixLQUFLNkQseUVBQThCLElBQzFEN0QsdUJBQXVCLENBQUNoTixNQUFNLEdBQUcsQ0FBQyxJQUNsQ2dOLHVCQUF1QixDQUFDaE4sTUFBTSxJQUFJNFEsb0VBQXlCO0FBRS9EOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNLLFNBQVMsQ0FBQy9ELElBQUksRUFBRTtFQUM5QixPQUFPLEdBQUcsSUFBSUEsSUFBSSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUc7QUFDakM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTZ0UsUUFBUSxDQUFDQyxHQUFHLEVBQUU7RUFDNUIsT0FBT0MsSUFBSSxDQUFDQyxLQUFLLENBQUNELElBQUksQ0FBQ0UsU0FBUyxDQUFDSCxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNJLFdBQVcsQ0FBQ2hZLE1BQU0sRUFBRWlZLE1BQU0sRUFBRTtFQUMxQyxPQUFPO0lBQUUsR0FBR2pZLE1BQU07SUFBRSxHQUFHaEQsTUFBTSxDQUFDa2IsV0FBVyxDQUFDbGIsTUFBTSxDQUFDbWIsT0FBTyxDQUFDRixNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ0csTUFBTSxDQUFDLENBQUMsR0FBR2hLLENBQUMsQ0FBQyxLQUFLQSxDQUFDLEtBQUs1UyxTQUFTLENBQUM7RUFBRSxDQUFDO0FBQzlHOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVMyWCxnQ0FBZ0MsQ0FBQ2tGLEdBQUcsRUFBRUMsUUFBUSxFQUFFO0VBQzlELElBQUlELEdBQUcsQ0FBQzFiLFFBQVEsQ0FBQzRiLFVBQVUsS0FBSyxTQUFTLEVBQUU7SUFDekNGLEdBQUcsQ0FBQzFiLFFBQVEsQ0FBQ1IsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUVtYyxRQUFRLENBQUM7RUFDN0QsQ0FBQyxNQUFNO0lBQ0xFLGNBQWMsQ0FBQ0YsUUFBUSxDQUFDO0VBQzFCO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0csNkJBQTZCLENBQUNKLEdBQUcsRUFBRUMsUUFBUSxFQUFFO0VBQzNELElBQUlELEdBQUcsQ0FBQzFiLFFBQVEsQ0FBQzRiLFVBQVUsS0FBSyxVQUFVLEVBQUU7SUFDMUNGLEdBQUcsQ0FBQ2xjLGdCQUFnQixDQUFDLE1BQU0sRUFBRW1jLFFBQVEsQ0FBQztFQUN4QyxDQUFDLE1BQU07SUFDTEUsY0FBYyxDQUFDRixRQUFRLENBQUM7RUFDMUI7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU25FLHdCQUF3QixDQUFDdUUsR0FBRyxFQUFFO0VBQzVDLE1BQU1DLFlBQVksR0FBRyxDQUFDLFdBQVcsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLFdBQVcsRUFBRSxPQUFPLENBQUM7RUFDbEYsS0FBSyxNQUFNbmIsT0FBTyxJQUFJa2IsR0FBRyxDQUFDRSxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO0lBQ2pFLE1BQU1DLGFBQWEsR0FBRyxDQUFDLE1BQU07TUFDM0IsTUFBTXhMLE1BQU0sR0FBRyxFQUFFO01BQ2pCLE1BQU0vUixJQUFJLEdBQUdrQyxPQUFPLENBQUNtRSxPQUFPLENBQUNtWCxRQUFRO01BQ3JDLElBQUksQ0FBQ3hkLElBQUksRUFBRTtRQUNULE9BQU8rUixNQUFNO01BQ2Y7TUFDQSxNQUFNMEwsR0FBRyxHQUFHemQsSUFBSSxDQUFDMGQsS0FBSyxDQUFDLEdBQUcsQ0FBQztNQUMzQixLQUFLLE1BQU1DLEVBQUUsSUFBSUYsR0FBRyxFQUFFO1FBQ3BCLE1BQU1HLFVBQVUsR0FBR1IsR0FBRyxDQUFDNUUsY0FBYyxDQUFDbUYsRUFBRSxDQUFDO1FBQ3pDLE1BQU1FLFNBQVMsR0FBR0QsVUFBVSxDQUFDdlgsT0FBTyxDQUFDeVgsVUFBVTtRQUMvQ3BHLHNEQUFhLENBQUMyRixZQUFZLENBQUNXLFFBQVEsQ0FBQ0gsU0FBUyxDQUFDLEVBQUUsbUJBQW1CLEVBQUU7VUFBRUEsU0FBUztVQUFFRDtRQUFXLENBQUMsQ0FBQztRQUMvRjdMLE1BQU0sQ0FBQ3pHLElBQUksQ0FBQ3NTLFVBQVUsQ0FBQ0MsU0FBUyxDQUFDLENBQUM7TUFDcEM7TUFDQSxPQUFPOUwsTUFBTTtJQUNmLENBQUMsR0FBRztJQUNKLE1BQU1yTixNQUFNLEdBQUd4QyxPQUFPLENBQUNtRSxPQUFPLENBQUN5WCxVQUFVO0lBQ3pDcEcsc0RBQWEsQ0FBQzJGLFlBQVksQ0FBQ1csUUFBUSxDQUFDdFosTUFBTSxDQUFDLEVBQUUsbUJBQW1CLEVBQUU7TUFBRUEsTUFBTTtNQUFFeEM7SUFBUSxDQUFDLENBQUM7SUFDdEZBLE9BQU8sQ0FBQ3dDLE1BQU0sQ0FBQyxHQUFHNFYsTUFBTSxDQUFDVSxJQUFJLENBQUNDLFVBQVUsQ0FBQy9ZLE9BQU8sQ0FBQ21FLE9BQU8sQ0FBQzRYLFFBQVEsRUFBRVYsYUFBYSxDQUFDO0VBQ25GO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU1csWUFBWSxDQUFDbkIsR0FBRyxFQUFFO0VBQ2hDLFNBQVNvQix3QkFBd0IsQ0FBQ2pHLFNBQVMsRUFBRTtJQUMzQyxJQUFJQSxTQUFTLENBQUNrRyxVQUFVLEtBQUssQ0FBQyxFQUFFO01BQzlCLE1BQU1DLEtBQUssR0FBR25HLFNBQVMsQ0FBQ29HLFVBQVUsQ0FBQyxDQUFDLENBQUM7TUFDckMsSUFBSUQsS0FBSyxDQUFDRSxjQUFjLEtBQUtGLEtBQUssQ0FBQ0csWUFBWSxFQUFFO1FBQy9DLE1BQU1DLHVCQUF1QixHQUFHSixLQUFLLENBQUNJLHVCQUF1QjtRQUM3RCxJQUFJQSx1QkFBdUIsWUFBWUMsT0FBTyxFQUFFO1VBQzlDLElBQUlELHVCQUF1QixDQUFDRSxVQUFVLEVBQUU7WUFDdEMsT0FBT1Isd0JBQXdCLENBQUNNLHVCQUF1QixDQUFDRSxVQUFVLENBQUNULFlBQVksRUFBRSxDQUFDO1VBQ3BGLENBQUMsTUFBTTtZQUNMLE1BQU1VLHNCQUFzQixHQUFHOVAsS0FBSyxDQUFDRSxTQUFTLENBQUM4TixNQUFNLENBQUNwYSxJQUFJLENBQ3hEK2IsdUJBQXVCLENBQUNuQixnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsRUFDNUNwYixPQUFPLElBQUssQ0FBQyxDQUFDQSxPQUFPLENBQUN5YyxVQUFVLENBQ2xDO1lBQ0QsSUFBSUMsc0JBQXNCLENBQUN6VCxNQUFNLEtBQUssQ0FBQyxFQUFFO2NBQ3ZDLE9BQU9nVCx3QkFBd0IsQ0FBQ1Msc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUNELFVBQVUsQ0FBQ1QsWUFBWSxFQUFFLENBQUM7WUFDdEY7VUFDRjtRQUNGO01BQ0Y7SUFDRjtJQUNBLE9BQU9oRyxTQUFTO0VBQ2xCO0VBRUEsT0FBT2lHLHdCQUF3QixDQUFDcEIsR0FBRyxDQUFDbUIsWUFBWSxFQUFFLENBQUM7QUFDckQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU3hGLFdBQVcsQ0FBQ1YsSUFBSSxFQUFFRCxPQUFPLEVBQUU7RUFDekMsSUFBSTtJQUNGQyxJQUFJLENBQUNVLFdBQVcsQ0FBQ1gsT0FBTyxDQUFDO0VBQzNCLENBQUMsQ0FBQyxPQUFPaEUsS0FBSyxFQUFFO0lBQ2QyRCxvREFBVyxDQUNULHdHQUF3RyxFQUN4RztNQUFFM0QsS0FBSztNQUFFaUUsSUFBSTtNQUFFRDtJQUFRLENBQUMsQ0FDekI7RUFDSDtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlTixZQUFZLEdBQUc7RUFDbkMsTUFBTSxDQUFDbUIsR0FBRyxDQUFDLEdBQUcsTUFBTTBCLE1BQU0sQ0FBQ3dFLElBQUksQ0FBQ0MsS0FBSyxDQUFDO0lBQUVDLE1BQU0sRUFBRSxJQUFJO0lBQUVDLGFBQWEsRUFBRTtFQUFLLENBQUMsQ0FBQztFQUM1RSxPQUFPckcsR0FBRztBQUNaOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZXNHLFlBQVksQ0FBQ3RHLEdBQUcsRUFBRXVHLE1BQU0sRUFBRTtFQUM5QyxPQUFPLE1BQU03RSxNQUFNLENBQUN3RSxJQUFJLENBQUN4UCxNQUFNLENBQUM7SUFDOUI4UCxRQUFRLEVBQUV4RyxHQUFHLENBQUN3RyxRQUFRO0lBQ3RCQyxXQUFXLEVBQUV6RyxHQUFHLENBQUMrRSxFQUFFO0lBQ25CMkIsS0FBSyxFQUFFMUcsR0FBRyxDQUFDMEcsS0FBSyxHQUFHLENBQUM7SUFDcEJDLEdBQUcsRUFBRUosTUFBTSxFQUFFSSxHQUFHO0lBQ2hCUCxNQUFNLEVBQUVHLE1BQU0sRUFBRUgsTUFBTSxJQUFJO0VBQzVCLENBQUMsQ0FBQztBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVRLGVBQWUsQ0FBQ0wsTUFBTSxFQUFFO0VBQzVDLE1BQU1GLGFBQWEsR0FBRyxNQUFNM0UsTUFBTSxDQUFDbUYsT0FBTyxDQUFDQyxVQUFVLEVBQUU7RUFDdkQsT0FBTyxNQUFNcEYsTUFBTSxDQUFDbUYsT0FBTyxDQUFDblEsTUFBTSxDQUFDO0lBQ2pDakQsS0FBSyxFQUFFNFMsYUFBYSxDQUFDNVMsS0FBSztJQUMxQmtULEdBQUcsRUFBRUosTUFBTSxFQUFFSTtFQUNmLENBQUMsQ0FBQztBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlN0YsY0FBYyxDQUFDZCxHQUFHLEVBQUUrRyxVQUFVLEVBQUVoRyxRQUFRLEVBQUU7RUFDOUQsTUFBTWlHLGFBQWEsR0FBRy9GLHNFQUFvQixDQUFDRixRQUFRLEVBQUUsSUFBSUUsK0RBQWEsQ0FBQ2paLDREQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO0VBQ2xHLElBQUlnZixhQUFhLENBQUNFLFdBQVcsS0FBS2pHLG1GQUFpQyxFQUFFO0lBQ25FLE1BQU1vRyxNQUFNLEdBQUcsTUFBTWYsWUFBWSxDQUFDdEcsR0FBRyxFQUFFO01BQUVvRyxNQUFNLEVBQUU7SUFBTSxDQUFDLENBQUM7SUFDekQsTUFBTTFFLE1BQU0sQ0FBQzRGLE1BQU0sQ0FBQ25CLEtBQUssQ0FBQztNQUFFb0IsS0FBSyxFQUFFRixNQUFNLENBQUN0QyxFQUFFO01BQUV0RixJQUFJLEVBQUUrRCxTQUFTLENBQUN1RCxVQUFVO0lBQUUsQ0FBQyxDQUFDO0lBQzVFO0lBQ0E7SUFDQSxJQUFJQyxhQUFhLENBQUNaLE1BQU0sSUFBSSxJQUFJLEVBQUU7TUFDaEMsTUFBTTFFLE1BQU0sQ0FBQ3dFLElBQUksQ0FBQ3NCLE1BQU0sQ0FBQ0gsTUFBTSxDQUFDdEMsRUFBRSxFQUFFO1FBQUVxQixNQUFNLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDdkQ7RUFDRixDQUFDLE1BQU07SUFDTCxNQUFNMUUsTUFBTSxDQUFDNEYsTUFBTSxDQUFDbkIsS0FBSyxDQUFDO01BQUVlLFdBQVcsRUFBRUYsYUFBYSxDQUFDRSxXQUFXO01BQUV6SCxJQUFJLEVBQUUrRCxTQUFTLENBQUN1RCxVQUFVO0lBQUUsQ0FBQyxDQUFDO0VBQ3BHO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlVSxRQUFRLENBQUN6SCxHQUFHLEVBQUUyRyxHQUFHLEVBQUU1RixRQUFRLEVBQUUyRyxvQkFBb0IsRUFBRTtFQUN2RSxNQUFNVixhQUFhLEdBQUcvRixzRUFBb0IsQ0FBQ0YsUUFBUSxFQUFFMkcsb0JBQW9CLENBQUM7RUFDMUUsSUFBSVYsYUFBYSxDQUFDRSxXQUFXLEtBQUtqRyx1RkFBcUMsRUFBRTtJQUN2RSxNQUFNUyxNQUFNLENBQUN3RSxJQUFJLENBQUNzQixNQUFNLENBQUN4SCxHQUFHLENBQUMrRSxFQUFFLEVBQUU7TUFBRTRCLEdBQUcsRUFBRUE7SUFBSSxDQUFDLENBQUM7RUFDaEQsQ0FBQyxNQUFNLElBQUlLLGFBQWEsQ0FBQ0UsV0FBVyxLQUFLakcsc0ZBQW9DLEVBQUU7SUFDN0UsTUFBTTJGLGVBQWUsQ0FBQztNQUFFRCxHQUFHLEVBQUVBO0lBQUksQ0FBQyxDQUFDO0VBQ3JDLENBQUMsTUFBTTtJQUNMLE1BQU1MLFlBQVksQ0FBQ3RHLEdBQUcsRUFBRTtNQUFFMkcsR0FBRyxFQUFFQSxHQUFHO01BQUVQLE1BQU0sRUFBRVksYUFBYSxDQUFDWixNQUFNLElBQUk7SUFBSyxDQUFDLENBQUM7RUFDN0U7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlN0UsZUFBZSxDQUFDdkIsR0FBRyxFQUFFZSxRQUFRLEVBQUUyRyxvQkFBb0IsRUFBRTtFQUN6RSxNQUFNZixHQUFHLEdBQUdqRixNQUFNLENBQUNtRyxPQUFPLENBQUNDLE1BQU0sQ0FBQyxjQUFjLENBQUM7RUFDakQsTUFBTUwsUUFBUSxDQUFDekgsR0FBRyxFQUFFMkcsR0FBRyxFQUFFNUYsUUFBUSxFQUFFMkcsb0JBQW9CLENBQUM7QUFDMUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZUssd0JBQXdCLENBQUMvSCxHQUFHLEVBQUVlLFFBQVEsRUFBRTJHLG9CQUFvQixFQUFFO0VBQ2xGLE1BQU1mLEdBQUcsR0FBRywwQkFBMEI7RUFDdEMsTUFBTWMsUUFBUSxDQUFDekgsR0FBRyxFQUFFMkcsR0FBRyxFQUFFNUYsUUFBUSxFQUFFMkcsb0JBQW9CLENBQUM7QUFDMUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZTFHLHFCQUFxQixDQUFDaEIsR0FBRyxFQUFFZSxRQUFRLEVBQUUyRyxvQkFBb0IsRUFBRTtFQUMvRSxNQUFNZixHQUFHLEdBQUcsK0JBQStCO0VBQzNDLE1BQU1jLFFBQVEsQ0FBQ3pILEdBQUcsRUFBRTJHLEdBQUcsRUFBRTVGLFFBQVEsRUFBRTJHLG9CQUFvQixDQUFDO0FBQzFEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNVd1QztBQUNLO0FBQ0w7QUFDRTs7QUFFekM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxJQUFJNUksTUFBTTs7QUFFakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxJQUFJOVcsT0FBTzs7QUFFbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZVIsSUFBSSxDQUFDMGdCLFFBQVEsRUFBRTtFQUNuQ3BKLE1BQU0sR0FBRyxJQUFJa0osOENBQU0sQ0FBQ0UsUUFBUSxDQUFDO0VBQzdCcEosTUFBTSxDQUFDckwsS0FBSyxDQUFDLG1CQUFtQixFQUFFO0lBQUV5VTtFQUFTLENBQUMsQ0FBQztFQUUvQ2xnQixPQUFPLEdBQUcsSUFBSWlnQixnREFBTyxDQUFDbkosTUFBTSxDQUFDO0VBQzdCLE1BQU05VyxPQUFPLENBQUNSLElBQUksRUFBRTtFQUVwQixNQUFNMmdCLFlBQVksQ0FBQ0QsUUFBUSxDQUFDO0FBQzlCO0FBRUEsZUFBZUMsWUFBWSxDQUFDRCxRQUFRLEVBQUU7RUFDcEMsTUFBTUUsV0FBVyxHQUFHLE9BQU87RUFDM0IsTUFBTUMsT0FBTyxHQUFHM0csTUFBTSxDQUFDMkcsT0FBTyxDQUFDQyxLQUFLO0VBQ3BDLElBQUlKLFFBQVEsS0FBS2pLLDhEQUFtQixFQUFFO0lBQ3BDTCxvREFBWSxHQUFHLENBQUMsTUFBTThELE1BQU0sQ0FBQ21HLE9BQU8sQ0FBQ1csZUFBZSxFQUFFLEVBQUVDLEVBQUUsS0FBSyxLQUFLO0lBQ3BFLE1BQU1KLE9BQU8sQ0FBQzdLLEdBQUcsQ0FBQztNQUFFLENBQUM0SyxXQUFXLEdBQUd4SyxvREFBWTJLO0lBQUMsQ0FBQyxDQUFDO0VBQ3BELENBQUMsTUFBTTtJQUNMM0ssb0RBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNeUssT0FBTyxDQUFDdk4sR0FBRyxDQUFDc04sV0FBVyxDQUFDLEVBQUVBLFdBQVcsQ0FBQztFQUNoRTtFQUNBdEosTUFBTSxDQUFDckwsS0FBSyxDQUFDLDJCQUEyQixFQUFFO0lBQUUsQ0FBQyxjQUFjLEdBQUdtSyxvREFBWTJLO0VBQUMsQ0FBQyxDQUFDO0FBQy9FOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BEdUM7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTXRILGFBQWEsQ0FBQztFQUN6QjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT2tHLFdBQVcsR0FBRztJQUNuQlEsV0FBVyxFQUFFLGFBQWE7SUFDMUJQLE9BQU8sRUFBRSxTQUFTO0lBQ2xCUSxVQUFVLEVBQUU7RUFDZCxDQUFDO0VBRUQsT0FBTzFHLFFBQVEsR0FBRyxNQUFNQSxRQUFRLENBQUM7SUFDL0JDLE9BQU87SUFDUEMsUUFBUTs7SUFFUjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDSTNLLFdBQVcsQ0FBQzBLLE9BQU8sRUFBRUMsUUFBUSxFQUFFQyxPQUFPLEdBQUdGLE9BQU8sRUFBRTtNQUNoRCxJQUFJLENBQUNBLE9BQU8sR0FBR3ZELG9EQUFZLEdBQUd5RCxPQUFPLEdBQUdGLE9BQU87TUFDL0MsSUFBSSxDQUFDQyxRQUFRLEdBQUdBLFFBQVE7SUFDMUI7SUFFQXNILE1BQU0sQ0FBQ0MsS0FBSyxFQUFFO01BQ1osT0FBT0EsS0FBSyxJQUFJLElBQUksQ0FBQ3hILE9BQU8sS0FBS3dILEtBQUssQ0FBQ3hILE9BQU8sSUFBSSxJQUFJLENBQUNDLFFBQVEsS0FBS3VILEtBQUssQ0FBQ3ZILFFBQVE7SUFDcEY7SUFFQSxPQUFPdUcsV0FBVyxHQUFHLElBQUl6RyxRQUFRLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQztJQUMvQyxPQUFPSSxjQUFjLEdBQUcsSUFBSUosUUFBUSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7SUFDaEQsT0FBTzBILGdCQUFnQixHQUFHLElBQUkxSCxRQUFRLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQztJQUNuRCxPQUFPMEcsVUFBVSxHQUFHLElBQUkxRyxRQUFRLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQztFQUMvQyxDQUFDOztFQUVEO0FBQ0Y7QUFDQTtFQUNFZ0csV0FBVzs7RUFFWDtBQUNGO0FBQ0E7QUFDQTtBQUNBO0VBQ0VkLE1BQU07O0VBRU47QUFDRjtBQUNBO0FBQ0E7RUFDRTNQLFdBQVcsQ0FBQ3lRLFdBQVcsRUFBRWQsTUFBTSxHQUFHLElBQUksRUFBRTtJQUN0QyxJQUFJLENBQUNjLFdBQVcsR0FBR0EsV0FBVztJQUM5QixJQUFJLENBQUNkLE1BQU0sR0FBR0EsTUFBTTtFQUN0QjtFQUVBLE9BQU91QixXQUFXLEdBQUcsSUFBSTFHLGFBQWEsQ0FBQ0EsYUFBYSxDQUFDa0csV0FBVyxDQUFDUSxXQUFXLENBQUM7RUFDN0UsT0FBT3JHLGNBQWMsR0FBRyxJQUFJTCxhQUFhLENBQUNBLGFBQWEsQ0FBQ2tHLFdBQVcsQ0FBQ0MsT0FBTyxFQUFFLElBQUksQ0FBQztFQUNsRixPQUFPd0IsZ0JBQWdCLEdBQUcsSUFBSTNILGFBQWEsQ0FBQ0EsYUFBYSxDQUFDa0csV0FBVyxDQUFDQyxPQUFPLEVBQUUsS0FBSyxDQUFDO0VBQ3JGLE9BQU9RLFVBQVUsR0FBRyxJQUFJM0csYUFBYSxDQUFDQSxhQUFhLENBQUNrRyxXQUFXLENBQUNTLFVBQVUsQ0FBQzs7RUFFM0U7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxPQUFPWCxNQUFNLENBQUNsRyxRQUFRLEVBQUUyRyxvQkFBb0IsRUFBRTtJQUM1QyxJQUFJekcsYUFBYSxDQUFDQyxRQUFRLENBQUNJLGNBQWMsQ0FBQ29ILE1BQU0sQ0FBQzNILFFBQVEsQ0FBQyxFQUFFLE9BQU9FLGFBQWEsQ0FBQ0ssY0FBYyxDQUFDLEtBQzNGLElBQUlMLGFBQWEsQ0FBQ0MsUUFBUSxDQUFDMEgsZ0JBQWdCLENBQUNGLE1BQU0sQ0FBQzNILFFBQVEsQ0FBQyxFQUFFLE9BQU9FLGFBQWEsQ0FBQzJILGdCQUFnQixDQUFDLEtBQ3BHLElBQUkzSCxhQUFhLENBQUNDLFFBQVEsQ0FBQzBHLFVBQVUsQ0FBQ2MsTUFBTSxDQUFDM0gsUUFBUSxDQUFDLEVBQUUsT0FBT0UsYUFBYSxDQUFDMkcsVUFBVSxDQUFDLEtBQ3hGLE9BQU9GLG9CQUFvQixJQUFJekcsYUFBYSxDQUFDMEcsV0FBVztFQUMvRDtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3JGdUM7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTUssTUFBTSxDQUFDO0VBQ2xCLENBQUNqRCxFQUFFOztFQUVIO0FBQ0Y7QUFDQTtBQUNBO0VBQ0V0TyxXQUFXLENBQUNzTyxFQUFFLEVBQUU7SUFDZCxJQUFJLENBQUMsQ0FBQ0EsRUFBRSxHQUFHQSxFQUFFO0VBQ2Y7O0VBRUE7QUFDRjtBQUNBO0VBQ0U4RCxLQUFLLENBQUM5RCxFQUFFLEVBQUU7SUFDUixJQUFJLENBQUMsQ0FBQ0EsRUFBRSxHQUFHQSxFQUFFO0VBQ2Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFaEcsSUFBSSxDQUFDSSxPQUFPLEVBQUUsR0FBRy9YLElBQUksRUFBRTtJQUNyQixJQUFJLENBQUMsQ0FBQzBoQixNQUFNLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRTNKLE9BQU8sRUFBRS9YLElBQUksQ0FBQztFQUNoRDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VxTSxLQUFLLENBQUMwTCxPQUFPLEVBQUUsR0FBRy9YLElBQUksRUFBRTtJQUN0QixJQUFJLENBQUMsQ0FBQzBoQixNQUFNLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRTNKLE9BQU8sRUFBRS9YLElBQUksQ0FBQztFQUNqRDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UyaEIsUUFBUSxDQUFDNUosT0FBTyxFQUFFLEdBQUcvWCxJQUFJLEVBQUU7SUFDekIsSUFBSSxDQUFDLENBQUMwaEIsTUFBTSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUUzSixPQUFPLEVBQUUvWCxJQUFJLENBQUM7RUFDcEQ7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFNmUsSUFBSSxDQUFDOUcsT0FBTyxFQUFFLEdBQUcvWCxJQUFJLEVBQUU7SUFDckIsSUFBSSxDQUFDLENBQUMwaEIsTUFBTSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUzSixPQUFPLEVBQUUvWCxJQUFJLENBQUM7RUFDL0M7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFK1QsS0FBSyxDQUFDZ0UsT0FBTyxFQUFFLEdBQUcvWCxJQUFJLEVBQUU7SUFDdEIsSUFBSSxDQUFDLENBQUMwaEIsTUFBTSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUUzSixPQUFPLEVBQUUvWCxJQUFJLENBQUM7RUFDakQ7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UrZCxNQUFNLENBQUM2RCxTQUFTLEVBQUU3SixPQUFPLEVBQUUsR0FBRy9YLElBQUksRUFBRTtJQUNsQyxJQUFJLENBQUMsQ0FBQzBoQixNQUFNLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRTNKLE9BQU8sRUFBRS9YLElBQUksRUFBRTRoQixTQUFTLENBQUM7RUFDN0Q7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsQ0FBQ0YsTUFBTSxDQUFDRyxVQUFVLEVBQUVDLE1BQU0sRUFBRS9KLE9BQU8sRUFBRS9YLElBQUksRUFBRTRoQixTQUFTLEVBQUU7SUFDcEQsSUFBSSxDQUFDcEwseURBQWlCLEVBQUU7TUFDdEI7SUFDRjtJQUVBLE1BQU13TCxZQUFZLEdBQUcsRUFBRTtJQUN2QixJQUFJaGlCLElBQUksSUFBSUEsSUFBSSxDQUFDbUwsTUFBTSxHQUFHLENBQUMsSUFBSSxPQUFPbkwsSUFBSSxDQUFDaWlCLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtNQUM5RCxLQUFLLE1BQU0sQ0FBQ25YLEdBQUcsRUFBRWhGLEtBQUssQ0FBQyxJQUFJcEUsTUFBTSxDQUFDbWIsT0FBTyxDQUFDN2MsSUFBSSxDQUFDZ1QsR0FBRyxFQUFFLENBQUMsRUFBRTtRQUNyRGdQLFlBQVksQ0FBQzFXLElBQUksQ0FBRSxLQUFJUixHQUFJLEdBQUUsQ0FBQztRQUM5QmtYLFlBQVksQ0FBQzFXLElBQUksQ0FBQ3hGLEtBQUssQ0FBQztNQUMxQjtJQUNGO0lBRUFvYyxPQUFPLENBQUNMLFVBQVUsQ0FBQyxDQUNqQixJQUFJQSxVQUFVLEtBQUssUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDRCxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsRUFDaEQsSUFBRyxJQUFJLENBQUMsQ0FBQ2pFLEVBQUcsS0FBSW1FLE1BQU8sSUFBRy9KLE9BQVEsRUFBQyxFQUNwQyxHQUFHL1gsSUFBSSxFQUNQLEdBQUdnaUIsWUFBWSxDQUNoQjtFQUNIO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5SHdEOztBQUV4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1uQixPQUFPLENBQUM7RUFDbkIsT0FBTyxDQUFDSSxPQUFPLEdBQUczRyxNQUFNLENBQUMyRyxPQUFPLENBQUNrQixJQUFJO0VBRXJDLE9BQU8sQ0FBQ25CLFdBQVcsR0FBRyxTQUFTO0VBRS9CLE9BQU8sQ0FBQ29CLGNBQWMsR0FBRyxlQUFlO0VBRXhDLE9BQU8sQ0FBQ0MsY0FBYyxHQUFHO0lBQ3ZCLENBQUN4QixPQUFPLENBQUMsQ0FBQ3VCLGNBQWMsR0FBRztFQUM3QixDQUFDO0VBRUQsT0FBT3JDLFdBQVcsR0FBR2xHLDJFQUF5QjtFQUU5QyxPQUFPeUksYUFBYSxHQUFHLENBQUM7RUFDeEIsT0FBT0MsYUFBYSxHQUFHLENBQUM7O0VBRXhCO0VBQ0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFLE9BQU8sQ0FBQ0MsS0FBSyxHQUFHLENBQ2Q7SUFBRXBMLElBQUksRUFBRSxXQUFXO0lBQU9xTCxZQUFZLEVBQUUsSUFBSTtJQUF5QkMsU0FBUyxFQUFHNWMsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSztFQUE2RSxDQUFDLEVBQzFMO0lBQUVzUixJQUFJLEVBQUUsVUFBVTtJQUFRcUwsWUFBWSxFQUFFLENBQUM7SUFBNEJDLFNBQVMsRUFBRzVjLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUssUUFBUSxJQUFJQSxLQUFLLElBQUkrYSxPQUFPLENBQUN5QixhQUFhLElBQUl4YyxLQUFLLElBQUkrYSxPQUFPLENBQUMwQjtFQUFjLENBQUMsRUFDMUw7SUFBRW5MLElBQUksRUFBRSxnQkFBZ0I7SUFBRXFMLFlBQVksRUFBRSxLQUFLO0lBQXdCQyxTQUFTLEVBQUc1YyxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsRUFDMUw7SUFBRXNSLElBQUksRUFBRSxlQUFlO0lBQUdxTCxZQUFZLEVBQUUsSUFBSTtJQUF5QkMsU0FBUyxFQUFHNWMsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSztFQUE2RSxDQUFDLEVBQzFMO0lBQUVzUixJQUFJLEVBQUUsYUFBYTtJQUFLcUwsWUFBWSxFQUFFLElBQUk7SUFBeUJDLFNBQVMsRUFBRzVjLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUs7RUFBNkUsQ0FBQyxFQUMxTDtJQUFFc1IsSUFBSSxFQUFFLGFBQWE7SUFBS3FMLFlBQVksRUFBRTVCLE9BQU8sQ0FBQ2QsV0FBVyxDQUFDQyxPQUFPO0lBQUUwQyxTQUFTLEVBQUc1YyxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLLFFBQVEsSUFBSXBFLE1BQU0sQ0FBQ2loQixNQUFNLENBQUM5QixPQUFPLENBQUNkLFdBQVcsQ0FBQyxDQUFDL0IsUUFBUSxDQUFDbFksS0FBSztFQUFnQixDQUFDLEVBQzFMO0lBQUVzUixJQUFJLEVBQUUsVUFBVTtJQUFRcUwsWUFBWSxFQUFFLElBQUk7SUFBeUJDLFNBQVMsRUFBRzVjLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUs7RUFBNkUsQ0FBQyxFQUMxTDtJQUFFc1IsSUFBSSxFQUFFLFdBQVc7SUFBT3FMLFlBQVksRUFBRSxJQUFJO0lBQXlCQyxTQUFTLEVBQUc1YyxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsRUFDMUw7SUFBRXNSLElBQUksRUFBRSxjQUFjO0lBQUlxTCxZQUFZLEVBQUUsS0FBSztJQUF3QkMsU0FBUyxFQUFHNWMsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSztFQUE2RSxDQUFDLENBQzNMO0VBRUQsT0FBTyxDQUFDOGMsYUFBYSxHQUFHO0lBQ3RCLEtBQUssTUFBTTtNQUFFeEwsSUFBSTtNQUFFcUwsWUFBWTtNQUFFQztJQUFVLENBQUMsSUFBSTdCLE9BQU8sQ0FBQyxDQUFDMkIsS0FBSyxFQUFFO01BQzlEM0IsT0FBTyxDQUFDLENBQUN3QixjQUFjLENBQUNqTCxJQUFJLENBQUMsR0FBR3FMLFlBQVk7TUFDNUMvZ0IsTUFBTSxDQUFDZ1AsY0FBYyxDQUFDbVEsT0FBTyxDQUFDN1IsU0FBUyxFQUFFb0ksSUFBSSxFQUFFO1FBQzdDaEIsR0FBRyxDQUFDdFEsS0FBSyxFQUFFO1VBQ1QsSUFBSSxDQUFDNGMsU0FBUyxDQUFDNWMsS0FBSyxDQUFDLEVBQUU7WUFDckIsTUFBTSxJQUFJdEYsS0FBSyxDQUFFLCtCQUE4QjRXLElBQUssWUFBV3RSLEtBQU0sRUFBQyxDQUFDO1VBQ3pFO1VBQ0EsSUFBSUEsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDK2MsS0FBSyxDQUFDekwsSUFBSSxDQUFDLEVBQUU7WUFDL0IsSUFBSSxDQUFDLENBQUN5TCxLQUFLLENBQUN6TCxJQUFJLENBQUMsR0FBR3RSLEtBQUs7WUFDekI7WUFBWSxJQUFJLENBQUMsQ0FBQ2dkLGFBQWEsRUFBRTtVQUNuQztRQUNGLENBQUM7UUFDRHBQLEdBQUcsR0FBRztVQUNKLE9BQU9nUCxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUNHLEtBQUssQ0FBQ3pMLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUN5TCxLQUFLLENBQUN6TCxJQUFJLENBQUMsR0FBR3FMLFlBQVk7UUFDeEU7TUFDRixDQUFDLENBQUM7SUFDSjtFQUNGO0VBQUMsWUFHQzVCLE9BQU8sQ0FBQyxDQUFDK0IsYUFBYSxFQUFFO0VBRzFCO0FBQ0Y7QUFDQTtFQUNFRyxTQUFTLEdBQUcsSUFBSyxNQUFNQSxTQUFTLENBQUM7SUFDL0IsQ0FBQ0MsU0FBUyxHQUFHLEVBQUU7SUFDZjtBQUNKO0FBQ0E7SUFDSUMsV0FBVyxDQUFDakcsUUFBUSxFQUFFO01BQ3BCLElBQUksQ0FBQyxDQUFDZ0csU0FBUyxDQUFDMVgsSUFBSSxDQUFDMFIsUUFBUSxDQUFDO0lBQ2hDO0lBQ0FrRyxLQUFLLEdBQUc7TUFDTixLQUFLLE1BQU1sRyxRQUFRLElBQUksSUFBSSxDQUFDLENBQUNnRyxTQUFTLEVBQUU7UUFDdENoRyxRQUFRLEVBQUU7TUFDWjtJQUNGO0VBQ0YsQ0FBQyxFQUFHO0VBRUosQ0FBQ3RGLE1BQU07RUFDUCxDQUFDbUwsS0FBSzs7RUFFTjtBQUNGO0FBQ0E7RUFDRXhULFdBQVcsQ0FBQ3FJLE1BQU0sRUFBRTtJQUNsQixJQUFJLENBQUMsQ0FBQ0EsTUFBTSxHQUFHQSxNQUFNO0lBQ3JCLElBQUksQ0FBQyxDQUFDbUwsS0FBSyxHQUFHbmhCLE1BQU0sQ0FBQzhOLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXFSLE9BQU8sQ0FBQyxDQUFDd0IsY0FBYyxDQUFDO0lBRXhEeEIsT0FBTyxDQUFDLENBQUNJLE9BQU8sQ0FBQzhCLFNBQVMsQ0FBQ0UsV0FBVyxDQUFDLENBQUNFLE9BQU8sRUFBRUMsUUFBUSxLQUFLO01BQzVELElBQUksQ0FBQyxDQUFDQyxpQkFBaUIsQ0FBQ0YsT0FBTyxFQUFFQyxRQUFRLENBQUM7SUFDNUMsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7QUFDRjtBQUNBO0VBQ0UsTUFBTWhqQixJQUFJLEdBQUc7SUFDWCxNQUFNdWlCLE1BQU0sR0FBRyxNQUFNOUIsT0FBTyxDQUFDLENBQUNJLE9BQU8sQ0FBQ3ZOLEdBQUcsQ0FBQ21OLE9BQU8sQ0FBQyxDQUFDRyxXQUFXLENBQUM7SUFDL0Q7SUFDQTtJQUNBdGYsTUFBTSxDQUFDOE4sTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDcVQsS0FBSyxFQUFFRixNQUFNLENBQUM5QixPQUFPLENBQUMsQ0FBQ0csV0FBVyxDQUFDLENBQUM7SUFDeEQsSUFBSSxDQUFDLENBQUN0SixNQUFNLENBQUNyTCxLQUFLLENBQUMsc0JBQXNCLEVBQUU7TUFBRSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsQ0FBQ3dXO0lBQU0sQ0FBQyxDQUFDO0VBQzlFOztFQUVBO0FBQ0Y7QUFDQTtFQUNFUyxLQUFLLEdBQUc7SUFDTixJQUFJLENBQUMsQ0FBQ1QsS0FBSyxHQUFHbmhCLE1BQU0sQ0FBQzhOLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXFSLE9BQU8sQ0FBQyxDQUFDd0IsY0FBYyxDQUFDO0lBQ3hEO0lBQVksSUFBSSxDQUFDLENBQUNTLGFBQWEsRUFBRTtFQUNuQztFQUVBLE1BQU0sQ0FBQ0EsYUFBYSxHQUFHO0lBQ3JCLElBQUksQ0FBQyxDQUFDRCxLQUFLLENBQUNoQyxPQUFPLENBQUMsQ0FBQ3VCLGNBQWMsQ0FBQyxHQUFHbUIsSUFBSSxDQUFDQyxHQUFHLEVBQUU7SUFDakQsTUFBTWIsTUFBTSxHQUFHO01BQUUsQ0FBQzlCLE9BQU8sQ0FBQyxDQUFDRyxXQUFXLEdBQUcsSUFBSSxDQUFDLENBQUM2QjtJQUFNLENBQUM7SUFDdEQsSUFBSSxDQUFDLENBQUNuTCxNQUFNLENBQUNyTCxLQUFLLENBQUMseUJBQXlCLEVBQUU7TUFBRXNXO0lBQU8sQ0FBQyxDQUFDO0lBQ3pELE1BQU05QixPQUFPLENBQUMsQ0FBQ0ksT0FBTyxDQUFDN0ssR0FBRyxDQUFDdU0sTUFBTSxDQUFDO0VBQ3BDO0VBRUEsQ0FBQ1UsaUJBQWlCLENBQUNGLE9BQU8sRUFBRUMsUUFBUSxFQUFFO0lBQ3BDLElBQUksQ0FBQyxDQUFDMUwsTUFBTSxDQUFDaUssUUFBUSxDQUFDLDhCQUE4QixFQUFFO01BQUV3QixPQUFPO01BQUVDO0lBQVMsQ0FBQyxDQUFDO0lBRTVFLElBQUksQ0FBQzFoQixNQUFNLENBQUMraEIsTUFBTSxDQUFDTixPQUFPLEVBQUV0QyxPQUFPLENBQUMsQ0FBQ0csV0FBVyxDQUFDLEVBQUU7TUFDakQ7SUFDRjtJQUVBLElBQUl0ZixNQUFNLENBQUMraEIsTUFBTSxDQUFDTixPQUFPLENBQUN0QyxPQUFPLENBQUMsQ0FBQ0csV0FBVyxDQUFDLEVBQUUsVUFBVSxDQUFDLEVBQUU7TUFDNUQsTUFBTTBDLFFBQVEsR0FBR1AsT0FBTyxDQUFDdEMsT0FBTyxDQUFDLENBQUNHLFdBQVcsQ0FBQyxDQUFDMEMsUUFBUTtNQUN2RCxJQUFJQSxRQUFRLENBQUM3QyxPQUFPLENBQUMsQ0FBQ3VCLGNBQWMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDUyxLQUFLLENBQUNoQyxPQUFPLENBQUMsQ0FBQ3VCLGNBQWMsQ0FBQyxFQUFFO1FBQzdFLElBQUksQ0FBQyxDQUFDMUssTUFBTSxDQUFDQyxJQUFJLENBQUMsNkRBQTZELEVBQUU7VUFDL0UsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLENBQUNrTDtRQUN6QixDQUFDLENBQUM7UUFDRjtNQUNGOztNQUVBO01BQ0E7TUFDQW5oQixNQUFNLENBQUM4TixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUNxVCxLQUFLLEVBQUVhLFFBQVEsQ0FBQztNQUNwQyxJQUFJLENBQUMsQ0FBQ2hNLE1BQU0sQ0FBQ3JMLEtBQUssQ0FBQyxzRUFBc0UsRUFBRTtRQUN6RixDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsQ0FBQ3dXO01BQ3pCLENBQUMsQ0FBQztJQUNKLENBQUMsTUFBTTtNQUNMOztNQUVBLElBQUksQ0FBQyxDQUFDQSxLQUFLLEdBQUduaEIsTUFBTSxDQUFDOE4sTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFcVIsT0FBTyxDQUFDLENBQUN3QixjQUFjLENBQUM7TUFDeEQsSUFBSSxDQUFDLENBQUMzSyxNQUFNLENBQUNyTCxLQUFLLENBQUMsaUZBQWlGLEVBQUU7UUFDcEcsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLENBQUN3VztNQUN6QixDQUFDLENBQUM7SUFDSjtJQUVBLElBQUksQ0FBQ0UsU0FBUyxDQUFDRyxLQUFLLEVBQUU7RUFDeEI7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsS0E7QUFDQTtBQUNBOztBQUU4QjtBQUNHO0FBQ0E7QUFDRjtBQUNTO0FBQ1Y7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVEs7O0FBRW5DO0FBQ0E7QUFDQTtBQUNPLE1BQU12TSxZQUFZLENBQUM7RUFDeEI7QUFDRjtBQUNBO0VBQ0UsQ0FBQ2dELFFBQVEsR0FBRyxJQUFJbEQsOERBQTBCLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUM7O0VBRS9EO0FBQ0Y7QUFDQTtFQUNFcEgsV0FBVyxDQUFDME4sR0FBRyxFQUFFO0lBQ2YsQ0FBQyxTQUFTLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDbFMsT0FBTyxDQUFFSCxJQUFJLElBQUs7TUFDOUNxUyxHQUFHLENBQUMxYixRQUFRLENBQUM4QixlQUFlLENBQUN0QyxnQkFBZ0IsQ0FDM0M2SixJQUFJLEVBQ0hqQyxDQUFDLElBQU0sSUFBSSxDQUFDLENBQUNrUixRQUFRLEdBQUcsSUFBSWxELDhEQUEwQixDQUFDaE8sQ0FBQyxDQUFDc1IsT0FBTyxFQUFFdFIsQ0FBQyxDQUFDdVIsUUFBUSxFQUFFdlIsQ0FBQyxDQUFDd1IsT0FBTyxDQUFFLENBQzNGO0lBQ0gsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7QUFDRjtBQUNBO0VBQ0UsSUFBSU4sUUFBUSxHQUFHO0lBQ2IsT0FBTyxJQUFJLENBQUMsQ0FBQ0EsUUFBUTtFQUN2QjtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0FDN0JtQzs7QUFFbkM7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNakQsZ0JBQWdCLENBQUM7RUFDNUIsQ0FBQ3NCLElBQUk7RUFFTCxDQUFDbUgsTUFBTSxHQUFHO0lBQ1IvSCxJQUFJLEVBQUUsRUFBRTtJQUNSRSxXQUFXLEVBQUUsS0FBSztJQUNsQnFNLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztJQUNuQkMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0lBQ3RCck0sU0FBUyxFQUFFLE1BQU0sQ0FBQztFQUNwQixDQUFDOztFQUVEO0FBQ0Y7QUFDQTtFQUNFbEksV0FBVyxDQUFDOFAsTUFBTSxFQUFFO0lBQ2xCLElBQUksQ0FBQyxDQUFDQSxNQUFNLEdBQUcxSSxtREFBZSxDQUFDLElBQUksQ0FBQyxDQUFDMEksTUFBTSxFQUFFQSxNQUFNLENBQUM7RUFDdEQ7RUFFQTBFLE9BQU8sR0FBRztJQUNSLElBQUksSUFBSSxDQUFDLENBQUM3TCxJQUFJLEVBQUU7TUFDZHZCLG1EQUFlLENBQUMsbUJBQW1CLEVBQUU7UUFBRXVCLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQ0E7TUFBSyxDQUFDLENBQUM7TUFDMUQ7SUFDRjtJQUVBLElBQUk7TUFDRixJQUFJLENBQUMsQ0FBQ0EsSUFBSSxHQUFHc0MsTUFBTSxDQUFDbUcsT0FBTyxDQUFDb0QsT0FBTyxDQUFDM2pCLFNBQVMsRUFBRTtRQUFFa1gsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDK0gsTUFBTSxDQUFDL0g7TUFBSyxDQUFDLENBQUM7SUFDN0UsQ0FBQyxDQUFDLE9BQU9yRCxLQUFLLEVBQUU7TUFDZDtNQUNBO01BQ0EwQyxtREFBZSxDQUNiLG1IQUFtSCxFQUNuSDtRQUFFMUM7TUFBTSxDQUFDLENBQ1Y7TUFDRDtJQUNGO0lBQ0EwQyxvREFBZ0IsQ0FBQyx3Q0FBd0MsRUFBRTtNQUFFdUIsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDQTtJQUFLLENBQUMsQ0FBQztJQUVoRixJQUFJLENBQUMsQ0FBQ0EsSUFBSSxDQUFDNEwsWUFBWSxDQUFDWCxXQUFXLENBQUVqTCxJQUFJLElBQUssSUFBSSxDQUFDLENBQUM0TCxZQUFZLENBQUM1TCxJQUFJLENBQUMsQ0FBQztJQUN2RSxJQUFJLENBQUMsQ0FBQ0EsSUFBSSxDQUFDVCxTQUFTLENBQUMwTCxXQUFXLENBQUMsQ0FBQ2xMLE9BQU8sRUFBRUMsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDVCxTQUFTLENBQUNRLE9BQU8sRUFBRUMsSUFBSSxDQUFDLENBQUM7SUFFbkYsSUFBSSxDQUFDLENBQUNtSCxNQUFNLENBQUN3RSxTQUFTLEVBQUU7RUFDMUI7RUFFQUcsVUFBVSxHQUFHO0lBQ1gsSUFBSSxJQUFJLENBQUMsQ0FBQzlMLElBQUksRUFBRTtNQUNkLElBQUksQ0FBQyxDQUFDQSxJQUFJLENBQUM4TCxVQUFVLEVBQUU7TUFDdkIsSUFBSSxDQUFDLENBQUM5TCxJQUFJLEdBQUc5WCxTQUFTO01BQ3RCdVcsb0RBQWdCLENBQUMsNkNBQTZDLENBQUM7SUFDakU7RUFDRjtFQUVBc04sU0FBUyxHQUFHO0lBQ1YsSUFBSSxDQUFDRCxVQUFVLEVBQUU7SUFDakIsSUFBSSxDQUFDRCxPQUFPLEVBQUU7RUFDaEI7O0VBRUE7QUFDRjtBQUNBO0VBQ0UsSUFBSTdMLElBQUksR0FBRztJQUNULE9BQU8sSUFBSSxDQUFDLENBQUNBLElBQUk7RUFDbkI7O0VBRUE7QUFDRjtBQUNBO0VBQ0VVLFdBQVcsQ0FBQ1gsT0FBTyxFQUFFO0lBQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQ2lNLGVBQWUsRUFBRSxFQUFFO01BQzVCO0lBQ0Y7SUFFQXZOLG1EQUFlLENBQUMsSUFBSSxDQUFDLENBQUN1QixJQUFJLEVBQUVELE9BQU8sQ0FBQztFQUN0QztFQUVBLENBQUNpTSxlQUFlLEdBQUc7SUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDaE0sSUFBSSxFQUFFO01BQ2YsSUFBSSxJQUFJLENBQUMsQ0FBQ21ILE1BQU0sQ0FBQzdILFdBQVcsRUFBRTtRQUM1QixJQUFJLENBQUN1TSxPQUFPLEVBQUU7TUFDaEIsQ0FBQyxNQUFNO1FBQ0xwTixtREFBZSxDQUFDLDhGQUE4RixDQUFDO01BQ2pIO0lBQ0Y7SUFDQSxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQ3VCLElBQUk7RUFDckI7RUFFQSxDQUFDNEwsWUFBWSxDQUFDNUwsSUFBSSxFQUFFO0lBQ2xCdkIsdURBQW1CLENBQUMsZ0JBQWdCLEVBQUU7TUFBRXVCO0lBQUssQ0FBQyxDQUFDO0lBRS9DLElBQUksQ0FBQyxDQUFDQSxJQUFJLEdBQUc5WCxTQUFTO0lBQ3RCdVcsb0RBQWdCLENBQUMsb0VBQW9FLENBQUM7SUFFdEYsSUFBSSxDQUFDLENBQUMwSSxNQUFNLENBQUN5RSxZQUFZLEVBQUU7RUFDN0I7RUFFQSxDQUFDck0sU0FBUyxDQUFDUSxPQUFPLEVBQUVDLElBQUksRUFBRTtJQUN4QnZCLHVEQUFtQixDQUFDLGFBQWEsRUFBRTtNQUFFc0IsT0FBTztNQUFFQztJQUFLLENBQUMsQ0FBQztJQUVyRCxJQUFJLENBQUMsQ0FBQ21ILE1BQU0sQ0FBQzVILFNBQVMsQ0FBQ1EsT0FBTyxDQUFDO0VBQ2pDO0FBQ0Y7Ozs7Ozs7Ozs7OztBQ3pHQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O1VDQUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7Ozs7V0N0QkE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGlDQUFpQyxXQUFXO1dBQzVDO1dBQ0E7Ozs7O1dDUEE7V0FDQTtXQUNBO1dBQ0E7V0FDQSx5Q0FBeUMsd0NBQXdDO1dBQ2pGO1dBQ0E7V0FDQTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLEdBQUc7V0FDSDtXQUNBO1dBQ0EsQ0FBQzs7Ozs7V0NQRDs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQSx1REFBdUQsaUJBQWlCO1dBQ3hFO1dBQ0EsZ0RBQWdELGFBQWE7V0FDN0Q7Ozs7O1dDTkE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7Ozs7O1VFZkE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL2NvbXBvbmVudC50cyIsIndlYnBhY2s6Ly8vZm91bmRhdGlvbi50cyIsIndlYnBhY2s6Ly8vZXZlbnRzLnRzIiwid2VicGFjazovLy9wb255ZmlsbC50cyIsIndlYnBhY2s6Ly8vY29uc3RhbnRzLnRzIiwid2VicGFjazovLy91dGlsLnRzIiwid2VicGFjazovLy8uLi9ub2RlX21vZHVsZXMvdHNsaWIvdHNsaWIuZXM2LmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19jb25maWcuanMiLCJ3ZWJwYWNrOi8vLy4vYWN0aW9uLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19jb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vbW9kdWxlcy9fX2Z1bmN0aW9ucy5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19fZ2xvYmFscy5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19faG93X3RvX29wZW5fbGluay5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19fbG9nZ2VyLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19vcHRpb25zLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvY29tbW9uLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvbW9kaWZpZXJfa2V5cy5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL3BvcnRfdG9fYmFja2dyb3VuZC5qcyIsIndlYnBhY2s6Ly8vLi9hY3Rpb24uc2Nzcz80OWU3Iiwid2VicGFjazovLy93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly8vd2VicGFjay9ydW50aW1lL2NvbXBhdCBnZXQgZGVmYXVsdCBleHBvcnQiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyIsIndlYnBhY2s6Ly8vd2VicGFjay9ydW50aW1lL2dsb2JhbCIsIndlYnBhY2s6Ly8vd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly8vd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly8vd2VicGFjay9ydW50aW1lL3B1YmxpY1BhdGgiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svc3RhcnR1cCIsIndlYnBhY2s6Ly8vd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsIi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcclxuQ29weXJpZ2h0IChjKSBNaWNyb3NvZnQgQ29ycG9yYXRpb24uXHJcblxyXG5QZXJtaXNzaW9uIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBhbmQvb3IgZGlzdHJpYnV0ZSB0aGlzIHNvZnR3YXJlIGZvciBhbnlcclxucHVycG9zZSB3aXRoIG9yIHdpdGhvdXQgZmVlIGlzIGhlcmVieSBncmFudGVkLlxyXG5cclxuVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiBBTkQgVEhFIEFVVEhPUiBESVNDTEFJTVMgQUxMIFdBUlJBTlRJRVMgV0lUSFxyXG5SRUdBUkQgVE8gVEhJUyBTT0ZUV0FSRSBJTkNMVURJTkcgQUxMIElNUExJRUQgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFlcclxuQU5EIEZJVE5FU1MuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1IgQkUgTElBQkxFIEZPUiBBTlkgU1BFQ0lBTCwgRElSRUNULFxyXG5JTkRJUkVDVCwgT1IgQ09OU0VRVUVOVElBTCBEQU1BR0VTIE9SIEFOWSBEQU1BR0VTIFdIQVRTT0VWRVIgUkVTVUxUSU5HIEZST01cclxuTE9TUyBPRiBVU0UsIERBVEEgT1IgUFJPRklUUywgV0hFVEhFUiBJTiBBTiBBQ1RJT04gT0YgQ09OVFJBQ1QsIE5FR0xJR0VOQ0UgT1JcclxuT1RIRVIgVE9SVElPVVMgQUNUSU9OLCBBUklTSU5HIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFIFVTRSBPUlxyXG5QRVJGT1JNQU5DRSBPRiBUSElTIFNPRlRXQVJFLlxyXG4qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiAqL1xyXG4vKiBnbG9iYWwgUmVmbGVjdCwgUHJvbWlzZSAqL1xyXG5cclxudmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbihkLCBiKSB7XHJcbiAgICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8XHJcbiAgICAgICAgKHsgX19wcm90b19fOiBbXSB9IGluc3RhbmNlb2YgQXJyYXkgJiYgZnVuY3Rpb24gKGQsIGIpIHsgZC5fX3Byb3RvX18gPSBiOyB9KSB8fFxyXG4gICAgICAgIGZ1bmN0aW9uIChkLCBiKSB7IGZvciAodmFyIHAgaW4gYikgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChiLCBwKSkgZFtwXSA9IGJbcF07IH07XHJcbiAgICByZXR1cm4gZXh0ZW5kU3RhdGljcyhkLCBiKTtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2V4dGVuZHMoZCwgYikge1xyXG4gICAgaWYgKHR5cGVvZiBiICE9PSBcImZ1bmN0aW9uXCIgJiYgYiAhPT0gbnVsbClcclxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2xhc3MgZXh0ZW5kcyB2YWx1ZSBcIiArIFN0cmluZyhiKSArIFwiIGlzIG5vdCBhIGNvbnN0cnVjdG9yIG9yIG51bGxcIik7XHJcbiAgICBleHRlbmRTdGF0aWNzKGQsIGIpO1xyXG4gICAgZnVuY3Rpb24gX18oKSB7IHRoaXMuY29uc3RydWN0b3IgPSBkOyB9XHJcbiAgICBkLnByb3RvdHlwZSA9IGIgPT09IG51bGwgPyBPYmplY3QuY3JlYXRlKGIpIDogKF9fLnByb3RvdHlwZSA9IGIucHJvdG90eXBlLCBuZXcgX18oKSk7XHJcbn1cclxuXHJcbmV4cG9ydCB2YXIgX19hc3NpZ24gPSBmdW5jdGlvbigpIHtcclxuICAgIF9fYXNzaWduID0gT2JqZWN0LmFzc2lnbiB8fCBmdW5jdGlvbiBfX2Fzc2lnbih0KSB7XHJcbiAgICAgICAgZm9yICh2YXIgcywgaSA9IDEsIG4gPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XHJcbiAgICAgICAgICAgIHMgPSBhcmd1bWVudHNbaV07XHJcbiAgICAgICAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiB0O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9fYXNzaWduLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3Jlc3QocywgZSkge1xyXG4gICAgdmFyIHQgPSB7fTtcclxuICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKVxyXG4gICAgICAgIHRbcF0gPSBzW3BdO1xyXG4gICAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKVxyXG4gICAgICAgIGZvciAodmFyIGkgPSAwLCBwID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhzKTsgaSA8IHAubGVuZ3RoOyBpKyspIHtcclxuICAgICAgICAgICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKVxyXG4gICAgICAgICAgICAgICAgdFtwW2ldXSA9IHNbcFtpXV07XHJcbiAgICAgICAgfVxyXG4gICAgcmV0dXJuIHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2RlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKSB7XHJcbiAgICB2YXIgYyA9IGFyZ3VtZW50cy5sZW5ndGgsIHIgPSBjIDwgMyA/IHRhcmdldCA6IGRlc2MgPT09IG51bGwgPyBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0YXJnZXQsIGtleSkgOiBkZXNjLCBkO1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0LmRlY29yYXRlID09PSBcImZ1bmN0aW9uXCIpIHIgPSBSZWZsZWN0LmRlY29yYXRlKGRlY29yYXRvcnMsIHRhcmdldCwga2V5LCBkZXNjKTtcclxuICAgIGVsc2UgZm9yICh2YXIgaSA9IGRlY29yYXRvcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIGlmIChkID0gZGVjb3JhdG9yc1tpXSkgciA9IChjIDwgMyA/IGQocikgOiBjID4gMyA/IGQodGFyZ2V0LCBrZXksIHIpIDogZCh0YXJnZXQsIGtleSkpIHx8IHI7XHJcbiAgICByZXR1cm4gYyA+IDMgJiYgciAmJiBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHIpLCByO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19wYXJhbShwYXJhbUluZGV4LCBkZWNvcmF0b3IpIHtcclxuICAgIHJldHVybiBmdW5jdGlvbiAodGFyZ2V0LCBrZXkpIHsgZGVjb3JhdG9yKHRhcmdldCwga2V5LCBwYXJhbUluZGV4KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tZXRhZGF0YShtZXRhZGF0YUtleSwgbWV0YWRhdGFWYWx1ZSkge1xyXG4gICAgaWYgKHR5cGVvZiBSZWZsZWN0ID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiBSZWZsZWN0Lm1ldGFkYXRhID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBSZWZsZWN0Lm1ldGFkYXRhKG1ldGFkYXRhS2V5LCBtZXRhZGF0YVZhbHVlKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXRlcih0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2dlbmVyYXRvcih0aGlzQXJnLCBib2R5KSB7XHJcbiAgICB2YXIgXyA9IHsgbGFiZWw6IDAsIHNlbnQ6IGZ1bmN0aW9uKCkgeyBpZiAodFswXSAmIDEpIHRocm93IHRbMV07IHJldHVybiB0WzFdOyB9LCB0cnlzOiBbXSwgb3BzOiBbXSB9LCBmLCB5LCB0LCBnO1xyXG4gICAgcmV0dXJuIGcgPSB7IG5leHQ6IHZlcmIoMCksIFwidGhyb3dcIjogdmVyYigxKSwgXCJyZXR1cm5cIjogdmVyYigyKSB9LCB0eXBlb2YgU3ltYm9sID09PSBcImZ1bmN0aW9uXCIgJiYgKGdbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkgeyByZXR1cm4gdGhpczsgfSksIGc7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgcmV0dXJuIGZ1bmN0aW9uICh2KSB7IHJldHVybiBzdGVwKFtuLCB2XSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAob3ApIHtcclxuICAgICAgICBpZiAoZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkdlbmVyYXRvciBpcyBhbHJlYWR5IGV4ZWN1dGluZy5cIik7XHJcbiAgICAgICAgd2hpbGUgKGcgJiYgKGcgPSAwLCBvcFswXSAmJiAoXyA9IDApKSwgXykgdHJ5IHtcclxuICAgICAgICAgICAgaWYgKGYgPSAxLCB5ICYmICh0ID0gb3BbMF0gJiAyID8geVtcInJldHVyblwiXSA6IG9wWzBdID8geVtcInRocm93XCJdIHx8ICgodCA9IHlbXCJyZXR1cm5cIl0pICYmIHQuY2FsbCh5KSwgMCkgOiB5Lm5leHQpICYmICEodCA9IHQuY2FsbCh5LCBvcFsxXSkpLmRvbmUpIHJldHVybiB0O1xyXG4gICAgICAgICAgICBpZiAoeSA9IDAsIHQpIG9wID0gW29wWzBdICYgMiwgdC52YWx1ZV07XHJcbiAgICAgICAgICAgIHN3aXRjaCAob3BbMF0pIHtcclxuICAgICAgICAgICAgICAgIGNhc2UgMDogY2FzZSAxOiB0ID0gb3A7IGJyZWFrO1xyXG4gICAgICAgICAgICAgICAgY2FzZSA0OiBfLmxhYmVsKys7IHJldHVybiB7IHZhbHVlOiBvcFsxXSwgZG9uZTogZmFsc2UgfTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNTogXy5sYWJlbCsrOyB5ID0gb3BbMV07IG9wID0gWzBdOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGNhc2UgNzogb3AgPSBfLm9wcy5wb3AoKTsgXy50cnlzLnBvcCgpOyBjb250aW51ZTtcclxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKCEodCA9IF8udHJ5cywgdCA9IHQubGVuZ3RoID4gMCAmJiB0W3QubGVuZ3RoIC0gMV0pICYmIChvcFswXSA9PT0gNiB8fCBvcFswXSA9PT0gMikpIHsgXyA9IDA7IGNvbnRpbnVlOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKG9wWzBdID09PSAzICYmICghdCB8fCAob3BbMV0gPiB0WzBdICYmIG9wWzFdIDwgdFszXSkpKSB7IF8ubGFiZWwgPSBvcFsxXTsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAob3BbMF0gPT09IDYgJiYgXy5sYWJlbCA8IHRbMV0pIHsgXy5sYWJlbCA9IHRbMV07IHQgPSBvcDsgYnJlYWs7IH1cclxuICAgICAgICAgICAgICAgICAgICBpZiAodCAmJiBfLmxhYmVsIDwgdFsyXSkgeyBfLmxhYmVsID0gdFsyXTsgXy5vcHMucHVzaChvcCk7IGJyZWFrOyB9XHJcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRbMl0pIF8ub3BzLnBvcCgpO1xyXG4gICAgICAgICAgICAgICAgICAgIF8udHJ5cy5wb3AoKTsgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgb3AgPSBib2R5LmNhbGwodGhpc0FyZywgXyk7XHJcbiAgICAgICAgfSBjYXRjaCAoZSkgeyBvcCA9IFs2LCBlXTsgeSA9IDA7IH0gZmluYWxseSB7IGYgPSB0ID0gMDsgfVxyXG4gICAgICAgIGlmIChvcFswXSAmIDUpIHRocm93IG9wWzFdOyByZXR1cm4geyB2YWx1ZTogb3BbMF0gPyBvcFsxXSA6IHZvaWQgMCwgZG9uZTogdHJ1ZSB9O1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgdmFyIF9fY3JlYXRlQmluZGluZyA9IE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcclxuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XHJcbiAgICB2YXIgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IobSwgayk7XHJcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xyXG4gICAgICAgIGRlc2MgPSB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24oKSB7IHJldHVybiBtW2tdOyB9IH07XHJcbiAgICB9XHJcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgazIsIGRlc2MpO1xyXG59KSA6IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xyXG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcclxuICAgIG9bazJdID0gbVtrXTtcclxufSk7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19leHBvcnRTdGFyKG0sIG8pIHtcclxuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKHAgIT09IFwiZGVmYXVsdFwiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwobywgcCkpIF9fY3JlYXRlQmluZGluZyhvLCBtLCBwKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fdmFsdWVzKG8pIHtcclxuICAgIHZhciBzID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIFN5bWJvbC5pdGVyYXRvciwgbSA9IHMgJiYgb1tzXSwgaSA9IDA7XHJcbiAgICBpZiAobSkgcmV0dXJuIG0uY2FsbChvKTtcclxuICAgIGlmIChvICYmIHR5cGVvZiBvLmxlbmd0aCA9PT0gXCJudW1iZXJcIikgcmV0dXJuIHtcclxuICAgICAgICBuZXh0OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgICAgIGlmIChvICYmIGkgPj0gby5sZW5ndGgpIG8gPSB2b2lkIDA7XHJcbiAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiBvICYmIG9baSsrXSwgZG9uZTogIW8gfTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihzID8gXCJPYmplY3QgaXMgbm90IGl0ZXJhYmxlLlwiIDogXCJTeW1ib2wuaXRlcmF0b3IgaXMgbm90IGRlZmluZWQuXCIpO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19yZWFkKG8sIG4pIHtcclxuICAgIHZhciBtID0gdHlwZW9mIFN5bWJvbCA9PT0gXCJmdW5jdGlvblwiICYmIG9bU3ltYm9sLml0ZXJhdG9yXTtcclxuICAgIGlmICghbSkgcmV0dXJuIG87XHJcbiAgICB2YXIgaSA9IG0uY2FsbChvKSwgciwgYXIgPSBbXSwgZTtcclxuICAgIHRyeSB7XHJcbiAgICAgICAgd2hpbGUgKChuID09PSB2b2lkIDAgfHwgbi0tID4gMCkgJiYgIShyID0gaS5uZXh0KCkpLmRvbmUpIGFyLnB1c2goci52YWx1ZSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaCAoZXJyb3IpIHsgZSA9IHsgZXJyb3I6IGVycm9yIH07IH1cclxuICAgIGZpbmFsbHkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGlmIChyICYmICFyLmRvbmUgJiYgKG0gPSBpW1wicmV0dXJuXCJdKSkgbS5jYWxsKGkpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBmaW5hbGx5IHsgaWYgKGUpIHRocm93IGUuZXJyb3I7IH1cclxuICAgIH1cclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuLyoqIEBkZXByZWNhdGVkICovXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZCgpIHtcclxuICAgIGZvciAodmFyIGFyID0gW10sIGkgPSAwOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKVxyXG4gICAgICAgIGFyID0gYXIuY29uY2F0KF9fcmVhZChhcmd1bWVudHNbaV0pKTtcclxuICAgIHJldHVybiBhcjtcclxufVxyXG5cclxuLyoqIEBkZXByZWNhdGVkICovXHJcbmV4cG9ydCBmdW5jdGlvbiBfX3NwcmVhZEFycmF5cygpIHtcclxuICAgIGZvciAodmFyIHMgPSAwLCBpID0gMCwgaWwgPSBhcmd1bWVudHMubGVuZ3RoOyBpIDwgaWw7IGkrKykgcyArPSBhcmd1bWVudHNbaV0ubGVuZ3RoO1xyXG4gICAgZm9yICh2YXIgciA9IEFycmF5KHMpLCBrID0gMCwgaSA9IDA7IGkgPCBpbDsgaSsrKVxyXG4gICAgICAgIGZvciAodmFyIGEgPSBhcmd1bWVudHNbaV0sIGogPSAwLCBqbCA9IGEubGVuZ3RoOyBqIDwgamw7IGorKywgaysrKVxyXG4gICAgICAgICAgICByW2tdID0gYVtqXTtcclxuICAgIHJldHVybiByO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19zcHJlYWRBcnJheSh0bywgZnJvbSwgcGFjaykge1xyXG4gICAgaWYgKHBhY2sgfHwgYXJndW1lbnRzLmxlbmd0aCA9PT0gMikgZm9yICh2YXIgaSA9IDAsIGwgPSBmcm9tLmxlbmd0aCwgYXI7IGkgPCBsOyBpKyspIHtcclxuICAgICAgICBpZiAoYXIgfHwgIShpIGluIGZyb20pKSB7XHJcbiAgICAgICAgICAgIGlmICghYXIpIGFyID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoZnJvbSwgMCwgaSk7XHJcbiAgICAgICAgICAgIGFyW2ldID0gZnJvbVtpXTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdG8uY29uY2F0KGFyIHx8IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20pKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fYXdhaXQodikge1xyXG4gICAgcmV0dXJuIHRoaXMgaW5zdGFuY2VvZiBfX2F3YWl0ID8gKHRoaXMudiA9IHYsIHRoaXMpIDogbmV3IF9fYXdhaXQodik7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jR2VuZXJhdG9yKHRoaXNBcmcsIF9hcmd1bWVudHMsIGdlbmVyYXRvcikge1xyXG4gICAgaWYgKCFTeW1ib2wuYXN5bmNJdGVyYXRvcikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlN5bWJvbC5hc3luY0l0ZXJhdG9yIGlzIG5vdCBkZWZpbmVkLlwiKTtcclxuICAgIHZhciBnID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pLCBpLCBxID0gW107XHJcbiAgICByZXR1cm4gaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4pIHsgaWYgKGdbbl0pIGlbbl0gPSBmdW5jdGlvbiAodikgeyByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24gKGEsIGIpIHsgcS5wdXNoKFtuLCB2LCBhLCBiXSkgPiAxIHx8IHJlc3VtZShuLCB2KTsgfSk7IH07IH1cclxuICAgIGZ1bmN0aW9uIHJlc3VtZShuLCB2KSB7IHRyeSB7IHN0ZXAoZ1tuXSh2KSk7IH0gY2F0Y2ggKGUpIHsgc2V0dGxlKHFbMF1bM10sIGUpOyB9IH1cclxuICAgIGZ1bmN0aW9uIHN0ZXAocikgeyByLnZhbHVlIGluc3RhbmNlb2YgX19hd2FpdCA/IFByb21pc2UucmVzb2x2ZShyLnZhbHVlLnYpLnRoZW4oZnVsZmlsbCwgcmVqZWN0KSA6IHNldHRsZShxWzBdWzJdLCByKTsgfVxyXG4gICAgZnVuY3Rpb24gZnVsZmlsbCh2YWx1ZSkgeyByZXN1bWUoXCJuZXh0XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gcmVqZWN0KHZhbHVlKSB7IHJlc3VtZShcInRocm93XCIsIHZhbHVlKTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKGYsIHYpIHsgaWYgKGYodiksIHEuc2hpZnQoKSwgcS5sZW5ndGgpIHJlc3VtZShxWzBdWzBdLCBxWzBdWzFdKTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19hc3luY0RlbGVnYXRvcihvKSB7XHJcbiAgICB2YXIgaSwgcDtcclxuICAgIHJldHVybiBpID0ge30sIHZlcmIoXCJuZXh0XCIpLCB2ZXJiKFwidGhyb3dcIiwgZnVuY3Rpb24gKGUpIHsgdGhyb3cgZTsgfSksIHZlcmIoXCJyZXR1cm5cIiksIGlbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGk7XHJcbiAgICBmdW5jdGlvbiB2ZXJiKG4sIGYpIHsgaVtuXSA9IG9bbl0gPyBmdW5jdGlvbiAodikgeyByZXR1cm4gKHAgPSAhcCkgPyB7IHZhbHVlOiBfX2F3YWl0KG9bbl0odikpLCBkb25lOiBuID09PSBcInJldHVyblwiIH0gOiBmID8gZih2KSA6IHY7IH0gOiBmOyB9XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2FzeW5jVmFsdWVzKG8pIHtcclxuICAgIGlmICghU3ltYm9sLmFzeW5jSXRlcmF0b3IpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJTeW1ib2wuYXN5bmNJdGVyYXRvciBpcyBub3QgZGVmaW5lZC5cIik7XHJcbiAgICB2YXIgbSA9IG9bU3ltYm9sLmFzeW5jSXRlcmF0b3JdLCBpO1xyXG4gICAgcmV0dXJuIG0gPyBtLmNhbGwobykgOiAobyA9IHR5cGVvZiBfX3ZhbHVlcyA9PT0gXCJmdW5jdGlvblwiID8gX192YWx1ZXMobykgOiBvW1N5bWJvbC5pdGVyYXRvcl0oKSwgaSA9IHt9LCB2ZXJiKFwibmV4dFwiKSwgdmVyYihcInRocm93XCIpLCB2ZXJiKFwicmV0dXJuXCIpLCBpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9IGZ1bmN0aW9uICgpIHsgcmV0dXJuIHRoaXM7IH0sIGkpO1xyXG4gICAgZnVuY3Rpb24gdmVyYihuKSB7IGlbbl0gPSBvW25dICYmIGZ1bmN0aW9uICh2KSB7IHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7IHYgPSBvW25dKHYpLCBzZXR0bGUocmVzb2x2ZSwgcmVqZWN0LCB2LmRvbmUsIHYudmFsdWUpOyB9KTsgfTsgfVxyXG4gICAgZnVuY3Rpb24gc2V0dGxlKHJlc29sdmUsIHJlamVjdCwgZCwgdikgeyBQcm9taXNlLnJlc29sdmUodikudGhlbihmdW5jdGlvbih2KSB7IHJlc29sdmUoeyB2YWx1ZTogdiwgZG9uZTogZCB9KTsgfSwgcmVqZWN0KTsgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19tYWtlVGVtcGxhdGVPYmplY3QoY29va2VkLCByYXcpIHtcclxuICAgIGlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNvb2tlZCwgXCJyYXdcIiwgeyB2YWx1ZTogcmF3IH0pOyB9IGVsc2UgeyBjb29rZWQucmF3ID0gcmF3OyB9XHJcbiAgICByZXR1cm4gY29va2VkO1xyXG59O1xyXG5cclxudmFyIF9fc2V0TW9kdWxlRGVmYXVsdCA9IE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgdikge1xyXG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIFwiZGVmYXVsdFwiLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2IH0pO1xyXG59KSA6IGZ1bmN0aW9uKG8sIHYpIHtcclxuICAgIG9bXCJkZWZhdWx0XCJdID0gdjtcclxufTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2ltcG9ydFN0YXIobW9kKSB7XHJcbiAgICBpZiAobW9kICYmIG1vZC5fX2VzTW9kdWxlKSByZXR1cm4gbW9kO1xyXG4gICAgdmFyIHJlc3VsdCA9IHt9O1xyXG4gICAgaWYgKG1vZCAhPSBudWxsKSBmb3IgKHZhciBrIGluIG1vZCkgaWYgKGsgIT09IFwiZGVmYXVsdFwiICYmIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChtb2QsIGspKSBfX2NyZWF0ZUJpbmRpbmcocmVzdWx0LCBtb2QsIGspO1xyXG4gICAgX19zZXRNb2R1bGVEZWZhdWx0KHJlc3VsdCwgbW9kKTtcclxuICAgIHJldHVybiByZXN1bHQ7XHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBfX2ltcG9ydERlZmF1bHQobW9kKSB7XHJcbiAgICByZXR1cm4gKG1vZCAmJiBtb2QuX19lc01vZHVsZSkgPyBtb2QgOiB7IGRlZmF1bHQ6IG1vZCB9O1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19jbGFzc1ByaXZhdGVGaWVsZEdldChyZWNlaXZlciwgc3RhdGUsIGtpbmQsIGYpIHtcclxuICAgIGlmIChraW5kID09PSBcImFcIiAmJiAhZikgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgYWNjZXNzb3Igd2FzIGRlZmluZWQgd2l0aG91dCBhIGdldHRlclwiKTtcclxuICAgIGlmICh0eXBlb2Ygc3RhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHJlY2VpdmVyICE9PSBzdGF0ZSB8fCAhZiA6ICFzdGF0ZS5oYXMocmVjZWl2ZXIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHJlYWQgcHJpdmF0ZSBtZW1iZXIgZnJvbSBhbiBvYmplY3Qgd2hvc2UgY2xhc3MgZGlkIG5vdCBkZWNsYXJlIGl0XCIpO1xyXG4gICAgcmV0dXJuIGtpbmQgPT09IFwibVwiID8gZiA6IGtpbmQgPT09IFwiYVwiID8gZi5jYWxsKHJlY2VpdmVyKSA6IGYgPyBmLnZhbHVlIDogc3RhdGUuZ2V0KHJlY2VpdmVyKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIF9fY2xhc3NQcml2YXRlRmllbGRTZXQocmVjZWl2ZXIsIHN0YXRlLCB2YWx1ZSwga2luZCwgZikge1xyXG4gICAgaWYgKGtpbmQgPT09IFwibVwiKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBtZXRob2QgaXMgbm90IHdyaXRhYmxlXCIpO1xyXG4gICAgaWYgKGtpbmQgPT09IFwiYVwiICYmICFmKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiUHJpdmF0ZSBhY2Nlc3NvciB3YXMgZGVmaW5lZCB3aXRob3V0IGEgc2V0dGVyXCIpO1xyXG4gICAgaWYgKHR5cGVvZiBzdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gcmVjZWl2ZXIgIT09IHN0YXRlIHx8ICFmIDogIXN0YXRlLmhhcyhyZWNlaXZlcikpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3Qgd3JpdGUgcHJpdmF0ZSBtZW1iZXIgdG8gYW4gb2JqZWN0IHdob3NlIGNsYXNzIGRpZCBub3QgZGVjbGFyZSBpdFwiKTtcclxuICAgIHJldHVybiAoa2luZCA9PT0gXCJhXCIgPyBmLmNhbGwocmVjZWl2ZXIsIHZhbHVlKSA6IGYgPyBmLnZhbHVlID0gdmFsdWUgOiBzdGF0ZS5zZXQocmVjZWl2ZXIsIHZhbHVlKSksIHZhbHVlO1xyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gX19jbGFzc1ByaXZhdGVGaWVsZEluKHN0YXRlLCByZWNlaXZlcikge1xyXG4gICAgaWYgKHJlY2VpdmVyID09PSBudWxsIHx8ICh0eXBlb2YgcmVjZWl2ZXIgIT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHJlY2VpdmVyICE9PSBcImZ1bmN0aW9uXCIpKSB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IHVzZSAnaW4nIG9wZXJhdG9yIG9uIG5vbi1vYmplY3RcIik7XHJcbiAgICByZXR1cm4gdHlwZW9mIHN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyByZWNlaXZlciA9PT0gc3RhdGUgOiBzdGF0ZS5oYXMocmVjZWl2ZXIpO1xyXG59XHJcbiIsIm1vZHVsZS5leHBvcnRzID0geyBjb25maWc6IHtcImxvZ0VuYWJsZWRcIjp0cnVlLFwicHJpdmF0ZU9wdGlvbkVuYWJsZWRcIjp0cnVlLFwiaXNNYWNcIjpmYWxzZX0gfTsiLCJcInVzZSBzdHJpY3RcIjtcblxuaW1wb3J0ICogYXMgcXFzIGZyb20gXCIuL21vZHVsZXMvY29tbW9uLmpzXCI7XG5pbXBvcnQgeyBQb3J0VG9CYWNrZ3JvdW5kIH0gZnJvbSBcIi4vbW9kdWxlcy9wb3J0X3RvX2JhY2tncm91bmQuanNcIjtcbmltcG9ydCB7IE1vZGlmaWVyS2V5cyB9IGZyb20gXCIuL21vZHVsZXMvbW9kaWZpZXJfa2V5cy5qc1wiO1xuXG5pbXBvcnQgeyBNRENSaXBwbGUgfSBmcm9tIFwiQG1hdGVyaWFsL3JpcHBsZVwiO1xuXG4oYXN5bmMgZnVuY3Rpb24gbWFpbigpIHtcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIEluaXRpYWxpemUgY29tbW9uIG1vZHVsZXNcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgYXdhaXQgcXFzLmluaXQocXFzLlNjcmlwdElkLkFDVElPTik7XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIENvbnN0YW50c1xuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBjb25zdCBNRVNTQUdFX0hBTkRMRVJTID0ge1xuICAgIFtxcXMuTWVzc2FnZVR5cGUuTk9USUZZX1NFTEVDVElPTl06IG9uTm90aWZ5U2VsZWN0aW9uLFxuICB9O1xuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBWYXJpYWJsZXNcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgY29uc3QgcG9ydFRvQmFja2dyb3VuZCA9IG5ldyBQb3J0VG9CYWNrZ3JvdW5kKHsgbmFtZTogZG9jdW1lbnQuVVJMLCBhdXRvQ29ubmVjdDogdHJ1ZSwgb25NZXNzYWdlIH0pO1xuXG4gIGNvbnN0IHBhcmVudFRhYiA9IGF3YWl0IHFxcy5nZXRBY3RpdmVUYWIoKTtcbiAgcXFzLmxvZ2dlci5pbmZvKFwiR2V0IGFjdGl2ZSB0YWIgYXMgdGhlIHBhcmVudCBvbmVcIiwgeyBwYXJlbnRUYWIgfSk7XG5cbiAgY29uc3QgbW9kaWZpZXJLZXlzID0gbmV3IE1vZGlmaWVyS2V5cyh3aW5kb3cpO1xuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBTdGFydHVwIE9wZXJhdGlvbnNcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgcXFzLmFkZERPTUNvbnRlbnRMb2FkZWRFdmVudExpc3RlbmVyKHdpbmRvdywgb25ET01Db250ZW50TG9hZGVkKTtcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gRXZlbnQgTGlzdGVuZXJzIChCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyKVxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBmdW5jdGlvbiBvbk1lc3NhZ2UobWVzc2FnZSwgcG9ydCkge1xuICAgIE1FU1NBR0VfSEFORExFUlNbbWVzc2FnZS50eXBlXShtZXNzYWdlLCBwb3J0KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uTm90aWZ5U2VsZWN0aW9uKG1lc3NhZ2UsIF9wb3J0KSB7XG4gICAgaWYgKG1lc3NhZ2Uuc2VsZWN0aW9uKSB7XG4gICAgICBjb25zdCBub3JtYWxpemVkU2VsZWN0aW9uVGV4dCA9IHFxcy5ub3JtYWxpemVTZWxlY3Rpb25UZXh0KG1lc3NhZ2Uuc2VsZWN0aW9uLnRleHQpO1xuICAgICAgaWYgKHFxcy5pc05vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0VmFsaWQobm9ybWFsaXplZFNlbGVjdGlvblRleHQpKSB7XG4gICAgICAgIGNvbnN0IHRleHRGaWVsZCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicXFzLXNlYXJjaC1iYXItdGV4dFwiKTtcbiAgICAgICAgdGV4dEZpZWxkLnZhbHVlID0gbm9ybWFsaXplZFNlbGVjdGlvblRleHQ7XG4gICAgICAgIHRleHRGaWVsZC5zZXRTZWxlY3Rpb25SYW5nZSgwLCB0ZXh0RmllbGQudmFsdWUubGVuZ3RoLCBcImZvcndhcmRcIik7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIEV2ZW50IExpc3RlbmVycyAoRE9NKVxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBhc3luYyBmdW5jdGlvbiBvbkRPTUNvbnRlbnRMb2FkZWQoKSB7XG4gICAgcG9ydFRvQmFja2dyb3VuZC5wb3N0TWVzc2FnZSh7IHR5cGU6IHFxcy5NZXNzYWdlVHlwZS5HRVRfU0VMRUNUSU9OLCB0YWI6IHBhcmVudFRhYiB9KTtcblxuICAgIHFxcy5pbmplY3RJMThOTWVzc2FnZXNJbkh0bWwoZG9jdW1lbnQpO1xuXG4gICAgYXdhaXQgZmlsbFNob3J0Y3V0c1RhYmxlKCk7XG5cbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInFxcy1zZWFyY2gtZm9ybVwiKS5hZGRFdmVudExpc3RlbmVyKFwic3VibWl0XCIsIG9uU2VhcmNoRm9ybVN1Ym1pdCk7XG5cbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInFxcy1zaG9ydGN1dHMtc2V0dGluZ3MtbGlua1wiKS5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgb25TaG9ydGN1dHNTZXR0aW5nc0xpbmtDbGljayk7XG5cbiAgICBjb25zdCBvcHRpb25zUGFnZUJ1dHRvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicXFzLW9wdGlvbnMtcGFnZVwiKTtcbiAgICBvcHRpb25zUGFnZUJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgb25PcHRpb25zUGFnZUJ1dHRvbkNsaWNrKTtcbiAgICBjb25zdCBvcHRpb25zUGFnZUJ1dHRvblJpcHBsZSA9IG5ldyBNRENSaXBwbGUob3B0aW9uc1BhZ2VCdXR0b24pO1xuICAgIG9wdGlvbnNQYWdlQnV0dG9uUmlwcGxlLnVuYm91bmRlZCA9IHRydWU7XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBvblNlYXJjaEZvcm1TdWJtaXQoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCBub3JtYWxpemVkU2VsZWN0aW9uVGV4dCA9IHFxcy5ub3JtYWxpemVTZWxlY3Rpb25UZXh0KFxuICAgICAgcXFzLmZpbHRlclNlbGVjdGlvblRleHQoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJxcXMtc2VhcmNoLWJhci10ZXh0XCIpLnZhbHVlKVxuICAgICk7XG4gICAgaWYgKHFxcy5pc05vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0VmFsaWQobm9ybWFsaXplZFNlbGVjdGlvblRleHQpKSB7XG4gICAgICBpZiAocXFzLm9wdGlvbnMuYXV0b0NvcHkpIHtcbiAgICAgICAgd2luZG93Lm5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0KTtcbiAgICAgIH1cbiAgICAgIGF3YWl0IHFxcy5kb1F1b3RlZFNlYXJjaChwYXJlbnRUYWIsIG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0LCBtb2RpZmllcktleXMua2V5U3RhdGUpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIG9uU2hvcnRjdXRzU2V0dGluZ3NMaW5rQ2xpY2soZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBhd2FpdCBxcXMub3BlblNob3J0Y3V0c1NldHRpbmdzKFxuICAgICAgcGFyZW50VGFiLFxuICAgICAgbmV3IHFxcy5Ib3dUb09wZW5MaW5rLktleVN0YXRlKGUuY3RybEtleSwgZS5zaGlmdEtleSwgZS5tZXRhS2V5KSxcbiAgICAgIHFxcy5Ib3dUb09wZW5MaW5rLk5FV19UQUJfQUNUSVZFXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIG9uT3B0aW9uc1BhZ2VCdXR0b25DbGljayhlKSB7XG4gICAgYXdhaXQgcXFzLm9wZW5PcHRpb25zUGFnZShcbiAgICAgIHBhcmVudFRhYixcbiAgICAgIG5ldyBxcXMuSG93VG9PcGVuTGluay5LZXlTdGF0ZShlLmN0cmxLZXksIGUuc2hpZnRLZXksIGUubWV0YUtleSksXG4gICAgICBxcXMuSG93VG9PcGVuTGluay5ORVdfVEFCX0FDVElWRVxuICAgICk7XG4gIH1cblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gRnVuY3Rpb25zXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gIGFzeW5jIGZ1bmN0aW9uIGZpbGxTaG9ydGN1dHNUYWJsZSgpIHtcbiAgICBjb25zdCBkaXZTaG9ydGN1dHMgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChcInFxcy1zaG9ydGN1dHNcIik7XG4gICAgY29uc3QgY29tbWFuZHMgPSBhd2FpdCBjaHJvbWUuY29tbWFuZHMuZ2V0QWxsKCk7XG4gICAgZm9yIChjb25zdCB7IG5hbWUsIHNob3J0Y3V0LCBkZXNjcmlwdGlvbiB9IG9mIGNvbW1hbmRzKSB7XG4gICAgICBjb25zdCBkaXZTaG9ydGN1dEtleSA9IGRpdlNob3J0Y3V0cy5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpKTtcbiAgICAgIGRpdlNob3J0Y3V0S2V5LmRhdGFzZXQuc2hvcnRjdXROYW1lID0gbmFtZTtcbiAgICAgIGRpdlNob3J0Y3V0S2V5LmNsYXNzTGlzdC5hZGQoXCJzaG9ydGN1dHNfX2tleVwiKTtcbiAgICAgIGNvbnN0IHNwYW5TaG9ydGN1dEtleSA9IGRpdlNob3J0Y3V0S2V5LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpKTtcbiAgICAgIGlmIChzaG9ydGN1dCkge1xuICAgICAgICBzcGFuU2hvcnRjdXRLZXkuaW5uZXJUZXh0ID0gc2hvcnRjdXQucmVwbGFjZUFsbCgvXFwrL2csIFwiICsgXCIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZGl2U2hvcnRjdXRLZXkuY2xhc3NMaXN0LmFkZChcInNob3J0Y3V0c19fa2V5LS1ub3Qtc2V0XCIpO1xuICAgICAgICBzcGFuU2hvcnRjdXRLZXkuaW5uZXJUZXh0ID0gY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShcIm1zZ19hY3Rpb25fc2hvcnRjdXRfa2V5X25vdF9zZXRcIik7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGRpdlNob3J0Y3V0RGVzY3JpcHRpb24gPSBkaXZTaG9ydGN1dHMuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSk7XG4gICAgICBkaXZTaG9ydGN1dERlc2NyaXB0aW9uLmRhdGFzZXQuc2hvcnRjdXROYW1lID0gbmFtZTtcbiAgICAgIGRpdlNob3J0Y3V0RGVzY3JpcHRpb24uY2xhc3NMaXN0LmFkZChcInNob3J0Y3V0c19fZGVzY3JpcHRpb25cIik7XG4gICAgICBjb25zdCBzcGFuU2hvcnRjdXREZXNjcmlwdGlvbiA9IGRpdlNob3J0Y3V0RGVzY3JpcHRpb24uYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIikpO1xuICAgICAgc3BhblNob3J0Y3V0RGVzY3JpcHRpb24uaW5uZXJUZXh0ID0gZGVzY3JpcHRpb247XG4gICAgfVxuICB9XG59KSgpO1xuIiwiLyoqXG4gKiBTY3JpcHQgaWQuXG4gKi9cbmV4cG9ydCBjb25zdCBTY3JpcHRJZCA9IHtcbiAgQUNUSU9OOiBcIkFDVElPTlwiLFxuICBCQUNLR1JPVU5EOiBcIkJBQ0tHUk9VTkRcIixcbiAgQ09OVEVOVDogXCItXCIsXG4gIE9QVElPTlM6IFwiT1BUSU9OU1wiLFxufTtcblxuLyoqXG4gKiBDb21tYW5kIElEcyBmb3Iga2V5Ym9hcmQgc2hvcnRjdXRzIGFuZCBjb250ZXh0IG1lbnVzLlxuICovXG5leHBvcnQgY29uc3QgQ29tbWFuZFR5cGUgPSB7XG4gIERPX1FVT1RFRF9TRUFSQ0g6IFwiZG9fcXVvdGVkX3NlYXJjaFwiLFxuICBQVVRfUVVPVEVTOiBcInB1dF9xdW90ZXNcIixcbn07XG5cbi8qKlxuICogTWVzc2FnZSB0eXBlcy5cbiAqL1xuZXhwb3J0IGNvbnN0IE1lc3NhZ2VUeXBlID0ge1xuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ29udGVudCBzY3JpcHRzIC0tPiBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBIRUxMTzogXCJoZWxsb1wiLFxuICBOT1RJRllfU0VMRUNUSU9OX1VQREFURUQ6IFwibm90aWZ5X3NlbGVjdGlvbl91cGRhdGVkXCIsXG4gIERPX1FVT1RFRF9TRUFSQ0g6IFwiZG9fcXVvdGVkX3NlYXJjaFwiLFxuICBPUEVOX09QVElPTlNfUEFHRTogXCJvcGVuX29wdGlvbnNfcGFnZVwiLFxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBDb250ZW50IHNjcmlwdHMgPC0tIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIFdFTENPTUU6IFwid2VsY29tZVwiLFxuICBQVVRfUVVPVEVTOiBcInB1dF9xdW90ZXNcIixcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQWN0aW9uIHNjcmlwdHMgLS0+IEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIEdFVF9TRUxFQ1RJT046IFwiZ2V0X3NlbGVjdGlvblwiLFxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyBBY3Rpb24gc2NyaXB0cyA8LS0gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlclxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgTk9USUZZX1NFTEVDVElPTjogXCJub3RpZnlfc2VsZWN0aW9uXCIsXG59O1xuXG4vKipcbiAqIFZhcmlvdXMgZG91YmxlIHF1b3Rlcy5cbiAqXG4gKiBJZiB5b3Ugc3Vycm91bmQgeW91ciBzZWFyY2ggcGhyYXNlIHdpdGggY2hhcmFjdGVycyBpbiB0aGlzIHN0cmluZywgR29vZ2xlXG4gKiBTZWFyY2ggd2lsbCBnaXZlIHlvdSBhbiBleGFjdCBtYXRjaC4gSW4gb3RoZXIgd29yZHMsIHRoZXNlIGFyZSB0aGUgY2hhcmFjdGVyc1xuICogdGhhdCBHb29nbGUgU2VhcmNoIHJlY29nbml6ZXMgYXMgdmFsaWQgZG91YmxlIHF1b3RlcyBmb3IgYW4gZXhhY3QgbWF0Y2guXG4gKlxuICogVGV4dCBjb250YWluaW5nIGRvdWJsZSBxdW90ZXMgY2Fubm90IGJlIGVuY2xvc2VkIGluIGRvdWJsZSBxdW90ZXMsIHNvIHRob3NlXG4gKiBjaGFyYWN0ZXJzIG11c3QgYmUgcmVtb3ZlZCBpZiB0aGV5IGFyZSBpbmNsdWRlZCBpbiB0aGUgc2VsZWN0ZWQgdGV4dCB3aGVuXG4gKiBzZWFyY2hpbmcgZm9yIGFuIGV4YWN0IG1hdGNoLlxuICovXG5leHBvcnQgY29uc3QgUVVPVEFUSU9OX01BUktTID0gXCJcXHUwMDIyXFx1MjAxY1xcdTIwMWRcXHUyMDFlXFx1MjAxZlxcdTIwMzNcXHUzMDFkXFx1MzAxZVxcdTMwMWZcXHVmZjAyXCI7IC8vIFwi4oCc4oCd4oCe4oCf4oCz44Cd44Ce44Cf77yCXG5cbi8qKlxuICogVGhlIG1heGltdW0gbGVuZ3RoIG9mIHRoZSBzZWxlY3RlZCB0ZXh0IHRvIGJlIHByb2Nlc3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IFNFTEVDVElPTl9URVhUX01BWF9MRU5HVEggPSAxMDI0O1xuXG4vKipcbiAqIEluZGljYXRlcyB0aGF0IHRoZSBsZW5ndGggb2YgdGhlIHNlbGVjdGVkIHRleHQgZXhjZWVkcyB0aGUgbGltaXQuXG4gKlxuICogQSB2ZXJ5IGxhcmdlIHRleHQgbWF5IGJlIHNlbGVjdGVkLCBpbiB3aGljaCBjYXNlIHRoaXMgc3RyaW5nIGlzIHByZXNlcnZlZFxuICogaW5zdGVhZCBvZiB0aGUgb3JpZ2luYWwgc3RyaW5nIGFzIHRoZSBzZWxlY3RlZCB0ZXh0IHRvIGF2b2lkIHdhc3RpbmcgbWVtb3J5XG4gKiBhbmQgbWFraW5nIGxvZ3Mgbm9pc3kuXG4gKi9cbmV4cG9ydCBjb25zdCBTRUxFQ1RJT05fVEVYVF9UT09fTE9OR19NQVJLRVIgPSBcIiMjIyBUb28gTG9uZyEgIyMjIHlvQmp2XkY3JXNnI05NeENycXZZS01nRDg1c1JYUmlHXCI7XG4iLCJpbXBvcnQgeyBTRUxFQ1RJT05fVEVYVF9NQVhfTEVOR1RILCBTRUxFQ1RJT05fVEVYVF9UT09fTE9OR19NQVJLRVIsIFFVT1RBVElPTl9NQVJLUyB9IGZyb20gXCIuL19fY29uc3RhbnRzLmpzXCI7XG5pbXBvcnQgeyBsb2dnZXIsIG9wdGlvbnMgfSBmcm9tIFwiLi9fX2dsb2JhbHMuanNcIjtcbmltcG9ydCB7IEhvd1RvT3BlbkxpbmsgfSBmcm9tIFwiLi9fX2hvd190b19vcGVuX2xpbmsuanNcIjtcblxuLyoqXG4gKiBGaWx0ZXJzIHRoZSBzZWxlY3RlZCB0ZXh0IG9idGFpbmVkIGZyb20gZXh0ZXJuYWwgc291cmNlcy5cbiAqXG4gKiBGb3Igc2VjdXJpdHkgcHVycG9zZXMsIGJlIHN1cmUgdG8gcGFzcyB0aGUgc2VsZWN0ZWQgdGV4dCBvYnRhaW5lZCBmcm9tXG4gKiBleHRlcm5hbCBzb3VyY2VzIHRocm91Z2ggdGhpcyBmaWx0ZXIgYmVmb3JlIHVzaW5nIGl0LlxuICpcbiAqIEBwYXJhbSB7P3N0cmluZ30gc2VsZWN0aW9uVGV4dFxuICogQHJldHVybnMgeyFzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmaWx0ZXJTZWxlY3Rpb25UZXh0KHNlbGVjdGlvblRleHQpIHtcbiAgc2VsZWN0aW9uVGV4dCA/Pz0gXCJcIjtcbiAgcmV0dXJuIHNlbGVjdGlvblRleHQubGVuZ3RoID4gU0VMRUNUSU9OX1RFWFRfTUFYX0xFTkdUSCA/IFNFTEVDVElPTl9URVhUX1RPT19MT05HX01BUktFUiA6IHNlbGVjdGlvblRleHQ7XG59XG5cbi8qKlxuICogTm9ybWFsaXplcyB0aGUgc2VsZWN0ZWQgdGV4dC5cbiAqXG4gKiBUaGUgbm9ybWFsaXphdGlvbiBpbmNsdWRlczpcbiAqXG4gKiAtIFJlcGxhY2UgZG91YmxlIHF1b3RlcyB3aXRoIGEgc3BhY2UuXG4gKiAtIENvbGxhcHNlIGNvbnNlY3V0aXZlIHdoaXRlc3BhY2UgY2hhcmFjdGVycyBpbnRvIHNpbmdsZSBzcGFjZS5cbiAqIC0gUmVtb3ZlIHdoaXRlc3BhY2UgZnJvbSBib3RoIGVuZHMgb2YgdGhlIHN0cmluZy5cbiAqXG4gKiBAcGFyYW0gez9zdHJpbmd9IHNlbGVjdGlvblRleHRcbiAqIEByZXR1cm5zIHshc3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gbm9ybWFsaXplU2VsZWN0aW9uVGV4dChzZWxlY3Rpb25UZXh0KSB7XG4gIHNlbGVjdGlvblRleHQgPSBmaWx0ZXJTZWxlY3Rpb25UZXh0KHNlbGVjdGlvblRleHQpO1xuICByZXR1cm4gc2VsZWN0aW9uVGV4dCA9PT0gU0VMRUNUSU9OX1RFWFRfVE9PX0xPTkdfTUFSS0VSXG4gICAgPyBzZWxlY3Rpb25UZXh0XG4gICAgOiBzZWxlY3Rpb25UZXh0LnJlcGxhY2VBbGwobmV3IFJlZ0V4cChgW1xcXFxzJHtRVU9UQVRJT05fTUFSS1N9XStgLCBcImdcIiksIFwiIFwiKS50cmltKCk7XG59XG5cbi8qKlxuICogQ2hlY2tzIGlmIHRoZSBub3JtYWxpemVkIHNlbGVjdGlvbiB0ZXh0IGlzIHZhbGlkIGZvciBwcm9jZXNzaW5nLlxuICpcbiAqIEBwYXJhbSB7P3N0cmluZ30gbm9ybWFsaXplZFNlbGVjdGlvblRleHRcbiAqIEByZXR1cm5zIHshYm9vbGVhbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzTm9ybWFsaXplZFNlbGVjdGlvblRleHRWYWxpZChub3JtYWxpemVkU2VsZWN0aW9uVGV4dCkge1xuICBub3JtYWxpemVkU2VsZWN0aW9uVGV4dCA/Pz0gXCJcIjtcbiAgcmV0dXJuIChcbiAgICBub3JtYWxpemVkU2VsZWN0aW9uVGV4dCAhPT0gU0VMRUNUSU9OX1RFWFRfVE9PX0xPTkdfTUFSS0VSICYmXG4gICAgbm9ybWFsaXplZFNlbGVjdGlvblRleHQubGVuZ3RoID4gMCAmJlxuICAgIG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0Lmxlbmd0aCA8PSBTRUxFQ1RJT05fVEVYVF9NQVhfTEVOR1RIXG4gICk7XG59XG5cbi8qKlxuICogUHV0cyBkb3VibGUgcXVvdGVzIGFyb3VuZCB0aGUgc3RyaW5nLlxuICpcbiAqIEBwYXJhbSB7P3N0cmluZ30gdGV4dFxuICogQHJldHVybnMgeyFzdHJpbmd9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBxdW90ZVRleHQodGV4dCkge1xuICByZXR1cm4gJ1wiJyArICh0ZXh0ID8/IFwiXCIpICsgJ1wiJztcbn1cblxuLyoqXG4gKiBDbG9uZXMgYW4gb2JqZWN0IHRyZWF0ZWQgYXMgYSBEVE8uXG4gKlxuICogSWYgeW91IG5lZWQgcGFzcyBhbiBvYmplY3Qgd2hvc2UgY29udGVudHMgbWF5IGJlIGNoYW5nZWQgbGF0ZXIgdG8gYW5cbiAqIGFzeW5jaHJvbm91cyBtZXRob2QsIHBhc3MgYW4gb2JqZWN0IGNsb25lZCBieSB0aGlzIGZ1bmN0aW9uIGluc3RlYWQgb2YgdGhlXG4gKiBvcmlnaW4gb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7P29iamVjdH0gb2JqXG4gKiBAcmV0dXJucyB7IW9iamVjdH1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNsb25lRHRvKG9iaikge1xuICByZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShvYmogPz8ge30pKTtcbn1cblxuLyoqXG4gKiBNZXJnZXMgYHJoc2AgdG8gYGxoc2AsIGlnbm9yaW5nIHByb3BlcnRpZXMgd2l0aCBhIHZhbHVlIG9mIGB1bmRlZmluZWRgLlxuICpcbiAqIEBwYXJhbSB7P29iamVjdH0gdGFyZ2V0XG4gKiBAcGFyYW0gez9vYmplY3R9IHNvdXJjZVxuICogQHJldHVybnMgeyFvYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtZXJnZU9iamVjdCh0YXJnZXQsIHNvdXJjZSkge1xuICByZXR1cm4geyAuLi50YXJnZXQsIC4uLk9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhzb3VyY2UgPz8ge30pLmZpbHRlcigoWywgdl0pID0+IHYgIT09IHVuZGVmaW5lZCkpIH07XG59XG5cbi8qKlxuICogU2V0cyB1cCBhbiBldmVudCBsaXN0ZW5lciBmb3IgYERPTUNvbnRlbnRMb2FkZWRgIGV2ZW50LlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gY2hlY2tzIGBEb2N1bWVudC5yZWFkeVN0YXRlYCBhbmQgc2V0cyB1cCB0aGUgZXZlbnQgbGlzdGVuZXIgYXNcbiAqIGEgbWljcm90YXNrcyBpZiB0aGUgZXZlbnQgaGFzIGFscmVhZHkgYmVlbiBmaXJlZC5cbiAqXG4gKiBAcGFyYW0geyFXaW5kb3d9IHdpblxuICogQHBhcmFtIHshZnVuY3Rpb24oKTp2b2lkfSBsaXN0ZW5lclxuICovXG5leHBvcnQgZnVuY3Rpb24gYWRkRE9NQ29udGVudExvYWRlZEV2ZW50TGlzdGVuZXIod2luLCBsaXN0ZW5lcikge1xuICBpZiAod2luLmRvY3VtZW50LnJlYWR5U3RhdGUgPT09IFwibG9hZGluZ1wiKSB7XG4gICAgd2luLmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJET01Db250ZW50TG9hZGVkXCIsIGxpc3RlbmVyKTtcbiAgfSBlbHNlIHtcbiAgICBxdWV1ZU1pY3JvdGFzayhsaXN0ZW5lcik7XG4gIH1cbn1cblxuLyoqXG4gKiBTZXRzIHVwIGFuIGV2ZW50IGxpc3RlbmVyIGZvciBgbG9hZGAgZXZlbnQuXG4gKlxuICogVGhpcyBmdW5jdGlvbiBjaGVja3MgYERvY3VtZW50LnJlYWR5U3RhdGVgIGFuZCBzZXRzIHVwIHRoZSBldmVudCBsaXN0ZW5lciBhc1xuICogYSBtaWNyb3Rhc2tzIGlmIHRoZSBldmVudCBoYXMgYWxyZWFkeSBiZWVuIGZpcmVkLlxuICpcbiAqIEBwYXJhbSB7IVdpbmRvd30gd2luXG4gKiBAcGFyYW0geyFmdW5jdGlvbigpOnZvaWR9IGxpc3RlbmVyXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZGRMb2FkQ29tcGxldGVkRXZlbnRMaXN0ZW5lcih3aW4sIGxpc3RlbmVyKSB7XG4gIGlmICh3aW4uZG9jdW1lbnQucmVhZHlTdGF0ZSAhPT0gXCJjb21wbGV0ZVwiKSB7XG4gICAgd2luLmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsIGxpc3RlbmVyKTtcbiAgfSBlbHNlIHtcbiAgICBxdWV1ZU1pY3JvdGFzayhsaXN0ZW5lcik7XG4gIH1cbn1cblxuLyoqXG4gKiBJbmplY3RzIGxvY2FsaXplZCBzdHJpbmdzIGludG8gSFRNTCBkb2N1bWVudC5cbiAqXG4gKiBAcGFyYW0geyFEb2N1bWVudH0gZG9jXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbmplY3RJMThOTWVzc2FnZXNJbkh0bWwoZG9jKSB7XG4gIGNvbnN0IEkxOE5fVEFSR0VUUyA9IFtcIm91dGVySFRNTFwiLCBcImlubmVySFRNTFwiLCBcIm91dGVyVGV4dFwiLCBcImlubmVyVGV4dFwiLCBcInZhbHVlXCJdO1xuICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgZG9jLnF1ZXJ5U2VsZWN0b3JBbGwoXCJbZGF0YS1ncm91cH49J2kxOG4nXCIpKSB7XG4gICAgY29uc3Qgc3Vic3RpdHV0aW9ucyA9ICgoKSA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSBbXTtcbiAgICAgIGNvbnN0IGFyZ3MgPSBlbGVtZW50LmRhdGFzZXQuaTE4bkFyZ3M7XG4gICAgICBpZiAoIWFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGlkcyA9IGFyZ3Muc3BsaXQoXCIgXCIpO1xuICAgICAgZm9yIChjb25zdCBpZCBvZiBpZHMpIHtcbiAgICAgICAgY29uc3QgYXJnRWxlbWVudCA9IGRvYy5nZXRFbGVtZW50QnlJZChpZCk7XG4gICAgICAgIGNvbnN0IGFyZ1RhcmdldCA9IGFyZ0VsZW1lbnQuZGF0YXNldC5pMThuVGFyZ2V0O1xuICAgICAgICBsb2dnZXIuYXNzZXJ0KEkxOE5fVEFSR0VUUy5pbmNsdWRlcyhhcmdUYXJnZXQpLCBcIlVuZXhwZWN0ZWQgdGFyZ2V0XCIsIHsgYXJnVGFyZ2V0LCBhcmdFbGVtZW50IH0pO1xuICAgICAgICByZXN1bHQucHVzaChhcmdFbGVtZW50W2FyZ1RhcmdldF0pO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9KSgpO1xuICAgIGNvbnN0IHRhcmdldCA9IGVsZW1lbnQuZGF0YXNldC5pMThuVGFyZ2V0O1xuICAgIGxvZ2dlci5hc3NlcnQoSTE4Tl9UQVJHRVRTLmluY2x1ZGVzKHRhcmdldCksIFwiVW5leHBlY3RlZCB0YXJnZXRcIiwgeyB0YXJnZXQsIGVsZW1lbnQgfSk7XG4gICAgZWxlbWVudFt0YXJnZXRdID0gY2hyb21lLmkxOG4uZ2V0TWVzc2FnZShlbGVtZW50LmRhdGFzZXQuaTE4bk5hbWUsIHN1YnN0aXR1dGlvbnMpO1xuICB9XG59XG5cbi8qKlxuICogR2V0cyBgU2VsZWN0aW9uYCBvYmplY3QuXG4gKlxuICogVGhpcyBmdW5jdGlvbiBub3Qgb25seSBjYWxscyBgV2luZG93LmdldFNlbGVjdGlvbigpYCwgYnV0IGFsc28gcmVjdXJzaXZlbHlcbiAqIHNlYXJjaGVzIHdpdGhpbiB0aGUgbmVzdGVkIFNoYWRvdyBET01zLlxuICpcbiAqIEBwYXJhbSB7IVdpbmRvd30gd2luXG4gKiBAcmV0dXJucyB7IVNlbGVjdGlvbn1cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFNlbGVjdGlvbih3aW4pIHtcbiAgZnVuY3Rpb24gZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5KHNlbGVjdGlvbikge1xuICAgIGlmIChzZWxlY3Rpb24ucmFuZ2VDb3VudCA9PT0gMSkge1xuICAgICAgY29uc3QgcmFuZ2UgPSBzZWxlY3Rpb24uZ2V0UmFuZ2VBdCgwKTtcbiAgICAgIGlmIChyYW5nZS5zdGFydENvbnRhaW5lciA9PT0gcmFuZ2UuZW5kQ29udGFpbmVyKSB7XG4gICAgICAgIGNvbnN0IGNvbW1vbkFuY2VzdG9yQ29udGFpbmVyID0gcmFuZ2UuY29tbW9uQW5jZXN0b3JDb250YWluZXI7XG4gICAgICAgIGlmIChjb21tb25BbmNlc3RvckNvbnRhaW5lciBpbnN0YW5jZW9mIEVsZW1lbnQpIHtcbiAgICAgICAgICBpZiAoY29tbW9uQW5jZXN0b3JDb250YWluZXIuc2hhZG93Um9vdCkge1xuICAgICAgICAgICAgcmV0dXJuIGZpbmRTZWxlY3Rpb25SZWN1cnNpdmVseShjb21tb25BbmNlc3RvckNvbnRhaW5lci5zaGFkb3dSb290LmdldFNlbGVjdGlvbigpKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgZWxlbWVudHNXaXRoU2hhZG93Um9vdCA9IEFycmF5LnByb3RvdHlwZS5maWx0ZXIuY2FsbChcbiAgICAgICAgICAgICAgY29tbW9uQW5jZXN0b3JDb250YWluZXIucXVlcnlTZWxlY3RvckFsbChcIipcIiksXG4gICAgICAgICAgICAgIChlbGVtZW50KSA9PiAhIWVsZW1lbnQuc2hhZG93Um9vdFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGlmIChlbGVtZW50c1dpdGhTaGFkb3dSb290Lmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICByZXR1cm4gZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5KGVsZW1lbnRzV2l0aFNoYWRvd1Jvb3RbMF0uc2hhZG93Um9vdC5nZXRTZWxlY3Rpb24oKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBzZWxlY3Rpb247XG4gIH1cblxuICByZXR1cm4gZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5KHdpbi5nZXRTZWxlY3Rpb24oKSk7XG59XG5cbi8qKlxuICogQ2FsbHMgYGNocm9tZS5ydW50aW1lLlBvcnQucG9zdE1lc3NhZ2UoKWAgbWV0aG9kLlxuICpcbiAqIENhdGNoZXMgdGhlIGVycm9yIHRocm93biBmcm9tIGBjaHJvbWUucnVudGltZS5Qb3J0LnBvc3RNZXNzYWdlKClgIG1ldGhvZCBhbmRcbiAqIGxvZ3MgYSB3YXJuaW5nIG1lc3NhZ2UuXG4gKlxuICogYGNocm9tZS5ydW50aW1lLlBvcnQucG9zdE1lc3NhZ2UoKWAgdGhyb3dzIGFuIGVycm9yIGlmIHRoZSBvdGhlciBzaWRlIG9mIHRoZVxuICogcG9ydCBoYXMgYWxyZWFkeSBiZWVuIGNsb3NlZCwgYnV0IHRoZXJlIGlzIG5vIHdheSB0byBjaGVjayBpbiBhZHZhbmNlIHdoZXRoZXJcbiAqIHRoZSBwb3J0IGlzIHN0aWxsIG9wZW5lZCBvciBoYXMgYmVlbiBjbG9zZWQuXG4gKiBQb3J0IGRpc2Nvbm5lY3Rpb24gaXMgb25lIG9mIHRoZSBleHBlY3RlZCBjb25kaXRpb25zLCBldmVuIGluIGFuIGVkZ2UgY2FzZSxcbiAqIGFuZCBtb3N0IG9mIHRoZSB0aW1lIGl0IGlzIG5vdCBhbiBlcnJvciBjYXNlLlxuICogVGhlcmVmb3JlLCBpZiBhbiBlcnJvciBpcyB0aHJvd24gZnJvbSBgY2hyb21lLnJ1bnRpbWUuUG9ydC5wb3N0TWVzc2FnZSgpYFxuICogbWV0aG9kLCB0aGlzIGZ1bmN0aW9uIGFzc3VtZXMgdGhlIGNhdXNlIGlzIHBvcnQgZGlzY29ubmVjdGlvbiBhbmQgbG9ncyBpdCBhc1xuICogYSB3YXJuaW5nIGluc3RlYWQgb2YgYW4gZXJyb3IuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnJ1bnRpbWUuUG9ydH0gcG9ydFxuICogQHBhcmFtIHshKn0gbWVzc2FnZVxuICovXG5leHBvcnQgZnVuY3Rpb24gcG9zdE1lc3NhZ2UocG9ydCwgbWVzc2FnZSkge1xuICB0cnkge1xuICAgIHBvcnQucG9zdE1lc3NhZ2UobWVzc2FnZSk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgbG9nZ2VyLndhcm4oXG4gICAgICBcIkl0IHNlZW1zIHRoYXQgdGhlIG1lc3NhZ2UgY291bGQgbm90IGJlIHNlbnQgYmVjYXVzZSB0aGUgb3RoZXIgc2lkZSBvZiB0aGUgcG9ydCBoYXMgYWxyZWFkeSBiZWVuIGNsb3NlZFwiLFxuICAgICAgeyBlcnJvciwgcG9ydCwgbWVzc2FnZSB9XG4gICAgKTtcbiAgfVxufVxuXG4vKipcbiAqIEdldHMgdGhlIGFjdGl2ZSB0YWIuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHJldHVybnMgeyFQcm9taXNlPCFjaHJvbWUudGFicy5UYWI+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0QWN0aXZlVGFiKCkge1xuICBjb25zdCBbdGFiXSA9IGF3YWl0IGNocm9tZS50YWJzLnF1ZXJ5KHsgYWN0aXZlOiB0cnVlLCBjdXJyZW50V2luZG93OiB0cnVlIH0pO1xuICByZXR1cm4gdGFiO1xufVxuXG4vKipcbiAqIENyZWF0ZXMgYSBuZXcgdGFiLlxuICpcbiAqICoqTm90ZToqKiBOb3QgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0cywgYXZhaWxhYmxlIG9ubHkgaW4gYmFja2dyb3VuZFxuICogc2VydmljZSB3b3JrZXIsIGFjdGlvbiBzY3JpcHRzIG9yIG9wdGlvbnMgc2NyaXB0LlxuICpcbiAqIEBwYXJhbSB7IWNocm9tZS50YWJzLlRhYn0gdGFiIEN1cnJlbnQgdGFiIGNhbGxpbmcgdGhpcyBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7P3t1cmw6P3N0cmluZz0sIGFjdGl2ZTo/Ym9vbGVhbj19PX0gcGFyYW1zXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVOZXdUYWIodGFiLCBwYXJhbXMpIHtcbiAgcmV0dXJuIGF3YWl0IGNocm9tZS50YWJzLmNyZWF0ZSh7XG4gICAgd2luZG93SWQ6IHRhYi53aW5kb3dJZCxcbiAgICBvcGVuZXJUYWJJZDogdGFiLmlkLFxuICAgIGluZGV4OiB0YWIuaW5kZXggKyAxLFxuICAgIHVybDogcGFyYW1zPy51cmwsXG4gICAgYWN0aXZlOiBwYXJhbXM/LmFjdGl2ZSA/PyB0cnVlLFxuICB9KTtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IHdpbmRvdy5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0gez97dXJsOj9zdHJpbmc9fT19IHBhcmFtc1xuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlTmV3V2luZG93KHBhcmFtcykge1xuICBjb25zdCBjdXJyZW50V2luZG93ID0gYXdhaXQgY2hyb21lLndpbmRvd3MuZ2V0Q3VycmVudCgpO1xuICByZXR1cm4gYXdhaXQgY2hyb21lLndpbmRvd3MuY3JlYXRlKHtcbiAgICBzdGF0ZTogY3VycmVudFdpbmRvdy5zdGF0ZSxcbiAgICB1cmw6IHBhcmFtcz8udXJsLFxuICB9KTtcbn1cblxuLyoqXG4gKiBJbnZva2VzIHNlYXJjaCBlbmdpbmUgdG8gZG8gcXVvdGVkIHNlYXJjaC5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0geyFjaHJvbWUudGFicy5UYWJ9IHRhYiBDdXJyZW50IHRhYiBjYWxsaW5nIHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0geyFzdHJpbmd9IHNlYXJjaFRleHQgVGV4dCB0byBzZWFyY2gsIG5vdCB0byBiZSBlbmNsb3NlZCBpbiBkb3VibGUgcXVvdGVzLlxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluay5LZXlTdGF0ZT19IGtleVN0YXRlXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkb1F1b3RlZFNlYXJjaCh0YWIsIHNlYXJjaFRleHQsIGtleVN0YXRlKSB7XG4gIGNvbnN0IGhvd1RvT3BlbkxpbmsgPSBIb3dUb09wZW5MaW5rLmRlY2lkZShrZXlTdGF0ZSwgbmV3IEhvd1RvT3Blbkxpbmsob3B0aW9ucy5kaXNwb3NpdGlvbiwgdHJ1ZSkpO1xuICBpZiAoaG93VG9PcGVuTGluay5kaXNwb3NpdGlvbiA9PT0gSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5ORVdfVEFCKSB7XG4gICAgY29uc3QgbmV3VGFiID0gYXdhaXQgY3JlYXRlTmV3VGFiKHRhYiwgeyBhY3RpdmU6IGZhbHNlIH0pO1xuICAgIGF3YWl0IGNocm9tZS5zZWFyY2gucXVlcnkoeyB0YWJJZDogbmV3VGFiLmlkLCB0ZXh0OiBxdW90ZVRleHQoc2VhcmNoVGV4dCkgfSk7XG4gICAgLy8gVG8gcHJldmVudCB0aGUgb21uaWJveCBmcm9tIHJlY2VpdmluZyBmb2N1cywgYWN0aXZhdGUgbmV3IHRhYiBhZnRlclxuICAgIC8vIGNyZWF0aW9uIGFuZCBzZWFyY2guXG4gICAgaWYgKGhvd1RvT3BlbkxpbmsuYWN0aXZlID8/IHRydWUpIHtcbiAgICAgIGF3YWl0IGNocm9tZS50YWJzLnVwZGF0ZShuZXdUYWIuaWQsIHsgYWN0aXZlOiB0cnVlIH0pO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBjaHJvbWUuc2VhcmNoLnF1ZXJ5KHsgZGlzcG9zaXRpb246IGhvd1RvT3BlbkxpbmsuZGlzcG9zaXRpb24sIHRleHQ6IHF1b3RlVGV4dChzZWFyY2hUZXh0KSB9KTtcbiAgfVxufVxuXG4vKipcbiAqIE9wZW5zIHRoZSB3ZWIgcGFnZSB3aXRoIHNwZWNpZmllZCBVUkwuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnRhYnMuVGFifSB0YWIgQ3VycmVudCB0YWIgY2FsbGluZyB0aGlzIGZ1bmN0aW9uLlxuICogQHBhcmFtIHshc3RyaW5nfSB1cmxcbiAqIEBwYXJhbSB7P0hvd1RvT3BlbkxpbmsuS2V5U3RhdGU9fSBrZXlTdGF0ZVxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluaz19IGRlZmF1bHRIb3dUb09wZW5MaW5rIFNwZWNpZmllcyB0aGUgZGVmYXVsdCBiZWhhdmlvclxuICogICAgaWYgbm8gY29udHJvbCBrZXkgaXMgcHJlc3NlZC5cbiAqIEByZXR1cm5zIHshUHJvbWlzZTx2b2lkPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5MaW5rKHRhYiwgdXJsLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspIHtcbiAgY29uc3QgaG93VG9PcGVuTGluayA9IEhvd1RvT3BlbkxpbmsuZGVjaWRlKGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluayk7XG4gIGlmIChob3dUb09wZW5MaW5rLmRpc3Bvc2l0aW9uID09PSBIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9uLkNVUlJFTlRfVEFCKSB7XG4gICAgYXdhaXQgY2hyb21lLnRhYnMudXBkYXRlKHRhYi5pZCwgeyB1cmw6IHVybCB9KTtcbiAgfSBlbHNlIGlmIChob3dUb09wZW5MaW5rLmRpc3Bvc2l0aW9uID09PSBIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9uLk5FV19XSU5ET1cpIHtcbiAgICBhd2FpdCBjcmVhdGVOZXdXaW5kb3coeyB1cmw6IHVybCB9KTtcbiAgfSBlbHNlIHtcbiAgICBhd2FpdCBjcmVhdGVOZXdUYWIodGFiLCB7IHVybDogdXJsLCBhY3RpdmU6IGhvd1RvT3BlbkxpbmsuYWN0aXZlID8/IHRydWUgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBPcGVucyB0aGUgZXh0ZW5zaW9uJ3MgT3B0aW9ucyBwYWdlLlxuICpcbiAqICoqTm90ZToqKiBOb3QgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0cywgYXZhaWxhYmxlIG9ubHkgaW4gYmFja2dyb3VuZFxuICogc2VydmljZSB3b3JrZXIsIGFjdGlvbiBzY3JpcHRzIG9yIG9wdGlvbnMgc2NyaXB0LlxuICpcbiAqIEBwYXJhbSB7IWNocm9tZS50YWJzLlRhYn0gdGFiIEN1cnJlbnQgdGFiIGNhbGxpbmcgdGhpcyBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7P0hvd1RvT3BlbkxpbmsuS2V5U3RhdGU9fSBrZXlTdGF0ZVxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluaz19IGRlZmF1bHRIb3dUb09wZW5MaW5rIFNwZWNpZmllcyB0aGUgZGVmYXVsdCBiZWhhdmlvclxuICogICAgaWYgbm8gY29udHJvbCBrZXkgaXMgcHJlc3NlZC5cbiAqIEByZXR1cm5zIHshUHJvbWlzZTx2b2lkPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5PcHRpb25zUGFnZSh0YWIsIGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluaykge1xuICBjb25zdCB1cmwgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJvcHRpb25zLmh0bWxcIik7XG4gIGF3YWl0IG9wZW5MaW5rKHRhYiwgdXJsLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspO1xufVxuXG4vKipcbiAqIE9wZW5zIHNlYXJjaCBlbmdpbmUgc2V0dGluZ3MgcGFnZSBvZiB0aGUgYnJvd3Nlci5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0geyFjaHJvbWUudGFicy5UYWJ9IHRhYiBDdXJyZW50IHRhYiBjYWxsaW5nIHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rLktleVN0YXRlPX0ga2V5U3RhdGVcbiAqIEBwYXJhbSB7P0hvd1RvT3Blbkxpbms9fSBkZWZhdWx0SG93VG9PcGVuTGluayBTcGVjaWZpZXMgdGhlIGRlZmF1bHQgYmVoYXZpb3JcbiAqICAgIGlmIG5vIGNvbnRyb2wga2V5IGlzIHByZXNzZWQuXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuU2VhcmNoRW5naW5lU2V0dGluZ3ModGFiLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspIHtcbiAgY29uc3QgdXJsID0gXCJjaHJvbWU6Ly9zZXR0aW5ncy9zZWFyY2hcIjtcbiAgYXdhaXQgb3BlbkxpbmsodGFiLCB1cmwsIGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluayk7XG59XG5cbi8qKlxuICogT3BlbnMga2V5Ym9hcmQgc2hvcnRjdXRzIHNldHRpbmdzIHBhZ2Ugb2YgdGhlIGJyb3dzZXIuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnRhYnMuVGFifSB0YWIgQ3VycmVudCB0YWIgY2FsbGluZyB0aGlzIGZ1bmN0aW9uLlxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluay5LZXlTdGF0ZT19IGtleVN0YXRlXG4gKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rPX0gZGVmYXVsdEhvd1RvT3BlbkxpbmsgU3BlY2lmaWVzIHRoZSBkZWZhdWx0IGJlaGF2aW9yXG4gKiAgICBpZiBubyBjb250cm9sIGtleSBpcyBwcmVzc2VkLlxuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlblNob3J0Y3V0c1NldHRpbmdzKHRhYiwga2V5U3RhdGUsIGRlZmF1bHRIb3dUb09wZW5MaW5rKSB7XG4gIGNvbnN0IHVybCA9IFwiY2hyb21lOi8vZXh0ZW5zaW9ucy9zaG9ydGN1dHNcIjtcbiAgYXdhaXQgb3BlbkxpbmsodGFiLCB1cmwsIGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluayk7XG59XG4iLCJpbXBvcnQgeyBjb25maWcgfSBmcm9tIFwiLi9fX2NvbmZpZy5qc1wiO1xuaW1wb3J0IHsgU2NyaXB0SWQgfSBmcm9tIFwiLi9fX2NvbnN0YW50cy5qc1wiO1xuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSBcIi4vX19sb2dnZXIuanNcIjtcbmltcG9ydCB7IE9wdGlvbnMgfSBmcm9tIFwiLi9fX29wdGlvbnMuanNcIjtcblxuLyoqXG4gKiBMb2dnZXIgdXNlZCB1c2VkIHRocm91Z2hvdXQgdGhlIGV4dGVuc2lvbi5cbiAqXG4gKiBJdCB3aWxsIGJlIGluaXRpYWxpemVkIGluIHtAbGluayBpbml0KCl9IGZ1bmN0aW9uLlxuICpcbiAqIEB0eXBlIHtMb2dnZXJ9XG4gKi9cbmV4cG9ydCBsZXQgbG9nZ2VyO1xuXG4vKipcbiAqIE9wdGlvbnMgdXNlZCB1c2VkIHRocm91Z2hvdXQgdGhlIGV4dGVuc2lvbi5cbiAqXG4gKiBJdCB3aWxsIGJlIGluaXRpYWxpemVkIGluIHtAbGluayBpbml0KCl9IGZ1bmN0aW9uLlxuICpcbiAqIEB0eXBlIHtPcHRpb25zfVxuICovXG5leHBvcnQgbGV0IG9wdGlvbnM7XG5cbi8qKlxuICogSW5pdGlhbGl6ZXMgdGhlIG1vZHVsZS5cbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIG11c3QgYmUgY2FsbGVkIGZpcnN0IHRvIGluaXRpYWxpemUgZ2xvYmFsIHZhcmlhYmxlcyBiZWZvcmVcbiAqIHVzaW5nIHRoZW0gYW5kIGFueSBvdGhlciBmdW5jdGlvbnMgZGVwZW5kaW5nIHRoZXNlIGdsb2JhbCB2YXJpYWJsZXMuXG4gKlxuICogQHBhcmFtIHshc3RyaW5nfSBzY3JpcHRJZFxuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaW5pdChzY3JpcHRJZCkge1xuICBsb2dnZXIgPSBuZXcgTG9nZ2VyKHNjcmlwdElkKTtcbiAgbG9nZ2VyLnN0YXRlKFwiSW5pdGlhbGl6ZSBzY3JpcHRcIiwgeyBzY3JpcHRJZCB9KTtcblxuICBvcHRpb25zID0gbmV3IE9wdGlvbnMobG9nZ2VyKTtcbiAgYXdhaXQgb3B0aW9ucy5pbml0KCk7XG5cbiAgYXdhaXQgY2hlY2tPc0lzTWFjKHNjcmlwdElkKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2hlY2tPc0lzTWFjKHNjcmlwdElkKSB7XG4gIGNvbnN0IFNUT1JBR0VfS0VZID0gXCJpc01hY1wiO1xuICBjb25zdCBzdG9yYWdlID0gY2hyb21lLnN0b3JhZ2UubG9jYWw7XG4gIGlmIChzY3JpcHRJZCA9PT0gU2NyaXB0SWQuQkFDS0dST1VORCkge1xuICAgIGNvbmZpZy5pc01hYyA9IChhd2FpdCBjaHJvbWUucnVudGltZS5nZXRQbGF0Zm9ybUluZm8oKSkub3MgPT09IFwibWFjXCI7XG4gICAgYXdhaXQgc3RvcmFnZS5zZXQoeyBbU1RPUkFHRV9LRVldOiBjb25maWcuaXNNYWMgfSk7XG4gIH0gZWxzZSB7XG4gICAgY29uZmlnLmlzTWFjID0gISEoYXdhaXQgc3RvcmFnZS5nZXQoU1RPUkFHRV9LRVkpKVtTVE9SQUdFX0tFWV07XG4gIH1cbiAgbG9nZ2VyLnN0YXRlKFwiVXBkYXRlZCBgaXNNYWNgIGluIGNvbmZpZ1wiLCB7IFtcImNvbmZpZy5pc01hY1wiXTogY29uZmlnLmlzTWFjIH0pO1xufVxuIiwiaW1wb3J0IHsgY29uZmlnIH0gZnJvbSBcIi4vX19jb25maWcuanNcIjtcblxuLyoqXG4gKiBDb250cm9scyBob3cgdG8gb3BlbiBhIGxpbmsgYmFzZWQgb24gdGhlIHN0YXRlIG9mIGNvbnRyb2wga2V5cyBzdWNoIGFzIGBDdHJsYFxuICogYW5kIGBTaGlmdGAuXG4gKi9cbmV4cG9ydCBjbGFzcyBIb3dUb09wZW5MaW5rIHtcbiAgLyoqXG4gICAqIExvY2F0aW9uIHdoZXJlIGEgbGluayBzaG91bGQgYmUgb3BlbmVkLlxuICAgKlxuICAgKiBUaGUgdmFsdWVzIG9mIHRoaXMgZW51bSBhcmUgc2FtZSBhc1xuICAgKiBbY2hyb21lLnNlYXJjaC5EaXNwb3NpdGlvbl0oaHR0cHM6Ly9kZXZlbG9wZXIuY2hyb21lLmNvbS9kb2NzL2V4dGVuc2lvbnMvcmVmZXJlbmNlL3NlYXJjaC8jdHlwZS1EaXNwb3NpdGlvbikuXG4gICAqIFRoZXJlZm9yZSwgdGhleSBjYW4gYmUgdXNlZCBhcy1pcyBhcyBhIHBhcmFtZXRlciB0b1xuICAgKiBbY2hyb21lLnNlYXJjaC5xdWVyeSgpXShodHRwczovL2RldmVsb3Blci5jaHJvbWUuY29tL2RvY3MvZXh0ZW5zaW9ucy9yZWZlcmVuY2Uvc2VhcmNoLyNtZXRob2QtcXVlcnkpLlxuICAgKi9cbiAgc3RhdGljIERpc3Bvc2l0aW9uID0ge1xuICAgIENVUlJFTlRfVEFCOiBcIkNVUlJFTlRfVEFCXCIsXG4gICAgTkVXX1RBQjogXCJORVdfVEFCXCIsXG4gICAgTkVXX1dJTkRPVzogXCJORVdfV0lORE9XXCIsXG4gIH07XG5cbiAgc3RhdGljIEtleVN0YXRlID0gY2xhc3MgS2V5U3RhdGUge1xuICAgIGN0cmxLZXk7XG4gICAgc2hpZnRLZXk7XG5cbiAgICAvKipcbiAgICAgKiBAcGFyYW0geyFib29sZWFufSBjdHJsS2V5XG4gICAgICogQHBhcmFtIHshYm9vbGVhbn0gc2hpZnRLZXlcbiAgICAgKiBAcGFyYW0geyFib29sZWFuPX0gbWV0YUtleSBJZiBzcGVjaWZpZWQsIGBtZXRhS2V5YCBpcyB1c2VkIGluc3RlYWQgb2ZcbiAgICAgKiAgICBgY3RybEtleWAgd2hlbiBydW5uaW5nIG9uIE1BQy5cbiAgICAgKi9cbiAgICBjb25zdHJ1Y3RvcihjdHJsS2V5LCBzaGlmdEtleSwgbWV0YUtleSA9IGN0cmxLZXkpIHtcbiAgICAgIHRoaXMuY3RybEtleSA9IGNvbmZpZy5pc01hYyA/IG1ldGFLZXkgOiBjdHJsS2V5O1xuICAgICAgdGhpcy5zaGlmdEtleSA9IHNoaWZ0S2V5O1xuICAgIH1cblxuICAgIGVxdWFscyhvdGhlcikge1xuICAgICAgcmV0dXJuIG90aGVyICYmIHRoaXMuY3RybEtleSA9PT0gb3RoZXIuY3RybEtleSAmJiB0aGlzLnNoaWZ0S2V5ID09PSBvdGhlci5zaGlmdEtleTtcbiAgICB9XG5cbiAgICBzdGF0aWMgQ1VSUkVOVF9UQUIgPSBuZXcgS2V5U3RhdGUoZmFsc2UsIGZhbHNlKTtcbiAgICBzdGF0aWMgTkVXX1RBQl9BQ1RJVkUgPSBuZXcgS2V5U3RhdGUodHJ1ZSwgdHJ1ZSk7XG4gICAgc3RhdGljIE5FV19UQUJfSU5BQ1RJVkUgPSBuZXcgS2V5U3RhdGUodHJ1ZSwgZmFsc2UpO1xuICAgIHN0YXRpYyBORVdfV0lORE9XID0gbmV3IEtleVN0YXRlKGZhbHNlLCB0cnVlKTtcbiAgfTtcblxuICAvKipcbiAgICogQHR5cGUgeyFIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9ufVxuICAgKi9cbiAgZGlzcG9zaXRpb247XG5cbiAgLyoqXG4gICAqIEF2YWlsYWJsZSBvbmx5IGlmIGBkaXNwb3NpdGlvbiA9PT0gIE5FV19UQUJgLlxuICAgKlxuICAgKiBAdHlwZSB7Ym9vbGVhbj19XG4gICAqL1xuICBhY3RpdmU7XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7IUhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb259IGRpc3Bvc2l0aW9uXG4gICAqIEBwYXJhbSB7Ym9vbGVhbj19IGFjdGl2ZSBBdmFpbGFibGUgb25seSBpZiBgZGlzcG9zaXRpb24gPT09ICBORVdfVEFCYC5cbiAgICovXG4gIGNvbnN0cnVjdG9yKGRpc3Bvc2l0aW9uLCBhY3RpdmUgPSB0cnVlKSB7XG4gICAgdGhpcy5kaXNwb3NpdGlvbiA9IGRpc3Bvc2l0aW9uO1xuICAgIHRoaXMuYWN0aXZlID0gYWN0aXZlO1xuICB9XG5cbiAgc3RhdGljIENVUlJFTlRfVEFCID0gbmV3IEhvd1RvT3BlbkxpbmsoSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5DVVJSRU5UX1RBQik7XG4gIHN0YXRpYyBORVdfVEFCX0FDVElWRSA9IG5ldyBIb3dUb09wZW5MaW5rKEhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb24uTkVXX1RBQiwgdHJ1ZSk7XG4gIHN0YXRpYyBORVdfVEFCX0lOQUNUSVZFID0gbmV3IEhvd1RvT3BlbkxpbmsoSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5ORVdfVEFCLCBmYWxzZSk7XG4gIHN0YXRpYyBORVdfV0lORE9XID0gbmV3IEhvd1RvT3BlbkxpbmsoSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5ORVdfV0lORE9XKTtcblxuICAvKipcbiAgICogRGVjaWRlcyBsb2NhdGlvbiB3aGVyZSBhIGxpbmsgc2hvdWxkIGJlIG9wZW5lZC5cbiAgICpcbiAgICogQHBhcmFtIHs/SG93VG9PcGVuTGluay5LZXlTdGF0ZT19IGtleVN0YXRlXG4gICAqIEBwYXJhbSB7P0hvd1RvT3Blbkxpbms9fSBkZWZhdWx0SG93VG9PcGVuTGlua1xuICAgKiBAcmV0dXJucyB7IUhvd1RvT3Blbkxpbmt9XG4gICAqL1xuICBzdGF0aWMgZGVjaWRlKGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluaykge1xuICAgIGlmIChIb3dUb09wZW5MaW5rLktleVN0YXRlLk5FV19UQUJfQUNUSVZFLmVxdWFscyhrZXlTdGF0ZSkpIHJldHVybiBIb3dUb09wZW5MaW5rLk5FV19UQUJfQUNUSVZFO1xuICAgIGVsc2UgaWYgKEhvd1RvT3BlbkxpbmsuS2V5U3RhdGUuTkVXX1RBQl9JTkFDVElWRS5lcXVhbHMoa2V5U3RhdGUpKSByZXR1cm4gSG93VG9PcGVuTGluay5ORVdfVEFCX0lOQUNUSVZFO1xuICAgIGVsc2UgaWYgKEhvd1RvT3BlbkxpbmsuS2V5U3RhdGUuTkVXX1dJTkRPVy5lcXVhbHMoa2V5U3RhdGUpKSByZXR1cm4gSG93VG9PcGVuTGluay5ORVdfV0lORE9XO1xuICAgIGVsc2UgcmV0dXJuIGRlZmF1bHRIb3dUb09wZW5MaW5rID8/IEhvd1RvT3BlbkxpbmsuQ1VSUkVOVF9UQUI7XG4gIH1cbn1cbiIsImltcG9ydCB7IGNvbmZpZyB9IGZyb20gXCIuL19fY29uZmlnLmpzXCI7XG5cbi8qKlxuICogT3V0cHV0cyBsb2dzIG9ubHkgaWYgYGNvbmZpZy5sb2dFbmFibGVkYCBpcyB0cnVlLiBPdGhlcndpc2UsIGFsbCBvZiB0aGVcbiAqIGluc3RhbmNlIG1ldGhvZHMgb2YgdGhpcyBjbGFzcyBoYXZlIG5vIG9wZXJhdGlvbnMgKGllIGVtcHR5KS5cbiAqL1xuZXhwb3J0IGNsYXNzIExvZ2dlciB7XG4gICNpZDtcblxuICAvKipcbiAgICogQHBhcmFtIHshc3RyaW5nfSBpZCBBcHBlYXJzIGF0IHRoZSBiZWdpbm5pbmcgb2YgdGhlIGxvZyBtZXNzYWdlLCBlbmNsb3NlZFxuICAgKiAgICBpbiBzcXVhcmUgYnJhY2tldHMuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihpZCkge1xuICAgIHRoaXMuI2lkID0gaWQ7XG4gIH1cblxuICAvKipcbiAgICogQHBhcmFtIHshc3RyaW5nfSBpZFxuICAgKi9cbiAgc2V0SWQoaWQpIHtcbiAgICB0aGlzLiNpZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUuZGVidWcoKWAgd2l0aCB0aGUgaGVhZGVyIGBbSU5GT11gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBpbmZvKG1lc3NhZ2UsIC4uLmFyZ3MpIHtcbiAgICB0aGlzLiNvdXRwdXQoXCJkZWJ1Z1wiLCBcIltJTkZPXVwiLCBtZXNzYWdlLCBhcmdzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIGBjb25zb2xlLmRlYnVnKClgIHdpdGggdGhlIGhlYWRlciBgW1NUQVRFXWAgcHJlcGVuZGVkIHRvIHRoZSBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0geyFzdHJpbmd9IG1lc3NhZ2VcbiAgICogQHBhcmFtIHsuLi5hbnk9fSBhcmdzIGFyZ3VtZW50cyBmb3IgdGhlIHN1YnN0aXR1dGlvbnMgaWYgaW5jbHVkZWQgaW4gdGhlXG4gICAqICAgIG1lc3NhZ2UuIElmIHNwZWNpZnlpbmcgYW4gb2JqZWN0IChrZXktdmFsdWUgcGFpcnMpIGF0IHRoZSBlbmQsIGl0IHdpbGxcbiAgICogICAgYmUgZGVjb21wb3NlZCBhbmQgb3V0cHV0IGluIHRoZSBmb3JtIGBcXG4ke2tleX09ICR7dmFsdWV9YC5cbiAgICovXG4gIHN0YXRlKG1lc3NhZ2UsIC4uLmFyZ3MpIHtcbiAgICB0aGlzLiNvdXRwdXQoXCJkZWJ1Z1wiLCBcIltTVEFURV1cIiwgbWVzc2FnZSwgYXJncyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBgY29uc29sZS5kZWJ1ZygpYCB3aXRoIHRoZSBoZWFkZXIgYFtDQUxMQkFDS11gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBjYWxsYmFjayhtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiZGVidWdcIiwgXCJbQ0FMTEJBQ0tdXCIsIG1lc3NhZ2UsIGFyZ3MpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUud2FybigpYCB3aXRoIHRoZSBoZWFkZXIgYFtXQVJOXWAgcHJlcGVuZGVkIHRvIHRoZSBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0geyFzdHJpbmd9IG1lc3NhZ2VcbiAgICogQHBhcmFtIHsuLi5hbnk9fSBhcmdzIGFyZ3VtZW50cyBmb3IgdGhlIHN1YnN0aXR1dGlvbnMgaWYgaW5jbHVkZWQgaW4gdGhlXG4gICAqICAgIG1lc3NhZ2UuIElmIHNwZWNpZnlpbmcgYW4gb2JqZWN0IChrZXktdmFsdWUgcGFpcnMpIGF0IHRoZSBlbmQsIGl0IHdpbGxcbiAgICogICAgYmUgZGVjb21wb3NlZCBhbmQgb3V0cHV0IGluIHRoZSBmb3JtIGBcXG4ke2tleX09ICR7dmFsdWV9YC5cbiAgICovXG4gIHdhcm4obWVzc2FnZSwgLi4uYXJncykge1xuICAgIHRoaXMuI291dHB1dChcIndhcm5cIiwgXCJbV0FSTl1cIiwgbWVzc2FnZSwgYXJncyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBgY29uc29sZS5lcnJvcigpYCB3aXRoIHRoZSBoZWFkZXIgYFtFUlJPUl1gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBlcnJvcihtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiZXJyb3JcIiwgXCJbRVJST1JdXCIsIG1lc3NhZ2UsIGFyZ3MpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUuYXNzZXJ0KClgIHdpdGggdGhlIGhlYWRlciBgW0VSUk9SXWAgcHJlcGVuZGVkIHRvIHRoZSBtZXNzYWdlLlxuICAgKlxuICAgKiBAcGFyYW0geyFib29sZWFufSBhc3NlcnRpb25cbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBhc3NlcnQoYXNzZXJ0aW9uLCBtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiYXNzZXJ0XCIsIFwiW0VSUk9SXVwiLCBtZXNzYWdlLCBhcmdzLCBhc3NlcnRpb24pO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgQ29uc29sZSBBUEkgc3BlY2lmaWVkIGJ5IHRoZSBgbWV0aG9kYCBhcmd1bWVudC5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBjb25zb2xlQXBpIENvbnNvbGUgQVBJIHRvIGNhbGwuXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gaGVhZGVyXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gbWVzc2FnZVxuICAgKiBAcGFyYW0gez9hbnlbXT19IGFyZ3NcbiAgICogQHBhcmFtIHs/Ym9vbGVhbj19IGFzc2VydGlvbiBtdXN0IGJlIHNwZWNpZmllZCBpZiBgbWV0aG9kYCBpcyBcImFzc2VydFwiLCBvdGhlcndpc2UgaWdub3JlZC5cbiAgICovXG4gICNvdXRwdXQoY29uc29sZUFwaSwgaGVhZGVyLCBtZXNzYWdlLCBhcmdzLCBhc3NlcnRpb24pIHtcbiAgICBpZiAoIWNvbmZpZy5sb2dFbmFibGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3Qgb3B0aW9uYWxBcmdzID0gW107XG4gICAgaWYgKGFyZ3MgJiYgYXJncy5sZW5ndGggPiAwICYmIHR5cGVvZiBhcmdzLmF0KC0xKSA9PT0gXCJvYmplY3RcIikge1xuICAgICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoYXJncy5wb3AoKSkpIHtcbiAgICAgICAgb3B0aW9uYWxBcmdzLnB1c2goYFxcbiR7a2V5fT1gKTtcbiAgICAgICAgb3B0aW9uYWxBcmdzLnB1c2godmFsdWUpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnNvbGVbY29uc29sZUFwaV0oXG4gICAgICAuLi4oY29uc29sZUFwaSA9PT0gXCJhc3NlcnRcIiA/IFshIWFzc2VydGlvbl0gOiBbXSksXG4gICAgICBgWyR7dGhpcy4jaWR9XSAke2hlYWRlcn0gJHttZXNzYWdlfWAsXG4gICAgICAuLi5hcmdzLFxuICAgICAgLi4ub3B0aW9uYWxBcmdzXG4gICAgKTtcbiAgfVxufVxuIiwiaW1wb3J0IHsgSG93VG9PcGVuTGluayB9IGZyb20gXCIuL19faG93X3RvX29wZW5fbGluay5qc1wiO1xuXG4vKipcbiAqIFVzZXItY3VzdG9taXphYmxlIGV4dGVuc2lvbiBvcHRpb25zLlxuICpcbiAqIE9wdGlvbnMgaXMgc3RvcmVkIGluIHRoZVxuICogW3N5bmNdKGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vZG9jcy9leHRlbnNpb25zL3JlZmVyZW5jZS9zdG9yYWdlLyNwcm9wZXJ0eS1zeW5jKVxuICogc3RvcmFnZSBhcmVhIHRoYXQgaXMgc3luY2VkIHVzaW5nIENocm9tZSBTeW5jLlxuICovXG5leHBvcnQgY2xhc3MgT3B0aW9ucyB7XG4gIHN0YXRpYyAjc3RvcmFnZSA9IGNocm9tZS5zdG9yYWdlLnN5bmM7XG5cbiAgc3RhdGljICNTVE9SQUdFX0tFWSA9IFwib3B0aW9uc1wiO1xuXG4gIHN0YXRpYyAjVVBEQVRFRF9BVF9LRVkgPSBcIl9fdXBkYXRlZEF0X19cIjtcblxuICBzdGF0aWMgI0RFRkFVTFRfVkFMVUVTID0ge1xuICAgIFtPcHRpb25zLiNVUERBVEVEX0FUX0tFWV06IDAsXG4gIH07XG5cbiAgc3RhdGljIERpc3Bvc2l0aW9uID0gSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbjtcblxuICBzdGF0aWMgSUNPTl9TSVpFX01JTiA9IDE7XG4gIHN0YXRpYyBJQ09OX1NJWkVfTUFYID0gNTtcblxuICAvLyBwcmV0dGllci1pZ25vcmVcbiAgLyoqXG4gICAqIERlZmluaXRpb24gb2Ygb3B0aW9ucy5cbiAgICpcbiAgICogSnVzdCBhZGQgYSByb3cgaW50byB0aGlzIHRhYmxlIHRvIGFkZCBhIG5ldyBvcHRpb24gaXRlbS4gVGhlIGNvZGUgbmVjZXNzYXJ5XG4gICAqIHRvIHJlYWQgYW5kIHdyaXRlIG9wdGlvbiB2YWx1ZXMgaXMgYXV0b21hdGljYWxseSBnZW5lcmF0ZWQuXG4gICAqXG4gICAqIEB0eXBlIHt7bmFtZTohc3RyaW5nLCBkZWZhdWx0VmFsdWU6ISosIHZhbGlkYXRvcjohZnVuY3Rpb24oPyopOmJvb2xlYW59W119XG4gICAqL1xuICBzdGF0aWMgI0lURU1TID0gW1xuICAgIHsgbmFtZTogXCJwb3B1cEljb25cIiAgICAgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImljb25TaXplXCIgICAgICAsIGRlZmF1bHRWYWx1ZTogMyAgICAgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiICYmIHZhbHVlID49IE9wdGlvbnMuSUNPTl9TSVpFX01JTiAmJiB2YWx1ZSA8PSBPcHRpb25zLklDT05fU0laRV9NQVggfSxcbiAgICB7IG5hbWU6IFwiYXZvaWRTZWxlY3Rpb25cIiwgZGVmYXVsdFZhbHVlOiBmYWxzZSAgICAgICAgICAgICAgICAgICAgICAsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgIHsgbmFtZTogXCJvcHRpb25zQnV0dG9uXCIgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImNvbnRleHRNZW51XCIgICAsIGRlZmF1bHRWYWx1ZTogdHJ1ZSAgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICB7IG5hbWU6IFwiZGlzcG9zaXRpb25cIiAgICwgZGVmYXVsdFZhbHVlOiBPcHRpb25zLkRpc3Bvc2l0aW9uLk5FV19UQUIsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIgJiYgT2JqZWN0LnZhbHVlcyhPcHRpb25zLkRpc3Bvc2l0aW9uKS5pbmNsdWRlcyh2YWx1ZSkgICAgICAgICAgICAgICB9LFxuICAgIHsgbmFtZTogXCJhdXRvQ29weVwiICAgICAgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImF1dG9FbnRlclwiICAgICAsIGRlZmF1bHRWYWx1ZTogdHJ1ZSAgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICB7IG5hbWU6IFwiYXV0b1N1cnJvdW5kXCIgICwgZGVmYXVsdFZhbHVlOiBmYWxzZSAgICAgICAgICAgICAgICAgICAgICAsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICBdO1xuXG4gIHN0YXRpYyAjZGVmaW5lT3B0aW9ucygpIHtcbiAgICBmb3IgKGNvbnN0IHsgbmFtZSwgZGVmYXVsdFZhbHVlLCB2YWxpZGF0b3IgfSBvZiBPcHRpb25zLiNJVEVNUykge1xuICAgICAgT3B0aW9ucy4jREVGQVVMVF9WQUxVRVNbbmFtZV0gPSBkZWZhdWx0VmFsdWU7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoT3B0aW9ucy5wcm90b3R5cGUsIG5hbWUsIHtcbiAgICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgICAgaWYgKCF2YWxpZGF0b3IodmFsdWUpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE9wdGlvbnM6IEludmFsaWQgdmFsdWUgZm9yICcke25hbWV9J1xcbnZhbHVlPSR7dmFsdWV9YCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh2YWx1ZSAhPT0gdGhpcy4jY2FjaGVbbmFtZV0pIHtcbiAgICAgICAgICAgIHRoaXMuI2NhY2hlW25hbWVdID0gdmFsdWU7XG4gICAgICAgICAgICAvKiBhc3luYyAqLyB0aGlzLiN1cGRhdGVTdG9yYWdlKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBnZXQoKSB7XG4gICAgICAgICAgcmV0dXJuIHZhbGlkYXRvcih0aGlzLiNjYWNoZVtuYW1lXSkgPyB0aGlzLiNjYWNoZVtuYW1lXSA6IGRlZmF1bHRWYWx1ZTtcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyB7XG4gICAgT3B0aW9ucy4jZGVmaW5lT3B0aW9ucygpO1xuICB9XG5cbiAgLyoqXG4gICAqIEZpcmVkIHdoZW4gb25lIG9yIG1vcmUgb3B0aW9ucyBhcmUgY2hhbmdlZCBleHRlcm5hbGx5LlxuICAgKi9cbiAgb25DaGFuZ2VkID0gbmV3IChjbGFzcyBvbkNoYW5nZWQge1xuICAgICNsaXN0ZW5lcnMgPSBbXTtcbiAgICAvKipcbiAgICAgKiBAcGFyYW0geyFmdW5jdGlvbighT3B0aW9ucyk6dm9pZH0gbGlzdGVuZXJcbiAgICAgKi9cbiAgICBhZGRMaXN0ZW5lcihsaXN0ZW5lcikge1xuICAgICAgdGhpcy4jbGlzdGVuZXJzLnB1c2gobGlzdGVuZXIpO1xuICAgIH1cbiAgICBfZmlyZSgpIHtcbiAgICAgIGZvciAoY29uc3QgbGlzdGVuZXIgb2YgdGhpcy4jbGlzdGVuZXJzKSB7XG4gICAgICAgIGxpc3RlbmVyKCk7XG4gICAgICB9XG4gICAgfVxuICB9KSgpO1xuXG4gICNsb2dnZXI7XG4gICNjYWNoZTtcblxuICAvKipcbiAgICogQHBhcmFtIHshTG9nZ2VyfSBsb2dnZXJcbiAgICovXG4gIGNvbnN0cnVjdG9yKGxvZ2dlcikge1xuICAgIHRoaXMuI2xvZ2dlciA9IGxvZ2dlcjtcbiAgICB0aGlzLiNjYWNoZSA9IE9iamVjdC5hc3NpZ24oe30sIE9wdGlvbnMuI0RFRkFVTFRfVkFMVUVTKTtcblxuICAgIE9wdGlvbnMuI3N0b3JhZ2Uub25DaGFuZ2VkLmFkZExpc3RlbmVyKChjaGFuZ2VzLCBhcmVhTmFtZSkgPT4ge1xuICAgICAgdGhpcy4jb25DaGFuZ2VkTGlzdGVuZXIoY2hhbmdlcywgYXJlYU5hbWUpO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIExvYWQgb3B0aW9ucyBmcm9tIHRoZSBzdG9yYWdlLlxuICAgKi9cbiAgYXN5bmMgaW5pdCgpIHtcbiAgICBjb25zdCB2YWx1ZXMgPSBhd2FpdCBPcHRpb25zLiNzdG9yYWdlLmdldChPcHRpb25zLiNTVE9SQUdFX0tFWSk7XG4gICAgLy8gTWVyZ2UgcmF0aGVyIHRoYW4gYXNzaWduIHRvIGVuc3VyZSBjb21wbGV0ZW5lc3Mgb2Ygb3B0aW9ucyBpbiBjYXNlIG9mXG4gICAgLy8gbWlzc2luZyBkYXRhIGluIHRoZSBzdG9yYWdlLlxuICAgIE9iamVjdC5hc3NpZ24odGhpcy4jY2FjaGUsIHZhbHVlc1tPcHRpb25zLiNTVE9SQUdFX0tFWV0pO1xuICAgIHRoaXMuI2xvZ2dlci5zdGF0ZShcIk9wdGlvbnM6IEluaXRpYWxpemVkXCIsIHsgW1widGhpcy4jY2FjaGVcIl06IHRoaXMuI2NhY2hlIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlc2V0IGFsbCBvcHRpb25zIHRvIHJlc3RvcmUgZGVmYXVsdHMuXG4gICAqL1xuICByZXNldCgpIHtcbiAgICB0aGlzLiNjYWNoZSA9IE9iamVjdC5hc3NpZ24oe30sIE9wdGlvbnMuI0RFRkFVTFRfVkFMVUVTKTtcbiAgICAvKiBhc3luYyAqLyB0aGlzLiN1cGRhdGVTdG9yYWdlKCk7XG4gIH1cblxuICBhc3luYyAjdXBkYXRlU3RvcmFnZSgpIHtcbiAgICB0aGlzLiNjYWNoZVtPcHRpb25zLiNVUERBVEVEX0FUX0tFWV0gPSBEYXRlLm5vdygpO1xuICAgIGNvbnN0IHZhbHVlcyA9IHsgW09wdGlvbnMuI1NUT1JBR0VfS0VZXTogdGhpcy4jY2FjaGUgfTtcbiAgICB0aGlzLiNsb2dnZXIuc3RhdGUoXCJPcHRpb25zOiBVcGRhdGUgc3RvcmFnZVwiLCB7IHZhbHVlcyB9KTtcbiAgICBhd2FpdCBPcHRpb25zLiNzdG9yYWdlLnNldCh2YWx1ZXMpO1xuICB9XG5cbiAgI29uQ2hhbmdlZExpc3RlbmVyKGNoYW5nZXMsIGFyZWFOYW1lKSB7XG4gICAgdGhpcy4jbG9nZ2VyLmNhbGxiYWNrKFwiT3B0aW9uczogb25DaGFuZ2VkTGlzdGVuZXIoKVwiLCB7IGNoYW5nZXMsIGFyZWFOYW1lIH0pO1xuXG4gICAgaWYgKCFPYmplY3QuaGFzT3duKGNoYW5nZXMsIE9wdGlvbnMuI1NUT1JBR0VfS0VZKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChPYmplY3QuaGFzT3duKGNoYW5nZXNbT3B0aW9ucy4jU1RPUkFHRV9LRVldLCBcIm5ld1ZhbHVlXCIpKSB7XG4gICAgICBjb25zdCBuZXdWYWx1ZSA9IGNoYW5nZXNbT3B0aW9ucy4jU1RPUkFHRV9LRVldLm5ld1ZhbHVlO1xuICAgICAgaWYgKG5ld1ZhbHVlW09wdGlvbnMuI1VQREFURURfQVRfS0VZXSA8PSB0aGlzLiNjYWNoZVtPcHRpb25zLiNVUERBVEVEX0FUX0tFWV0pIHtcbiAgICAgICAgdGhpcy4jbG9nZ2VyLmluZm8oXCJPcHRpb25zOiBDYWNoZSB3YXMgbm90IG92ZXJ3cml0dGVuIGJlY2F1c2UgaXQgaXMgdXAgdG8gZGF0ZVwiLCB7XG4gICAgICAgICAgW1widGhpcy4jY2FjaGVcIl06IHRoaXMuI2NhY2hlLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBNZXJnZSByYXRoZXIgdGhhbiBhc3NpZ24gdG8gZW5zdXJlIGNvbXBsZXRlbmVzcyBvZiBvcHRpb25zIGluIGNhc2Ugb2ZcbiAgICAgIC8vIG1pc3NpbmcgZGF0YSBpbiB0aGUgc3RvcmFnZS5cbiAgICAgIE9iamVjdC5hc3NpZ24odGhpcy4jY2FjaGUsIG5ld1ZhbHVlKTtcbiAgICAgIHRoaXMuI2xvZ2dlci5zdGF0ZShcIk9wdGlvbnM6IENhY2hlIHdhcyBvdmVyd3JpdHRlbiBieSB2YWx1ZXMgaW4gc3RvcmFnZSB1cGRhdGVkIGJ5IG90aGVyXCIsIHtcbiAgICAgICAgW1widGhpcy4jY2FjaGVcIl06IHRoaXMuI2NhY2hlLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIFRoZSBzdG9yYWdlIGhhcyBiZWVuIGNsZWFyZWQuXG5cbiAgICAgIHRoaXMuI2NhY2hlID0gT2JqZWN0LmFzc2lnbih7fSwgT3B0aW9ucy4jREVGQVVMVF9WQUxVRVMpO1xuICAgICAgdGhpcy4jbG9nZ2VyLnN0YXRlKFwiT3B0aW9uczogQ2FjaGUgd2FzIHJlc2V0IHRvIGRlZmF1bHQgdmFsdWVzIGJlY2F1c2UgdGhlIHN0b3JhZ2UgaGFzIGJlZW4gY2xlYXJlZFwiLCB7XG4gICAgICAgIFtcInRoaXMuI2NhY2hlXCJdOiB0aGlzLiNjYWNoZSxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHRoaXMub25DaGFuZ2VkLl9maXJlKCk7XG4gIH1cbn1cbiIsIi8qKlxuICogQGZpbGUgQWdncmVnYXRlcyBtb2R1bGVzLlxuICovXG5cbmV4cG9ydCAqIGZyb20gXCIuL19fY29uZmlnLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9fX2NvbnN0YW50cy5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19mdW5jdGlvbnMuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL19fZ2xvYmFscy5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19ob3dfdG9fb3Blbl9saW5rLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9fX2xvZ2dlci5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19vcHRpb25zLmpzXCI7XG4iLCJpbXBvcnQgKiBhcyBxcXMgZnJvbSBcIi4vY29tbW9uLmpzXCI7XG5cbi8qKlxuICogQ2FwdHVyaW5nIHN0YXRlIG9mIG1vZGlmaWVyIGtleXMuXG4gKi9cbmV4cG9ydCBjbGFzcyBNb2RpZmllcktleXMge1xuICAvKipcbiAgICogQHR5cGUgeyFIb3dUb09wZW5MaW5rLktleVN0YXRlfVxuICAgKi9cbiAgI2tleVN0YXRlID0gbmV3IHFxcy5Ib3dUb09wZW5MaW5rLktleVN0YXRlKGZhbHNlLCBmYWxzZSwgZmFsc2UpO1xuXG4gIC8qKlxuICAgKiAgQHBhcmFtIHshV2luZG93fSB3aW5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHdpbikge1xuICAgIFtcImtleWRvd25cIiwgXCJrZXl1cFwiLCBcImNsaWNrXCJdLmZvckVhY2goKHR5cGUpID0+IHtcbiAgICAgIHdpbi5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICAgICAgdHlwZSxcbiAgICAgICAgKGUpID0+ICh0aGlzLiNrZXlTdGF0ZSA9IG5ldyBxcXMuSG93VG9PcGVuTGluay5LZXlTdGF0ZShlLmN0cmxLZXksIGUuc2hpZnRLZXksIGUubWV0YUtleSkpXG4gICAgICApO1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIEByZXR1cm5zIHshSG93VG9PcGVuTGluay5LZXlTdGF0ZX1cbiAgICovXG4gIGdldCBrZXlTdGF0ZSgpIHtcbiAgICByZXR1cm4gdGhpcy4ja2V5U3RhdGU7XG4gIH1cbn1cbiIsImltcG9ydCAqIGFzIHFxcyBmcm9tIFwiLi9jb21tb24uanNcIjtcblxuLyoqXG4gKiBSZXByZXNlbnQgdGhlIGNvbm5lY3Rpb24gdG8gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciwgYW5kIHByb3ZpZGUgYWJpbGl0eSB0b1xuICogcmUtY29ubmVjdCB0byBpdCBhdXRvbWF0aWNhbGx5IGlmIGl0IGlzIGlkbGUgKGkuZS4gaXMgZGlzY29ubmVjdGVkKS5cbiAqL1xuZXhwb3J0IGNsYXNzIFBvcnRUb0JhY2tncm91bmQge1xuICAjcG9ydDtcblxuICAjcGFyYW1zID0ge1xuICAgIG5hbWU6IFwiXCIsXG4gICAgYXV0b0Nvbm5lY3Q6IGZhbHNlLFxuICAgIG9uQ29ubmVjdDogKCkgPT4ge30sXG4gICAgb25EaXNjb25uZWN0OiAoKSA9PiB7fSxcbiAgICBvbk1lc3NhZ2U6ICgpID0+IHt9LFxuICB9O1xuXG4gIC8qKlxuICAgKiBAcGFyYW0gez97bmFtZTo/c3RyaW5nPSxhdXRvQ29ubmVjdDo/Ym9vbGVhbj0sb25Db25uZWN0Oj9mdW5jdGlvbigpOnZvaWQ9LG9uRGlzY29ubmVjdDo/ZnVuY3Rpb24oKTp2b2lkPSxvbk1lc3NhZ2U6P2Z1bmN0aW9uKCEqKTp2b2lkPX09fSBwYXJhbXNcbiAgICovXG4gIGNvbnN0cnVjdG9yKHBhcmFtcykge1xuICAgIHRoaXMuI3BhcmFtcyA9IHFxcy5tZXJnZU9iamVjdCh0aGlzLiNwYXJhbXMsIHBhcmFtcyk7XG4gIH1cblxuICBjb25uZWN0KCkge1xuICAgIGlmICh0aGlzLiNwb3J0KSB7XG4gICAgICBxcXMubG9nZ2VyLndhcm4oXCJBbHJlYWR5IGNvbm5lY3RlZFwiLCB7IHBvcnQ6IHRoaXMuI3BvcnQgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuI3BvcnQgPSBjaHJvbWUucnVudGltZS5jb25uZWN0KHVuZGVmaW5lZCwgeyBuYW1lOiB0aGlzLiNwYXJhbXMubmFtZSB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgLy8gVGhlIGV4dGVuc2lvbiBtaWdodCBoYXZlIGJlZW4gcmVmcmVzaGVkLCBpbiB3aGljaCBjYXNlIGl0IHdpbGwgbmV2ZXIgYmVcbiAgICAgIC8vIGFibGUgdG8gY29ubmVjdCB0byBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyIGZyb20gdGhpcyBjb250ZXh0IGFnYWluLlxuICAgICAgcXFzLmxvZ2dlci5pbmZvKFxuICAgICAgICBcIuKaoCBUaGUgZXh0ZW5zaW9uIG1pZ2h0IGhhdmUgYmVlbiByZWZyZXNoZWQsIGluIHdoaWNoIGNhc2UgaXQgaXMgaW1wb3NzaWJsZSB0byBjb25uZWN0IHRvIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcIixcbiAgICAgICAgeyBlcnJvciB9XG4gICAgICApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBxcXMubG9nZ2VyLnN0YXRlKFwiQ29ubmVjdGVkIHRvIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcIiwgeyBwb3J0OiB0aGlzLiNwb3J0IH0pO1xuXG4gICAgdGhpcy4jcG9ydC5vbkRpc2Nvbm5lY3QuYWRkTGlzdGVuZXIoKHBvcnQpID0+IHRoaXMuI29uRGlzY29ubmVjdChwb3J0KSk7XG4gICAgdGhpcy4jcG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UsIHBvcnQpID0+IHRoaXMuI29uTWVzc2FnZShtZXNzYWdlLCBwb3J0KSk7XG5cbiAgICB0aGlzLiNwYXJhbXMub25Db25uZWN0KCk7XG4gIH1cblxuICBkaXNjb25uZWN0KCkge1xuICAgIGlmICh0aGlzLiNwb3J0KSB7XG4gICAgICB0aGlzLiNwb3J0LmRpc2Nvbm5lY3QoKTtcbiAgICAgIHRoaXMuI3BvcnQgPSB1bmRlZmluZWQ7XG4gICAgICBxcXMubG9nZ2VyLnN0YXRlKFwiRGlzY29ubmVjdGVkIGZyb20gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlclwiKTtcbiAgICB9XG4gIH1cblxuICByZWNvbm5lY3QoKSB7XG4gICAgdGhpcy5kaXNjb25uZWN0KCk7XG4gICAgdGhpcy5jb25uZWN0KCk7XG4gIH1cblxuICAvKipcbiAgICogQHJldHVybnMgeyFjaHJvbWUucnVudGltZS5Qb3J0fVxuICAgKi9cbiAgZ2V0IHBvcnQoKSB7XG4gICAgcmV0dXJuIHRoaXMuI3BvcnQ7XG4gIH1cblxuICAvKipcbiAgICogQHBhcmFtIHshKn0gbWVzc2FnZVxuICAgKi9cbiAgcG9zdE1lc3NhZ2UobWVzc2FnZSkge1xuICAgIGlmICghdGhpcy4jY2hlY2tDb25uZWN0aW9uKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBxcXMucG9zdE1lc3NhZ2UodGhpcy4jcG9ydCwgbWVzc2FnZSk7XG4gIH1cblxuICAjY2hlY2tDb25uZWN0aW9uKCkge1xuICAgIGlmICghdGhpcy4jcG9ydCkge1xuICAgICAgaWYgKHRoaXMuI3BhcmFtcy5hdXRvQ29ubmVjdCkge1xuICAgICAgICB0aGlzLmNvbm5lY3QoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHFxcy5sb2dnZXIud2FybihcIkNvdWxkIG5vdCBzZW5kIG1lc3NhZ2UgdG8gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBiZWNhdXNlIHRoZSBwb3J0IGhhcyBhbHJlYWR5IGJlZW4gY2xvc2VkXCIpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gISF0aGlzLiNwb3J0O1xuICB9XG5cbiAgI29uRGlzY29ubmVjdChwb3J0KSB7XG4gICAgcXFzLmxvZ2dlci5jYWxsYmFjayhcIm9uRGlzY29ubmVjdCgpXCIsIHsgcG9ydCB9KTtcblxuICAgIHRoaXMuI3BvcnQgPSB1bmRlZmluZWQ7XG4gICAgcXFzLmxvZ2dlci5zdGF0ZShcIlBvcnQgdG8gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciBoYXMgYmVlbiBjbG9zZWQgYnkgdGhlIG90aGVyIGVuZFwiKTtcblxuICAgIHRoaXMuI3BhcmFtcy5vbkRpc2Nvbm5lY3QoKTtcbiAgfVxuXG4gICNvbk1lc3NhZ2UobWVzc2FnZSwgcG9ydCkge1xuICAgIHFxcy5sb2dnZXIuY2FsbGJhY2soXCJvbk1lc3NhZ2UoKVwiLCB7IG1lc3NhZ2UsIHBvcnQgfSk7XG5cbiAgICB0aGlzLiNwYXJhbXMub25NZXNzYWdlKG1lc3NhZ2UpO1xuICB9XG59XG4iLCIvLyBleHRyYWN0ZWQgYnkgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5cbmV4cG9ydCB7fTsiLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdKG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuIiwiLy8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbl9fd2VicGFja19yZXF1aXJlX18ubiA9IChtb2R1bGUpID0+IHtcblx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG5cdFx0KCkgPT4gKG1vZHVsZVsnZGVmYXVsdCddKSA6XG5cdFx0KCkgPT4gKG1vZHVsZSk7XG5cdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsIHsgYTogZ2V0dGVyIH0pO1xuXHRyZXR1cm4gZ2V0dGVyO1xufTsiLCIvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9ucyBmb3IgaGFybW9ueSBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSAoZXhwb3J0cywgZGVmaW5pdGlvbikgPT4ge1xuXHRmb3IodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG5cdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGRlZmluaXRpb24sIGtleSkgJiYgIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBrZXkpKSB7XG5cdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuXHRcdH1cblx0fVxufTsiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLmcgPSAoZnVuY3Rpb24oKSB7XG5cdGlmICh0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gJ29iamVjdCcpIHJldHVybiBnbG9iYWxUaGlzO1xuXHR0cnkge1xuXHRcdHJldHVybiB0aGlzIHx8IG5ldyBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09ICdvYmplY3QnKSByZXR1cm4gd2luZG93O1xuXHR9XG59KSgpOyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJ2YXIgc2NyaXB0VXJsO1xuaWYgKF9fd2VicGFja19yZXF1aXJlX18uZy5pbXBvcnRTY3JpcHRzKSBzY3JpcHRVcmwgPSBfX3dlYnBhY2tfcmVxdWlyZV9fLmcubG9jYXRpb24gKyBcIlwiO1xudmFyIGRvY3VtZW50ID0gX193ZWJwYWNrX3JlcXVpcmVfXy5nLmRvY3VtZW50O1xuaWYgKCFzY3JpcHRVcmwgJiYgZG9jdW1lbnQpIHtcblx0aWYgKGRvY3VtZW50LmN1cnJlbnRTY3JpcHQpXG5cdFx0c2NyaXB0VXJsID0gZG9jdW1lbnQuY3VycmVudFNjcmlwdC5zcmNcblx0aWYgKCFzY3JpcHRVcmwpIHtcblx0XHR2YXIgc2NyaXB0cyA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKFwic2NyaXB0XCIpO1xuXHRcdGlmKHNjcmlwdHMubGVuZ3RoKSBzY3JpcHRVcmwgPSBzY3JpcHRzW3NjcmlwdHMubGVuZ3RoIC0gMV0uc3JjXG5cdH1cbn1cbi8vIFdoZW4gc3VwcG9ydGluZyBicm93c2VycyB3aGVyZSBhbiBhdXRvbWF0aWMgcHVibGljUGF0aCBpcyBub3Qgc3VwcG9ydGVkIHlvdSBtdXN0IHNwZWNpZnkgYW4gb3V0cHV0LnB1YmxpY1BhdGggbWFudWFsbHkgdmlhIGNvbmZpZ3VyYXRpb25cbi8vIG9yIHBhc3MgYW4gZW1wdHkgc3RyaW5nIChcIlwiKSBhbmQgc2V0IHRoZSBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyB2YXJpYWJsZSBmcm9tIHlvdXIgY29kZSB0byB1c2UgeW91ciBvd24gbG9naWMuXG5pZiAoIXNjcmlwdFVybCkgdGhyb3cgbmV3IEVycm9yKFwiQXV0b21hdGljIHB1YmxpY1BhdGggaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGJyb3dzZXJcIik7XG5zY3JpcHRVcmwgPSBzY3JpcHRVcmwucmVwbGFjZSgvIy4qJC8sIFwiXCIpLnJlcGxhY2UoL1xcPy4qJC8sIFwiXCIpLnJlcGxhY2UoL1xcL1teXFwvXSskLywgXCIvXCIpO1xuX193ZWJwYWNrX3JlcXVpcmVfXy5wID0gc2NyaXB0VXJsOyIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vYWN0aW9uLmpzXCIpO1xuX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vYWN0aW9uLnNjc3NcIik7XG4vLyBUaGlzIGVudHJ5IG1vZHVsZSBkb2Vzbid0IHRlbGwgYWJvdXQgaXQncyB0b3AtbGV2ZWwgZGVjbGFyYXRpb25zIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vYWN0aW9uLmh0bWxcIik7XG4iLCIiXSwibmFtZXMiOlsiTURDRm91bmRhdGlvbiIsInJvb3QiLCJmb3VuZGF0aW9uIiwiX2kiLCJhcmdzIiwiaW5pdGlhbGl6ZSIsInVuZGVmaW5lZCIsImdldERlZmF1bHRGb3VuZGF0aW9uIiwiaW5pdCIsImluaXRpYWxTeW5jV2l0aERPTSIsIk1EQ0NvbXBvbmVudCIsIl9hcmdzIiwiRXJyb3IiLCJkZXN0cm95IiwiZXZ0VHlwZSIsImhhbmRsZXIiLCJvcHRpb25zIiwiYWRkRXZlbnRMaXN0ZW5lciIsInJlbW92ZUV2ZW50TGlzdGVuZXIiLCJldnREYXRhIiwic2hvdWxkQnViYmxlIiwiZXZ0IiwiQ3VzdG9tRXZlbnQiLCJidWJibGVzIiwiZGV0YWlsIiwiZG9jdW1lbnQiLCJjcmVhdGVFdmVudCIsImluaXRDdXN0b21FdmVudCIsImRpc3BhdGNoRXZlbnQiLCJhZGFwdGVyIiwiT2JqZWN0IiwiYXBwbHlQYXNzaXZlIiwiZ2xvYmFsT2JqIiwic3VwcG9ydHNQYXNzaXZlT3B0aW9uIiwicGFzc2l2ZSIsInBhc3NpdmVTdXBwb3J0ZWQiLCJlcnIiLCJjbG9zZXN0IiwiZWxlbWVudCIsInNlbGVjdG9yIiwiZWwiLCJtYXRjaGVzIiwicGFyZW50RWxlbWVudCIsIm5hdGl2ZU1hdGNoZXMiLCJ3ZWJraXRNYXRjaGVzU2VsZWN0b3IiLCJtc01hdGNoZXNTZWxlY3RvciIsImNhbGwiLCJlc3RpbWF0ZVNjcm9sbFdpZHRoIiwiaHRtbEVsIiwib2Zmc2V0UGFyZW50Iiwic2Nyb2xsV2lkdGgiLCJjbG9uZSIsImNsb25lTm9kZSIsInN0eWxlIiwic2V0UHJvcGVydHkiLCJkb2N1bWVudEVsZW1lbnQiLCJhcHBlbmRDaGlsZCIsInJlbW92ZUNoaWxkIiwiTURDUmlwcGxlRm91bmRhdGlvbiIsInV0aWwiLCJfX2V4dGVuZHMiLCJfdGhpcyIsIk1EQ1JpcHBsZSIsIm9wdHMiLCJpc1VuYm91bmRlZCIsInJpcHBsZSIsInVuYm91bmRlZCIsImluc3RhbmNlIiwiYWRkQ2xhc3MiLCJjbGFzc05hbWUiLCJjbGFzc0xpc3QiLCJhZGQiLCJicm93c2VyU3VwcG9ydHNDc3NWYXJzIiwic3VwcG9ydHNDc3NWYXJpYWJsZXMiLCJ3aW5kb3ciLCJjb21wdXRlQm91bmRpbmdSZWN0IiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwiY29udGFpbnNFdmVudFRhcmdldCIsInRhcmdldCIsImNvbnRhaW5zIiwiZGVyZWdpc3RlckRvY3VtZW50SW50ZXJhY3Rpb25IYW5kbGVyIiwiZGVyZWdpc3RlckludGVyYWN0aW9uSGFuZGxlciIsImRlcmVnaXN0ZXJSZXNpemVIYW5kbGVyIiwiZ2V0V2luZG93UGFnZU9mZnNldCIsIngiLCJwYWdlWE9mZnNldCIsInkiLCJwYWdlWU9mZnNldCIsImlzU3VyZmFjZUFjdGl2ZSIsImlzU3VyZmFjZURpc2FibGVkIiwiZGlzYWJsZWQiLCJyZWdpc3RlckRvY3VtZW50SW50ZXJhY3Rpb25IYW5kbGVyIiwicmVnaXN0ZXJJbnRlcmFjdGlvbkhhbmRsZXIiLCJyZWdpc3RlclJlc2l6ZUhhbmRsZXIiLCJyZW1vdmVDbGFzcyIsInJlbW92ZSIsInVwZGF0ZUNzc1ZhcmlhYmxlIiwidmFyTmFtZSIsInZhbHVlIiwiQm9vbGVhbiIsInNldFVuYm91bmRlZCIsImFjdGl2YXRlIiwiZGVhY3RpdmF0ZSIsImxheW91dCIsImNyZWF0ZUFkYXB0ZXIiLCJkYXRhc2V0IiwiY3NzQ2xhc3NlcyIsIkJHX0ZPQ1VTRUQiLCJGR19BQ1RJVkFUSU9OIiwiRkdfREVBQ1RJVkFUSU9OIiwiUk9PVCIsIlVOQk9VTkRFRCIsInN0cmluZ3MiLCJWQVJfRkdfU0NBTEUiLCJWQVJfRkdfU0laRSIsIlZBUl9GR19UUkFOU0xBVEVfRU5EIiwiVkFSX0ZHX1RSQU5TTEFURV9TVEFSVCIsIlZBUl9MRUZUIiwiVkFSX1RPUCIsIm51bWJlcnMiLCJERUFDVElWQVRJT05fVElNRU9VVF9NUyIsIkZHX0RFQUNUSVZBVElPTl9NUyIsIklOSVRJQUxfT1JJR0lOX1NDQUxFIiwiUEFERElORyIsIlRBUF9ERUxBWV9NUyIsImdldE5vcm1hbGl6ZWRFdmVudENvb3JkcyIsIkFDVElWQVRJT05fRVZFTlRfVFlQRVMiLCJQT0lOVEVSX0RFQUNUSVZBVElPTl9FVkVOVF9UWVBFUyIsImFjdGl2YXRlZFRhcmdldHMiLCJfc3VwZXIiLCJkZWZhdWx0QWRhcHRlciIsIndpZHRoIiwiaGVpZ2h0IiwibGVmdCIsInRvcCIsImFjdGl2YXRpb25TdGF0ZSIsImRlZmF1bHRBY3RpdmF0aW9uU3RhdGUiLCJhY3RpdmF0aW9uVGltZXJDYWxsYmFjayIsImFjdGl2YXRpb25BbmltYXRpb25IYXNFbmRlZCIsInJ1bkRlYWN0aXZhdGlvblVYTG9naWNJZlJlYWR5IiwiYWN0aXZhdGVIYW5kbGVyIiwiZSIsImFjdGl2YXRlSW1wbCIsImRlYWN0aXZhdGVIYW5kbGVyIiwiZGVhY3RpdmF0ZUltcGwiLCJmb2N1c0hhbmRsZXIiLCJoYW5kbGVGb2N1cyIsImJsdXJIYW5kbGVyIiwiaGFuZGxlQmx1ciIsInJlc2l6ZUhhbmRsZXIiLCJyaWdodCIsImJvdHRvbSIsInN1cHBvcnRzUHJlc3NSaXBwbGUiLCJyZWdpc3RlclJvb3RIYW5kbGVycyIsIlJPT1RfMSIsIlVOQk9VTkRFRF8xIiwicmVxdWVzdEFuaW1hdGlvbkZyYW1lIiwibGF5b3V0SW50ZXJuYWwiLCJhY3RpdmF0aW9uVGltZXIiLCJjbGVhclRpbWVvdXQiLCJmZ0RlYWN0aXZhdGlvblJlbW92YWxUaW1lciIsIlJPT1RfMiIsIlVOQk9VTkRFRF8yIiwicmVtb3ZlQ3NzVmFycyIsImRlcmVnaXN0ZXJSb290SGFuZGxlcnMiLCJkZXJlZ2lzdGVyRGVhY3RpdmF0aW9uSGFuZGxlcnMiLCJsYXlvdXRGcmFtZSIsImNhbmNlbEFuaW1hdGlvbkZyYW1lIiwiYWN0aXZhdGlvbkV2ZW50IiwiaGFzRGVhY3RpdmF0aW9uVVhSdW4iLCJpc0FjdGl2YXRlZCIsImlzUHJvZ3JhbW1hdGljIiwid2FzQWN0aXZhdGVkQnlQb2ludGVyIiwid2FzRWxlbWVudE1hZGVBY3RpdmUiLCJ0eXBlIiwicmlwcGxlU3RyaW5ncyIsImtleXMiLCJmb3JFYWNoIiwia2V5IiwiaW5kZXhPZiIsInByZXZpb3VzQWN0aXZhdGlvbkV2ZW50IiwiaXNTYW1lSW50ZXJhY3Rpb24iLCJoYXNBY3RpdmF0ZWRDaGlsZCIsImxlbmd0aCIsInNvbWUiLCJyZXNldEFjdGl2YXRpb25TdGF0ZSIsInB1c2giLCJyZWdpc3RlckRlYWN0aXZhdGlvbkhhbmRsZXJzIiwiY2hlY2tFbGVtZW50TWFkZUFjdGl2ZSIsImFuaW1hdGVBY3RpdmF0aW9uIiwia2V5Q29kZSIsInRyYW5zbGF0ZVN0YXJ0IiwidHJhbnNsYXRlRW5kIiwiZ2V0RmdUcmFuc2xhdGlvbkNvb3JkaW5hdGVzIiwic3RhcnRQb2ludCIsImVuZFBvaW50Iiwicm1Cb3VuZGVkQWN0aXZhdGlvbkNsYXNzZXMiLCJzZXRUaW1lb3V0IiwiZnJhbWUiLCJpbml0aWFsU2l6ZSIsImFjdGl2YXRpb25IYXNFbmRlZCIsInN0YXRlIiwiYW5pbWF0ZURlYWN0aXZhdGlvbiIsIl9hIiwibWF4RGltIiwiTWF0aCIsIm1heCIsImdldEJvdW5kZWRSYWRpdXMiLCJoeXBvdGVudXNlIiwic3FydCIsInBvdyIsIm1heFJhZGl1cyIsImZsb29yIiwiZmdTY2FsZSIsInVwZGF0ZUxheW91dENzc1ZhcnMiLCJ1bmJvdW5kZWRDb29yZHMiLCJyb3VuZCIsInN1cHBvcnRzQ3NzVmFyaWFibGVzXyIsIndpbmRvd09iaiIsImZvcmNlUmVmcmVzaCIsInN1cHBvcnRzQ3NzVmFycyIsInN1cHBvcnRzRnVuY3Rpb25QcmVzZW50IiwiQ1NTIiwic3VwcG9ydHMiLCJleHBsaWNpdGx5U3VwcG9ydHNDc3NWYXJzIiwid2VBcmVGZWF0dXJlRGV0ZWN0aW5nU2FmYXJpMTBwbHVzIiwicGFnZU9mZnNldCIsImNsaWVudFJlY3QiLCJkb2N1bWVudFgiLCJkb2N1bWVudFkiLCJub3JtYWxpemVkWCIsIm5vcm1hbGl6ZWRZIiwidG91Y2hFdmVudCIsImNoYW5nZWRUb3VjaGVzIiwicGFnZVgiLCJwYWdlWSIsIm1vdXNlRXZlbnQiLCJleHRlbmRTdGF0aWNzIiwiZCIsImIiLCJzZXRQcm90b3R5cGVPZiIsIl9fcHJvdG9fXyIsIkFycmF5IiwicCIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwiVHlwZUVycm9yIiwiU3RyaW5nIiwiX18iLCJjb25zdHJ1Y3RvciIsImNyZWF0ZSIsIl9fYXNzaWduIiwiYXNzaWduIiwidCIsInMiLCJpIiwibiIsImFyZ3VtZW50cyIsImFwcGx5IiwiX19yZXN0IiwiZ2V0T3duUHJvcGVydHlTeW1ib2xzIiwicHJvcGVydHlJc0VudW1lcmFibGUiLCJfX2RlY29yYXRlIiwiZGVjb3JhdG9ycyIsImRlc2MiLCJjIiwiciIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsIlJlZmxlY3QiLCJkZWNvcmF0ZSIsImRlZmluZVByb3BlcnR5IiwiX19wYXJhbSIsInBhcmFtSW5kZXgiLCJkZWNvcmF0b3IiLCJfX21ldGFkYXRhIiwibWV0YWRhdGFLZXkiLCJtZXRhZGF0YVZhbHVlIiwibWV0YWRhdGEiLCJfX2F3YWl0ZXIiLCJ0aGlzQXJnIiwiX2FyZ3VtZW50cyIsIlAiLCJnZW5lcmF0b3IiLCJhZG9wdCIsInJlc29sdmUiLCJQcm9taXNlIiwicmVqZWN0IiwiZnVsZmlsbGVkIiwic3RlcCIsIm5leHQiLCJyZWplY3RlZCIsInJlc3VsdCIsImRvbmUiLCJ0aGVuIiwiX19nZW5lcmF0b3IiLCJib2R5IiwiXyIsImxhYmVsIiwic2VudCIsInRyeXMiLCJvcHMiLCJmIiwiZyIsInZlcmIiLCJTeW1ib2wiLCJpdGVyYXRvciIsInYiLCJvcCIsInBvcCIsIl9fY3JlYXRlQmluZGluZyIsIm8iLCJtIiwiayIsImsyIiwiX19lc01vZHVsZSIsIndyaXRhYmxlIiwiY29uZmlndXJhYmxlIiwiZW51bWVyYWJsZSIsImdldCIsIl9fZXhwb3J0U3RhciIsIl9fdmFsdWVzIiwiX19yZWFkIiwiYXIiLCJlcnJvciIsIl9fc3ByZWFkIiwiY29uY2F0IiwiX19zcHJlYWRBcnJheXMiLCJpbCIsImEiLCJqIiwiamwiLCJfX3NwcmVhZEFycmF5IiwidG8iLCJmcm9tIiwicGFjayIsImwiLCJzbGljZSIsIl9fYXdhaXQiLCJfX2FzeW5jR2VuZXJhdG9yIiwiYXN5bmNJdGVyYXRvciIsInEiLCJyZXN1bWUiLCJzZXR0bGUiLCJmdWxmaWxsIiwic2hpZnQiLCJfX2FzeW5jRGVsZWdhdG9yIiwiX19hc3luY1ZhbHVlcyIsIl9fbWFrZVRlbXBsYXRlT2JqZWN0IiwiY29va2VkIiwicmF3IiwiX19zZXRNb2R1bGVEZWZhdWx0IiwiX19pbXBvcnRTdGFyIiwibW9kIiwiX19pbXBvcnREZWZhdWx0IiwiZGVmYXVsdCIsIl9fY2xhc3NQcml2YXRlRmllbGRHZXQiLCJyZWNlaXZlciIsImtpbmQiLCJoYXMiLCJfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0Iiwic2V0IiwiX19jbGFzc1ByaXZhdGVGaWVsZEluIiwibW9kdWxlIiwiZXhwb3J0cyIsImNvbmZpZyIsInFxcyIsIlBvcnRUb0JhY2tncm91bmQiLCJNb2RpZmllcktleXMiLCJtYWluIiwiU2NyaXB0SWQiLCJBQ1RJT04iLCJNRVNTQUdFX0hBTkRMRVJTIiwiTWVzc2FnZVR5cGUiLCJOT1RJRllfU0VMRUNUSU9OIiwib25Ob3RpZnlTZWxlY3Rpb24iLCJwb3J0VG9CYWNrZ3JvdW5kIiwibmFtZSIsIlVSTCIsImF1dG9Db25uZWN0Iiwib25NZXNzYWdlIiwicGFyZW50VGFiIiwiZ2V0QWN0aXZlVGFiIiwibG9nZ2VyIiwiaW5mbyIsIm1vZGlmaWVyS2V5cyIsImFkZERPTUNvbnRlbnRMb2FkZWRFdmVudExpc3RlbmVyIiwib25ET01Db250ZW50TG9hZGVkIiwibWVzc2FnZSIsInBvcnQiLCJfcG9ydCIsInNlbGVjdGlvbiIsIm5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0Iiwibm9ybWFsaXplU2VsZWN0aW9uVGV4dCIsInRleHQiLCJpc05vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0VmFsaWQiLCJ0ZXh0RmllbGQiLCJnZXRFbGVtZW50QnlJZCIsInNldFNlbGVjdGlvblJhbmdlIiwicG9zdE1lc3NhZ2UiLCJHRVRfU0VMRUNUSU9OIiwidGFiIiwiaW5qZWN0STE4Tk1lc3NhZ2VzSW5IdG1sIiwiZmlsbFNob3J0Y3V0c1RhYmxlIiwib25TZWFyY2hGb3JtU3VibWl0Iiwib25TaG9ydGN1dHNTZXR0aW5nc0xpbmtDbGljayIsIm9wdGlvbnNQYWdlQnV0dG9uIiwib25PcHRpb25zUGFnZUJ1dHRvbkNsaWNrIiwib3B0aW9uc1BhZ2VCdXR0b25SaXBwbGUiLCJwcmV2ZW50RGVmYXVsdCIsImZpbHRlclNlbGVjdGlvblRleHQiLCJhdXRvQ29weSIsIm5hdmlnYXRvciIsImNsaXBib2FyZCIsIndyaXRlVGV4dCIsImRvUXVvdGVkU2VhcmNoIiwia2V5U3RhdGUiLCJvcGVuU2hvcnRjdXRzU2V0dGluZ3MiLCJIb3dUb09wZW5MaW5rIiwiS2V5U3RhdGUiLCJjdHJsS2V5Iiwic2hpZnRLZXkiLCJtZXRhS2V5IiwiTkVXX1RBQl9BQ1RJVkUiLCJvcGVuT3B0aW9uc1BhZ2UiLCJkaXZTaG9ydGN1dHMiLCJjb21tYW5kcyIsImNocm9tZSIsImdldEFsbCIsInNob3J0Y3V0IiwiZGVzY3JpcHRpb24iLCJkaXZTaG9ydGN1dEtleSIsImNyZWF0ZUVsZW1lbnQiLCJzaG9ydGN1dE5hbWUiLCJzcGFuU2hvcnRjdXRLZXkiLCJpbm5lclRleHQiLCJyZXBsYWNlQWxsIiwiaTE4biIsImdldE1lc3NhZ2UiLCJkaXZTaG9ydGN1dERlc2NyaXB0aW9uIiwic3BhblNob3J0Y3V0RGVzY3JpcHRpb24iLCJCQUNLR1JPVU5EIiwiQ09OVEVOVCIsIk9QVElPTlMiLCJDb21tYW5kVHlwZSIsIkRPX1FVT1RFRF9TRUFSQ0giLCJQVVRfUVVPVEVTIiwiSEVMTE8iLCJOT1RJRllfU0VMRUNUSU9OX1VQREFURUQiLCJPUEVOX09QVElPTlNfUEFHRSIsIldFTENPTUUiLCJRVU9UQVRJT05fTUFSS1MiLCJTRUxFQ1RJT05fVEVYVF9NQVhfTEVOR1RIIiwiU0VMRUNUSU9OX1RFWFRfVE9PX0xPTkdfTUFSS0VSIiwic2VsZWN0aW9uVGV4dCIsIlJlZ0V4cCIsInRyaW0iLCJxdW90ZVRleHQiLCJjbG9uZUR0byIsIm9iaiIsIkpTT04iLCJwYXJzZSIsInN0cmluZ2lmeSIsIm1lcmdlT2JqZWN0Iiwic291cmNlIiwiZnJvbUVudHJpZXMiLCJlbnRyaWVzIiwiZmlsdGVyIiwid2luIiwibGlzdGVuZXIiLCJyZWFkeVN0YXRlIiwicXVldWVNaWNyb3Rhc2siLCJhZGRMb2FkQ29tcGxldGVkRXZlbnRMaXN0ZW5lciIsImRvYyIsIkkxOE5fVEFSR0VUUyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJzdWJzdGl0dXRpb25zIiwiaTE4bkFyZ3MiLCJpZHMiLCJzcGxpdCIsImlkIiwiYXJnRWxlbWVudCIsImFyZ1RhcmdldCIsImkxOG5UYXJnZXQiLCJhc3NlcnQiLCJpbmNsdWRlcyIsImkxOG5OYW1lIiwiZ2V0U2VsZWN0aW9uIiwiZmluZFNlbGVjdGlvblJlY3Vyc2l2ZWx5IiwicmFuZ2VDb3VudCIsInJhbmdlIiwiZ2V0UmFuZ2VBdCIsInN0YXJ0Q29udGFpbmVyIiwiZW5kQ29udGFpbmVyIiwiY29tbW9uQW5jZXN0b3JDb250YWluZXIiLCJFbGVtZW50Iiwic2hhZG93Um9vdCIsImVsZW1lbnRzV2l0aFNoYWRvd1Jvb3QiLCJ3YXJuIiwidGFicyIsInF1ZXJ5IiwiYWN0aXZlIiwiY3VycmVudFdpbmRvdyIsImNyZWF0ZU5ld1RhYiIsInBhcmFtcyIsIndpbmRvd0lkIiwib3BlbmVyVGFiSWQiLCJpbmRleCIsInVybCIsImNyZWF0ZU5ld1dpbmRvdyIsIndpbmRvd3MiLCJnZXRDdXJyZW50Iiwic2VhcmNoVGV4dCIsImhvd1RvT3BlbkxpbmsiLCJkZWNpZGUiLCJkaXNwb3NpdGlvbiIsIkRpc3Bvc2l0aW9uIiwiTkVXX1RBQiIsIm5ld1RhYiIsInNlYXJjaCIsInRhYklkIiwidXBkYXRlIiwib3BlbkxpbmsiLCJkZWZhdWx0SG93VG9PcGVuTGluayIsIkNVUlJFTlRfVEFCIiwiTkVXX1dJTkRPVyIsInJ1bnRpbWUiLCJnZXRVUkwiLCJvcGVuU2VhcmNoRW5naW5lU2V0dGluZ3MiLCJMb2dnZXIiLCJPcHRpb25zIiwic2NyaXB0SWQiLCJjaGVja09zSXNNYWMiLCJTVE9SQUdFX0tFWSIsInN0b3JhZ2UiLCJsb2NhbCIsImlzTWFjIiwiZ2V0UGxhdGZvcm1JbmZvIiwib3MiLCJlcXVhbHMiLCJvdGhlciIsIk5FV19UQUJfSU5BQ1RJVkUiLCJzZXRJZCIsIm91dHB1dCIsImNhbGxiYWNrIiwiYXNzZXJ0aW9uIiwiY29uc29sZUFwaSIsImhlYWRlciIsImxvZ0VuYWJsZWQiLCJvcHRpb25hbEFyZ3MiLCJhdCIsImNvbnNvbGUiLCJzeW5jIiwiVVBEQVRFRF9BVF9LRVkiLCJERUZBVUxUX1ZBTFVFUyIsIklDT05fU0laRV9NSU4iLCJJQ09OX1NJWkVfTUFYIiwiSVRFTVMiLCJkZWZhdWx0VmFsdWUiLCJ2YWxpZGF0b3IiLCJ2YWx1ZXMiLCJkZWZpbmVPcHRpb25zIiwiY2FjaGUiLCJ1cGRhdGVTdG9yYWdlIiwib25DaGFuZ2VkIiwibGlzdGVuZXJzIiwiYWRkTGlzdGVuZXIiLCJfZmlyZSIsImNoYW5nZXMiLCJhcmVhTmFtZSIsIm9uQ2hhbmdlZExpc3RlbmVyIiwicmVzZXQiLCJEYXRlIiwibm93IiwiaGFzT3duIiwibmV3VmFsdWUiLCJvbkNvbm5lY3QiLCJvbkRpc2Nvbm5lY3QiLCJjb25uZWN0IiwiZGlzY29ubmVjdCIsInJlY29ubmVjdCIsImNoZWNrQ29ubmVjdGlvbiJdLCJzb3VyY2VSb290IjoiIn0=