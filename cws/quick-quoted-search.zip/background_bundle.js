/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./modules/__config.js":
/*!*****************************!*\
  !*** ./modules/__config.js ***!
  \*****************************/
/***/ ((module) => {

module.exports = {
  config: {
    "logEnabled": true,
    "privateOptionEnabled": true,
    "isMac": false
  }
};

/***/ }),

/***/ "./modules/__constants.js":
/*!********************************!*\
  !*** ./modules/__constants.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommandType": () => (/* binding */ CommandType),
/* harmony export */   "MessageType": () => (/* binding */ MessageType),
/* harmony export */   "QUOTATION_MARKS": () => (/* binding */ QUOTATION_MARKS),
/* harmony export */   "SELECTION_TEXT_MAX_LENGTH": () => (/* binding */ SELECTION_TEXT_MAX_LENGTH),
/* harmony export */   "SELECTION_TEXT_TOO_LONG_MARKER": () => (/* binding */ SELECTION_TEXT_TOO_LONG_MARKER),
/* harmony export */   "ScriptId": () => (/* binding */ ScriptId)
/* harmony export */ });
/**
 * Script id.
 */
const ScriptId = {
  ACTION: "ACTION",
  BACKGROUND: "BACKGROUND",
  CONTENT: "-",
  OPTIONS: "OPTIONS"
};

/**
 * Command IDs for keyboard shortcuts and context menus.
 */
const CommandType = {
  DO_QUOTED_SEARCH: "do_quoted_search",
  PUT_QUOTES: "put_quotes"
};

/**
 * Message types.
 */
const MessageType = {
  // ---------------------------------------------------------------------------
  // Content scripts --> Background service worker
  // ---------------------------------------------------------------------------
  HELLO: "hello",
  NOTIFY_SELECTION_UPDATED: "notify_selection_updated",
  DO_QUOTED_SEARCH: "do_quoted_search",
  OPEN_OPTIONS_PAGE: "open_options_page",
  // ---------------------------------------------------------------------------
  // Content scripts <-- Background service worker
  // ---------------------------------------------------------------------------
  WELCOME: "welcome",
  PUT_QUOTES: "put_quotes",
  // ---------------------------------------------------------------------------
  // Action scripts --> Background service worker
  // ---------------------------------------------------------------------------
  GET_SELECTION: "get_selection",
  // ---------------------------------------------------------------------------
  // Action scripts <-- Background service worker
  // ---------------------------------------------------------------------------
  NOTIFY_SELECTION: "notify_selection"
};

/**
 * Various double quotes.
 *
 * If you surround your search phrase with characters in this string, Google
 * Search will give you an exact match. In other words, these are the characters
 * that Google Search recognizes as valid double quotes for an exact match.
 *
 * Text containing double quotes cannot be enclosed in double quotes, so those
 * characters must be removed if they are included in the selected text when
 * searching for an exact match.
 */
const QUOTATION_MARKS = "\u0022\u201c\u201d\u201e\u201f\u2033\u301d\u301e\u301f\uff02"; // "“”„‟″〝〞〟＂

/**
 * The maximum length of the selected text to be processed.
 */
const SELECTION_TEXT_MAX_LENGTH = 1024;

/**
 * Indicates that the length of the selected text exceeds the limit.
 *
 * A very large text may be selected, in which case this string is preserved
 * instead of the original string as the selected text to avoid wasting memory
 * and making logs noisy.
 */
const SELECTION_TEXT_TOO_LONG_MARKER = "### Too Long! ### yoBjv^F7%sg#NMxCrqvYKMgD85sRXRiG";

/***/ }),

/***/ "./modules/__functions.js":
/*!********************************!*\
  !*** ./modules/__functions.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "addDOMContentLoadedEventListener": () => (/* binding */ addDOMContentLoadedEventListener),
/* harmony export */   "addLoadCompletedEventListener": () => (/* binding */ addLoadCompletedEventListener),
/* harmony export */   "cloneDto": () => (/* binding */ cloneDto),
/* harmony export */   "createNewTab": () => (/* binding */ createNewTab),
/* harmony export */   "createNewWindow": () => (/* binding */ createNewWindow),
/* harmony export */   "doQuotedSearch": () => (/* binding */ doQuotedSearch),
/* harmony export */   "filterSelectionText": () => (/* binding */ filterSelectionText),
/* harmony export */   "getActiveTab": () => (/* binding */ getActiveTab),
/* harmony export */   "getSelection": () => (/* binding */ getSelection),
/* harmony export */   "injectI18NMessagesInHtml": () => (/* binding */ injectI18NMessagesInHtml),
/* harmony export */   "isNormalizedSelectionTextValid": () => (/* binding */ isNormalizedSelectionTextValid),
/* harmony export */   "mergeObject": () => (/* binding */ mergeObject),
/* harmony export */   "normalizeSelectionText": () => (/* binding */ normalizeSelectionText),
/* harmony export */   "openLink": () => (/* binding */ openLink),
/* harmony export */   "openOptionsPage": () => (/* binding */ openOptionsPage),
/* harmony export */   "openSearchEngineSettings": () => (/* binding */ openSearchEngineSettings),
/* harmony export */   "openShortcutsSettings": () => (/* binding */ openShortcutsSettings),
/* harmony export */   "postMessage": () => (/* binding */ postMessage),
/* harmony export */   "quoteText": () => (/* binding */ quoteText)
/* harmony export */ });
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _globals_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__globals.js */ "./modules/__globals.js");
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");




/**
 * Filters the selected text obtained from external sources.
 *
 * For security purposes, be sure to pass the selected text obtained from
 * external sources through this filter before using it.
 *
 * @param {?string} selectionText
 * @returns {!string}
 */
function filterSelectionText(selectionText) {
  selectionText ??= "";
  return selectionText.length > _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_MAX_LENGTH ? _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER : selectionText;
}

/**
 * Normalizes the selected text.
 *
 * The normalization includes:
 *
 * - Replace double quotes with a space.
 * - Collapse consecutive whitespace characters into single space.
 * - Remove whitespace from both ends of the string.
 *
 * @param {?string} selectionText
 * @returns {!string}
 */
function normalizeSelectionText(selectionText) {
  selectionText = filterSelectionText(selectionText);
  return selectionText === _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER ? selectionText : selectionText.replaceAll(new RegExp(`[\\s${_constants_js__WEBPACK_IMPORTED_MODULE_0__.QUOTATION_MARKS}]+`, "g"), " ").trim();
}

/**
 * Checks if the normalized selection text is valid for processing.
 *
 * @param {?string} normalizedSelectionText
 * @returns {!boolean}
 */
function isNormalizedSelectionTextValid(normalizedSelectionText) {
  normalizedSelectionText ??= "";
  return normalizedSelectionText !== _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_TOO_LONG_MARKER && normalizedSelectionText.length > 0 && normalizedSelectionText.length <= _constants_js__WEBPACK_IMPORTED_MODULE_0__.SELECTION_TEXT_MAX_LENGTH;
}

/**
 * Puts double quotes around the string.
 *
 * @param {?string} text
 * @returns {!string}
 */
function quoteText(text) {
  return '"' + (text ?? "") + '"';
}

/**
 * Clones an object treated as a DTO.
 *
 * If you need pass an object whose contents may be changed later to an
 * asynchronous method, pass an object cloned by this function instead of the
 * origin object.
 *
 * @param {?object} obj
 * @returns {!object}
 */
function cloneDto(obj) {
  return JSON.parse(JSON.stringify(obj ?? {}));
}

/**
 * Merges `rhs` to `lhs`, ignoring properties with a value of `undefined`.
 *
 * @param {?object} target
 * @param {?object} source
 * @returns {!object}
 */
function mergeObject(target, source) {
  return {
    ...target,
    ...Object.fromEntries(Object.entries(source ?? {}).filter(([, v]) => v !== undefined))
  };
}

/**
 * Sets up an event listener for `DOMContentLoaded` event.
 *
 * This function checks `Document.readyState` and sets up the event listener as
 * a microtasks if the event has already been fired.
 *
 * @param {!Window} win
 * @param {!function():void} listener
 */
function addDOMContentLoadedEventListener(win, listener) {
  if (win.document.readyState === "loading") {
    win.document.addEventListener("DOMContentLoaded", listener);
  } else {
    queueMicrotask(listener);
  }
}

/**
 * Sets up an event listener for `load` event.
 *
 * This function checks `Document.readyState` and sets up the event listener as
 * a microtasks if the event has already been fired.
 *
 * @param {!Window} win
 * @param {!function():void} listener
 */
function addLoadCompletedEventListener(win, listener) {
  if (win.document.readyState !== "complete") {
    win.addEventListener("load", listener);
  } else {
    queueMicrotask(listener);
  }
}

/**
 * Injects localized strings into HTML document.
 *
 * @param {!Document} doc
 */
function injectI18NMessagesInHtml(doc) {
  const I18N_TARGETS = ["outerHTML", "innerHTML", "outerText", "innerText", "value"];
  for (const element of doc.querySelectorAll("[data-group~='i18n'")) {
    const substitutions = (() => {
      const result = [];
      const args = element.dataset.i18nArgs;
      if (!args) {
        return result;
      }
      const ids = args.split(" ");
      for (const id of ids) {
        const argElement = doc.getElementById(id);
        const argTarget = argElement.dataset.i18nTarget;
        _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.assert(I18N_TARGETS.includes(argTarget), "Unexpected target", {
          argTarget,
          argElement
        });
        result.push(argElement[argTarget]);
      }
      return result;
    })();
    const target = element.dataset.i18nTarget;
    _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.assert(I18N_TARGETS.includes(target), "Unexpected target", {
      target,
      element
    });
    element[target] = chrome.i18n.getMessage(element.dataset.i18nName, substitutions);
  }
}

/**
 * Gets `Selection` object.
 *
 * This function not only calls `Window.getSelection()`, but also recursively
 * searches within the nested Shadow DOMs.
 *
 * @param {!Window} win
 * @returns {!Selection}
 */
function getSelection(win) {
  function findSelectionRecursively(selection) {
    if (selection.rangeCount === 1) {
      const range = selection.getRangeAt(0);
      if (range.startContainer === range.endContainer) {
        const commonAncestorContainer = range.commonAncestorContainer;
        if (commonAncestorContainer instanceof Element) {
          if (commonAncestorContainer.shadowRoot) {
            return findSelectionRecursively(commonAncestorContainer.shadowRoot.getSelection());
          } else {
            const elementsWithShadowRoot = Array.prototype.filter.call(commonAncestorContainer.querySelectorAll("*"), element => !!element.shadowRoot);
            if (elementsWithShadowRoot.length === 1) {
              return findSelectionRecursively(elementsWithShadowRoot[0].shadowRoot.getSelection());
            }
          }
        }
      }
    }
    return selection;
  }
  return findSelectionRecursively(win.getSelection());
}

/**
 * Calls `chrome.runtime.Port.postMessage()` method.
 *
 * Catches the error thrown from `chrome.runtime.Port.postMessage()` method and
 * logs a warning message.
 *
 * `chrome.runtime.Port.postMessage()` throws an error if the other side of the
 * port has already been closed, but there is no way to check in advance whether
 * the port is still opened or has been closed.
 * Port disconnection is one of the expected conditions, even in an edge case,
 * and most of the time it is not an error case.
 * Therefore, if an error is thrown from `chrome.runtime.Port.postMessage()`
 * method, this function assumes the cause is port disconnection and logs it as
 * a warning instead of an error.
 *
 * @param {!chrome.runtime.Port} port
 * @param {!*} message
 */
function postMessage(port, message) {
  try {
    port.postMessage(message);
  } catch (error) {
    _globals_js__WEBPACK_IMPORTED_MODULE_1__.logger.warn("It seems that the message could not be sent because the other side of the port has already been closed", {
      error,
      port,
      message
    });
  }
}

/**
 * Gets the active tab.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @returns {!Promise<!chrome.tabs.Tab>}
 */
async function getActiveTab() {
  const [tab] = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });
  return tab;
}

/**
 * Creates a new tab.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?{url:?string=, active:?boolean=}=} params
 * @returns {!Promise<void>}
 */
async function createNewTab(tab, params) {
  return await chrome.tabs.create({
    windowId: tab.windowId,
    openerTabId: tab.id,
    index: tab.index + 1,
    url: params?.url,
    active: params?.active ?? true
  });
}

/**
 * Creates a new window.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {?{url:?string=}=} params
 * @returns {!Promise<void>}
 */
async function createNewWindow(params) {
  const currentWindow = await chrome.windows.getCurrent();
  return await chrome.windows.create({
    state: currentWindow.state,
    url: params?.url
  });
}

/**
 * Invokes search engine to do quoted search.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {!string} searchText Text to search, not to be enclosed in double quotes.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @returns {!Promise<void>}
 */
async function doQuotedSearch(tab, searchText, keyState) {
  const howToOpenLink = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.decide(keyState, new _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink(_globals_js__WEBPACK_IMPORTED_MODULE_1__.options.disposition, true));
  if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.NEW_TAB) {
    const newTab = await createNewTab(tab, {
      active: false
    });
    await chrome.search.query({
      tabId: newTab.id,
      text: quoteText(searchText)
    });
    // To prevent the omnibox from receiving focus, activate new tab after
    // creation and search.
    if (howToOpenLink.active ?? true) {
      await chrome.tabs.update(newTab.id, {
        active: true
      });
    }
  } else {
    await chrome.search.query({
      disposition: howToOpenLink.disposition,
      text: quoteText(searchText)
    });
  }
}

/**
 * Opens the web page with specified URL.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {!string} url
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openLink(tab, url, keyState, defaultHowToOpenLink) {
  const howToOpenLink = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.decide(keyState, defaultHowToOpenLink);
  if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.CURRENT_TAB) {
    await chrome.tabs.update(tab.id, {
      url: url
    });
  } else if (howToOpenLink.disposition === _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_2__.HowToOpenLink.Disposition.NEW_WINDOW) {
    await createNewWindow({
      url: url
    });
  } else {
    await createNewTab(tab, {
      url: url,
      active: howToOpenLink.active ?? true
    });
  }
}

/**
 * Opens the extension's Options page.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openOptionsPage(tab, keyState, defaultHowToOpenLink) {
  const url = chrome.runtime.getURL("options.html");
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/**
 * Opens search engine settings page of the browser.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openSearchEngineSettings(tab, keyState, defaultHowToOpenLink) {
  const url = "chrome://settings/search";
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/**
 * Opens keyboard shortcuts settings page of the browser.
 *
 * **Note:** Not available in content scripts, available only in background
 * service worker, action scripts or options script.
 *
 * @param {!chrome.tabs.Tab} tab Current tab calling this function.
 * @param {?HowToOpenLink.KeyState=} keyState
 * @param {?HowToOpenLink=} defaultHowToOpenLink Specifies the default behavior
 *    if no control key is pressed.
 * @returns {!Promise<void>}
 */
async function openShortcutsSettings(tab, keyState, defaultHowToOpenLink) {
  const url = "chrome://extensions/shortcuts";
  await openLink(tab, url, keyState, defaultHowToOpenLink);
}

/***/ }),

/***/ "./modules/__globals.js":
/*!******************************!*\
  !*** ./modules/__globals.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "init": () => (/* binding */ init),
/* harmony export */   "logger": () => (/* binding */ logger),
/* harmony export */   "options": () => (/* binding */ options)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__logger.js */ "./modules/__logger.js");
/* harmony import */ var _options_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./__options.js */ "./modules/__options.js");





/**
 * Logger used used throughout the extension.
 *
 * It will be initialized in {@link init()} function.
 *
 * @type {Logger}
 */
let logger;

/**
 * Options used used throughout the extension.
 *
 * It will be initialized in {@link init()} function.
 *
 * @type {Options}
 */
let options;

/**
 * Initializes the module.
 *
 * This function must be called first to initialize global variables before
 * using them and any other functions depending these global variables.
 *
 * @param {!string} scriptId
 * @returns {!Promise<void>}
 */
async function init(scriptId) {
  logger = new _logger_js__WEBPACK_IMPORTED_MODULE_2__.Logger(scriptId);
  logger.state("Initialize script", {
    scriptId
  });
  options = new _options_js__WEBPACK_IMPORTED_MODULE_3__.Options(logger);
  await options.init();
  await checkOsIsMac(scriptId);
}
async function checkOsIsMac(scriptId) {
  const STORAGE_KEY = "isMac";
  const storage = chrome.storage.local;
  if (scriptId === _constants_js__WEBPACK_IMPORTED_MODULE_1__.ScriptId.BACKGROUND) {
    _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac = (await chrome.runtime.getPlatformInfo()).os === "mac";
    await storage.set({
      [STORAGE_KEY]: _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac
    });
  } else {
    _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac = !!(await storage.get(STORAGE_KEY))[STORAGE_KEY];
  }
  logger.state("Updated `isMac` in config", {
    ["config.isMac"]: _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac
  });
}

/***/ }),

/***/ "./modules/__how_to_open_link.js":
/*!***************************************!*\
  !*** ./modules/__how_to_open_link.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HowToOpenLink": () => (/* binding */ HowToOpenLink)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Controls how to open a link based on the state of control keys such as `Ctrl`
 * and `Shift`.
 */
class HowToOpenLink {
  /**
   * Location where a link should be opened.
   *
   * The values of this enum are same as
   * [chrome.search.Disposition](https://developer.chrome.com/docs/extensions/reference/search/#type-Disposition).
   * Therefore, they can be used as-is as a parameter to
   * [chrome.search.query()](https://developer.chrome.com/docs/extensions/reference/search/#method-query).
   */
  static Disposition = {
    CURRENT_TAB: "CURRENT_TAB",
    NEW_TAB: "NEW_TAB",
    NEW_WINDOW: "NEW_WINDOW"
  };
  static KeyState = class KeyState {
    ctrlKey;
    shiftKey;

    /**
     * @param {!boolean} ctrlKey
     * @param {!boolean} shiftKey
     * @param {!boolean=} metaKey If specified, `metaKey` is used instead of
     *    `ctrlKey` when running on MAC.
     */
    constructor(ctrlKey, shiftKey, metaKey = ctrlKey) {
      this.ctrlKey = _config_js__WEBPACK_IMPORTED_MODULE_0__.config.isMac ? metaKey : ctrlKey;
      this.shiftKey = shiftKey;
    }
    equals(other) {
      return other && this.ctrlKey === other.ctrlKey && this.shiftKey === other.shiftKey;
    }
    static CURRENT_TAB = new KeyState(false, false);
    static NEW_TAB_ACTIVE = new KeyState(true, true);
    static NEW_TAB_INACTIVE = new KeyState(true, false);
    static NEW_WINDOW = new KeyState(false, true);
  };

  /**
   * @type {!HowToOpenLink.Disposition}
   */
  disposition;

  /**
   * Available only if `disposition ===  NEW_TAB`.
   *
   * @type {boolean=}
   */
  active;

  /**
   * @param {!HowToOpenLink.Disposition} disposition
   * @param {boolean=} active Available only if `disposition ===  NEW_TAB`.
   */
  constructor(disposition, active = true) {
    this.disposition = disposition;
    this.active = active;
  }
  static CURRENT_TAB = new HowToOpenLink(HowToOpenLink.Disposition.CURRENT_TAB);
  static NEW_TAB_ACTIVE = new HowToOpenLink(HowToOpenLink.Disposition.NEW_TAB, true);
  static NEW_TAB_INACTIVE = new HowToOpenLink(HowToOpenLink.Disposition.NEW_TAB, false);
  static NEW_WINDOW = new HowToOpenLink(HowToOpenLink.Disposition.NEW_WINDOW);

  /**
   * Decides location where a link should be opened.
   *
   * @param {?HowToOpenLink.KeyState=} keyState
   * @param {?HowToOpenLink=} defaultHowToOpenLink
   * @returns {!HowToOpenLink}
   */
  static decide(keyState, defaultHowToOpenLink) {
    if (HowToOpenLink.KeyState.NEW_TAB_ACTIVE.equals(keyState)) return HowToOpenLink.NEW_TAB_ACTIVE;else if (HowToOpenLink.KeyState.NEW_TAB_INACTIVE.equals(keyState)) return HowToOpenLink.NEW_TAB_INACTIVE;else if (HowToOpenLink.KeyState.NEW_WINDOW.equals(keyState)) return HowToOpenLink.NEW_WINDOW;else return defaultHowToOpenLink ?? HowToOpenLink.CURRENT_TAB;
  }
}

/***/ }),

/***/ "./modules/__logger.js":
/*!*****************************!*\
  !*** ./modules/__logger.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Logger": () => (/* binding */ Logger)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);


/**
 * Outputs logs only if `config.logEnabled` is true. Otherwise, all of the
 * instance methods of this class have no operations (ie empty).
 */
class Logger {
  #id;

  /**
   * @param {!string} id Appears at the beginning of the log message, enclosed
   *    in square brackets.
   */
  constructor(id) {
    this.#id = id;
  }

  /**
   * @param {!string} id
   */
  setId(id) {
    this.#id = id;
  }

  /**
   * Call `console.debug()` with the header `[INFO]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  info(message, ...args) {
    this.#output("debug", "[INFO]", message, args);
  }

  /**
   * Call `console.debug()` with the header `[STATE]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  state(message, ...args) {
    this.#output("debug", "[STATE]", message, args);
  }

  /**
   * Call `console.debug()` with the header `[CALLBACK]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  callback(message, ...args) {
    this.#output("debug", "[CALLBACK]", message, args);
  }

  /**
   * Call `console.warn()` with the header `[WARN]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  warn(message, ...args) {
    this.#output("warn", "[WARN]", message, args);
  }

  /**
   * Call `console.error()` with the header `[ERROR]` prepended to the message.
   *
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  error(message, ...args) {
    this.#output("error", "[ERROR]", message, args);
  }

  /**
   * Call `console.assert()` with the header `[ERROR]` prepended to the message.
   *
   * @param {!boolean} assertion
   * @param {!string} message
   * @param {...any=} args arguments for the substitutions if included in the
   *    message. If specifying an object (key-value pairs) at the end, it will
   *    be decomposed and output in the form `\n${key}= ${value}`.
   */
  assert(assertion, message, ...args) {
    this.#output("assert", "[ERROR]", message, args, assertion);
  }

  /**
   * Call Console API specified by the `method` argument.
   *
   * @param {!string} consoleApi Console API to call.
   * @param {!string} header
   * @param {!string} message
   * @param {?any[]=} args
   * @param {?boolean=} assertion must be specified if `method` is "assert", otherwise ignored.
   */
  #output(consoleApi, header, message, args, assertion) {
    if (!_config_js__WEBPACK_IMPORTED_MODULE_0__.config.logEnabled) {
      return;
    }
    const optionalArgs = [];
    if (args && args.length > 0 && typeof args.at(-1) === "object") {
      for (const [key, value] of Object.entries(args.pop())) {
        optionalArgs.push(`\n${key}=`);
        optionalArgs.push(value);
      }
    }
    console[consoleApi](...(consoleApi === "assert" ? [!!assertion] : []), `[${this.#id}] ${header} ${message}`, ...args, ...optionalArgs);
  }
}

/***/ }),

/***/ "./modules/__options.js":
/*!******************************!*\
  !*** ./modules/__options.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Options": () => (/* binding */ Options)
/* harmony export */ });
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");


/**
 * User-customizable extension options.
 *
 * Options is stored in the
 * [sync](https://developer.chrome.com/docs/extensions/reference/storage/#property-sync)
 * storage area that is synced using Chrome Sync.
 */
class Options {
  static #storage = chrome.storage.sync;
  static #STORAGE_KEY = "options";
  static #UPDATED_AT_KEY = "__updatedAt__";
  static #DEFAULT_VALUES = {
    [Options.#UPDATED_AT_KEY]: 0
  };
  static Disposition = _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_0__.HowToOpenLink.Disposition;
  static ICON_SIZE_MIN = 1;
  static ICON_SIZE_MAX = 5;

  // prettier-ignore
  /**
   * Definition of options.
   *
   * Just add a row into this table to add a new option item. The code necessary
   * to read and write option values is automatically generated.
   *
   * @type {{name:!string, defaultValue:!*, validator:!function(?*):boolean}[]}
   */
  static #ITEMS = [{
    name: "popupIcon",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "iconSize",
    defaultValue: 3,
    validator: value => typeof value === "number" && value >= Options.ICON_SIZE_MIN && value <= Options.ICON_SIZE_MAX
  }, {
    name: "avoidSelection",
    defaultValue: false,
    validator: value => typeof value === "boolean"
  }, {
    name: "optionsButton",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "contextMenu",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "disposition",
    defaultValue: Options.Disposition.NEW_TAB,
    validator: value => typeof value === "string" && Object.values(Options.Disposition).includes(value)
  }, {
    name: "autoCopy",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "autoEnter",
    defaultValue: true,
    validator: value => typeof value === "boolean"
  }, {
    name: "autoSurround",
    defaultValue: false,
    validator: value => typeof value === "boolean"
  }];
  static #defineOptions() {
    for (const {
      name,
      defaultValue,
      validator
    } of Options.#ITEMS) {
      Options.#DEFAULT_VALUES[name] = defaultValue;
      Object.defineProperty(Options.prototype, name, {
        set(value) {
          if (!validator(value)) {
            throw new Error(`Options: Invalid value for '${name}'\nvalue=${value}`);
          }
          if (value !== this.#cache[name]) {
            this.#cache[name] = value;
            /* async */
            this.#updateStorage();
          }
        },
        get() {
          return validator(this.#cache[name]) ? this.#cache[name] : defaultValue;
        }
      });
    }
  }
  static #_ = Options.#defineOptions();
  /**
   * Fired when one or more options are changed externally.
   */
  onChanged = new class onChanged {
    #listeners = [];
    /**
     * @param {!function(!Options):void} listener
     */
    addListener(listener) {
      this.#listeners.push(listener);
    }
    _fire() {
      for (const listener of this.#listeners) {
        listener();
      }
    }
  }();
  #logger;
  #cache;

  /**
   * @param {!Logger} logger
   */
  constructor(logger) {
    this.#logger = logger;
    this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
    Options.#storage.onChanged.addListener((changes, areaName) => {
      this.#onChangedListener(changes, areaName);
    });
  }

  /**
   * Load options from the storage.
   */
  async init() {
    const values = await Options.#storage.get(Options.#STORAGE_KEY);
    // Merge rather than assign to ensure completeness of options in case of
    // missing data in the storage.
    Object.assign(this.#cache, values[Options.#STORAGE_KEY]);
    this.#logger.state("Options: Initialized", {
      ["this.#cache"]: this.#cache
    });
  }

  /**
   * Reset all options to restore defaults.
   */
  reset() {
    this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
    /* async */
    this.#updateStorage();
  }
  async #updateStorage() {
    this.#cache[Options.#UPDATED_AT_KEY] = Date.now();
    const values = {
      [Options.#STORAGE_KEY]: this.#cache
    };
    this.#logger.state("Options: Update storage", {
      values
    });
    await Options.#storage.set(values);
  }
  #onChangedListener(changes, areaName) {
    this.#logger.callback("Options: onChangedListener()", {
      changes,
      areaName
    });
    if (!Object.hasOwn(changes, Options.#STORAGE_KEY)) {
      return;
    }
    if (Object.hasOwn(changes[Options.#STORAGE_KEY], "newValue")) {
      const newValue = changes[Options.#STORAGE_KEY].newValue;
      if (newValue[Options.#UPDATED_AT_KEY] <= this.#cache[Options.#UPDATED_AT_KEY]) {
        this.#logger.info("Options: Cache was not overwritten because it is up to date", {
          ["this.#cache"]: this.#cache
        });
        return;
      }

      // Merge rather than assign to ensure completeness of options in case of
      // missing data in the storage.
      Object.assign(this.#cache, newValue);
      this.#logger.state("Options: Cache was overwritten by values in storage updated by other", {
        ["this.#cache"]: this.#cache
      });
    } else {
      // The storage has been cleared.

      this.#cache = Object.assign({}, Options.#DEFAULT_VALUES);
      this.#logger.state("Options: Cache was reset to default values because the storage has been cleared", {
        ["this.#cache"]: this.#cache
      });
    }
    this.onChanged._fire();
  }
}

/***/ }),

/***/ "./modules/common.js":
/*!***************************!*\
  !*** ./modules/common.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommandType": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.CommandType),
/* harmony export */   "HowToOpenLink": () => (/* reexport safe */ _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_4__.HowToOpenLink),
/* harmony export */   "Logger": () => (/* reexport safe */ _logger_js__WEBPACK_IMPORTED_MODULE_5__.Logger),
/* harmony export */   "MessageType": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.MessageType),
/* harmony export */   "Options": () => (/* reexport safe */ _options_js__WEBPACK_IMPORTED_MODULE_6__.Options),
/* harmony export */   "QUOTATION_MARKS": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.QUOTATION_MARKS),
/* harmony export */   "SELECTION_TEXT_MAX_LENGTH": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.SELECTION_TEXT_MAX_LENGTH),
/* harmony export */   "SELECTION_TEXT_TOO_LONG_MARKER": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.SELECTION_TEXT_TOO_LONG_MARKER),
/* harmony export */   "ScriptId": () => (/* reexport safe */ _constants_js__WEBPACK_IMPORTED_MODULE_1__.ScriptId),
/* harmony export */   "addDOMContentLoadedEventListener": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.addDOMContentLoadedEventListener),
/* harmony export */   "addLoadCompletedEventListener": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.addLoadCompletedEventListener),
/* harmony export */   "cloneDto": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.cloneDto),
/* harmony export */   "createNewTab": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.createNewTab),
/* harmony export */   "createNewWindow": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.createNewWindow),
/* harmony export */   "doQuotedSearch": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.doQuotedSearch),
/* harmony export */   "filterSelectionText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.filterSelectionText),
/* harmony export */   "getActiveTab": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.getActiveTab),
/* harmony export */   "getSelection": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.getSelection),
/* harmony export */   "init": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.init),
/* harmony export */   "injectI18NMessagesInHtml": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.injectI18NMessagesInHtml),
/* harmony export */   "isNormalizedSelectionTextValid": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.isNormalizedSelectionTextValid),
/* harmony export */   "logger": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.logger),
/* harmony export */   "mergeObject": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.mergeObject),
/* harmony export */   "normalizeSelectionText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.normalizeSelectionText),
/* harmony export */   "openLink": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openLink),
/* harmony export */   "openOptionsPage": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openOptionsPage),
/* harmony export */   "openSearchEngineSettings": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openSearchEngineSettings),
/* harmony export */   "openShortcutsSettings": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.openShortcutsSettings),
/* harmony export */   "options": () => (/* reexport safe */ _globals_js__WEBPACK_IMPORTED_MODULE_3__.options),
/* harmony export */   "postMessage": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.postMessage),
/* harmony export */   "quoteText": () => (/* reexport safe */ _functions_js__WEBPACK_IMPORTED_MODULE_2__.quoteText)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./__config.js */ "./modules/__config.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_config_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in _config_js__WEBPACK_IMPORTED_MODULE_0__) if(__WEBPACK_IMPORT_KEY__ !== "default") __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => _config_js__WEBPACK_IMPORTED_MODULE_0__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./__constants.js */ "./modules/__constants.js");
/* harmony import */ var _functions_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./__functions.js */ "./modules/__functions.js");
/* harmony import */ var _globals_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./__globals.js */ "./modules/__globals.js");
/* harmony import */ var _how_to_open_link_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./__how_to_open_link.js */ "./modules/__how_to_open_link.js");
/* harmony import */ var _logger_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./__logger.js */ "./modules/__logger.js");
/* harmony import */ var _options_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./__options.js */ "./modules/__options.js");
/**
 * @file Aggregates modules.
 */









/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!***********************!*\
  !*** ./background.js ***!
  \***********************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _modules_common_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modules/common.js */ "./modules/common.js");



(async function main() {
  //////////////////////////////////////////////////////////////////////////////
  // Initialize common modules
  //////////////////////////////////////////////////////////////////////////////

  await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.init(_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.ScriptId.BACKGROUND);

  //////////////////////////////////////////////////////////////////////////////
  // Constants
  //////////////////////////////////////////////////////////////////////////////

  const MESSAGE_HANDLERS = {
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.HELLO]: onHello,
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.NOTIFY_SELECTION_UPDATED]: onNotifySelectionUpdated,
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.DO_QUOTED_SEARCH]: onDoQuotedSearch,
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.OPEN_OPTIONS_PAGE]: onOpenOptionsPage,
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.GET_SELECTION]: onGetSelection
  };

  //////////////////////////////////////////////////////////////////////////////
  // Variables
  //////////////////////////////////////////////////////////////////////////////

  const currentSelection = {
    sender: undefined,
    text: "",
    editable: false,
    searchable: false,
    blur: true
  };
  const commands = {
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.CommandType.DO_QUOTED_SEARCH]: {
      shortcut: "",
      contextMenu: {
        properties: {
          title: chrome.i18n.getMessage("msg_context_menu_title_do_quoted_search"),
          type: "normal",
          contexts: ["selection"]
        },
        registered: false,
        onlyEditable: false,
        titleChangesInSearchable: false
      },
      async onShortcutPressed(tab) {
        await doQuotedSearchForSelectionText(tab, currentSelection.text);
      },
      async onContextMenuClicked(info, tab) {
        await doQuotedSearchForSelectionText(tab, _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.filterSelectionText(info.selectionText));
      }
    },
    [_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.CommandType.PUT_QUOTES]: {
      shortcut: "",
      contextMenu: {
        properties: {
          title: chrome.i18n.getMessage("msg_context_menu_title_put_quotes"),
          type: "normal",
          contexts: ["editable"]
        },
        registered: false,
        onlyEditable: true,
        titleChangesInSearchable: true
      },
      onShortcutPressed(tab) {
        putQuotesAroundSelectionText(tab, currentSelection.sender.frameId);
      },
      onContextMenuClicked(info, tab) {
        putQuotesAroundSelectionText(tab, info.frameId);
      }
    }
  };

  //////////////////////////////////////////////////////////////////////////////
  // Startup Operations
  //////////////////////////////////////////////////////////////////////////////

  chrome.runtime.onConnect.addListener(onConnect);
  chrome.tabs.onActivated.addListener(onTabsActivate);
  chrome.tabs.onUpdated.addListener(onTabsUpdated);
  chrome.contextMenus.onClicked.addListener(onContextMenuClicked);
  chrome.commands.onCommand.addListener(onCommand);
  _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.onChanged.addListener(onOptionsChanged);

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (Content scripts, Action scripts)
  //////////////////////////////////////////////////////////////////////////////

  async function onConnect(port) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onConnect()", {
      port
    });
    port.onMessage.addListener(onMessage);
    await updateCommandShortcuts();
  }
  function onMessage(message, port) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onMessage()", {
      message,
      port
    });
    MESSAGE_HANDLERS[message.type](message, port);
  }
  async function onHello(_message, port) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.postMessage(port, {
      type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.WELCOME,
      identity: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.cloneDto(port.sender)
    });
  }
  function onNotifySelectionUpdated(message, port) {
    if (message.selection.blur) {
      if (!isOwnerOfCurrentSelection(port.sender.tab.id, port.sender.frameId)) {
        _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Ignore message from blurred content because selection state has already been updated by newly focused content");
        return;
      }
    }
    updateCurrentSelection(message.selection, port.sender);
    updateContextMenu(currentSelection);
  }
  async function onDoQuotedSearch(message, port) {
    await doQuotedSearchForSelectionText(port.sender.tab, message.selectionText, message.keyState);
  }
  async function onOpenOptionsPage(message, port) {
    await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.openOptionsPage(port.sender.tab, message.keyState, message.defaultHowToOpenLink);
  }
  function onGetSelection(message, port) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.postMessage(port, {
      type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.NOTIFY_SELECTION,
      selection: isOwnerOfCurrentSelection(message.tab.id) ? _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.cloneDto(currentSelection) : undefined
    });
  }

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (Tabs)
  //////////////////////////////////////////////////////////////////////////////

  // Listen for `chrome.tabs` events to ensure Background service worker to be
  // loaded before Content scripts connect to it.

  function onTabsActivate(activeInfo) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onTabsActivate()", {
      activeInfo
    });
  }
  function onTabsUpdated(tabId, changeInfo, tab) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onTabsUpdated()", {
      tabId,
      changeInfo,
      tab
    });
  }

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (Context menus, Keyboard shortcuts)
  //////////////////////////////////////////////////////////////////////////////

  function onContextMenuClicked(info, tab) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onContextMenuClicked()", {
      info,
      tab
    });
    if (!isOwnerOfCurrentSelection(tab?.id, info.frameId)) {
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Ignore context menu clicked event due to sent from unknown content", {
        info,
        tab,
        currentSelection
      });
      return;
    }
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.assert(commands[info.menuItemId].contextMenu.registered, "Unregistered context menu was invoked", {
      ["info.menuItemId"]: info.menuItemId,
      info,
      tab
    });
    commands[info.menuItemId].onContextMenuClicked(info, tab);
  }
  async function onCommand(command, tab) {
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.callback("onCommand()", {
      command,
      tab
    });

    // tab is null if the shortcut key is set to global.
    if (!tab) {
      tab = await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.getActiveTab();
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Got active tab because null was passed on onCommand event", {
        command,
        tab
      });
      if (!tab) {
        _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Ignore keyboard shortcut event because active tab could not be obtained", {
          command
        });
        return;
      }
    }
    if (!isOwnerOfCurrentSelection(tab.id)) {
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Ignore keyboard shortcut event due to sent from unknown content", {
        command,
        tab,
        currentSelection
      });
      return;
    }
    if (currentSelection.blur) {
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info("Ignore keyboard shortcut event due to current selection blurred", {
        command,
        tab,
        currentSelection
      });
      return;
    }
    commands[command].onShortcutPressed(tab);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Event Listeners (Options)
  //////////////////////////////////////////////////////////////////////////////

  function onOptionsChanged() {
    updateContextMenu(currentSelection);
  }

  //////////////////////////////////////////////////////////////////////////////
  // Functions
  //////////////////////////////////////////////////////////////////////////////

  function updateCurrentSelection(selection, sender) {
    Object.assign(currentSelection, selection);
    currentSelection.sender = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.cloneDto(sender);
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Update current selection", {
      currentSelection
    });
  }
  function isOwnerOfCurrentSelection(tabId, frameId) {
    return currentSelection.sender && currentSelection.sender.tab.id === tabId && (frameId === undefined || currentSelection.sender.frameId === frameId);
  }
  async function updateCommandShortcuts() {
    const extensionCommands = await chrome.commands.getAll();
    for (const {
      name,
      shortcut
    } of extensionCommands) {
      commands[name].shortcut = shortcut;
    }
  }
  function updateContextMenu(selection) {
    const isSelectionTextValid = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.isNormalizedSelectionTextValid(_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.normalizeSelectionText(selection.text));
    for (const [id, command] of Object.entries(commands)) {
      const contextMenu = command.contextMenu;
      const properties = contextMenu.properties;
      const visible = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.contextMenu && !selection.blur && isSelectionTextValid && (!contextMenu.onlyEditable || selection.editable);
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.state("Update context menu visibility", {
        id,
        visible
      });
      if (visible) {
        let titleSupplement = "";
        if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.autoEnter && selection.searchable && contextMenu.titleChangesInSearchable) {
          titleSupplement += chrome.i18n.getMessage("msg_context_menu_title_put_quotes_supplement");
        }
        if (command.shortcut) {
          titleSupplement += `   [${command.shortcut}]`;
        }
        if (!contextMenu.registered) {
          chrome.contextMenus.create({
            id: id,
            title: properties.title + titleSupplement,
            type: properties.type,
            contexts: properties.contexts
          });
          contextMenu.registered = true;
        } else {
          chrome.contextMenus.update(id, {
            title: properties.title + titleSupplement
          });
        }
      } else {
        if (contextMenu.registered) {
          chrome.contextMenus.remove(id);
          contextMenu.registered = false;
        }
      }
    }
  }
  async function doQuotedSearchForSelectionText(tab, selectionText, keyState) {
    const normalizedSelectionText = _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.normalizeSelectionText(selectionText);
    if (!_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.isNormalizedSelectionTextValid(normalizedSelectionText)) {
      _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.logger.info(`Ignore ${_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.CommandType.DO_QUOTED_SEARCH} command due to unexpected selection text`, {
        selectionText
      });
      return;
    }
    if (_modules_common_js__WEBPACK_IMPORTED_MODULE_0__.options.autoCopy) {
      await writeTextToClipboard(tab, normalizedSelectionText);
    }
    await _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.doQuotedSearch(tab, normalizedSelectionText, keyState);
  }
  function putQuotesAroundSelectionText(tab, frameId) {
    const port = chrome.tabs.connect(tab.id, {
      name: "background",
      frameId: frameId
    });
    _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.postMessage(port, {
      type: _modules_common_js__WEBPACK_IMPORTED_MODULE_0__.MessageType.PUT_QUOTES
    });
    port.disconnect();
  }
  async function writeTextToClipboard(tab, text) {
    await chrome.scripting.executeScript({
      target: {
        tabId: tab.id
      },
      injectImmediately: true,
      args: [text],
      func: text => window.navigator.clipboard.writeText(text)
    });
  }
})();
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZF9idW5kbGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUFBLE1BQU0sQ0FBQ0MsT0FBTyxHQUFHO0VBQUVDLE1BQU0sRUFBRTtJQUFDLFlBQVksRUFBQyxJQUFJO0lBQUMsc0JBQXNCLEVBQUMsSUFBSTtJQUFDLE9BQU8sRUFBQztFQUFLO0FBQUUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBMUY7QUFDQTtBQUNBO0FBQ08sTUFBTUMsUUFBUSxHQUFHO0VBQ3RCQyxNQUFNLEVBQUUsUUFBUTtFQUNoQkMsVUFBVSxFQUFFLFlBQVk7RUFDeEJDLE9BQU8sRUFBRSxHQUFHO0VBQ1pDLE9BQU8sRUFBRTtBQUNYLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ08sTUFBTUMsV0FBVyxHQUFHO0VBQ3pCQyxnQkFBZ0IsRUFBRSxrQkFBa0I7RUFDcENDLFVBQVUsRUFBRTtBQUNkLENBQUM7O0FBRUQ7QUFDQTtBQUNBO0FBQ08sTUFBTUMsV0FBVyxHQUFHO0VBQ3pCO0VBQ0E7RUFDQTtFQUNBQyxLQUFLLEVBQUUsT0FBTztFQUNkQyx3QkFBd0IsRUFBRSwwQkFBMEI7RUFDcERKLGdCQUFnQixFQUFFLGtCQUFrQjtFQUNwQ0ssaUJBQWlCLEVBQUUsbUJBQW1CO0VBRXRDO0VBQ0E7RUFDQTtFQUNBQyxPQUFPLEVBQUUsU0FBUztFQUNsQkwsVUFBVSxFQUFFLFlBQVk7RUFFeEI7RUFDQTtFQUNBO0VBQ0FNLGFBQWEsRUFBRSxlQUFlO0VBRTlCO0VBQ0E7RUFDQTtFQUNBQyxnQkFBZ0IsRUFBRTtBQUNwQixDQUFDOztBQUVEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQyxlQUFlLEdBQUcsOERBQThELENBQUMsQ0FBQzs7QUFFL0Y7QUFDQTtBQUNBO0FBQ08sTUFBTUMseUJBQXlCLEdBQUcsSUFBSTs7QUFFN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxNQUFNQyw4QkFBOEIsR0FBRyxvREFBb0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hFWTtBQUM3RDtBQUNPOztBQUV4RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTSSxtQkFBbUIsQ0FBQ0MsYUFBYSxFQUFFO0VBQ2pEQSxhQUFhLEtBQUssRUFBRTtFQUNwQixPQUFPQSxhQUFhLENBQUNDLE1BQU0sR0FBR1Asb0VBQXlCLEdBQUdDLHlFQUE4QixHQUFHSyxhQUFhO0FBQzFHOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNFLHNCQUFzQixDQUFDRixhQUFhLEVBQUU7RUFDcERBLGFBQWEsR0FBR0QsbUJBQW1CLENBQUNDLGFBQWEsQ0FBQztFQUNsRCxPQUFPQSxhQUFhLEtBQUtMLHlFQUE4QixHQUNuREssYUFBYSxHQUNiQSxhQUFhLENBQUNHLFVBQVUsQ0FBQyxJQUFJQyxNQUFNLENBQUUsT0FBTVgsMERBQWdCLElBQUcsRUFBRSxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQ1ksSUFBSSxFQUFFO0FBQ3ZGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLDhCQUE4QixDQUFDQyx1QkFBdUIsRUFBRTtFQUN0RUEsdUJBQXVCLEtBQUssRUFBRTtFQUM5QixPQUNFQSx1QkFBdUIsS0FBS1oseUVBQThCLElBQzFEWSx1QkFBdUIsQ0FBQ04sTUFBTSxHQUFHLENBQUMsSUFDbENNLHVCQUF1QixDQUFDTixNQUFNLElBQUlQLG9FQUF5QjtBQUUvRDs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTYyxTQUFTLENBQUNDLElBQUksRUFBRTtFQUM5QixPQUFPLEdBQUcsSUFBSUEsSUFBSSxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUc7QUFDakM7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTQyxRQUFRLENBQUNDLEdBQUcsRUFBRTtFQUM1QixPQUFPQyxJQUFJLENBQUNDLEtBQUssQ0FBQ0QsSUFBSSxDQUFDRSxTQUFTLENBQUNILEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0ksV0FBVyxDQUFDQyxNQUFNLEVBQUVDLE1BQU0sRUFBRTtFQUMxQyxPQUFPO0lBQUUsR0FBR0QsTUFBTTtJQUFFLEdBQUdFLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDRCxNQUFNLENBQUNFLE9BQU8sQ0FBQ0gsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNJLE1BQU0sQ0FBQyxDQUFDLEdBQUdDLENBQUMsQ0FBQyxLQUFLQSxDQUFDLEtBQUtDLFNBQVMsQ0FBQztFQUFFLENBQUM7QUFDOUc7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsZ0NBQWdDLENBQUNDLEdBQUcsRUFBRUMsUUFBUSxFQUFFO0VBQzlELElBQUlELEdBQUcsQ0FBQ0UsUUFBUSxDQUFDQyxVQUFVLEtBQUssU0FBUyxFQUFFO0lBQ3pDSCxHQUFHLENBQUNFLFFBQVEsQ0FBQ0UsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUVILFFBQVEsQ0FBQztFQUM3RCxDQUFDLE1BQU07SUFDTEksY0FBYyxDQUFDSixRQUFRLENBQUM7RUFDMUI7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTSyw2QkFBNkIsQ0FBQ04sR0FBRyxFQUFFQyxRQUFRLEVBQUU7RUFDM0QsSUFBSUQsR0FBRyxDQUFDRSxRQUFRLENBQUNDLFVBQVUsS0FBSyxVQUFVLEVBQUU7SUFDMUNILEdBQUcsQ0FBQ0ksZ0JBQWdCLENBQUMsTUFBTSxFQUFFSCxRQUFRLENBQUM7RUFDeEMsQ0FBQyxNQUFNO0lBQ0xJLGNBQWMsQ0FBQ0osUUFBUSxDQUFDO0VBQzFCO0FBQ0Y7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNNLHdCQUF3QixDQUFDQyxHQUFHLEVBQUU7RUFDNUMsTUFBTUMsWUFBWSxHQUFHLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLE9BQU8sQ0FBQztFQUNsRixLQUFLLE1BQU1DLE9BQU8sSUFBSUYsR0FBRyxDQUFDRyxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFO0lBQ2pFLE1BQU1DLGFBQWEsR0FBRyxDQUFDLE1BQU07TUFDM0IsTUFBTUMsTUFBTSxHQUFHLEVBQUU7TUFDakIsTUFBTUMsSUFBSSxHQUFHSixPQUFPLENBQUNLLE9BQU8sQ0FBQ0MsUUFBUTtNQUNyQyxJQUFJLENBQUNGLElBQUksRUFBRTtRQUNULE9BQU9ELE1BQU07TUFDZjtNQUNBLE1BQU1JLEdBQUcsR0FBR0gsSUFBSSxDQUFDSSxLQUFLLENBQUMsR0FBRyxDQUFDO01BQzNCLEtBQUssTUFBTUMsRUFBRSxJQUFJRixHQUFHLEVBQUU7UUFDcEIsTUFBTUcsVUFBVSxHQUFHWixHQUFHLENBQUNhLGNBQWMsQ0FBQ0YsRUFBRSxDQUFDO1FBQ3pDLE1BQU1HLFNBQVMsR0FBR0YsVUFBVSxDQUFDTCxPQUFPLENBQUNRLFVBQVU7UUFDL0NwRCxzREFBYSxDQUFDc0MsWUFBWSxDQUFDZ0IsUUFBUSxDQUFDSCxTQUFTLENBQUMsRUFBRSxtQkFBbUIsRUFBRTtVQUFFQSxTQUFTO1VBQUVGO1FBQVcsQ0FBQyxDQUFDO1FBQy9GUCxNQUFNLENBQUNhLElBQUksQ0FBQ04sVUFBVSxDQUFDRSxTQUFTLENBQUMsQ0FBQztNQUNwQztNQUNBLE9BQU9ULE1BQU07SUFDZixDQUFDLEdBQUc7SUFDSixNQUFNdEIsTUFBTSxHQUFHbUIsT0FBTyxDQUFDSyxPQUFPLENBQUNRLFVBQVU7SUFDekNwRCxzREFBYSxDQUFDc0MsWUFBWSxDQUFDZ0IsUUFBUSxDQUFDbEMsTUFBTSxDQUFDLEVBQUUsbUJBQW1CLEVBQUU7TUFBRUEsTUFBTTtNQUFFbUI7SUFBUSxDQUFDLENBQUM7SUFDdEZBLE9BQU8sQ0FBQ25CLE1BQU0sQ0FBQyxHQUFHb0MsTUFBTSxDQUFDQyxJQUFJLENBQUNDLFVBQVUsQ0FBQ25CLE9BQU8sQ0FBQ0ssT0FBTyxDQUFDZSxRQUFRLEVBQUVsQixhQUFhLENBQUM7RUFDbkY7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTbUIsWUFBWSxDQUFDL0IsR0FBRyxFQUFFO0VBQ2hDLFNBQVNnQyx3QkFBd0IsQ0FBQ0MsU0FBUyxFQUFFO0lBQzNDLElBQUlBLFNBQVMsQ0FBQ0MsVUFBVSxLQUFLLENBQUMsRUFBRTtNQUM5QixNQUFNQyxLQUFLLEdBQUdGLFNBQVMsQ0FBQ0csVUFBVSxDQUFDLENBQUMsQ0FBQztNQUNyQyxJQUFJRCxLQUFLLENBQUNFLGNBQWMsS0FBS0YsS0FBSyxDQUFDRyxZQUFZLEVBQUU7UUFDL0MsTUFBTUMsdUJBQXVCLEdBQUdKLEtBQUssQ0FBQ0ksdUJBQXVCO1FBQzdELElBQUlBLHVCQUF1QixZQUFZQyxPQUFPLEVBQUU7VUFDOUMsSUFBSUQsdUJBQXVCLENBQUNFLFVBQVUsRUFBRTtZQUN0QyxPQUFPVCx3QkFBd0IsQ0FBQ08sdUJBQXVCLENBQUNFLFVBQVUsQ0FBQ1YsWUFBWSxFQUFFLENBQUM7VUFDcEYsQ0FBQyxNQUFNO1lBQ0wsTUFBTVcsc0JBQXNCLEdBQUdDLEtBQUssQ0FBQ0MsU0FBUyxDQUFDaEQsTUFBTSxDQUFDaUQsSUFBSSxDQUN4RE4sdUJBQXVCLENBQUM1QixnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsRUFDNUNELE9BQU8sSUFBSyxDQUFDLENBQUNBLE9BQU8sQ0FBQytCLFVBQVUsQ0FDbEM7WUFDRCxJQUFJQyxzQkFBc0IsQ0FBQ2xFLE1BQU0sS0FBSyxDQUFDLEVBQUU7Y0FDdkMsT0FBT3dELHdCQUF3QixDQUFDVSxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQ0QsVUFBVSxDQUFDVixZQUFZLEVBQUUsQ0FBQztZQUN0RjtVQUNGO1FBQ0Y7TUFDRjtJQUNGO0lBQ0EsT0FBT0UsU0FBUztFQUNsQjtFQUVBLE9BQU9ELHdCQUF3QixDQUFDaEMsR0FBRyxDQUFDK0IsWUFBWSxFQUFFLENBQUM7QUFDckQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU2UsV0FBVyxDQUFDQyxJQUFJLEVBQUVDLE9BQU8sRUFBRTtFQUN6QyxJQUFJO0lBQ0ZELElBQUksQ0FBQ0QsV0FBVyxDQUFDRSxPQUFPLENBQUM7RUFDM0IsQ0FBQyxDQUFDLE9BQU9DLEtBQUssRUFBRTtJQUNkOUUsb0RBQVcsQ0FDVCx3R0FBd0csRUFDeEc7TUFBRThFLEtBQUs7TUFBRUYsSUFBSTtNQUFFQztJQUFRLENBQUMsQ0FDekI7RUFDSDtBQUNGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlRyxZQUFZLEdBQUc7RUFDbkMsTUFBTSxDQUFDQyxHQUFHLENBQUMsR0FBRyxNQUFNekIsTUFBTSxDQUFDMEIsSUFBSSxDQUFDQyxLQUFLLENBQUM7SUFBRUMsTUFBTSxFQUFFLElBQUk7SUFBRUMsYUFBYSxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQzVFLE9BQU9KLEdBQUc7QUFDWjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVLLFlBQVksQ0FBQ0wsR0FBRyxFQUFFTSxNQUFNLEVBQUU7RUFDOUMsT0FBTyxNQUFNL0IsTUFBTSxDQUFDMEIsSUFBSSxDQUFDTSxNQUFNLENBQUM7SUFDOUJDLFFBQVEsRUFBRVIsR0FBRyxDQUFDUSxRQUFRO0lBQ3RCQyxXQUFXLEVBQUVULEdBQUcsQ0FBQ2pDLEVBQUU7SUFDbkIyQyxLQUFLLEVBQUVWLEdBQUcsQ0FBQ1UsS0FBSyxHQUFHLENBQUM7SUFDcEJDLEdBQUcsRUFBRUwsTUFBTSxFQUFFSyxHQUFHO0lBQ2hCUixNQUFNLEVBQUVHLE1BQU0sRUFBRUgsTUFBTSxJQUFJO0VBQzVCLENBQUMsQ0FBQztBQUNKOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVTLGVBQWUsQ0FBQ04sTUFBTSxFQUFFO0VBQzVDLE1BQU1GLGFBQWEsR0FBRyxNQUFNN0IsTUFBTSxDQUFDc0MsT0FBTyxDQUFDQyxVQUFVLEVBQUU7RUFDdkQsT0FBTyxNQUFNdkMsTUFBTSxDQUFDc0MsT0FBTyxDQUFDTixNQUFNLENBQUM7SUFDakNRLEtBQUssRUFBRVgsYUFBYSxDQUFDVyxLQUFLO0lBQzFCSixHQUFHLEVBQUVMLE1BQU0sRUFBRUs7RUFDZixDQUFDLENBQUM7QUFDSjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZUssY0FBYyxDQUFDaEIsR0FBRyxFQUFFaUIsVUFBVSxFQUFFQyxRQUFRLEVBQUU7RUFDOUQsTUFBTUMsYUFBYSxHQUFHbEcsc0VBQW9CLENBQUNpRyxRQUFRLEVBQUUsSUFBSWpHLCtEQUFhLENBQUNELDREQUFtQixFQUFFLElBQUksQ0FBQyxDQUFDO0VBQ2xHLElBQUltRyxhQUFhLENBQUNFLFdBQVcsS0FBS3BHLG1GQUFpQyxFQUFFO0lBQ25FLE1BQU11RyxNQUFNLEdBQUcsTUFBTW5CLFlBQVksQ0FBQ0wsR0FBRyxFQUFFO01BQUVHLE1BQU0sRUFBRTtJQUFNLENBQUMsQ0FBQztJQUN6RCxNQUFNNUIsTUFBTSxDQUFDa0QsTUFBTSxDQUFDdkIsS0FBSyxDQUFDO01BQUV3QixLQUFLLEVBQUVGLE1BQU0sQ0FBQ3pELEVBQUU7TUFBRW5DLElBQUksRUFBRUQsU0FBUyxDQUFDc0YsVUFBVTtJQUFFLENBQUMsQ0FBQztJQUM1RTtJQUNBO0lBQ0EsSUFBSUUsYUFBYSxDQUFDaEIsTUFBTSxJQUFJLElBQUksRUFBRTtNQUNoQyxNQUFNNUIsTUFBTSxDQUFDMEIsSUFBSSxDQUFDMEIsTUFBTSxDQUFDSCxNQUFNLENBQUN6RCxFQUFFLEVBQUU7UUFBRW9DLE1BQU0sRUFBRTtNQUFLLENBQUMsQ0FBQztJQUN2RDtFQUNGLENBQUMsTUFBTTtJQUNMLE1BQU01QixNQUFNLENBQUNrRCxNQUFNLENBQUN2QixLQUFLLENBQUM7TUFBRW1CLFdBQVcsRUFBRUYsYUFBYSxDQUFDRSxXQUFXO01BQUV6RixJQUFJLEVBQUVELFNBQVMsQ0FBQ3NGLFVBQVU7SUFBRSxDQUFDLENBQUM7RUFDcEc7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVXLFFBQVEsQ0FBQzVCLEdBQUcsRUFBRVcsR0FBRyxFQUFFTyxRQUFRLEVBQUVXLG9CQUFvQixFQUFFO0VBQ3ZFLE1BQU1WLGFBQWEsR0FBR2xHLHNFQUFvQixDQUFDaUcsUUFBUSxFQUFFVyxvQkFBb0IsQ0FBQztFQUMxRSxJQUFJVixhQUFhLENBQUNFLFdBQVcsS0FBS3BHLHVGQUFxQyxFQUFFO0lBQ3ZFLE1BQU1zRCxNQUFNLENBQUMwQixJQUFJLENBQUMwQixNQUFNLENBQUMzQixHQUFHLENBQUNqQyxFQUFFLEVBQUU7TUFBRTRDLEdBQUcsRUFBRUE7SUFBSSxDQUFDLENBQUM7RUFDaEQsQ0FBQyxNQUFNLElBQUlRLGFBQWEsQ0FBQ0UsV0FBVyxLQUFLcEcsc0ZBQW9DLEVBQUU7SUFDN0UsTUFBTTJGLGVBQWUsQ0FBQztNQUFFRCxHQUFHLEVBQUVBO0lBQUksQ0FBQyxDQUFDO0VBQ3JDLENBQUMsTUFBTTtJQUNMLE1BQU1OLFlBQVksQ0FBQ0wsR0FBRyxFQUFFO01BQUVXLEdBQUcsRUFBRUEsR0FBRztNQUFFUixNQUFNLEVBQUVnQixhQUFhLENBQUNoQixNQUFNLElBQUk7SUFBSyxDQUFDLENBQUM7RUFDN0U7QUFDRjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxlQUFlNkIsZUFBZSxDQUFDaEMsR0FBRyxFQUFFa0IsUUFBUSxFQUFFVyxvQkFBb0IsRUFBRTtFQUN6RSxNQUFNbEIsR0FBRyxHQUFHcEMsTUFBTSxDQUFDMEQsT0FBTyxDQUFDQyxNQUFNLENBQUMsY0FBYyxDQUFDO0VBQ2pELE1BQU1OLFFBQVEsQ0FBQzVCLEdBQUcsRUFBRVcsR0FBRyxFQUFFTyxRQUFRLEVBQUVXLG9CQUFvQixDQUFDO0FBQzFEOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLGVBQWVNLHdCQUF3QixDQUFDbkMsR0FBRyxFQUFFa0IsUUFBUSxFQUFFVyxvQkFBb0IsRUFBRTtFQUNsRixNQUFNbEIsR0FBRyxHQUFHLDBCQUEwQjtFQUN0QyxNQUFNaUIsUUFBUSxDQUFDNUIsR0FBRyxFQUFFVyxHQUFHLEVBQUVPLFFBQVEsRUFBRVcsb0JBQW9CLENBQUM7QUFDMUQ7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZU8scUJBQXFCLENBQUNwQyxHQUFHLEVBQUVrQixRQUFRLEVBQUVXLG9CQUFvQixFQUFFO0VBQy9FLE1BQU1sQixHQUFHLEdBQUcsK0JBQStCO0VBQzNDLE1BQU1pQixRQUFRLENBQUM1QixHQUFHLEVBQUVXLEdBQUcsRUFBRU8sUUFBUSxFQUFFVyxvQkFBb0IsQ0FBQztBQUMxRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVXdUM7QUFDSztBQUNMO0FBQ0U7O0FBRXpDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBSTlHLE1BQU07O0FBRWpCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBSUMsT0FBTzs7QUFFbEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sZUFBZXVILElBQUksQ0FBQ0MsUUFBUSxFQUFFO0VBQ25DekgsTUFBTSxHQUFHLElBQUlzSCw4Q0FBTSxDQUFDRyxRQUFRLENBQUM7RUFDN0J6SCxNQUFNLENBQUNnRyxLQUFLLENBQUMsbUJBQW1CLEVBQUU7SUFBRXlCO0VBQVMsQ0FBQyxDQUFDO0VBRS9DeEgsT0FBTyxHQUFHLElBQUlzSCxnREFBTyxDQUFDdkgsTUFBTSxDQUFDO0VBQzdCLE1BQU1DLE9BQU8sQ0FBQ3VILElBQUksRUFBRTtFQUVwQixNQUFNRSxZQUFZLENBQUNELFFBQVEsQ0FBQztBQUM5QjtBQUVBLGVBQWVDLFlBQVksQ0FBQ0QsUUFBUSxFQUFFO0VBQ3BDLE1BQU1FLFdBQVcsR0FBRyxPQUFPO0VBQzNCLE1BQU1DLE9BQU8sR0FBR3BFLE1BQU0sQ0FBQ29FLE9BQU8sQ0FBQ0MsS0FBSztFQUNwQyxJQUFJSixRQUFRLEtBQUszSSw4REFBbUIsRUFBRTtJQUNwQ0Qsb0RBQVksR0FBRyxDQUFDLE1BQU0yRSxNQUFNLENBQUMwRCxPQUFPLENBQUNhLGVBQWUsRUFBRSxFQUFFQyxFQUFFLEtBQUssS0FBSztJQUNwRSxNQUFNSixPQUFPLENBQUNLLEdBQUcsQ0FBQztNQUFFLENBQUNOLFdBQVcsR0FBRzlJLG9EQUFZaUo7SUFBQyxDQUFDLENBQUM7RUFDcEQsQ0FBQyxNQUFNO0lBQ0xqSixvREFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0rSSxPQUFPLENBQUNNLEdBQUcsQ0FBQ1AsV0FBVyxDQUFDLEVBQUVBLFdBQVcsQ0FBQztFQUNoRTtFQUNBM0gsTUFBTSxDQUFDZ0csS0FBSyxDQUFDLDJCQUEyQixFQUFFO0lBQUUsQ0FBQyxjQUFjLEdBQUduSCxvREFBWWlKO0VBQUMsQ0FBQyxDQUFDO0FBQy9FOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BEdUM7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTTVILGFBQWEsQ0FBQztFQUN6QjtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT3FHLFdBQVcsR0FBRztJQUNuQlEsV0FBVyxFQUFFLGFBQWE7SUFDMUJQLE9BQU8sRUFBRSxTQUFTO0lBQ2xCUSxVQUFVLEVBQUU7RUFDZCxDQUFDO0VBRUQsT0FBT21CLFFBQVEsR0FBRyxNQUFNQSxRQUFRLENBQUM7SUFDL0JDLE9BQU87SUFDUEMsUUFBUTs7SUFFUjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDSUMsV0FBVyxDQUFDRixPQUFPLEVBQUVDLFFBQVEsRUFBRUUsT0FBTyxHQUFHSCxPQUFPLEVBQUU7TUFDaEQsSUFBSSxDQUFDQSxPQUFPLEdBQUd2SixvREFBWSxHQUFHMEosT0FBTyxHQUFHSCxPQUFPO01BQy9DLElBQUksQ0FBQ0MsUUFBUSxHQUFHQSxRQUFRO0lBQzFCO0lBRUFHLE1BQU0sQ0FBQ0MsS0FBSyxFQUFFO01BQ1osT0FBT0EsS0FBSyxJQUFJLElBQUksQ0FBQ0wsT0FBTyxLQUFLSyxLQUFLLENBQUNMLE9BQU8sSUFBSSxJQUFJLENBQUNDLFFBQVEsS0FBS0ksS0FBSyxDQUFDSixRQUFRO0lBQ3BGO0lBRUEsT0FBT3RCLFdBQVcsR0FBRyxJQUFJb0IsUUFBUSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUM7SUFDL0MsT0FBT08sY0FBYyxHQUFHLElBQUlQLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDO0lBQ2hELE9BQU9RLGdCQUFnQixHQUFHLElBQUlSLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDO0lBQ25ELE9BQU9uQixVQUFVLEdBQUcsSUFBSW1CLFFBQVEsQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDO0VBQy9DLENBQUM7O0VBRUQ7QUFDRjtBQUNBO0VBQ0U3QixXQUFXOztFQUVYO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7RUFDRWxCLE1BQU07O0VBRU47QUFDRjtBQUNBO0FBQ0E7RUFDRWtELFdBQVcsQ0FBQ2hDLFdBQVcsRUFBRWxCLE1BQU0sR0FBRyxJQUFJLEVBQUU7SUFDdEMsSUFBSSxDQUFDa0IsV0FBVyxHQUFHQSxXQUFXO0lBQzlCLElBQUksQ0FBQ2xCLE1BQU0sR0FBR0EsTUFBTTtFQUN0QjtFQUVBLE9BQU8yQixXQUFXLEdBQUcsSUFBSTdHLGFBQWEsQ0FBQ0EsYUFBYSxDQUFDcUcsV0FBVyxDQUFDUSxXQUFXLENBQUM7RUFDN0UsT0FBTzJCLGNBQWMsR0FBRyxJQUFJeEksYUFBYSxDQUFDQSxhQUFhLENBQUNxRyxXQUFXLENBQUNDLE9BQU8sRUFBRSxJQUFJLENBQUM7RUFDbEYsT0FBT21DLGdCQUFnQixHQUFHLElBQUl6SSxhQUFhLENBQUNBLGFBQWEsQ0FBQ3FHLFdBQVcsQ0FBQ0MsT0FBTyxFQUFFLEtBQUssQ0FBQztFQUNyRixPQUFPUSxVQUFVLEdBQUcsSUFBSTlHLGFBQWEsQ0FBQ0EsYUFBYSxDQUFDcUcsV0FBVyxDQUFDUyxVQUFVLENBQUM7O0VBRTNFO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBT1gsTUFBTSxDQUFDRixRQUFRLEVBQUVXLG9CQUFvQixFQUFFO0lBQzVDLElBQUk1RyxhQUFhLENBQUNpSSxRQUFRLENBQUNPLGNBQWMsQ0FBQ0YsTUFBTSxDQUFDckMsUUFBUSxDQUFDLEVBQUUsT0FBT2pHLGFBQWEsQ0FBQ3dJLGNBQWMsQ0FBQyxLQUMzRixJQUFJeEksYUFBYSxDQUFDaUksUUFBUSxDQUFDUSxnQkFBZ0IsQ0FBQ0gsTUFBTSxDQUFDckMsUUFBUSxDQUFDLEVBQUUsT0FBT2pHLGFBQWEsQ0FBQ3lJLGdCQUFnQixDQUFDLEtBQ3BHLElBQUl6SSxhQUFhLENBQUNpSSxRQUFRLENBQUNuQixVQUFVLENBQUN3QixNQUFNLENBQUNyQyxRQUFRLENBQUMsRUFBRSxPQUFPakcsYUFBYSxDQUFDOEcsVUFBVSxDQUFDLEtBQ3hGLE9BQU9GLG9CQUFvQixJQUFJNUcsYUFBYSxDQUFDNkcsV0FBVztFQUMvRDtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3JGdUM7O0FBRXZDO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTU8sTUFBTSxDQUFDO0VBQ2xCLENBQUN0RSxFQUFFOztFQUVIO0FBQ0Y7QUFDQTtBQUNBO0VBQ0VzRixXQUFXLENBQUN0RixFQUFFLEVBQUU7SUFDZCxJQUFJLENBQUMsQ0FBQ0EsRUFBRSxHQUFHQSxFQUFFO0VBQ2Y7O0VBRUE7QUFDRjtBQUNBO0VBQ0U0RixLQUFLLENBQUM1RixFQUFFLEVBQUU7SUFDUixJQUFJLENBQUMsQ0FBQ0EsRUFBRSxHQUFHQSxFQUFFO0VBQ2Y7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFNkYsSUFBSSxDQUFDaEUsT0FBTyxFQUFFLEdBQUdsQyxJQUFJLEVBQUU7SUFDckIsSUFBSSxDQUFDLENBQUNtRyxNQUFNLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRWpFLE9BQU8sRUFBRWxDLElBQUksQ0FBQztFQUNoRDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0VxRCxLQUFLLENBQUNuQixPQUFPLEVBQUUsR0FBR2xDLElBQUksRUFBRTtJQUN0QixJQUFJLENBQUMsQ0FBQ21HLE1BQU0sQ0FBQyxPQUFPLEVBQUUsU0FBUyxFQUFFakUsT0FBTyxFQUFFbEMsSUFBSSxDQUFDO0VBQ2pEOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRW9HLFFBQVEsQ0FBQ2xFLE9BQU8sRUFBRSxHQUFHbEMsSUFBSSxFQUFFO0lBQ3pCLElBQUksQ0FBQyxDQUFDbUcsTUFBTSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUVqRSxPQUFPLEVBQUVsQyxJQUFJLENBQUM7RUFDcEQ7O0VBRUE7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNFb0MsSUFBSSxDQUFDRixPQUFPLEVBQUUsR0FBR2xDLElBQUksRUFBRTtJQUNyQixJQUFJLENBQUMsQ0FBQ21HLE1BQU0sQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFakUsT0FBTyxFQUFFbEMsSUFBSSxDQUFDO0VBQy9DOztFQUVBO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRW1DLEtBQUssQ0FBQ0QsT0FBTyxFQUFFLEdBQUdsQyxJQUFJLEVBQUU7SUFDdEIsSUFBSSxDQUFDLENBQUNtRyxNQUFNLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRWpFLE9BQU8sRUFBRWxDLElBQUksQ0FBQztFQUNqRDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRVUsTUFBTSxDQUFDMkYsU0FBUyxFQUFFbkUsT0FBTyxFQUFFLEdBQUdsQyxJQUFJLEVBQUU7SUFDbEMsSUFBSSxDQUFDLENBQUNtRyxNQUFNLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRWpFLE9BQU8sRUFBRWxDLElBQUksRUFBRXFHLFNBQVMsQ0FBQztFQUM3RDs7RUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDRSxDQUFDRixNQUFNLENBQUNHLFVBQVUsRUFBRUMsTUFBTSxFQUFFckUsT0FBTyxFQUFFbEMsSUFBSSxFQUFFcUcsU0FBUyxFQUFFO0lBQ3BELElBQUksQ0FBQ25LLHlEQUFpQixFQUFFO01BQ3RCO0lBQ0Y7SUFFQSxNQUFNdUssWUFBWSxHQUFHLEVBQUU7SUFDdkIsSUFBSXpHLElBQUksSUFBSUEsSUFBSSxDQUFDdEMsTUFBTSxHQUFHLENBQUMsSUFBSSxPQUFPc0MsSUFBSSxDQUFDMEcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssUUFBUSxFQUFFO01BQzlELEtBQUssTUFBTSxDQUFDQyxHQUFHLEVBQUVDLEtBQUssQ0FBQyxJQUFJakksTUFBTSxDQUFDRSxPQUFPLENBQUNtQixJQUFJLENBQUM2RyxHQUFHLEVBQUUsQ0FBQyxFQUFFO1FBQ3JESixZQUFZLENBQUM3RixJQUFJLENBQUUsS0FBSStGLEdBQUksR0FBRSxDQUFDO1FBQzlCRixZQUFZLENBQUM3RixJQUFJLENBQUNnRyxLQUFLLENBQUM7TUFDMUI7SUFDRjtJQUVBRSxPQUFPLENBQUNSLFVBQVUsQ0FBQyxDQUNqQixJQUFJQSxVQUFVLEtBQUssUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDRCxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUMsRUFDaEQsSUFBRyxJQUFJLENBQUMsQ0FBQ2hHLEVBQUcsS0FBSWtHLE1BQU8sSUFBR3JFLE9BQVEsRUFBQyxFQUNwQyxHQUFHbEMsSUFBSSxFQUNQLEdBQUd5RyxZQUFZLENBQ2hCO0VBQ0g7QUFDRjs7Ozs7Ozs7Ozs7Ozs7OztBQzlId0Q7O0FBRXhEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sTUFBTTdCLE9BQU8sQ0FBQztFQUNuQixPQUFPLENBQUNLLE9BQU8sR0FBR3BFLE1BQU0sQ0FBQ29FLE9BQU8sQ0FBQzhCLElBQUk7RUFFckMsT0FBTyxDQUFDL0IsV0FBVyxHQUFHLFNBQVM7RUFFL0IsT0FBTyxDQUFDZ0MsY0FBYyxHQUFHLGVBQWU7RUFFeEMsT0FBTyxDQUFDQyxjQUFjLEdBQUc7SUFDdkIsQ0FBQ3JDLE9BQU8sQ0FBQyxDQUFDb0MsY0FBYyxHQUFHO0VBQzdCLENBQUM7RUFFRCxPQUFPcEQsV0FBVyxHQUFHckcsMkVBQXlCO0VBRTlDLE9BQU8ySixhQUFhLEdBQUcsQ0FBQztFQUN4QixPQUFPQyxhQUFhLEdBQUcsQ0FBQzs7RUFFeEI7RUFDQTtBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0UsT0FBTyxDQUFDQyxLQUFLLEdBQUcsQ0FDZDtJQUFFQyxJQUFJLEVBQUUsV0FBVztJQUFPQyxZQUFZLEVBQUUsSUFBSTtJQUF5QkMsU0FBUyxFQUFHWCxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsRUFDMUw7SUFBRVMsSUFBSSxFQUFFLFVBQVU7SUFBUUMsWUFBWSxFQUFFLENBQUM7SUFBNEJDLFNBQVMsRUFBR1gsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSyxRQUFRLElBQUlBLEtBQUssSUFBSWhDLE9BQU8sQ0FBQ3NDLGFBQWEsSUFBSU4sS0FBSyxJQUFJaEMsT0FBTyxDQUFDdUM7RUFBYyxDQUFDLEVBQzFMO0lBQUVFLElBQUksRUFBRSxnQkFBZ0I7SUFBRUMsWUFBWSxFQUFFLEtBQUs7SUFBd0JDLFNBQVMsRUFBR1gsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSztFQUE2RSxDQUFDLEVBQzFMO0lBQUVTLElBQUksRUFBRSxlQUFlO0lBQUdDLFlBQVksRUFBRSxJQUFJO0lBQXlCQyxTQUFTLEVBQUdYLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUs7RUFBNkUsQ0FBQyxFQUMxTDtJQUFFUyxJQUFJLEVBQUUsYUFBYTtJQUFLQyxZQUFZLEVBQUUsSUFBSTtJQUF5QkMsU0FBUyxFQUFHWCxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsRUFDMUw7SUFBRVMsSUFBSSxFQUFFLGFBQWE7SUFBS0MsWUFBWSxFQUFFMUMsT0FBTyxDQUFDaEIsV0FBVyxDQUFDQyxPQUFPO0lBQUUwRCxTQUFTLEVBQUdYLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUssUUFBUSxJQUFJakksTUFBTSxDQUFDNkksTUFBTSxDQUFDNUMsT0FBTyxDQUFDaEIsV0FBVyxDQUFDLENBQUNqRCxRQUFRLENBQUNpRyxLQUFLO0VBQWdCLENBQUMsRUFDMUw7SUFBRVMsSUFBSSxFQUFFLFVBQVU7SUFBUUMsWUFBWSxFQUFFLElBQUk7SUFBeUJDLFNBQVMsRUFBR1gsS0FBSyxJQUFLLE9BQU9BLEtBQUssS0FBSztFQUE2RSxDQUFDLEVBQzFMO0lBQUVTLElBQUksRUFBRSxXQUFXO0lBQU9DLFlBQVksRUFBRSxJQUFJO0lBQXlCQyxTQUFTLEVBQUdYLEtBQUssSUFBSyxPQUFPQSxLQUFLLEtBQUs7RUFBNkUsQ0FBQyxFQUMxTDtJQUFFUyxJQUFJLEVBQUUsY0FBYztJQUFJQyxZQUFZLEVBQUUsS0FBSztJQUF3QkMsU0FBUyxFQUFHWCxLQUFLLElBQUssT0FBT0EsS0FBSyxLQUFLO0VBQTZFLENBQUMsQ0FDM0w7RUFFRCxPQUFPLENBQUNhLGFBQWEsR0FBRztJQUN0QixLQUFLLE1BQU07TUFBRUosSUFBSTtNQUFFQyxZQUFZO01BQUVDO0lBQVUsQ0FBQyxJQUFJM0MsT0FBTyxDQUFDLENBQUN3QyxLQUFLLEVBQUU7TUFDOUR4QyxPQUFPLENBQUMsQ0FBQ3FDLGNBQWMsQ0FBQ0ksSUFBSSxDQUFDLEdBQUdDLFlBQVk7TUFDNUMzSSxNQUFNLENBQUMrSSxjQUFjLENBQUM5QyxPQUFPLENBQUM5QyxTQUFTLEVBQUV1RixJQUFJLEVBQUU7UUFDN0MvQixHQUFHLENBQUNzQixLQUFLLEVBQUU7VUFDVCxJQUFJLENBQUNXLFNBQVMsQ0FBQ1gsS0FBSyxDQUFDLEVBQUU7WUFDckIsTUFBTSxJQUFJZSxLQUFLLENBQUUsK0JBQThCTixJQUFLLFlBQVdULEtBQU0sRUFBQyxDQUFDO1VBQ3pFO1VBQ0EsSUFBSUEsS0FBSyxLQUFLLElBQUksQ0FBQyxDQUFDZ0IsS0FBSyxDQUFDUCxJQUFJLENBQUMsRUFBRTtZQUMvQixJQUFJLENBQUMsQ0FBQ08sS0FBSyxDQUFDUCxJQUFJLENBQUMsR0FBR1QsS0FBSztZQUN6QjtZQUFZLElBQUksQ0FBQyxDQUFDaUIsYUFBYSxFQUFFO1VBQ25DO1FBQ0YsQ0FBQztRQUNEdEMsR0FBRyxHQUFHO1VBQ0osT0FBT2dDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQ0ssS0FBSyxDQUFDUCxJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDTyxLQUFLLENBQUNQLElBQUksQ0FBQyxHQUFHQyxZQUFZO1FBQ3hFO01BQ0YsQ0FBQyxDQUFDO0lBQ0o7RUFDRjtFQUFDLFlBR0MxQyxPQUFPLENBQUMsQ0FBQzZDLGFBQWEsRUFBRTtFQUcxQjtBQUNGO0FBQ0E7RUFDRUssU0FBUyxHQUFHLElBQUssTUFBTUEsU0FBUyxDQUFDO0lBQy9CLENBQUNDLFNBQVMsR0FBRyxFQUFFO0lBQ2Y7QUFDSjtBQUNBO0lBQ0lDLFdBQVcsQ0FBQzdJLFFBQVEsRUFBRTtNQUNwQixJQUFJLENBQUMsQ0FBQzRJLFNBQVMsQ0FBQ25ILElBQUksQ0FBQ3pCLFFBQVEsQ0FBQztJQUNoQztJQUNBOEksS0FBSyxHQUFHO01BQ04sS0FBSyxNQUFNOUksUUFBUSxJQUFJLElBQUksQ0FBQyxDQUFDNEksU0FBUyxFQUFFO1FBQ3RDNUksUUFBUSxFQUFFO01BQ1o7SUFDRjtFQUNGLENBQUMsRUFBRztFQUVKLENBQUM5QixNQUFNO0VBQ1AsQ0FBQ3VLLEtBQUs7O0VBRU47QUFDRjtBQUNBO0VBQ0VqQyxXQUFXLENBQUN0SSxNQUFNLEVBQUU7SUFDbEIsSUFBSSxDQUFDLENBQUNBLE1BQU0sR0FBR0EsTUFBTTtJQUNyQixJQUFJLENBQUMsQ0FBQ3VLLEtBQUssR0FBR2pKLE1BQU0sQ0FBQ3VKLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXRELE9BQU8sQ0FBQyxDQUFDcUMsY0FBYyxDQUFDO0lBRXhEckMsT0FBTyxDQUFDLENBQUNLLE9BQU8sQ0FBQzZDLFNBQVMsQ0FBQ0UsV0FBVyxDQUFDLENBQUNHLE9BQU8sRUFBRUMsUUFBUSxLQUFLO01BQzVELElBQUksQ0FBQyxDQUFDQyxpQkFBaUIsQ0FBQ0YsT0FBTyxFQUFFQyxRQUFRLENBQUM7SUFDNUMsQ0FBQyxDQUFDO0VBQ0o7O0VBRUE7QUFDRjtBQUNBO0VBQ0UsTUFBTXZELElBQUksR0FBRztJQUNYLE1BQU0yQyxNQUFNLEdBQUcsTUFBTTVDLE9BQU8sQ0FBQyxDQUFDSyxPQUFPLENBQUNNLEdBQUcsQ0FBQ1gsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQztJQUMvRDtJQUNBO0lBQ0FyRyxNQUFNLENBQUN1SixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUNOLEtBQUssRUFBRUosTUFBTSxDQUFDNUMsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDO0lBQ3hELElBQUksQ0FBQyxDQUFDM0gsTUFBTSxDQUFDZ0csS0FBSyxDQUFDLHNCQUFzQixFQUFFO01BQUUsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLENBQUN1RTtJQUFNLENBQUMsQ0FBQztFQUM5RTs7RUFFQTtBQUNGO0FBQ0E7RUFDRVUsS0FBSyxHQUFHO0lBQ04sSUFBSSxDQUFDLENBQUNWLEtBQUssR0FBR2pKLE1BQU0sQ0FBQ3VKLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXRELE9BQU8sQ0FBQyxDQUFDcUMsY0FBYyxDQUFDO0lBQ3hEO0lBQVksSUFBSSxDQUFDLENBQUNZLGFBQWEsRUFBRTtFQUNuQztFQUVBLE1BQU0sQ0FBQ0EsYUFBYSxHQUFHO0lBQ3JCLElBQUksQ0FBQyxDQUFDRCxLQUFLLENBQUNoRCxPQUFPLENBQUMsQ0FBQ29DLGNBQWMsQ0FBQyxHQUFHdUIsSUFBSSxDQUFDQyxHQUFHLEVBQUU7SUFDakQsTUFBTWhCLE1BQU0sR0FBRztNQUFFLENBQUM1QyxPQUFPLENBQUMsQ0FBQ0ksV0FBVyxHQUFHLElBQUksQ0FBQyxDQUFDNEM7SUFBTSxDQUFDO0lBQ3RELElBQUksQ0FBQyxDQUFDdkssTUFBTSxDQUFDZ0csS0FBSyxDQUFDLHlCQUF5QixFQUFFO01BQUVtRTtJQUFPLENBQUMsQ0FBQztJQUN6RCxNQUFNNUMsT0FBTyxDQUFDLENBQUNLLE9BQU8sQ0FBQ0ssR0FBRyxDQUFDa0MsTUFBTSxDQUFDO0VBQ3BDO0VBRUEsQ0FBQ2EsaUJBQWlCLENBQUNGLE9BQU8sRUFBRUMsUUFBUSxFQUFFO0lBQ3BDLElBQUksQ0FBQyxDQUFDL0ssTUFBTSxDQUFDK0ksUUFBUSxDQUFDLDhCQUE4QixFQUFFO01BQUUrQixPQUFPO01BQUVDO0lBQVMsQ0FBQyxDQUFDO0lBRTVFLElBQUksQ0FBQ3pKLE1BQU0sQ0FBQzhKLE1BQU0sQ0FBQ04sT0FBTyxFQUFFdkQsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxFQUFFO01BQ2pEO0lBQ0Y7SUFFQSxJQUFJckcsTUFBTSxDQUFDOEosTUFBTSxDQUFDTixPQUFPLENBQUN2RCxPQUFPLENBQUMsQ0FBQ0ksV0FBVyxDQUFDLEVBQUUsVUFBVSxDQUFDLEVBQUU7TUFDNUQsTUFBTTBELFFBQVEsR0FBR1AsT0FBTyxDQUFDdkQsT0FBTyxDQUFDLENBQUNJLFdBQVcsQ0FBQyxDQUFDMEQsUUFBUTtNQUN2RCxJQUFJQSxRQUFRLENBQUM5RCxPQUFPLENBQUMsQ0FBQ29DLGNBQWMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDWSxLQUFLLENBQUNoRCxPQUFPLENBQUMsQ0FBQ29DLGNBQWMsQ0FBQyxFQUFFO1FBQzdFLElBQUksQ0FBQyxDQUFDM0osTUFBTSxDQUFDNkksSUFBSSxDQUFDLDZEQUE2RCxFQUFFO1VBQy9FLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxDQUFDMEI7UUFDekIsQ0FBQyxDQUFDO1FBQ0Y7TUFDRjs7TUFFQTtNQUNBO01BQ0FqSixNQUFNLENBQUN1SixNQUFNLENBQUMsSUFBSSxDQUFDLENBQUNOLEtBQUssRUFBRWMsUUFBUSxDQUFDO01BQ3BDLElBQUksQ0FBQyxDQUFDckwsTUFBTSxDQUFDZ0csS0FBSyxDQUFDLHNFQUFzRSxFQUFFO1FBQ3pGLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxDQUFDdUU7TUFDekIsQ0FBQyxDQUFDO0lBQ0osQ0FBQyxNQUFNO01BQ0w7O01BRUEsSUFBSSxDQUFDLENBQUNBLEtBQUssR0FBR2pKLE1BQU0sQ0FBQ3VKLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRXRELE9BQU8sQ0FBQyxDQUFDcUMsY0FBYyxDQUFDO01BQ3hELElBQUksQ0FBQyxDQUFDNUosTUFBTSxDQUFDZ0csS0FBSyxDQUFDLGlGQUFpRixFQUFFO1FBQ3BHLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxDQUFDdUU7TUFDekIsQ0FBQyxDQUFDO0lBQ0o7SUFFQSxJQUFJLENBQUNFLFNBQVMsQ0FBQ0csS0FBSyxFQUFFO0VBQ3hCO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEtBO0FBQ0E7QUFDQTs7QUFFOEI7QUFDRztBQUNBO0FBQ0Y7QUFDUztBQUNWOzs7Ozs7O1VDVDlCO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7O1dDdEJBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxpQ0FBaUMsV0FBVztXQUM1QztXQUNBOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0E7Ozs7O1dDUEE7Ozs7O1dDQUE7V0FDQTtXQUNBO1dBQ0EsdURBQXVELGlCQUFpQjtXQUN4RTtXQUNBLGdEQUFnRCxhQUFhO1dBQzdEOzs7Ozs7Ozs7Ozs7O0FDTmE7O0FBRThCO0FBRTNDLENBQUMsZUFBZVcsSUFBSSxHQUFHO0VBQ3JCO0VBQ0E7RUFDQTs7RUFFQSxNQUFNRCxvREFBUSxDQUFDQSxtRUFBdUIsQ0FBQzs7RUFFdkM7RUFDQTtFQUNBOztFQUVBLE1BQU1FLGdCQUFnQixHQUFHO0lBQ3ZCLENBQUNGLGlFQUFxQixHQUFHRyxPQUFPO0lBQ2hDLENBQUNILG9GQUF3QyxHQUFHSSx3QkFBd0I7SUFDcEUsQ0FBQ0osNEVBQWdDLEdBQUdLLGdCQUFnQjtJQUNwRCxDQUFDTCw2RUFBaUMsR0FBR00saUJBQWlCO0lBQ3RELENBQUNOLHlFQUE2QixHQUFHTztFQUNuQyxDQUFDOztFQUVEO0VBQ0E7RUFDQTs7RUFFQSxNQUFNQyxnQkFBZ0IsR0FBRztJQUN2QkMsTUFBTSxFQUFFcEssU0FBUztJQUNqQmQsSUFBSSxFQUFFLEVBQUU7SUFDUm1MLFFBQVEsRUFBRSxLQUFLO0lBQ2ZDLFVBQVUsRUFBRSxLQUFLO0lBQ2pCQyxJQUFJLEVBQUU7RUFDUixDQUFDO0VBRUQsTUFBTUMsUUFBUSxHQUFHO0lBQ2YsQ0FBQ2IsNEVBQWdDLEdBQUc7TUFDbENjLFFBQVEsRUFBRSxFQUFFO01BQ1pDLFdBQVcsRUFBRTtRQUNYQyxVQUFVLEVBQUU7VUFDVkMsS0FBSyxFQUFFL0ksTUFBTSxDQUFDQyxJQUFJLENBQUNDLFVBQVUsQ0FBQyx5Q0FBeUMsQ0FBQztVQUN4RThJLElBQUksRUFBRSxRQUFRO1VBQ2RDLFFBQVEsRUFBRSxDQUFDLFdBQVc7UUFDeEIsQ0FBQztRQUNEQyxVQUFVLEVBQUUsS0FBSztRQUNqQkMsWUFBWSxFQUFFLEtBQUs7UUFDbkJDLHdCQUF3QixFQUFFO01BQzVCLENBQUM7TUFDRCxNQUFNQyxpQkFBaUIsQ0FBQzVILEdBQUcsRUFBRTtRQUMzQixNQUFNNkgsOEJBQThCLENBQUM3SCxHQUFHLEVBQUU2RyxnQkFBZ0IsQ0FBQ2pMLElBQUksQ0FBQztNQUNsRSxDQUFDO01BQ0QsTUFBTWtNLG9CQUFvQixDQUFDbEUsSUFBSSxFQUFFNUQsR0FBRyxFQUFFO1FBQ3BDLE1BQU02SCw4QkFBOEIsQ0FBQzdILEdBQUcsRUFBRXFHLG1FQUF1QixDQUFDekMsSUFBSSxDQUFDekksYUFBYSxDQUFDLENBQUM7TUFDeEY7SUFDRixDQUFDO0lBQ0QsQ0FBQ2tMLHNFQUEwQixHQUFHO01BQzVCYyxRQUFRLEVBQUUsRUFBRTtNQUNaQyxXQUFXLEVBQUU7UUFDWEMsVUFBVSxFQUFFO1VBQ1ZDLEtBQUssRUFBRS9JLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDQyxVQUFVLENBQUMsbUNBQW1DLENBQUM7VUFDbEU4SSxJQUFJLEVBQUUsUUFBUTtVQUNkQyxRQUFRLEVBQUUsQ0FBQyxVQUFVO1FBQ3ZCLENBQUM7UUFDREMsVUFBVSxFQUFFLEtBQUs7UUFDakJDLFlBQVksRUFBRSxJQUFJO1FBQ2xCQyx3QkFBd0IsRUFBRTtNQUM1QixDQUFDO01BQ0RDLGlCQUFpQixDQUFDNUgsR0FBRyxFQUFFO1FBQ3JCK0gsNEJBQTRCLENBQUMvSCxHQUFHLEVBQUU2RyxnQkFBZ0IsQ0FBQ0MsTUFBTSxDQUFDa0IsT0FBTyxDQUFDO01BQ3BFLENBQUM7TUFDREYsb0JBQW9CLENBQUNsRSxJQUFJLEVBQUU1RCxHQUFHLEVBQUU7UUFDOUIrSCw0QkFBNEIsQ0FBQy9ILEdBQUcsRUFBRTRELElBQUksQ0FBQ29FLE9BQU8sQ0FBQztNQUNqRDtJQUNGO0VBQ0YsQ0FBQzs7RUFFRDtFQUNBO0VBQ0E7O0VBRUF6SixNQUFNLENBQUMwRCxPQUFPLENBQUNnRyxTQUFTLENBQUN2QyxXQUFXLENBQUN1QyxTQUFTLENBQUM7RUFFL0MxSixNQUFNLENBQUMwQixJQUFJLENBQUNpSSxXQUFXLENBQUN4QyxXQUFXLENBQUN5QyxjQUFjLENBQUM7RUFDbkQ1SixNQUFNLENBQUMwQixJQUFJLENBQUNtSSxTQUFTLENBQUMxQyxXQUFXLENBQUMyQyxhQUFhLENBQUM7RUFFaEQ5SixNQUFNLENBQUMrSixZQUFZLENBQUNDLFNBQVMsQ0FBQzdDLFdBQVcsQ0FBQ29DLG9CQUFvQixDQUFDO0VBQy9EdkosTUFBTSxDQUFDMkksUUFBUSxDQUFDc0IsU0FBUyxDQUFDOUMsV0FBVyxDQUFDOEMsU0FBUyxDQUFDO0VBRWhEbkMsNkVBQWlDLENBQUNvQyxnQkFBZ0IsQ0FBQzs7RUFFbkQ7RUFDQTtFQUNBOztFQUVBLGVBQWVSLFNBQVMsQ0FBQ3RJLElBQUksRUFBRTtJQUM3QjBHLCtEQUFtQixDQUFDLGFBQWEsRUFBRTtNQUFFMUc7SUFBSyxDQUFDLENBQUM7SUFDNUNBLElBQUksQ0FBQytJLFNBQVMsQ0FBQ2hELFdBQVcsQ0FBQ2dELFNBQVMsQ0FBQztJQUNyQyxNQUFNQyxzQkFBc0IsRUFBRTtFQUNoQztFQUVBLFNBQVNELFNBQVMsQ0FBQzlJLE9BQU8sRUFBRUQsSUFBSSxFQUFFO0lBQ2hDMEcsK0RBQW1CLENBQUMsYUFBYSxFQUFFO01BQUV6RyxPQUFPO01BQUVEO0lBQUssQ0FBQyxDQUFDO0lBQ3JENEcsZ0JBQWdCLENBQUMzRyxPQUFPLENBQUMySCxJQUFJLENBQUMsQ0FBQzNILE9BQU8sRUFBRUQsSUFBSSxDQUFDO0VBQy9DO0VBRUEsZUFBZTZHLE9BQU8sQ0FBQ29DLFFBQVEsRUFBRWpKLElBQUksRUFBRTtJQUNyQzBHLDJEQUFlLENBQUMxRyxJQUFJLEVBQUU7TUFDcEI0SCxJQUFJLEVBQUVsQixtRUFBdUI7TUFDN0J3QyxRQUFRLEVBQUV4Qyx3REFBWSxDQUFDMUcsSUFBSSxDQUFDbUgsTUFBTTtJQUNwQyxDQUFDLENBQUM7RUFDSjtFQUVBLFNBQVNMLHdCQUF3QixDQUFDN0csT0FBTyxFQUFFRCxJQUFJLEVBQUU7SUFDL0MsSUFBSUMsT0FBTyxDQUFDZixTQUFTLENBQUNvSSxJQUFJLEVBQUU7TUFDMUIsSUFBSSxDQUFDNkIseUJBQXlCLENBQUNuSixJQUFJLENBQUNtSCxNQUFNLENBQUM5RyxHQUFHLENBQUNqQyxFQUFFLEVBQUU0QixJQUFJLENBQUNtSCxNQUFNLENBQUNrQixPQUFPLENBQUMsRUFBRTtRQUN2RTNCLDJEQUFlLENBQ2IsK0dBQStHLENBQ2hIO1FBQ0Q7TUFDRjtJQUNGO0lBRUEwQyxzQkFBc0IsQ0FBQ25KLE9BQU8sQ0FBQ2YsU0FBUyxFQUFFYyxJQUFJLENBQUNtSCxNQUFNLENBQUM7SUFDdERrQyxpQkFBaUIsQ0FBQ25DLGdCQUFnQixDQUFDO0VBQ3JDO0VBRUEsZUFBZUgsZ0JBQWdCLENBQUM5RyxPQUFPLEVBQUVELElBQUksRUFBRTtJQUM3QyxNQUFNa0ksOEJBQThCLENBQUNsSSxJQUFJLENBQUNtSCxNQUFNLENBQUM5RyxHQUFHLEVBQUVKLE9BQU8sQ0FBQ3pFLGFBQWEsRUFBRXlFLE9BQU8sQ0FBQ3NCLFFBQVEsQ0FBQztFQUNoRztFQUVBLGVBQWV5RixpQkFBaUIsQ0FBQy9HLE9BQU8sRUFBRUQsSUFBSSxFQUFFO0lBQzlDLE1BQU0wRywrREFBbUIsQ0FBQzFHLElBQUksQ0FBQ21ILE1BQU0sQ0FBQzlHLEdBQUcsRUFBRUosT0FBTyxDQUFDc0IsUUFBUSxFQUFFdEIsT0FBTyxDQUFDaUMsb0JBQW9CLENBQUM7RUFDNUY7RUFFQSxTQUFTK0UsY0FBYyxDQUFDaEgsT0FBTyxFQUFFRCxJQUFJLEVBQUU7SUFDckMwRywyREFBZSxDQUFDMUcsSUFBSSxFQUFFO01BQ3BCNEgsSUFBSSxFQUFFbEIsNEVBQWdDO01BQ3RDeEgsU0FBUyxFQUFFaUsseUJBQXlCLENBQUNsSixPQUFPLENBQUNJLEdBQUcsQ0FBQ2pDLEVBQUUsQ0FBQyxHQUFHc0ksd0RBQVksQ0FBQ1EsZ0JBQWdCLENBQUMsR0FBR25LO0lBQzFGLENBQUMsQ0FBQztFQUNKOztFQUVBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBOztFQUVBLFNBQVN5TCxjQUFjLENBQUNjLFVBQVUsRUFBRTtJQUNsQzVDLCtEQUFtQixDQUFDLGtCQUFrQixFQUFFO01BQUU0QztJQUFXLENBQUMsQ0FBQztFQUN6RDtFQUVBLFNBQVNaLGFBQWEsQ0FBQzNHLEtBQUssRUFBRXdILFVBQVUsRUFBRWxKLEdBQUcsRUFBRTtJQUM3Q3FHLCtEQUFtQixDQUFDLGlCQUFpQixFQUFFO01BQUUzRSxLQUFLO01BQUV3SCxVQUFVO01BQUVsSjtJQUFJLENBQUMsQ0FBQztFQUNwRTs7RUFFQTtFQUNBO0VBQ0E7O0VBRUEsU0FBUzhILG9CQUFvQixDQUFDbEUsSUFBSSxFQUFFNUQsR0FBRyxFQUFFO0lBQ3ZDcUcsK0RBQW1CLENBQUMsd0JBQXdCLEVBQUU7TUFBRXpDLElBQUk7TUFBRTVEO0lBQUksQ0FBQyxDQUFDO0lBRTVELElBQUksQ0FBQzhJLHlCQUF5QixDQUFDOUksR0FBRyxFQUFFakMsRUFBRSxFQUFFNkYsSUFBSSxDQUFDb0UsT0FBTyxDQUFDLEVBQUU7TUFDckQzQiwyREFBZSxDQUFDLG9FQUFvRSxFQUFFO1FBQ3BGekMsSUFBSTtRQUNKNUQsR0FBRztRQUNINkc7TUFDRixDQUFDLENBQUM7TUFDRjtJQUNGO0lBRUFSLDZEQUFpQixDQUFDYSxRQUFRLENBQUN0RCxJQUFJLENBQUN1RixVQUFVLENBQUMsQ0FBQy9CLFdBQVcsQ0FBQ0ssVUFBVSxFQUFFLHVDQUF1QyxFQUFFO01BQzNHLENBQUMsaUJBQWlCLEdBQUc3RCxJQUFJLENBQUN1RixVQUFVO01BQ3BDdkYsSUFBSTtNQUNKNUQ7SUFDRixDQUFDLENBQUM7SUFFRmtILFFBQVEsQ0FBQ3RELElBQUksQ0FBQ3VGLFVBQVUsQ0FBQyxDQUFDckIsb0JBQW9CLENBQUNsRSxJQUFJLEVBQUU1RCxHQUFHLENBQUM7RUFDM0Q7RUFFQSxlQUFld0ksU0FBUyxDQUFDWSxPQUFPLEVBQUVwSixHQUFHLEVBQUU7SUFDckNxRywrREFBbUIsQ0FBQyxhQUFhLEVBQUU7TUFBRStDLE9BQU87TUFBRXBKO0lBQUksQ0FBQyxDQUFDOztJQUVwRDtJQUNBLElBQUksQ0FBQ0EsR0FBRyxFQUFFO01BQ1JBLEdBQUcsR0FBRyxNQUFNcUcsNERBQWdCLEVBQUU7TUFDOUJBLDJEQUFlLENBQUMsMkRBQTJELEVBQUU7UUFBRStDLE9BQU87UUFBRXBKO01BQUksQ0FBQyxDQUFDO01BQzlGLElBQUksQ0FBQ0EsR0FBRyxFQUFFO1FBQ1JxRywyREFBZSxDQUFDLHlFQUF5RSxFQUFFO1VBQUUrQztRQUFRLENBQUMsQ0FBQztRQUN2RztNQUNGO0lBQ0Y7SUFFQSxJQUFJLENBQUNOLHlCQUF5QixDQUFDOUksR0FBRyxDQUFDakMsRUFBRSxDQUFDLEVBQUU7TUFDdENzSSwyREFBZSxDQUFDLGlFQUFpRSxFQUFFO1FBQ2pGK0MsT0FBTztRQUNQcEosR0FBRztRQUNINkc7TUFDRixDQUFDLENBQUM7TUFDRjtJQUNGO0lBRUEsSUFBSUEsZ0JBQWdCLENBQUNJLElBQUksRUFBRTtNQUN6QlosMkRBQWUsQ0FBQyxpRUFBaUUsRUFBRTtRQUNqRitDLE9BQU87UUFDUHBKLEdBQUc7UUFDSDZHO01BQ0YsQ0FBQyxDQUFDO01BQ0Y7SUFDRjtJQUVBSyxRQUFRLENBQUNrQyxPQUFPLENBQUMsQ0FBQ3hCLGlCQUFpQixDQUFDNUgsR0FBRyxDQUFDO0VBQzFDOztFQUVBO0VBQ0E7RUFDQTs7RUFFQSxTQUFTeUksZ0JBQWdCLEdBQUc7SUFDMUJPLGlCQUFpQixDQUFDbkMsZ0JBQWdCLENBQUM7RUFDckM7O0VBRUE7RUFDQTtFQUNBOztFQUVBLFNBQVNrQyxzQkFBc0IsQ0FBQ2xLLFNBQVMsRUFBRWlJLE1BQU0sRUFBRTtJQUNqRHpLLE1BQU0sQ0FBQ3VKLE1BQU0sQ0FBQ2lCLGdCQUFnQixFQUFFaEksU0FBUyxDQUFDO0lBQzFDZ0ksZ0JBQWdCLENBQUNDLE1BQU0sR0FBR1Qsd0RBQVksQ0FBQ1MsTUFBTSxDQUFDO0lBQzlDVCw0REFBZ0IsQ0FBQywwQkFBMEIsRUFBRTtNQUFFUTtJQUFpQixDQUFDLENBQUM7RUFDcEU7RUFFQSxTQUFTaUMseUJBQXlCLENBQUNwSCxLQUFLLEVBQUVzRyxPQUFPLEVBQUU7SUFDakQsT0FDRW5CLGdCQUFnQixDQUFDQyxNQUFNLElBQ3ZCRCxnQkFBZ0IsQ0FBQ0MsTUFBTSxDQUFDOUcsR0FBRyxDQUFDakMsRUFBRSxLQUFLMkQsS0FBSyxLQUN2Q3NHLE9BQU8sS0FBS3RMLFNBQVMsSUFBSW1LLGdCQUFnQixDQUFDQyxNQUFNLENBQUNrQixPQUFPLEtBQUtBLE9BQU8sQ0FBQztFQUUxRTtFQUVBLGVBQWVXLHNCQUFzQixHQUFHO0lBQ3RDLE1BQU1VLGlCQUFpQixHQUFHLE1BQU05SyxNQUFNLENBQUMySSxRQUFRLENBQUNvQyxNQUFNLEVBQUU7SUFDeEQsS0FBSyxNQUFNO01BQUV2RSxJQUFJO01BQUVvQztJQUFTLENBQUMsSUFBSWtDLGlCQUFpQixFQUFFO01BQ2xEbkMsUUFBUSxDQUFDbkMsSUFBSSxDQUFDLENBQUNvQyxRQUFRLEdBQUdBLFFBQVE7SUFDcEM7RUFDRjtFQUVBLFNBQVM2QixpQkFBaUIsQ0FBQ25LLFNBQVMsRUFBRTtJQUNwQyxNQUFNMEssb0JBQW9CLEdBQUdsRCw4RUFBa0MsQ0FBQ0Esc0VBQTBCLENBQUN4SCxTQUFTLENBQUNqRCxJQUFJLENBQUMsQ0FBQztJQUUzRyxLQUFLLE1BQU0sQ0FBQ21DLEVBQUUsRUFBRXFMLE9BQU8sQ0FBQyxJQUFJL00sTUFBTSxDQUFDRSxPQUFPLENBQUMySyxRQUFRLENBQUMsRUFBRTtNQUNwRCxNQUFNRSxXQUFXLEdBQUdnQyxPQUFPLENBQUNoQyxXQUFXO01BQ3ZDLE1BQU1DLFVBQVUsR0FBR0QsV0FBVyxDQUFDQyxVQUFVO01BQ3pDLE1BQU1tQyxPQUFPLEdBQ1huRCxtRUFBdUIsSUFDdkIsQ0FBQ3hILFNBQVMsQ0FBQ29JLElBQUksSUFDZnNDLG9CQUFvQixLQUNuQixDQUFDbkMsV0FBVyxDQUFDTSxZQUFZLElBQUk3SSxTQUFTLENBQUNrSSxRQUFRLENBQUM7TUFDbkRWLDREQUFnQixDQUFDLGdDQUFnQyxFQUFFO1FBQUV0SSxFQUFFO1FBQUV5TDtNQUFRLENBQUMsQ0FBQztNQUVuRSxJQUFJQSxPQUFPLEVBQUU7UUFDWCxJQUFJQyxlQUFlLEdBQUcsRUFBRTtRQUN4QixJQUFJcEQsaUVBQXFCLElBQUl4SCxTQUFTLENBQUNtSSxVQUFVLElBQUlJLFdBQVcsQ0FBQ08sd0JBQXdCLEVBQUU7VUFDekY4QixlQUFlLElBQUlsTCxNQUFNLENBQUNDLElBQUksQ0FBQ0MsVUFBVSxDQUFDLDhDQUE4QyxDQUFDO1FBQzNGO1FBQ0EsSUFBSTJLLE9BQU8sQ0FBQ2pDLFFBQVEsRUFBRTtVQUNwQnNDLGVBQWUsSUFBSyxPQUFNTCxPQUFPLENBQUNqQyxRQUFTLEdBQUU7UUFDL0M7UUFFQSxJQUFJLENBQUNDLFdBQVcsQ0FBQ0ssVUFBVSxFQUFFO1VBQzNCbEosTUFBTSxDQUFDK0osWUFBWSxDQUFDL0gsTUFBTSxDQUFDO1lBQ3pCeEMsRUFBRSxFQUFFQSxFQUFFO1lBQ051SixLQUFLLEVBQUVELFVBQVUsQ0FBQ0MsS0FBSyxHQUFHbUMsZUFBZTtZQUN6Q2xDLElBQUksRUFBRUYsVUFBVSxDQUFDRSxJQUFJO1lBQ3JCQyxRQUFRLEVBQUVILFVBQVUsQ0FBQ0c7VUFDdkIsQ0FBQyxDQUFDO1VBQ0ZKLFdBQVcsQ0FBQ0ssVUFBVSxHQUFHLElBQUk7UUFDL0IsQ0FBQyxNQUFNO1VBQ0xsSixNQUFNLENBQUMrSixZQUFZLENBQUMzRyxNQUFNLENBQUM1RCxFQUFFLEVBQUU7WUFBRXVKLEtBQUssRUFBRUQsVUFBVSxDQUFDQyxLQUFLLEdBQUdtQztVQUFnQixDQUFDLENBQUM7UUFDL0U7TUFDRixDQUFDLE1BQU07UUFDTCxJQUFJckMsV0FBVyxDQUFDSyxVQUFVLEVBQUU7VUFDMUJsSixNQUFNLENBQUMrSixZQUFZLENBQUNxQixNQUFNLENBQUM1TCxFQUFFLENBQUM7VUFDOUJxSixXQUFXLENBQUNLLFVBQVUsR0FBRyxLQUFLO1FBQ2hDO01BQ0Y7SUFDRjtFQUNGO0VBRUEsZUFBZUksOEJBQThCLENBQUM3SCxHQUFHLEVBQUU3RSxhQUFhLEVBQUUrRixRQUFRLEVBQUU7SUFDMUUsTUFBTXhGLHVCQUF1QixHQUFHMkssc0VBQTBCLENBQUNsTCxhQUFhLENBQUM7SUFDekUsSUFBSSxDQUFDa0wsOEVBQWtDLENBQUMzSyx1QkFBdUIsQ0FBQyxFQUFFO01BQ2hFMkssMkRBQWUsQ0FBRSxVQUFTQSw0RUFBaUMsMkNBQTBDLEVBQUU7UUFDckdsTDtNQUNGLENBQUMsQ0FBQztNQUNGO0lBQ0Y7SUFFQSxJQUFJa0wsZ0VBQW9CLEVBQUU7TUFDeEIsTUFBTXdELG9CQUFvQixDQUFDN0osR0FBRyxFQUFFdEUsdUJBQXVCLENBQUM7SUFDMUQ7SUFFQSxNQUFNMkssOERBQWtCLENBQUNyRyxHQUFHLEVBQUV0RSx1QkFBdUIsRUFBRXdGLFFBQVEsQ0FBQztFQUNsRTtFQUVBLFNBQVM2Ryw0QkFBNEIsQ0FBQy9ILEdBQUcsRUFBRWdJLE9BQU8sRUFBRTtJQUNsRCxNQUFNckksSUFBSSxHQUFHcEIsTUFBTSxDQUFDMEIsSUFBSSxDQUFDNkosT0FBTyxDQUFDOUosR0FBRyxDQUFDakMsRUFBRSxFQUFFO01BQUVnSCxJQUFJLEVBQUUsWUFBWTtNQUFFaUQsT0FBTyxFQUFFQTtJQUFRLENBQUMsQ0FBQztJQUNsRjNCLDJEQUFlLENBQUMxRyxJQUFJLEVBQUU7TUFBRTRILElBQUksRUFBRWxCLHNFQUEwQmpNO0lBQUMsQ0FBQyxDQUFDO0lBQzNEdUYsSUFBSSxDQUFDb0ssVUFBVSxFQUFFO0VBQ25CO0VBRUEsZUFBZUYsb0JBQW9CLENBQUM3SixHQUFHLEVBQUVwRSxJQUFJLEVBQUU7SUFDN0MsTUFBTTJDLE1BQU0sQ0FBQ3lMLFNBQVMsQ0FBQ0MsYUFBYSxDQUFDO01BQ25DOU4sTUFBTSxFQUFFO1FBQUV1RixLQUFLLEVBQUUxQixHQUFHLENBQUNqQztNQUFHLENBQUM7TUFDekJtTSxpQkFBaUIsRUFBRSxJQUFJO01BQ3ZCeE0sSUFBSSxFQUFFLENBQUM5QixJQUFJLENBQUM7TUFDWnVPLElBQUksRUFBR3ZPLElBQUksSUFBS3dPLE1BQU0sQ0FBQ0MsU0FBUyxDQUFDQyxTQUFTLENBQUNDLFNBQVMsQ0FBQzNPLElBQUk7SUFDM0QsQ0FBQyxDQUFDO0VBQ0o7QUFDRixDQUFDLEdBQUcsQyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL21vZHVsZXMvX19jb25maWcuanMiLCJ3ZWJwYWNrOi8vLy4vbW9kdWxlcy9fX2NvbnN0YW50cy5qcyIsIndlYnBhY2s6Ly8vLi9tb2R1bGVzL19fZnVuY3Rpb25zLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19nbG9iYWxzLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19ob3dfdG9fb3Blbl9saW5rLmpzIiwid2VicGFjazovLy8uL21vZHVsZXMvX19sb2dnZXIuanMiLCJ3ZWJwYWNrOi8vLy4vbW9kdWxlcy9fX29wdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vbW9kdWxlcy9jb21tb24uanMiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovLy93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly8vd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovLy93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovLy93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovLy8uL2JhY2tncm91bmQuanMiXSwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSB7IGNvbmZpZzoge1wibG9nRW5hYmxlZFwiOnRydWUsXCJwcml2YXRlT3B0aW9uRW5hYmxlZFwiOnRydWUsXCJpc01hY1wiOmZhbHNlfSB9OyIsIi8qKlxuICogU2NyaXB0IGlkLlxuICovXG5leHBvcnQgY29uc3QgU2NyaXB0SWQgPSB7XG4gIEFDVElPTjogXCJBQ1RJT05cIixcbiAgQkFDS0dST1VORDogXCJCQUNLR1JPVU5EXCIsXG4gIENPTlRFTlQ6IFwiLVwiLFxuICBPUFRJT05TOiBcIk9QVElPTlNcIixcbn07XG5cbi8qKlxuICogQ29tbWFuZCBJRHMgZm9yIGtleWJvYXJkIHNob3J0Y3V0cyBhbmQgY29udGV4dCBtZW51cy5cbiAqL1xuZXhwb3J0IGNvbnN0IENvbW1hbmRUeXBlID0ge1xuICBET19RVU9URURfU0VBUkNIOiBcImRvX3F1b3RlZF9zZWFyY2hcIixcbiAgUFVUX1FVT1RFUzogXCJwdXRfcXVvdGVzXCIsXG59O1xuXG4vKipcbiAqIE1lc3NhZ2UgdHlwZXMuXG4gKi9cbmV4cG9ydCBjb25zdCBNZXNzYWdlVHlwZSA9IHtcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIENvbnRlbnQgc2NyaXB0cyAtLT4gQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlclxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgSEVMTE86IFwiaGVsbG9cIixcbiAgTk9USUZZX1NFTEVDVElPTl9VUERBVEVEOiBcIm5vdGlmeV9zZWxlY3Rpb25fdXBkYXRlZFwiLFxuICBET19RVU9URURfU0VBUkNIOiBcImRvX3F1b3RlZF9zZWFyY2hcIixcbiAgT1BFTl9PUFRJT05TX1BBR0U6IFwib3Blbl9vcHRpb25zX3BhZ2VcIixcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQ29udGVudCBzY3JpcHRzIDwtLSBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBXRUxDT01FOiBcIndlbGNvbWVcIixcbiAgUFVUX1FVT1RFUzogXCJwdXRfcXVvdGVzXCIsXG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIEFjdGlvbiBzY3JpcHRzIC0tPiBCYWNrZ3JvdW5kIHNlcnZpY2Ugd29ya2VyXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICBHRVRfU0VMRUNUSU9OOiBcImdldF9zZWxlY3Rpb25cIixcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gQWN0aW9uIHNjcmlwdHMgPC0tIEJhY2tncm91bmQgc2VydmljZSB3b3JrZXJcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIE5PVElGWV9TRUxFQ1RJT046IFwibm90aWZ5X3NlbGVjdGlvblwiLFxufTtcblxuLyoqXG4gKiBWYXJpb3VzIGRvdWJsZSBxdW90ZXMuXG4gKlxuICogSWYgeW91IHN1cnJvdW5kIHlvdXIgc2VhcmNoIHBocmFzZSB3aXRoIGNoYXJhY3RlcnMgaW4gdGhpcyBzdHJpbmcsIEdvb2dsZVxuICogU2VhcmNoIHdpbGwgZ2l2ZSB5b3UgYW4gZXhhY3QgbWF0Y2guIEluIG90aGVyIHdvcmRzLCB0aGVzZSBhcmUgdGhlIGNoYXJhY3RlcnNcbiAqIHRoYXQgR29vZ2xlIFNlYXJjaCByZWNvZ25pemVzIGFzIHZhbGlkIGRvdWJsZSBxdW90ZXMgZm9yIGFuIGV4YWN0IG1hdGNoLlxuICpcbiAqIFRleHQgY29udGFpbmluZyBkb3VibGUgcXVvdGVzIGNhbm5vdCBiZSBlbmNsb3NlZCBpbiBkb3VibGUgcXVvdGVzLCBzbyB0aG9zZVxuICogY2hhcmFjdGVycyBtdXN0IGJlIHJlbW92ZWQgaWYgdGhleSBhcmUgaW5jbHVkZWQgaW4gdGhlIHNlbGVjdGVkIHRleHQgd2hlblxuICogc2VhcmNoaW5nIGZvciBhbiBleGFjdCBtYXRjaC5cbiAqL1xuZXhwb3J0IGNvbnN0IFFVT1RBVElPTl9NQVJLUyA9IFwiXFx1MDAyMlxcdTIwMWNcXHUyMDFkXFx1MjAxZVxcdTIwMWZcXHUyMDMzXFx1MzAxZFxcdTMwMWVcXHUzMDFmXFx1ZmYwMlwiOyAvLyBcIuKAnOKAneKAnuKAn+KAs+OAneOAnuOAn++8glxuXG4vKipcbiAqIFRoZSBtYXhpbXVtIGxlbmd0aCBvZiB0aGUgc2VsZWN0ZWQgdGV4dCB0byBiZSBwcm9jZXNzZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBTRUxFQ1RJT05fVEVYVF9NQVhfTEVOR1RIID0gMTAyNDtcblxuLyoqXG4gKiBJbmRpY2F0ZXMgdGhhdCB0aGUgbGVuZ3RoIG9mIHRoZSBzZWxlY3RlZCB0ZXh0IGV4Y2VlZHMgdGhlIGxpbWl0LlxuICpcbiAqIEEgdmVyeSBsYXJnZSB0ZXh0IG1heSBiZSBzZWxlY3RlZCwgaW4gd2hpY2ggY2FzZSB0aGlzIHN0cmluZyBpcyBwcmVzZXJ2ZWRcbiAqIGluc3RlYWQgb2YgdGhlIG9yaWdpbmFsIHN0cmluZyBhcyB0aGUgc2VsZWN0ZWQgdGV4dCB0byBhdm9pZCB3YXN0aW5nIG1lbW9yeVxuICogYW5kIG1ha2luZyBsb2dzIG5vaXN5LlxuICovXG5leHBvcnQgY29uc3QgU0VMRUNUSU9OX1RFWFRfVE9PX0xPTkdfTUFSS0VSID0gXCIjIyMgVG9vIExvbmchICMjIyB5b0Jqdl5GNyVzZyNOTXhDcnF2WUtNZ0Q4NXNSWFJpR1wiO1xuIiwiaW1wb3J0IHsgU0VMRUNUSU9OX1RFWFRfTUFYX0xFTkdUSCwgU0VMRUNUSU9OX1RFWFRfVE9PX0xPTkdfTUFSS0VSLCBRVU9UQVRJT05fTUFSS1MgfSBmcm9tIFwiLi9fX2NvbnN0YW50cy5qc1wiO1xuaW1wb3J0IHsgbG9nZ2VyLCBvcHRpb25zIH0gZnJvbSBcIi4vX19nbG9iYWxzLmpzXCI7XG5pbXBvcnQgeyBIb3dUb09wZW5MaW5rIH0gZnJvbSBcIi4vX19ob3dfdG9fb3Blbl9saW5rLmpzXCI7XG5cbi8qKlxuICogRmlsdGVycyB0aGUgc2VsZWN0ZWQgdGV4dCBvYnRhaW5lZCBmcm9tIGV4dGVybmFsIHNvdXJjZXMuXG4gKlxuICogRm9yIHNlY3VyaXR5IHB1cnBvc2VzLCBiZSBzdXJlIHRvIHBhc3MgdGhlIHNlbGVjdGVkIHRleHQgb2J0YWluZWQgZnJvbVxuICogZXh0ZXJuYWwgc291cmNlcyB0aHJvdWdoIHRoaXMgZmlsdGVyIGJlZm9yZSB1c2luZyBpdC5cbiAqXG4gKiBAcGFyYW0gez9zdHJpbmd9IHNlbGVjdGlvblRleHRcbiAqIEByZXR1cm5zIHshc3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gZmlsdGVyU2VsZWN0aW9uVGV4dChzZWxlY3Rpb25UZXh0KSB7XG4gIHNlbGVjdGlvblRleHQgPz89IFwiXCI7XG4gIHJldHVybiBzZWxlY3Rpb25UZXh0Lmxlbmd0aCA+IFNFTEVDVElPTl9URVhUX01BWF9MRU5HVEggPyBTRUxFQ1RJT05fVEVYVF9UT09fTE9OR19NQVJLRVIgOiBzZWxlY3Rpb25UZXh0O1xufVxuXG4vKipcbiAqIE5vcm1hbGl6ZXMgdGhlIHNlbGVjdGVkIHRleHQuXG4gKlxuICogVGhlIG5vcm1hbGl6YXRpb24gaW5jbHVkZXM6XG4gKlxuICogLSBSZXBsYWNlIGRvdWJsZSBxdW90ZXMgd2l0aCBhIHNwYWNlLlxuICogLSBDb2xsYXBzZSBjb25zZWN1dGl2ZSB3aGl0ZXNwYWNlIGNoYXJhY3RlcnMgaW50byBzaW5nbGUgc3BhY2UuXG4gKiAtIFJlbW92ZSB3aGl0ZXNwYWNlIGZyb20gYm90aCBlbmRzIG9mIHRoZSBzdHJpbmcuXG4gKlxuICogQHBhcmFtIHs/c3RyaW5nfSBzZWxlY3Rpb25UZXh0XG4gKiBAcmV0dXJucyB7IXN0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZVNlbGVjdGlvblRleHQoc2VsZWN0aW9uVGV4dCkge1xuICBzZWxlY3Rpb25UZXh0ID0gZmlsdGVyU2VsZWN0aW9uVGV4dChzZWxlY3Rpb25UZXh0KTtcbiAgcmV0dXJuIHNlbGVjdGlvblRleHQgPT09IFNFTEVDVElPTl9URVhUX1RPT19MT05HX01BUktFUlxuICAgID8gc2VsZWN0aW9uVGV4dFxuICAgIDogc2VsZWN0aW9uVGV4dC5yZXBsYWNlQWxsKG5ldyBSZWdFeHAoYFtcXFxccyR7UVVPVEFUSU9OX01BUktTfV0rYCwgXCJnXCIpLCBcIiBcIikudHJpbSgpO1xufVxuXG4vKipcbiAqIENoZWNrcyBpZiB0aGUgbm9ybWFsaXplZCBzZWxlY3Rpb24gdGV4dCBpcyB2YWxpZCBmb3IgcHJvY2Vzc2luZy5cbiAqXG4gKiBAcGFyYW0gez9zdHJpbmd9IG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0XG4gKiBAcmV0dXJucyB7IWJvb2xlYW59XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc05vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0VmFsaWQobm9ybWFsaXplZFNlbGVjdGlvblRleHQpIHtcbiAgbm9ybWFsaXplZFNlbGVjdGlvblRleHQgPz89IFwiXCI7XG4gIHJldHVybiAoXG4gICAgbm9ybWFsaXplZFNlbGVjdGlvblRleHQgIT09IFNFTEVDVElPTl9URVhUX1RPT19MT05HX01BUktFUiAmJlxuICAgIG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0Lmxlbmd0aCA+IDAgJiZcbiAgICBub3JtYWxpemVkU2VsZWN0aW9uVGV4dC5sZW5ndGggPD0gU0VMRUNUSU9OX1RFWFRfTUFYX0xFTkdUSFxuICApO1xufVxuXG4vKipcbiAqIFB1dHMgZG91YmxlIHF1b3RlcyBhcm91bmQgdGhlIHN0cmluZy5cbiAqXG4gKiBAcGFyYW0gez9zdHJpbmd9IHRleHRcbiAqIEByZXR1cm5zIHshc3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gcXVvdGVUZXh0KHRleHQpIHtcbiAgcmV0dXJuICdcIicgKyAodGV4dCA/PyBcIlwiKSArICdcIic7XG59XG5cbi8qKlxuICogQ2xvbmVzIGFuIG9iamVjdCB0cmVhdGVkIGFzIGEgRFRPLlxuICpcbiAqIElmIHlvdSBuZWVkIHBhc3MgYW4gb2JqZWN0IHdob3NlIGNvbnRlbnRzIG1heSBiZSBjaGFuZ2VkIGxhdGVyIHRvIGFuXG4gKiBhc3luY2hyb25vdXMgbWV0aG9kLCBwYXNzIGFuIG9iamVjdCBjbG9uZWQgYnkgdGhpcyBmdW5jdGlvbiBpbnN0ZWFkIG9mIHRoZVxuICogb3JpZ2luIG9iamVjdC5cbiAqXG4gKiBAcGFyYW0gez9vYmplY3R9IG9ialxuICogQHJldHVybnMgeyFvYmplY3R9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjbG9uZUR0byhvYmopIHtcbiAgcmV0dXJuIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkob2JqID8/IHt9KSk7XG59XG5cbi8qKlxuICogTWVyZ2VzIGByaHNgIHRvIGBsaHNgLCBpZ25vcmluZyBwcm9wZXJ0aWVzIHdpdGggYSB2YWx1ZSBvZiBgdW5kZWZpbmVkYC5cbiAqXG4gKiBAcGFyYW0gez9vYmplY3R9IHRhcmdldFxuICogQHBhcmFtIHs/b2JqZWN0fSBzb3VyY2VcbiAqIEByZXR1cm5zIHshb2JqZWN0fVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VPYmplY3QodGFyZ2V0LCBzb3VyY2UpIHtcbiAgcmV0dXJuIHsgLi4udGFyZ2V0LCAuLi5PYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoc291cmNlID8/IHt9KS5maWx0ZXIoKFssIHZdKSA9PiB2ICE9PSB1bmRlZmluZWQpKSB9O1xufVxuXG4vKipcbiAqIFNldHMgdXAgYW4gZXZlbnQgbGlzdGVuZXIgZm9yIGBET01Db250ZW50TG9hZGVkYCBldmVudC5cbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIGNoZWNrcyBgRG9jdW1lbnQucmVhZHlTdGF0ZWAgYW5kIHNldHMgdXAgdGhlIGV2ZW50IGxpc3RlbmVyIGFzXG4gKiBhIG1pY3JvdGFza3MgaWYgdGhlIGV2ZW50IGhhcyBhbHJlYWR5IGJlZW4gZmlyZWQuXG4gKlxuICogQHBhcmFtIHshV2luZG93fSB3aW5cbiAqIEBwYXJhbSB7IWZ1bmN0aW9uKCk6dm9pZH0gbGlzdGVuZXJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFkZERPTUNvbnRlbnRMb2FkZWRFdmVudExpc3RlbmVyKHdpbiwgbGlzdGVuZXIpIHtcbiAgaWYgKHdpbi5kb2N1bWVudC5yZWFkeVN0YXRlID09PSBcImxvYWRpbmdcIikge1xuICAgIHdpbi5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwiRE9NQ29udGVudExvYWRlZFwiLCBsaXN0ZW5lcik7XG4gIH0gZWxzZSB7XG4gICAgcXVldWVNaWNyb3Rhc2sobGlzdGVuZXIpO1xuICB9XG59XG5cbi8qKlxuICogU2V0cyB1cCBhbiBldmVudCBsaXN0ZW5lciBmb3IgYGxvYWRgIGV2ZW50LlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gY2hlY2tzIGBEb2N1bWVudC5yZWFkeVN0YXRlYCBhbmQgc2V0cyB1cCB0aGUgZXZlbnQgbGlzdGVuZXIgYXNcbiAqIGEgbWljcm90YXNrcyBpZiB0aGUgZXZlbnQgaGFzIGFscmVhZHkgYmVlbiBmaXJlZC5cbiAqXG4gKiBAcGFyYW0geyFXaW5kb3d9IHdpblxuICogQHBhcmFtIHshZnVuY3Rpb24oKTp2b2lkfSBsaXN0ZW5lclxuICovXG5leHBvcnQgZnVuY3Rpb24gYWRkTG9hZENvbXBsZXRlZEV2ZW50TGlzdGVuZXIod2luLCBsaXN0ZW5lcikge1xuICBpZiAod2luLmRvY3VtZW50LnJlYWR5U3RhdGUgIT09IFwiY29tcGxldGVcIikge1xuICAgIHdpbi5hZGRFdmVudExpc3RlbmVyKFwibG9hZFwiLCBsaXN0ZW5lcik7XG4gIH0gZWxzZSB7XG4gICAgcXVldWVNaWNyb3Rhc2sobGlzdGVuZXIpO1xuICB9XG59XG5cbi8qKlxuICogSW5qZWN0cyBsb2NhbGl6ZWQgc3RyaW5ncyBpbnRvIEhUTUwgZG9jdW1lbnQuXG4gKlxuICogQHBhcmFtIHshRG9jdW1lbnR9IGRvY1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5qZWN0STE4Tk1lc3NhZ2VzSW5IdG1sKGRvYykge1xuICBjb25zdCBJMThOX1RBUkdFVFMgPSBbXCJvdXRlckhUTUxcIiwgXCJpbm5lckhUTUxcIiwgXCJvdXRlclRleHRcIiwgXCJpbm5lclRleHRcIiwgXCJ2YWx1ZVwiXTtcbiAgZm9yIChjb25zdCBlbGVtZW50IG9mIGRvYy5xdWVyeVNlbGVjdG9yQWxsKFwiW2RhdGEtZ3JvdXB+PSdpMThuJ1wiKSkge1xuICAgIGNvbnN0IHN1YnN0aXR1dGlvbnMgPSAoKCkgPT4ge1xuICAgICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgICBjb25zdCBhcmdzID0gZWxlbWVudC5kYXRhc2V0LmkxOG5BcmdzO1xuICAgICAgaWYgKCFhcmdzKSB7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9XG4gICAgICBjb25zdCBpZHMgPSBhcmdzLnNwbGl0KFwiIFwiKTtcbiAgICAgIGZvciAoY29uc3QgaWQgb2YgaWRzKSB7XG4gICAgICAgIGNvbnN0IGFyZ0VsZW1lbnQgPSBkb2MuZ2V0RWxlbWVudEJ5SWQoaWQpO1xuICAgICAgICBjb25zdCBhcmdUYXJnZXQgPSBhcmdFbGVtZW50LmRhdGFzZXQuaTE4blRhcmdldDtcbiAgICAgICAgbG9nZ2VyLmFzc2VydChJMThOX1RBUkdFVFMuaW5jbHVkZXMoYXJnVGFyZ2V0KSwgXCJVbmV4cGVjdGVkIHRhcmdldFwiLCB7IGFyZ1RhcmdldCwgYXJnRWxlbWVudCB9KTtcbiAgICAgICAgcmVzdWx0LnB1c2goYXJnRWxlbWVudFthcmdUYXJnZXRdKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSkoKTtcbiAgICBjb25zdCB0YXJnZXQgPSBlbGVtZW50LmRhdGFzZXQuaTE4blRhcmdldDtcbiAgICBsb2dnZXIuYXNzZXJ0KEkxOE5fVEFSR0VUUy5pbmNsdWRlcyh0YXJnZXQpLCBcIlVuZXhwZWN0ZWQgdGFyZ2V0XCIsIHsgdGFyZ2V0LCBlbGVtZW50IH0pO1xuICAgIGVsZW1lbnRbdGFyZ2V0XSA9IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoZWxlbWVudC5kYXRhc2V0LmkxOG5OYW1lLCBzdWJzdGl0dXRpb25zKTtcbiAgfVxufVxuXG4vKipcbiAqIEdldHMgYFNlbGVjdGlvbmAgb2JqZWN0LlxuICpcbiAqIFRoaXMgZnVuY3Rpb24gbm90IG9ubHkgY2FsbHMgYFdpbmRvdy5nZXRTZWxlY3Rpb24oKWAsIGJ1dCBhbHNvIHJlY3Vyc2l2ZWx5XG4gKiBzZWFyY2hlcyB3aXRoaW4gdGhlIG5lc3RlZCBTaGFkb3cgRE9Ncy5cbiAqXG4gKiBAcGFyYW0geyFXaW5kb3d9IHdpblxuICogQHJldHVybnMgeyFTZWxlY3Rpb259XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRTZWxlY3Rpb24od2luKSB7XG4gIGZ1bmN0aW9uIGZpbmRTZWxlY3Rpb25SZWN1cnNpdmVseShzZWxlY3Rpb24pIHtcbiAgICBpZiAoc2VsZWN0aW9uLnJhbmdlQ291bnQgPT09IDEpIHtcbiAgICAgIGNvbnN0IHJhbmdlID0gc2VsZWN0aW9uLmdldFJhbmdlQXQoMCk7XG4gICAgICBpZiAocmFuZ2Uuc3RhcnRDb250YWluZXIgPT09IHJhbmdlLmVuZENvbnRhaW5lcikge1xuICAgICAgICBjb25zdCBjb21tb25BbmNlc3RvckNvbnRhaW5lciA9IHJhbmdlLmNvbW1vbkFuY2VzdG9yQ29udGFpbmVyO1xuICAgICAgICBpZiAoY29tbW9uQW5jZXN0b3JDb250YWluZXIgaW5zdGFuY2VvZiBFbGVtZW50KSB7XG4gICAgICAgICAgaWYgKGNvbW1vbkFuY2VzdG9yQ29udGFpbmVyLnNoYWRvd1Jvb3QpIHtcbiAgICAgICAgICAgIHJldHVybiBmaW5kU2VsZWN0aW9uUmVjdXJzaXZlbHkoY29tbW9uQW5jZXN0b3JDb250YWluZXIuc2hhZG93Um9vdC5nZXRTZWxlY3Rpb24oKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGVsZW1lbnRzV2l0aFNoYWRvd1Jvb3QgPSBBcnJheS5wcm90b3R5cGUuZmlsdGVyLmNhbGwoXG4gICAgICAgICAgICAgIGNvbW1vbkFuY2VzdG9yQ29udGFpbmVyLnF1ZXJ5U2VsZWN0b3JBbGwoXCIqXCIpLFxuICAgICAgICAgICAgICAoZWxlbWVudCkgPT4gISFlbGVtZW50LnNoYWRvd1Jvb3RcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBpZiAoZWxlbWVudHNXaXRoU2hhZG93Um9vdC5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIGZpbmRTZWxlY3Rpb25SZWN1cnNpdmVseShlbGVtZW50c1dpdGhTaGFkb3dSb290WzBdLnNoYWRvd1Jvb3QuZ2V0U2VsZWN0aW9uKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gc2VsZWN0aW9uO1xuICB9XG5cbiAgcmV0dXJuIGZpbmRTZWxlY3Rpb25SZWN1cnNpdmVseSh3aW4uZ2V0U2VsZWN0aW9uKCkpO1xufVxuXG4vKipcbiAqIENhbGxzIGBjaHJvbWUucnVudGltZS5Qb3J0LnBvc3RNZXNzYWdlKClgIG1ldGhvZC5cbiAqXG4gKiBDYXRjaGVzIHRoZSBlcnJvciB0aHJvd24gZnJvbSBgY2hyb21lLnJ1bnRpbWUuUG9ydC5wb3N0TWVzc2FnZSgpYCBtZXRob2QgYW5kXG4gKiBsb2dzIGEgd2FybmluZyBtZXNzYWdlLlxuICpcbiAqIGBjaHJvbWUucnVudGltZS5Qb3J0LnBvc3RNZXNzYWdlKClgIHRocm93cyBhbiBlcnJvciBpZiB0aGUgb3RoZXIgc2lkZSBvZiB0aGVcbiAqIHBvcnQgaGFzIGFscmVhZHkgYmVlbiBjbG9zZWQsIGJ1dCB0aGVyZSBpcyBubyB3YXkgdG8gY2hlY2sgaW4gYWR2YW5jZSB3aGV0aGVyXG4gKiB0aGUgcG9ydCBpcyBzdGlsbCBvcGVuZWQgb3IgaGFzIGJlZW4gY2xvc2VkLlxuICogUG9ydCBkaXNjb25uZWN0aW9uIGlzIG9uZSBvZiB0aGUgZXhwZWN0ZWQgY29uZGl0aW9ucywgZXZlbiBpbiBhbiBlZGdlIGNhc2UsXG4gKiBhbmQgbW9zdCBvZiB0aGUgdGltZSBpdCBpcyBub3QgYW4gZXJyb3IgY2FzZS5cbiAqIFRoZXJlZm9yZSwgaWYgYW4gZXJyb3IgaXMgdGhyb3duIGZyb20gYGNocm9tZS5ydW50aW1lLlBvcnQucG9zdE1lc3NhZ2UoKWBcbiAqIG1ldGhvZCwgdGhpcyBmdW5jdGlvbiBhc3N1bWVzIHRoZSBjYXVzZSBpcyBwb3J0IGRpc2Nvbm5lY3Rpb24gYW5kIGxvZ3MgaXQgYXNcbiAqIGEgd2FybmluZyBpbnN0ZWFkIG9mIGFuIGVycm9yLlxuICpcbiAqIEBwYXJhbSB7IWNocm9tZS5ydW50aW1lLlBvcnR9IHBvcnRcbiAqIEBwYXJhbSB7ISp9IG1lc3NhZ2VcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBvc3RNZXNzYWdlKHBvcnQsIG1lc3NhZ2UpIHtcbiAgdHJ5IHtcbiAgICBwb3J0LnBvc3RNZXNzYWdlKG1lc3NhZ2UpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGxvZ2dlci53YXJuKFxuICAgICAgXCJJdCBzZWVtcyB0aGF0IHRoZSBtZXNzYWdlIGNvdWxkIG5vdCBiZSBzZW50IGJlY2F1c2UgdGhlIG90aGVyIHNpZGUgb2YgdGhlIHBvcnQgaGFzIGFscmVhZHkgYmVlbiBjbG9zZWRcIixcbiAgICAgIHsgZXJyb3IsIHBvcnQsIG1lc3NhZ2UgfVxuICAgICk7XG4gIH1cbn1cblxuLyoqXG4gKiBHZXRzIHRoZSBhY3RpdmUgdGFiLlxuICpcbiAqICoqTm90ZToqKiBOb3QgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0cywgYXZhaWxhYmxlIG9ubHkgaW4gYmFja2dyb3VuZFxuICogc2VydmljZSB3b3JrZXIsIGFjdGlvbiBzY3JpcHRzIG9yIG9wdGlvbnMgc2NyaXB0LlxuICpcbiAqIEByZXR1cm5zIHshUHJvbWlzZTwhY2hyb21lLnRhYnMuVGFiPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFjdGl2ZVRhYigpIHtcbiAgY29uc3QgW3RhYl0gPSBhd2FpdCBjaHJvbWUudGFicy5xdWVyeSh7IGFjdGl2ZTogdHJ1ZSwgY3VycmVudFdpbmRvdzogdHJ1ZSB9KTtcbiAgcmV0dXJuIHRhYjtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IHRhYi5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0geyFjaHJvbWUudGFicy5UYWJ9IHRhYiBDdXJyZW50IHRhYiBjYWxsaW5nIHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0gez97dXJsOj9zdHJpbmc9LCBhY3RpdmU6P2Jvb2xlYW49fT19IHBhcmFtc1xuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlTmV3VGFiKHRhYiwgcGFyYW1zKSB7XG4gIHJldHVybiBhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoe1xuICAgIHdpbmRvd0lkOiB0YWIud2luZG93SWQsXG4gICAgb3BlbmVyVGFiSWQ6IHRhYi5pZCxcbiAgICBpbmRleDogdGFiLmluZGV4ICsgMSxcbiAgICB1cmw6IHBhcmFtcz8udXJsLFxuICAgIGFjdGl2ZTogcGFyYW1zPy5hY3RpdmUgPz8gdHJ1ZSxcbiAgfSk7XG59XG5cbi8qKlxuICogQ3JlYXRlcyBhIG5ldyB3aW5kb3cuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHBhcmFtIHs/e3VybDo/c3RyaW5nPX09fSBwYXJhbXNcbiAqIEByZXR1cm5zIHshUHJvbWlzZTx2b2lkPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZU5ld1dpbmRvdyhwYXJhbXMpIHtcbiAgY29uc3QgY3VycmVudFdpbmRvdyA9IGF3YWl0IGNocm9tZS53aW5kb3dzLmdldEN1cnJlbnQoKTtcbiAgcmV0dXJuIGF3YWl0IGNocm9tZS53aW5kb3dzLmNyZWF0ZSh7XG4gICAgc3RhdGU6IGN1cnJlbnRXaW5kb3cuc3RhdGUsXG4gICAgdXJsOiBwYXJhbXM/LnVybCxcbiAgfSk7XG59XG5cbi8qKlxuICogSW52b2tlcyBzZWFyY2ggZW5naW5lIHRvIGRvIHF1b3RlZCBzZWFyY2guXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnRhYnMuVGFifSB0YWIgQ3VycmVudCB0YWIgY2FsbGluZyB0aGlzIGZ1bmN0aW9uLlxuICogQHBhcmFtIHshc3RyaW5nfSBzZWFyY2hUZXh0IFRleHQgdG8gc2VhcmNoLCBub3QgdG8gYmUgZW5jbG9zZWQgaW4gZG91YmxlIHF1b3Rlcy5cbiAqIEBwYXJhbSB7P0hvd1RvT3BlbkxpbmsuS2V5U3RhdGU9fSBrZXlTdGF0ZVxuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZG9RdW90ZWRTZWFyY2godGFiLCBzZWFyY2hUZXh0LCBrZXlTdGF0ZSkge1xuICBjb25zdCBob3dUb09wZW5MaW5rID0gSG93VG9PcGVuTGluay5kZWNpZGUoa2V5U3RhdGUsIG5ldyBIb3dUb09wZW5MaW5rKG9wdGlvbnMuZGlzcG9zaXRpb24sIHRydWUpKTtcbiAgaWYgKGhvd1RvT3BlbkxpbmsuZGlzcG9zaXRpb24gPT09IEhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb24uTkVXX1RBQikge1xuICAgIGNvbnN0IG5ld1RhYiA9IGF3YWl0IGNyZWF0ZU5ld1RhYih0YWIsIHsgYWN0aXZlOiBmYWxzZSB9KTtcbiAgICBhd2FpdCBjaHJvbWUuc2VhcmNoLnF1ZXJ5KHsgdGFiSWQ6IG5ld1RhYi5pZCwgdGV4dDogcXVvdGVUZXh0KHNlYXJjaFRleHQpIH0pO1xuICAgIC8vIFRvIHByZXZlbnQgdGhlIG9tbmlib3ggZnJvbSByZWNlaXZpbmcgZm9jdXMsIGFjdGl2YXRlIG5ldyB0YWIgYWZ0ZXJcbiAgICAvLyBjcmVhdGlvbiBhbmQgc2VhcmNoLlxuICAgIGlmIChob3dUb09wZW5MaW5rLmFjdGl2ZSA/PyB0cnVlKSB7XG4gICAgICBhd2FpdCBjaHJvbWUudGFicy51cGRhdGUobmV3VGFiLmlkLCB7IGFjdGl2ZTogdHJ1ZSB9KTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgY2hyb21lLnNlYXJjaC5xdWVyeSh7IGRpc3Bvc2l0aW9uOiBob3dUb09wZW5MaW5rLmRpc3Bvc2l0aW9uLCB0ZXh0OiBxdW90ZVRleHQoc2VhcmNoVGV4dCkgfSk7XG4gIH1cbn1cblxuLyoqXG4gKiBPcGVucyB0aGUgd2ViIHBhZ2Ugd2l0aCBzcGVjaWZpZWQgVVJMLlxuICpcbiAqICoqTm90ZToqKiBOb3QgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0cywgYXZhaWxhYmxlIG9ubHkgaW4gYmFja2dyb3VuZFxuICogc2VydmljZSB3b3JrZXIsIGFjdGlvbiBzY3JpcHRzIG9yIG9wdGlvbnMgc2NyaXB0LlxuICpcbiAqIEBwYXJhbSB7IWNocm9tZS50YWJzLlRhYn0gdGFiIEN1cnJlbnQgdGFiIGNhbGxpbmcgdGhpcyBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7IXN0cmluZ30gdXJsXG4gKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rLktleVN0YXRlPX0ga2V5U3RhdGVcbiAqIEBwYXJhbSB7P0hvd1RvT3Blbkxpbms9fSBkZWZhdWx0SG93VG9PcGVuTGluayBTcGVjaWZpZXMgdGhlIGRlZmF1bHQgYmVoYXZpb3JcbiAqICAgIGlmIG5vIGNvbnRyb2wga2V5IGlzIHByZXNzZWQuXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuTGluayh0YWIsIHVybCwga2V5U3RhdGUsIGRlZmF1bHRIb3dUb09wZW5MaW5rKSB7XG4gIGNvbnN0IGhvd1RvT3BlbkxpbmsgPSBIb3dUb09wZW5MaW5rLmRlY2lkZShrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspO1xuICBpZiAoaG93VG9PcGVuTGluay5kaXNwb3NpdGlvbiA9PT0gSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5DVVJSRU5UX1RBQikge1xuICAgIGF3YWl0IGNocm9tZS50YWJzLnVwZGF0ZSh0YWIuaWQsIHsgdXJsOiB1cmwgfSk7XG4gIH0gZWxzZSBpZiAoaG93VG9PcGVuTGluay5kaXNwb3NpdGlvbiA9PT0gSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbi5ORVdfV0lORE9XKSB7XG4gICAgYXdhaXQgY3JlYXRlTmV3V2luZG93KHsgdXJsOiB1cmwgfSk7XG4gIH0gZWxzZSB7XG4gICAgYXdhaXQgY3JlYXRlTmV3VGFiKHRhYiwgeyB1cmw6IHVybCwgYWN0aXZlOiBob3dUb09wZW5MaW5rLmFjdGl2ZSA/PyB0cnVlIH0pO1xuICB9XG59XG5cbi8qKlxuICogT3BlbnMgdGhlIGV4dGVuc2lvbidzIE9wdGlvbnMgcGFnZS5cbiAqXG4gKiAqKk5vdGU6KiogTm90IGF2YWlsYWJsZSBpbiBjb250ZW50IHNjcmlwdHMsIGF2YWlsYWJsZSBvbmx5IGluIGJhY2tncm91bmRcbiAqIHNlcnZpY2Ugd29ya2VyLCBhY3Rpb24gc2NyaXB0cyBvciBvcHRpb25zIHNjcmlwdC5cbiAqXG4gKiBAcGFyYW0geyFjaHJvbWUudGFicy5UYWJ9IHRhYiBDdXJyZW50IHRhYiBjYWxsaW5nIHRoaXMgZnVuY3Rpb24uXG4gKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rLktleVN0YXRlPX0ga2V5U3RhdGVcbiAqIEBwYXJhbSB7P0hvd1RvT3Blbkxpbms9fSBkZWZhdWx0SG93VG9PcGVuTGluayBTcGVjaWZpZXMgdGhlIGRlZmF1bHQgYmVoYXZpb3JcbiAqICAgIGlmIG5vIGNvbnRyb2wga2V5IGlzIHByZXNzZWQuXG4gKiBAcmV0dXJucyB7IVByb21pc2U8dm9pZD59XG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBvcGVuT3B0aW9uc1BhZ2UodGFiLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspIHtcbiAgY29uc3QgdXJsID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwib3B0aW9ucy5odG1sXCIpO1xuICBhd2FpdCBvcGVuTGluayh0YWIsIHVybCwga2V5U3RhdGUsIGRlZmF1bHRIb3dUb09wZW5MaW5rKTtcbn1cblxuLyoqXG4gKiBPcGVucyBzZWFyY2ggZW5naW5lIHNldHRpbmdzIHBhZ2Ugb2YgdGhlIGJyb3dzZXIuXG4gKlxuICogKipOb3RlOioqIE5vdCBhdmFpbGFibGUgaW4gY29udGVudCBzY3JpcHRzLCBhdmFpbGFibGUgb25seSBpbiBiYWNrZ3JvdW5kXG4gKiBzZXJ2aWNlIHdvcmtlciwgYWN0aW9uIHNjcmlwdHMgb3Igb3B0aW9ucyBzY3JpcHQuXG4gKlxuICogQHBhcmFtIHshY2hyb21lLnRhYnMuVGFifSB0YWIgQ3VycmVudCB0YWIgY2FsbGluZyB0aGlzIGZ1bmN0aW9uLlxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluay5LZXlTdGF0ZT19IGtleVN0YXRlXG4gKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rPX0gZGVmYXVsdEhvd1RvT3BlbkxpbmsgU3BlY2lmaWVzIHRoZSBkZWZhdWx0IGJlaGF2aW9yXG4gKiAgICBpZiBubyBjb250cm9sIGtleSBpcyBwcmVzc2VkLlxuICogQHJldHVybnMgeyFQcm9taXNlPHZvaWQ+fVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlblNlYXJjaEVuZ2luZVNldHRpbmdzKHRhYiwga2V5U3RhdGUsIGRlZmF1bHRIb3dUb09wZW5MaW5rKSB7XG4gIGNvbnN0IHVybCA9IFwiY2hyb21lOi8vc2V0dGluZ3Mvc2VhcmNoXCI7XG4gIGF3YWl0IG9wZW5MaW5rKHRhYiwgdXJsLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspO1xufVxuXG4vKipcbiAqIE9wZW5zIGtleWJvYXJkIHNob3J0Y3V0cyBzZXR0aW5ncyBwYWdlIG9mIHRoZSBicm93c2VyLlxuICpcbiAqICoqTm90ZToqKiBOb3QgYXZhaWxhYmxlIGluIGNvbnRlbnQgc2NyaXB0cywgYXZhaWxhYmxlIG9ubHkgaW4gYmFja2dyb3VuZFxuICogc2VydmljZSB3b3JrZXIsIGFjdGlvbiBzY3JpcHRzIG9yIG9wdGlvbnMgc2NyaXB0LlxuICpcbiAqIEBwYXJhbSB7IWNocm9tZS50YWJzLlRhYn0gdGFiIEN1cnJlbnQgdGFiIGNhbGxpbmcgdGhpcyBmdW5jdGlvbi5cbiAqIEBwYXJhbSB7P0hvd1RvT3BlbkxpbmsuS2V5U3RhdGU9fSBrZXlTdGF0ZVxuICogQHBhcmFtIHs/SG93VG9PcGVuTGluaz19IGRlZmF1bHRIb3dUb09wZW5MaW5rIFNwZWNpZmllcyB0aGUgZGVmYXVsdCBiZWhhdmlvclxuICogICAgaWYgbm8gY29udHJvbCBrZXkgaXMgcHJlc3NlZC5cbiAqIEByZXR1cm5zIHshUHJvbWlzZTx2b2lkPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5TaG9ydGN1dHNTZXR0aW5ncyh0YWIsIGtleVN0YXRlLCBkZWZhdWx0SG93VG9PcGVuTGluaykge1xuICBjb25zdCB1cmwgPSBcImNocm9tZTovL2V4dGVuc2lvbnMvc2hvcnRjdXRzXCI7XG4gIGF3YWl0IG9wZW5MaW5rKHRhYiwgdXJsLCBrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspO1xufVxuIiwiaW1wb3J0IHsgY29uZmlnIH0gZnJvbSBcIi4vX19jb25maWcuanNcIjtcbmltcG9ydCB7IFNjcmlwdElkIH0gZnJvbSBcIi4vX19jb25zdGFudHMuanNcIjtcbmltcG9ydCB7IExvZ2dlciB9IGZyb20gXCIuL19fbG9nZ2VyLmpzXCI7XG5pbXBvcnQgeyBPcHRpb25zIH0gZnJvbSBcIi4vX19vcHRpb25zLmpzXCI7XG5cbi8qKlxuICogTG9nZ2VyIHVzZWQgdXNlZCB0aHJvdWdob3V0IHRoZSBleHRlbnNpb24uXG4gKlxuICogSXQgd2lsbCBiZSBpbml0aWFsaXplZCBpbiB7QGxpbmsgaW5pdCgpfSBmdW5jdGlvbi5cbiAqXG4gKiBAdHlwZSB7TG9nZ2VyfVxuICovXG5leHBvcnQgbGV0IGxvZ2dlcjtcblxuLyoqXG4gKiBPcHRpb25zIHVzZWQgdXNlZCB0aHJvdWdob3V0IHRoZSBleHRlbnNpb24uXG4gKlxuICogSXQgd2lsbCBiZSBpbml0aWFsaXplZCBpbiB7QGxpbmsgaW5pdCgpfSBmdW5jdGlvbi5cbiAqXG4gKiBAdHlwZSB7T3B0aW9uc31cbiAqL1xuZXhwb3J0IGxldCBvcHRpb25zO1xuXG4vKipcbiAqIEluaXRpYWxpemVzIHRoZSBtb2R1bGUuXG4gKlxuICogVGhpcyBmdW5jdGlvbiBtdXN0IGJlIGNhbGxlZCBmaXJzdCB0byBpbml0aWFsaXplIGdsb2JhbCB2YXJpYWJsZXMgYmVmb3JlXG4gKiB1c2luZyB0aGVtIGFuZCBhbnkgb3RoZXIgZnVuY3Rpb25zIGRlcGVuZGluZyB0aGVzZSBnbG9iYWwgdmFyaWFibGVzLlxuICpcbiAqIEBwYXJhbSB7IXN0cmluZ30gc2NyaXB0SWRcbiAqIEByZXR1cm5zIHshUHJvbWlzZTx2b2lkPn1cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGluaXQoc2NyaXB0SWQpIHtcbiAgbG9nZ2VyID0gbmV3IExvZ2dlcihzY3JpcHRJZCk7XG4gIGxvZ2dlci5zdGF0ZShcIkluaXRpYWxpemUgc2NyaXB0XCIsIHsgc2NyaXB0SWQgfSk7XG5cbiAgb3B0aW9ucyA9IG5ldyBPcHRpb25zKGxvZ2dlcik7XG4gIGF3YWl0IG9wdGlvbnMuaW5pdCgpO1xuXG4gIGF3YWl0IGNoZWNrT3NJc01hYyhzY3JpcHRJZCk7XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNoZWNrT3NJc01hYyhzY3JpcHRJZCkge1xuICBjb25zdCBTVE9SQUdFX0tFWSA9IFwiaXNNYWNcIjtcbiAgY29uc3Qgc3RvcmFnZSA9IGNocm9tZS5zdG9yYWdlLmxvY2FsO1xuICBpZiAoc2NyaXB0SWQgPT09IFNjcmlwdElkLkJBQ0tHUk9VTkQpIHtcbiAgICBjb25maWcuaXNNYWMgPSAoYXdhaXQgY2hyb21lLnJ1bnRpbWUuZ2V0UGxhdGZvcm1JbmZvKCkpLm9zID09PSBcIm1hY1wiO1xuICAgIGF3YWl0IHN0b3JhZ2Uuc2V0KHsgW1NUT1JBR0VfS0VZXTogY29uZmlnLmlzTWFjIH0pO1xuICB9IGVsc2Uge1xuICAgIGNvbmZpZy5pc01hYyA9ICEhKGF3YWl0IHN0b3JhZ2UuZ2V0KFNUT1JBR0VfS0VZKSlbU1RPUkFHRV9LRVldO1xuICB9XG4gIGxvZ2dlci5zdGF0ZShcIlVwZGF0ZWQgYGlzTWFjYCBpbiBjb25maWdcIiwgeyBbXCJjb25maWcuaXNNYWNcIl06IGNvbmZpZy5pc01hYyB9KTtcbn1cbiIsImltcG9ydCB7IGNvbmZpZyB9IGZyb20gXCIuL19fY29uZmlnLmpzXCI7XG5cbi8qKlxuICogQ29udHJvbHMgaG93IHRvIG9wZW4gYSBsaW5rIGJhc2VkIG9uIHRoZSBzdGF0ZSBvZiBjb250cm9sIGtleXMgc3VjaCBhcyBgQ3RybGBcbiAqIGFuZCBgU2hpZnRgLlxuICovXG5leHBvcnQgY2xhc3MgSG93VG9PcGVuTGluayB7XG4gIC8qKlxuICAgKiBMb2NhdGlvbiB3aGVyZSBhIGxpbmsgc2hvdWxkIGJlIG9wZW5lZC5cbiAgICpcbiAgICogVGhlIHZhbHVlcyBvZiB0aGlzIGVudW0gYXJlIHNhbWUgYXNcbiAgICogW2Nocm9tZS5zZWFyY2guRGlzcG9zaXRpb25dKGh0dHBzOi8vZGV2ZWxvcGVyLmNocm9tZS5jb20vZG9jcy9leHRlbnNpb25zL3JlZmVyZW5jZS9zZWFyY2gvI3R5cGUtRGlzcG9zaXRpb24pLlxuICAgKiBUaGVyZWZvcmUsIHRoZXkgY2FuIGJlIHVzZWQgYXMtaXMgYXMgYSBwYXJhbWV0ZXIgdG9cbiAgICogW2Nocm9tZS5zZWFyY2gucXVlcnkoKV0oaHR0cHM6Ly9kZXZlbG9wZXIuY2hyb21lLmNvbS9kb2NzL2V4dGVuc2lvbnMvcmVmZXJlbmNlL3NlYXJjaC8jbWV0aG9kLXF1ZXJ5KS5cbiAgICovXG4gIHN0YXRpYyBEaXNwb3NpdGlvbiA9IHtcbiAgICBDVVJSRU5UX1RBQjogXCJDVVJSRU5UX1RBQlwiLFxuICAgIE5FV19UQUI6IFwiTkVXX1RBQlwiLFxuICAgIE5FV19XSU5ET1c6IFwiTkVXX1dJTkRPV1wiLFxuICB9O1xuXG4gIHN0YXRpYyBLZXlTdGF0ZSA9IGNsYXNzIEtleVN0YXRlIHtcbiAgICBjdHJsS2V5O1xuICAgIHNoaWZ0S2V5O1xuXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHshYm9vbGVhbn0gY3RybEtleVxuICAgICAqIEBwYXJhbSB7IWJvb2xlYW59IHNoaWZ0S2V5XG4gICAgICogQHBhcmFtIHshYm9vbGVhbj19IG1ldGFLZXkgSWYgc3BlY2lmaWVkLCBgbWV0YUtleWAgaXMgdXNlZCBpbnN0ZWFkIG9mXG4gICAgICogICAgYGN0cmxLZXlgIHdoZW4gcnVubmluZyBvbiBNQUMuXG4gICAgICovXG4gICAgY29uc3RydWN0b3IoY3RybEtleSwgc2hpZnRLZXksIG1ldGFLZXkgPSBjdHJsS2V5KSB7XG4gICAgICB0aGlzLmN0cmxLZXkgPSBjb25maWcuaXNNYWMgPyBtZXRhS2V5IDogY3RybEtleTtcbiAgICAgIHRoaXMuc2hpZnRLZXkgPSBzaGlmdEtleTtcbiAgICB9XG5cbiAgICBlcXVhbHMob3RoZXIpIHtcbiAgICAgIHJldHVybiBvdGhlciAmJiB0aGlzLmN0cmxLZXkgPT09IG90aGVyLmN0cmxLZXkgJiYgdGhpcy5zaGlmdEtleSA9PT0gb3RoZXIuc2hpZnRLZXk7XG4gICAgfVxuXG4gICAgc3RhdGljIENVUlJFTlRfVEFCID0gbmV3IEtleVN0YXRlKGZhbHNlLCBmYWxzZSk7XG4gICAgc3RhdGljIE5FV19UQUJfQUNUSVZFID0gbmV3IEtleVN0YXRlKHRydWUsIHRydWUpO1xuICAgIHN0YXRpYyBORVdfVEFCX0lOQUNUSVZFID0gbmV3IEtleVN0YXRlKHRydWUsIGZhbHNlKTtcbiAgICBzdGF0aWMgTkVXX1dJTkRPVyA9IG5ldyBLZXlTdGF0ZShmYWxzZSwgdHJ1ZSk7XG4gIH07XG5cbiAgLyoqXG4gICAqIEB0eXBlIHshSG93VG9PcGVuTGluay5EaXNwb3NpdGlvbn1cbiAgICovXG4gIGRpc3Bvc2l0aW9uO1xuXG4gIC8qKlxuICAgKiBBdmFpbGFibGUgb25seSBpZiBgZGlzcG9zaXRpb24gPT09ICBORVdfVEFCYC5cbiAgICpcbiAgICogQHR5cGUge2Jvb2xlYW49fVxuICAgKi9cbiAgYWN0aXZlO1xuXG4gIC8qKlxuICAgKiBAcGFyYW0geyFIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9ufSBkaXNwb3NpdGlvblxuICAgKiBAcGFyYW0ge2Jvb2xlYW49fSBhY3RpdmUgQXZhaWxhYmxlIG9ubHkgaWYgYGRpc3Bvc2l0aW9uID09PSAgTkVXX1RBQmAuXG4gICAqL1xuICBjb25zdHJ1Y3RvcihkaXNwb3NpdGlvbiwgYWN0aXZlID0gdHJ1ZSkge1xuICAgIHRoaXMuZGlzcG9zaXRpb24gPSBkaXNwb3NpdGlvbjtcbiAgICB0aGlzLmFjdGl2ZSA9IGFjdGl2ZTtcbiAgfVxuXG4gIHN0YXRpYyBDVVJSRU5UX1RBQiA9IG5ldyBIb3dUb09wZW5MaW5rKEhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb24uQ1VSUkVOVF9UQUIpO1xuICBzdGF0aWMgTkVXX1RBQl9BQ1RJVkUgPSBuZXcgSG93VG9PcGVuTGluayhIb3dUb09wZW5MaW5rLkRpc3Bvc2l0aW9uLk5FV19UQUIsIHRydWUpO1xuICBzdGF0aWMgTkVXX1RBQl9JTkFDVElWRSA9IG5ldyBIb3dUb09wZW5MaW5rKEhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb24uTkVXX1RBQiwgZmFsc2UpO1xuICBzdGF0aWMgTkVXX1dJTkRPVyA9IG5ldyBIb3dUb09wZW5MaW5rKEhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb24uTkVXX1dJTkRPVyk7XG5cbiAgLyoqXG4gICAqIERlY2lkZXMgbG9jYXRpb24gd2hlcmUgYSBsaW5rIHNob3VsZCBiZSBvcGVuZWQuXG4gICAqXG4gICAqIEBwYXJhbSB7P0hvd1RvT3BlbkxpbmsuS2V5U3RhdGU9fSBrZXlTdGF0ZVxuICAgKiBAcGFyYW0gez9Ib3dUb09wZW5MaW5rPX0gZGVmYXVsdEhvd1RvT3BlbkxpbmtcbiAgICogQHJldHVybnMgeyFIb3dUb09wZW5MaW5rfVxuICAgKi9cbiAgc3RhdGljIGRlY2lkZShrZXlTdGF0ZSwgZGVmYXVsdEhvd1RvT3BlbkxpbmspIHtcbiAgICBpZiAoSG93VG9PcGVuTGluay5LZXlTdGF0ZS5ORVdfVEFCX0FDVElWRS5lcXVhbHMoa2V5U3RhdGUpKSByZXR1cm4gSG93VG9PcGVuTGluay5ORVdfVEFCX0FDVElWRTtcbiAgICBlbHNlIGlmIChIb3dUb09wZW5MaW5rLktleVN0YXRlLk5FV19UQUJfSU5BQ1RJVkUuZXF1YWxzKGtleVN0YXRlKSkgcmV0dXJuIEhvd1RvT3BlbkxpbmsuTkVXX1RBQl9JTkFDVElWRTtcbiAgICBlbHNlIGlmIChIb3dUb09wZW5MaW5rLktleVN0YXRlLk5FV19XSU5ET1cuZXF1YWxzKGtleVN0YXRlKSkgcmV0dXJuIEhvd1RvT3BlbkxpbmsuTkVXX1dJTkRPVztcbiAgICBlbHNlIHJldHVybiBkZWZhdWx0SG93VG9PcGVuTGluayA/PyBIb3dUb09wZW5MaW5rLkNVUlJFTlRfVEFCO1xuICB9XG59XG4iLCJpbXBvcnQgeyBjb25maWcgfSBmcm9tIFwiLi9fX2NvbmZpZy5qc1wiO1xuXG4vKipcbiAqIE91dHB1dHMgbG9ncyBvbmx5IGlmIGBjb25maWcubG9nRW5hYmxlZGAgaXMgdHJ1ZS4gT3RoZXJ3aXNlLCBhbGwgb2YgdGhlXG4gKiBpbnN0YW5jZSBtZXRob2RzIG9mIHRoaXMgY2xhc3MgaGF2ZSBubyBvcGVyYXRpb25zIChpZSBlbXB0eSkuXG4gKi9cbmV4cG9ydCBjbGFzcyBMb2dnZXIge1xuICAjaWQ7XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gaWQgQXBwZWFycyBhdCB0aGUgYmVnaW5uaW5nIG9mIHRoZSBsb2cgbWVzc2FnZSwgZW5jbG9zZWRcbiAgICogICAgaW4gc3F1YXJlIGJyYWNrZXRzLlxuICAgKi9cbiAgY29uc3RydWN0b3IoaWQpIHtcbiAgICB0aGlzLiNpZCA9IGlkO1xuICB9XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gaWRcbiAgICovXG4gIHNldElkKGlkKSB7XG4gICAgdGhpcy4jaWQgPSBpZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIGBjb25zb2xlLmRlYnVnKClgIHdpdGggdGhlIGhlYWRlciBgW0lORk9dYCBwcmVwZW5kZWQgdG8gdGhlIG1lc3NhZ2UuXG4gICAqXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gbWVzc2FnZVxuICAgKiBAcGFyYW0gey4uLmFueT19IGFyZ3MgYXJndW1lbnRzIGZvciB0aGUgc3Vic3RpdHV0aW9ucyBpZiBpbmNsdWRlZCBpbiB0aGVcbiAgICogICAgbWVzc2FnZS4gSWYgc3BlY2lmeWluZyBhbiBvYmplY3QgKGtleS12YWx1ZSBwYWlycykgYXQgdGhlIGVuZCwgaXQgd2lsbFxuICAgKiAgICBiZSBkZWNvbXBvc2VkIGFuZCBvdXRwdXQgaW4gdGhlIGZvcm0gYFxcbiR7a2V5fT0gJHt2YWx1ZX1gLlxuICAgKi9cbiAgaW5mbyhtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiZGVidWdcIiwgXCJbSU5GT11cIiwgbWVzc2FnZSwgYXJncyk7XG4gIH1cblxuICAvKipcbiAgICogQ2FsbCBgY29uc29sZS5kZWJ1ZygpYCB3aXRoIHRoZSBoZWFkZXIgYFtTVEFURV1gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICBzdGF0ZShtZXNzYWdlLCAuLi5hcmdzKSB7XG4gICAgdGhpcy4jb3V0cHV0KFwiZGVidWdcIiwgXCJbU1RBVEVdXCIsIG1lc3NhZ2UsIGFyZ3MpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUuZGVidWcoKWAgd2l0aCB0aGUgaGVhZGVyIGBbQ0FMTEJBQ0tdYCBwcmVwZW5kZWQgdG8gdGhlIG1lc3NhZ2UuXG4gICAqXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gbWVzc2FnZVxuICAgKiBAcGFyYW0gey4uLmFueT19IGFyZ3MgYXJndW1lbnRzIGZvciB0aGUgc3Vic3RpdHV0aW9ucyBpZiBpbmNsdWRlZCBpbiB0aGVcbiAgICogICAgbWVzc2FnZS4gSWYgc3BlY2lmeWluZyBhbiBvYmplY3QgKGtleS12YWx1ZSBwYWlycykgYXQgdGhlIGVuZCwgaXQgd2lsbFxuICAgKiAgICBiZSBkZWNvbXBvc2VkIGFuZCBvdXRwdXQgaW4gdGhlIGZvcm0gYFxcbiR7a2V5fT0gJHt2YWx1ZX1gLlxuICAgKi9cbiAgY2FsbGJhY2sobWVzc2FnZSwgLi4uYXJncykge1xuICAgIHRoaXMuI291dHB1dChcImRlYnVnXCIsIFwiW0NBTExCQUNLXVwiLCBtZXNzYWdlLCBhcmdzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIGBjb25zb2xlLndhcm4oKWAgd2l0aCB0aGUgaGVhZGVyIGBbV0FSTl1gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshc3RyaW5nfSBtZXNzYWdlXG4gICAqIEBwYXJhbSB7Li4uYW55PX0gYXJncyBhcmd1bWVudHMgZm9yIHRoZSBzdWJzdGl0dXRpb25zIGlmIGluY2x1ZGVkIGluIHRoZVxuICAgKiAgICBtZXNzYWdlLiBJZiBzcGVjaWZ5aW5nIGFuIG9iamVjdCAoa2V5LXZhbHVlIHBhaXJzKSBhdCB0aGUgZW5kLCBpdCB3aWxsXG4gICAqICAgIGJlIGRlY29tcG9zZWQgYW5kIG91dHB1dCBpbiB0aGUgZm9ybSBgXFxuJHtrZXl9PSAke3ZhbHVlfWAuXG4gICAqL1xuICB3YXJuKG1lc3NhZ2UsIC4uLmFyZ3MpIHtcbiAgICB0aGlzLiNvdXRwdXQoXCJ3YXJuXCIsIFwiW1dBUk5dXCIsIG1lc3NhZ2UsIGFyZ3MpO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGwgYGNvbnNvbGUuZXJyb3IoKWAgd2l0aCB0aGUgaGVhZGVyIGBbRVJST1JdYCBwcmVwZW5kZWQgdG8gdGhlIG1lc3NhZ2UuXG4gICAqXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gbWVzc2FnZVxuICAgKiBAcGFyYW0gey4uLmFueT19IGFyZ3MgYXJndW1lbnRzIGZvciB0aGUgc3Vic3RpdHV0aW9ucyBpZiBpbmNsdWRlZCBpbiB0aGVcbiAgICogICAgbWVzc2FnZS4gSWYgc3BlY2lmeWluZyBhbiBvYmplY3QgKGtleS12YWx1ZSBwYWlycykgYXQgdGhlIGVuZCwgaXQgd2lsbFxuICAgKiAgICBiZSBkZWNvbXBvc2VkIGFuZCBvdXRwdXQgaW4gdGhlIGZvcm0gYFxcbiR7a2V5fT0gJHt2YWx1ZX1gLlxuICAgKi9cbiAgZXJyb3IobWVzc2FnZSwgLi4uYXJncykge1xuICAgIHRoaXMuI291dHB1dChcImVycm9yXCIsIFwiW0VSUk9SXVwiLCBtZXNzYWdlLCBhcmdzKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIGBjb25zb2xlLmFzc2VydCgpYCB3aXRoIHRoZSBoZWFkZXIgYFtFUlJPUl1gIHByZXBlbmRlZCB0byB0aGUgbWVzc2FnZS5cbiAgICpcbiAgICogQHBhcmFtIHshYm9vbGVhbn0gYXNzZXJ0aW9uXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gbWVzc2FnZVxuICAgKiBAcGFyYW0gey4uLmFueT19IGFyZ3MgYXJndW1lbnRzIGZvciB0aGUgc3Vic3RpdHV0aW9ucyBpZiBpbmNsdWRlZCBpbiB0aGVcbiAgICogICAgbWVzc2FnZS4gSWYgc3BlY2lmeWluZyBhbiBvYmplY3QgKGtleS12YWx1ZSBwYWlycykgYXQgdGhlIGVuZCwgaXQgd2lsbFxuICAgKiAgICBiZSBkZWNvbXBvc2VkIGFuZCBvdXRwdXQgaW4gdGhlIGZvcm0gYFxcbiR7a2V5fT0gJHt2YWx1ZX1gLlxuICAgKi9cbiAgYXNzZXJ0KGFzc2VydGlvbiwgbWVzc2FnZSwgLi4uYXJncykge1xuICAgIHRoaXMuI291dHB1dChcImFzc2VydFwiLCBcIltFUlJPUl1cIiwgbWVzc2FnZSwgYXJncywgYXNzZXJ0aW9uKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYWxsIENvbnNvbGUgQVBJIHNwZWNpZmllZCBieSB0aGUgYG1ldGhvZGAgYXJndW1lbnQuXG4gICAqXG4gICAqIEBwYXJhbSB7IXN0cmluZ30gY29uc29sZUFwaSBDb25zb2xlIEFQSSB0byBjYWxsLlxuICAgKiBAcGFyYW0geyFzdHJpbmd9IGhlYWRlclxuICAgKiBAcGFyYW0geyFzdHJpbmd9IG1lc3NhZ2VcbiAgICogQHBhcmFtIHs/YW55W109fSBhcmdzXG4gICAqIEBwYXJhbSB7P2Jvb2xlYW49fSBhc3NlcnRpb24gbXVzdCBiZSBzcGVjaWZpZWQgaWYgYG1ldGhvZGAgaXMgXCJhc3NlcnRcIiwgb3RoZXJ3aXNlIGlnbm9yZWQuXG4gICAqL1xuICAjb3V0cHV0KGNvbnNvbGVBcGksIGhlYWRlciwgbWVzc2FnZSwgYXJncywgYXNzZXJ0aW9uKSB7XG4gICAgaWYgKCFjb25maWcubG9nRW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IG9wdGlvbmFsQXJncyA9IFtdO1xuICAgIGlmIChhcmdzICYmIGFyZ3MubGVuZ3RoID4gMCAmJiB0eXBlb2YgYXJncy5hdCgtMSkgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGFyZ3MucG9wKCkpKSB7XG4gICAgICAgIG9wdGlvbmFsQXJncy5wdXNoKGBcXG4ke2tleX09YCk7XG4gICAgICAgIG9wdGlvbmFsQXJncy5wdXNoKHZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zb2xlW2NvbnNvbGVBcGldKFxuICAgICAgLi4uKGNvbnNvbGVBcGkgPT09IFwiYXNzZXJ0XCIgPyBbISFhc3NlcnRpb25dIDogW10pLFxuICAgICAgYFske3RoaXMuI2lkfV0gJHtoZWFkZXJ9ICR7bWVzc2FnZX1gLFxuICAgICAgLi4uYXJncyxcbiAgICAgIC4uLm9wdGlvbmFsQXJnc1xuICAgICk7XG4gIH1cbn1cbiIsImltcG9ydCB7IEhvd1RvT3BlbkxpbmsgfSBmcm9tIFwiLi9fX2hvd190b19vcGVuX2xpbmsuanNcIjtcblxuLyoqXG4gKiBVc2VyLWN1c3RvbWl6YWJsZSBleHRlbnNpb24gb3B0aW9ucy5cbiAqXG4gKiBPcHRpb25zIGlzIHN0b3JlZCBpbiB0aGVcbiAqIFtzeW5jXShodHRwczovL2RldmVsb3Blci5jaHJvbWUuY29tL2RvY3MvZXh0ZW5zaW9ucy9yZWZlcmVuY2Uvc3RvcmFnZS8jcHJvcGVydHktc3luYylcbiAqIHN0b3JhZ2UgYXJlYSB0aGF0IGlzIHN5bmNlZCB1c2luZyBDaHJvbWUgU3luYy5cbiAqL1xuZXhwb3J0IGNsYXNzIE9wdGlvbnMge1xuICBzdGF0aWMgI3N0b3JhZ2UgPSBjaHJvbWUuc3RvcmFnZS5zeW5jO1xuXG4gIHN0YXRpYyAjU1RPUkFHRV9LRVkgPSBcIm9wdGlvbnNcIjtcblxuICBzdGF0aWMgI1VQREFURURfQVRfS0VZID0gXCJfX3VwZGF0ZWRBdF9fXCI7XG5cbiAgc3RhdGljICNERUZBVUxUX1ZBTFVFUyA9IHtcbiAgICBbT3B0aW9ucy4jVVBEQVRFRF9BVF9LRVldOiAwLFxuICB9O1xuXG4gIHN0YXRpYyBEaXNwb3NpdGlvbiA9IEhvd1RvT3BlbkxpbmsuRGlzcG9zaXRpb247XG5cbiAgc3RhdGljIElDT05fU0laRV9NSU4gPSAxO1xuICBzdGF0aWMgSUNPTl9TSVpFX01BWCA9IDU7XG5cbiAgLy8gcHJldHRpZXItaWdub3JlXG4gIC8qKlxuICAgKiBEZWZpbml0aW9uIG9mIG9wdGlvbnMuXG4gICAqXG4gICAqIEp1c3QgYWRkIGEgcm93IGludG8gdGhpcyB0YWJsZSB0byBhZGQgYSBuZXcgb3B0aW9uIGl0ZW0uIFRoZSBjb2RlIG5lY2Vzc2FyeVxuICAgKiB0byByZWFkIGFuZCB3cml0ZSBvcHRpb24gdmFsdWVzIGlzIGF1dG9tYXRpY2FsbHkgZ2VuZXJhdGVkLlxuICAgKlxuICAgKiBAdHlwZSB7e25hbWU6IXN0cmluZywgZGVmYXVsdFZhbHVlOiEqLCB2YWxpZGF0b3I6IWZ1bmN0aW9uKD8qKTpib29sZWFufVtdfVxuICAgKi9cbiAgc3RhdGljICNJVEVNUyA9IFtcbiAgICB7IG5hbWU6IFwicG9wdXBJY29uXCIgICAgICwgZGVmYXVsdFZhbHVlOiB0cnVlICAgICAgICAgICAgICAgICAgICAgICAsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgIHsgbmFtZTogXCJpY29uU2l6ZVwiICAgICAgLCBkZWZhdWx0VmFsdWU6IDMgICAgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIiAmJiB2YWx1ZSA+PSBPcHRpb25zLklDT05fU0laRV9NSU4gJiYgdmFsdWUgPD0gT3B0aW9ucy5JQ09OX1NJWkVfTUFYIH0sXG4gICAgeyBuYW1lOiBcImF2b2lkU2VsZWN0aW9uXCIsIGRlZmF1bHRWYWx1ZTogZmFsc2UgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICB7IG5hbWU6IFwib3B0aW9uc0J1dHRvblwiICwgZGVmYXVsdFZhbHVlOiB0cnVlICAgICAgICAgICAgICAgICAgICAgICAsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgIHsgbmFtZTogXCJjb250ZXh0TWVudVwiICAgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImRpc3Bvc2l0aW9uXCIgICAsIGRlZmF1bHRWYWx1ZTogT3B0aW9ucy5EaXNwb3NpdGlvbi5ORVdfVEFCLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiICYmIE9iamVjdC52YWx1ZXMoT3B0aW9ucy5EaXNwb3NpdGlvbikuaW5jbHVkZXModmFsdWUpICAgICAgICAgICAgICAgfSxcbiAgICB7IG5hbWU6IFwiYXV0b0NvcHlcIiAgICAgICwgZGVmYXVsdFZhbHVlOiB0cnVlICAgICAgICAgICAgICAgICAgICAgICAsIHZhbGlkYXRvcjogKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgIHsgbmFtZTogXCJhdXRvRW50ZXJcIiAgICAgLCBkZWZhdWx0VmFsdWU6IHRydWUgICAgICAgICAgICAgICAgICAgICAgICwgdmFsaWRhdG9yOiAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgeyBuYW1lOiBcImF1dG9TdXJyb3VuZFwiICAsIGRlZmF1bHRWYWx1ZTogZmFsc2UgICAgICAgICAgICAgICAgICAgICAgLCB2YWxpZGF0b3I6ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgXTtcblxuICBzdGF0aWMgI2RlZmluZU9wdGlvbnMoKSB7XG4gICAgZm9yIChjb25zdCB7IG5hbWUsIGRlZmF1bHRWYWx1ZSwgdmFsaWRhdG9yIH0gb2YgT3B0aW9ucy4jSVRFTVMpIHtcbiAgICAgIE9wdGlvbnMuI0RFRkFVTFRfVkFMVUVTW25hbWVdID0gZGVmYXVsdFZhbHVlO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KE9wdGlvbnMucHJvdG90eXBlLCBuYW1lLCB7XG4gICAgICAgIHNldCh2YWx1ZSkge1xuICAgICAgICAgIGlmICghdmFsaWRhdG9yKHZhbHVlKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBPcHRpb25zOiBJbnZhbGlkIHZhbHVlIGZvciAnJHtuYW1lfSdcXG52YWx1ZT0ke3ZhbHVlfWApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAodmFsdWUgIT09IHRoaXMuI2NhY2hlW25hbWVdKSB7XG4gICAgICAgICAgICB0aGlzLiNjYWNoZVtuYW1lXSA9IHZhbHVlO1xuICAgICAgICAgICAgLyogYXN5bmMgKi8gdGhpcy4jdXBkYXRlU3RvcmFnZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgZ2V0KCkge1xuICAgICAgICAgIHJldHVybiB2YWxpZGF0b3IodGhpcy4jY2FjaGVbbmFtZV0pID8gdGhpcy4jY2FjaGVbbmFtZV0gOiBkZWZhdWx0VmFsdWU7XG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBzdGF0aWMge1xuICAgIE9wdGlvbnMuI2RlZmluZU9wdGlvbnMoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBGaXJlZCB3aGVuIG9uZSBvciBtb3JlIG9wdGlvbnMgYXJlIGNoYW5nZWQgZXh0ZXJuYWxseS5cbiAgICovXG4gIG9uQ2hhbmdlZCA9IG5ldyAoY2xhc3Mgb25DaGFuZ2VkIHtcbiAgICAjbGlzdGVuZXJzID0gW107XG4gICAgLyoqXG4gICAgICogQHBhcmFtIHshZnVuY3Rpb24oIU9wdGlvbnMpOnZvaWR9IGxpc3RlbmVyXG4gICAgICovXG4gICAgYWRkTGlzdGVuZXIobGlzdGVuZXIpIHtcbiAgICAgIHRoaXMuI2xpc3RlbmVycy5wdXNoKGxpc3RlbmVyKTtcbiAgICB9XG4gICAgX2ZpcmUoKSB7XG4gICAgICBmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIHRoaXMuI2xpc3RlbmVycykge1xuICAgICAgICBsaXN0ZW5lcigpO1xuICAgICAgfVxuICAgIH1cbiAgfSkoKTtcblxuICAjbG9nZ2VyO1xuICAjY2FjaGU7XG5cbiAgLyoqXG4gICAqIEBwYXJhbSB7IUxvZ2dlcn0gbG9nZ2VyXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihsb2dnZXIpIHtcbiAgICB0aGlzLiNsb2dnZXIgPSBsb2dnZXI7XG4gICAgdGhpcy4jY2FjaGUgPSBPYmplY3QuYXNzaWduKHt9LCBPcHRpb25zLiNERUZBVUxUX1ZBTFVFUyk7XG5cbiAgICBPcHRpb25zLiNzdG9yYWdlLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcigoY2hhbmdlcywgYXJlYU5hbWUpID0+IHtcbiAgICAgIHRoaXMuI29uQ2hhbmdlZExpc3RlbmVyKGNoYW5nZXMsIGFyZWFOYW1lKTtcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBMb2FkIG9wdGlvbnMgZnJvbSB0aGUgc3RvcmFnZS5cbiAgICovXG4gIGFzeW5jIGluaXQoKSB7XG4gICAgY29uc3QgdmFsdWVzID0gYXdhaXQgT3B0aW9ucy4jc3RvcmFnZS5nZXQoT3B0aW9ucy4jU1RPUkFHRV9LRVkpO1xuICAgIC8vIE1lcmdlIHJhdGhlciB0aGFuIGFzc2lnbiB0byBlbnN1cmUgY29tcGxldGVuZXNzIG9mIG9wdGlvbnMgaW4gY2FzZSBvZlxuICAgIC8vIG1pc3NpbmcgZGF0YSBpbiB0aGUgc3RvcmFnZS5cbiAgICBPYmplY3QuYXNzaWduKHRoaXMuI2NhY2hlLCB2YWx1ZXNbT3B0aW9ucy4jU1RPUkFHRV9LRVldKTtcbiAgICB0aGlzLiNsb2dnZXIuc3RhdGUoXCJPcHRpb25zOiBJbml0aWFsaXplZFwiLCB7IFtcInRoaXMuI2NhY2hlXCJdOiB0aGlzLiNjYWNoZSB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXNldCBhbGwgb3B0aW9ucyB0byByZXN0b3JlIGRlZmF1bHRzLlxuICAgKi9cbiAgcmVzZXQoKSB7XG4gICAgdGhpcy4jY2FjaGUgPSBPYmplY3QuYXNzaWduKHt9LCBPcHRpb25zLiNERUZBVUxUX1ZBTFVFUyk7XG4gICAgLyogYXN5bmMgKi8gdGhpcy4jdXBkYXRlU3RvcmFnZSgpO1xuICB9XG5cbiAgYXN5bmMgI3VwZGF0ZVN0b3JhZ2UoKSB7XG4gICAgdGhpcy4jY2FjaGVbT3B0aW9ucy4jVVBEQVRFRF9BVF9LRVldID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCB2YWx1ZXMgPSB7IFtPcHRpb25zLiNTVE9SQUdFX0tFWV06IHRoaXMuI2NhY2hlIH07XG4gICAgdGhpcy4jbG9nZ2VyLnN0YXRlKFwiT3B0aW9uczogVXBkYXRlIHN0b3JhZ2VcIiwgeyB2YWx1ZXMgfSk7XG4gICAgYXdhaXQgT3B0aW9ucy4jc3RvcmFnZS5zZXQodmFsdWVzKTtcbiAgfVxuXG4gICNvbkNoYW5nZWRMaXN0ZW5lcihjaGFuZ2VzLCBhcmVhTmFtZSkge1xuICAgIHRoaXMuI2xvZ2dlci5jYWxsYmFjayhcIk9wdGlvbnM6IG9uQ2hhbmdlZExpc3RlbmVyKClcIiwgeyBjaGFuZ2VzLCBhcmVhTmFtZSB9KTtcblxuICAgIGlmICghT2JqZWN0Lmhhc093bihjaGFuZ2VzLCBPcHRpb25zLiNTVE9SQUdFX0tFWSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAoT2JqZWN0Lmhhc093bihjaGFuZ2VzW09wdGlvbnMuI1NUT1JBR0VfS0VZXSwgXCJuZXdWYWx1ZVwiKSkge1xuICAgICAgY29uc3QgbmV3VmFsdWUgPSBjaGFuZ2VzW09wdGlvbnMuI1NUT1JBR0VfS0VZXS5uZXdWYWx1ZTtcbiAgICAgIGlmIChuZXdWYWx1ZVtPcHRpb25zLiNVUERBVEVEX0FUX0tFWV0gPD0gdGhpcy4jY2FjaGVbT3B0aW9ucy4jVVBEQVRFRF9BVF9LRVldKSB7XG4gICAgICAgIHRoaXMuI2xvZ2dlci5pbmZvKFwiT3B0aW9uczogQ2FjaGUgd2FzIG5vdCBvdmVyd3JpdHRlbiBiZWNhdXNlIGl0IGlzIHVwIHRvIGRhdGVcIiwge1xuICAgICAgICAgIFtcInRoaXMuI2NhY2hlXCJdOiB0aGlzLiNjYWNoZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gTWVyZ2UgcmF0aGVyIHRoYW4gYXNzaWduIHRvIGVuc3VyZSBjb21wbGV0ZW5lc3Mgb2Ygb3B0aW9ucyBpbiBjYXNlIG9mXG4gICAgICAvLyBtaXNzaW5nIGRhdGEgaW4gdGhlIHN0b3JhZ2UuXG4gICAgICBPYmplY3QuYXNzaWduKHRoaXMuI2NhY2hlLCBuZXdWYWx1ZSk7XG4gICAgICB0aGlzLiNsb2dnZXIuc3RhdGUoXCJPcHRpb25zOiBDYWNoZSB3YXMgb3ZlcndyaXR0ZW4gYnkgdmFsdWVzIGluIHN0b3JhZ2UgdXBkYXRlZCBieSBvdGhlclwiLCB7XG4gICAgICAgIFtcInRoaXMuI2NhY2hlXCJdOiB0aGlzLiNjYWNoZSxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICAvLyBUaGUgc3RvcmFnZSBoYXMgYmVlbiBjbGVhcmVkLlxuXG4gICAgICB0aGlzLiNjYWNoZSA9IE9iamVjdC5hc3NpZ24oe30sIE9wdGlvbnMuI0RFRkFVTFRfVkFMVUVTKTtcbiAgICAgIHRoaXMuI2xvZ2dlci5zdGF0ZShcIk9wdGlvbnM6IENhY2hlIHdhcyByZXNldCB0byBkZWZhdWx0IHZhbHVlcyBiZWNhdXNlIHRoZSBzdG9yYWdlIGhhcyBiZWVuIGNsZWFyZWRcIiwge1xuICAgICAgICBbXCJ0aGlzLiNjYWNoZVwiXTogdGhpcy4jY2FjaGUsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICB0aGlzLm9uQ2hhbmdlZC5fZmlyZSgpO1xuICB9XG59XG4iLCIvKipcbiAqIEBmaWxlIEFnZ3JlZ2F0ZXMgbW9kdWxlcy5cbiAqL1xuXG5leHBvcnQgKiBmcm9tIFwiLi9fX2NvbmZpZy5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19jb25zdGFudHMuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL19fZnVuY3Rpb25zLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9fX2dsb2JhbHMuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL19faG93X3RvX29wZW5fbGluay5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vX19sb2dnZXIuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL19fb3B0aW9ucy5qc1wiO1xuIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIlwidXNlIHN0cmljdFwiO1xuXG5pbXBvcnQgKiBhcyBxcXMgZnJvbSBcIi4vbW9kdWxlcy9jb21tb24uanNcIjtcblxuKGFzeW5jIGZ1bmN0aW9uIG1haW4oKSB7XG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBJbml0aWFsaXplIGNvbW1vbiBtb2R1bGVzXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gIGF3YWl0IHFxcy5pbml0KHFxcy5TY3JpcHRJZC5CQUNLR1JPVU5EKTtcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gQ29uc3RhbnRzXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gIGNvbnN0IE1FU1NBR0VfSEFORExFUlMgPSB7XG4gICAgW3Fxcy5NZXNzYWdlVHlwZS5IRUxMT106IG9uSGVsbG8sXG4gICAgW3Fxcy5NZXNzYWdlVHlwZS5OT1RJRllfU0VMRUNUSU9OX1VQREFURURdOiBvbk5vdGlmeVNlbGVjdGlvblVwZGF0ZWQsXG4gICAgW3Fxcy5NZXNzYWdlVHlwZS5ET19RVU9URURfU0VBUkNIXTogb25Eb1F1b3RlZFNlYXJjaCxcbiAgICBbcXFzLk1lc3NhZ2VUeXBlLk9QRU5fT1BUSU9OU19QQUdFXTogb25PcGVuT3B0aW9uc1BhZ2UsXG4gICAgW3Fxcy5NZXNzYWdlVHlwZS5HRVRfU0VMRUNUSU9OXTogb25HZXRTZWxlY3Rpb24sXG4gIH07XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIFZhcmlhYmxlc1xuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBjb25zdCBjdXJyZW50U2VsZWN0aW9uID0ge1xuICAgIHNlbmRlcjogdW5kZWZpbmVkLFxuICAgIHRleHQ6IFwiXCIsXG4gICAgZWRpdGFibGU6IGZhbHNlLFxuICAgIHNlYXJjaGFibGU6IGZhbHNlLFxuICAgIGJsdXI6IHRydWUsXG4gIH07XG5cbiAgY29uc3QgY29tbWFuZHMgPSB7XG4gICAgW3Fxcy5Db21tYW5kVHlwZS5ET19RVU9URURfU0VBUkNIXToge1xuICAgICAgc2hvcnRjdXQ6IFwiXCIsXG4gICAgICBjb250ZXh0TWVudToge1xuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgdGl0bGU6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJtc2dfY29udGV4dF9tZW51X3RpdGxlX2RvX3F1b3RlZF9zZWFyY2hcIiksXG4gICAgICAgICAgdHlwZTogXCJub3JtYWxcIixcbiAgICAgICAgICBjb250ZXh0czogW1wic2VsZWN0aW9uXCJdLFxuICAgICAgICB9LFxuICAgICAgICByZWdpc3RlcmVkOiBmYWxzZSxcbiAgICAgICAgb25seUVkaXRhYmxlOiBmYWxzZSxcbiAgICAgICAgdGl0bGVDaGFuZ2VzSW5TZWFyY2hhYmxlOiBmYWxzZSxcbiAgICAgIH0sXG4gICAgICBhc3luYyBvblNob3J0Y3V0UHJlc3NlZCh0YWIpIHtcbiAgICAgICAgYXdhaXQgZG9RdW90ZWRTZWFyY2hGb3JTZWxlY3Rpb25UZXh0KHRhYiwgY3VycmVudFNlbGVjdGlvbi50ZXh0KTtcbiAgICAgIH0sXG4gICAgICBhc3luYyBvbkNvbnRleHRNZW51Q2xpY2tlZChpbmZvLCB0YWIpIHtcbiAgICAgICAgYXdhaXQgZG9RdW90ZWRTZWFyY2hGb3JTZWxlY3Rpb25UZXh0KHRhYiwgcXFzLmZpbHRlclNlbGVjdGlvblRleHQoaW5mby5zZWxlY3Rpb25UZXh0KSk7XG4gICAgICB9LFxuICAgIH0sXG4gICAgW3Fxcy5Db21tYW5kVHlwZS5QVVRfUVVPVEVTXToge1xuICAgICAgc2hvcnRjdXQ6IFwiXCIsXG4gICAgICBjb250ZXh0TWVudToge1xuICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgdGl0bGU6IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJtc2dfY29udGV4dF9tZW51X3RpdGxlX3B1dF9xdW90ZXNcIiksXG4gICAgICAgICAgdHlwZTogXCJub3JtYWxcIixcbiAgICAgICAgICBjb250ZXh0czogW1wiZWRpdGFibGVcIl0sXG4gICAgICAgIH0sXG4gICAgICAgIHJlZ2lzdGVyZWQ6IGZhbHNlLFxuICAgICAgICBvbmx5RWRpdGFibGU6IHRydWUsXG4gICAgICAgIHRpdGxlQ2hhbmdlc0luU2VhcmNoYWJsZTogdHJ1ZSxcbiAgICAgIH0sXG4gICAgICBvblNob3J0Y3V0UHJlc3NlZCh0YWIpIHtcbiAgICAgICAgcHV0UXVvdGVzQXJvdW5kU2VsZWN0aW9uVGV4dCh0YWIsIGN1cnJlbnRTZWxlY3Rpb24uc2VuZGVyLmZyYW1lSWQpO1xuICAgICAgfSxcbiAgICAgIG9uQ29udGV4dE1lbnVDbGlja2VkKGluZm8sIHRhYikge1xuICAgICAgICBwdXRRdW90ZXNBcm91bmRTZWxlY3Rpb25UZXh0KHRhYiwgaW5mby5mcmFtZUlkKTtcbiAgICAgIH0sXG4gICAgfSxcbiAgfTtcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gU3RhcnR1cCBPcGVyYXRpb25zXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuXG4gIGNocm9tZS5ydW50aW1lLm9uQ29ubmVjdC5hZGRMaXN0ZW5lcihvbkNvbm5lY3QpO1xuXG4gIGNocm9tZS50YWJzLm9uQWN0aXZhdGVkLmFkZExpc3RlbmVyKG9uVGFic0FjdGl2YXRlKTtcbiAgY2hyb21lLnRhYnMub25VcGRhdGVkLmFkZExpc3RlbmVyKG9uVGFic1VwZGF0ZWQpO1xuXG4gIGNocm9tZS5jb250ZXh0TWVudXMub25DbGlja2VkLmFkZExpc3RlbmVyKG9uQ29udGV4dE1lbnVDbGlja2VkKTtcbiAgY2hyb21lLmNvbW1hbmRzLm9uQ29tbWFuZC5hZGRMaXN0ZW5lcihvbkNvbW1hbmQpO1xuXG4gIHFxcy5vcHRpb25zLm9uQ2hhbmdlZC5hZGRMaXN0ZW5lcihvbk9wdGlvbnNDaGFuZ2VkKTtcblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gRXZlbnQgTGlzdGVuZXJzIChDb250ZW50IHNjcmlwdHMsIEFjdGlvbiBzY3JpcHRzKVxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBhc3luYyBmdW5jdGlvbiBvbkNvbm5lY3QocG9ydCkge1xuICAgIHFxcy5sb2dnZXIuY2FsbGJhY2soXCJvbkNvbm5lY3QoKVwiLCB7IHBvcnQgfSk7XG4gICAgcG9ydC5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlKTtcbiAgICBhd2FpdCB1cGRhdGVDb21tYW5kU2hvcnRjdXRzKCk7XG4gIH1cblxuICBmdW5jdGlvbiBvbk1lc3NhZ2UobWVzc2FnZSwgcG9ydCkge1xuICAgIHFxcy5sb2dnZXIuY2FsbGJhY2soXCJvbk1lc3NhZ2UoKVwiLCB7IG1lc3NhZ2UsIHBvcnQgfSk7XG4gICAgTUVTU0FHRV9IQU5ETEVSU1ttZXNzYWdlLnR5cGVdKG1lc3NhZ2UsIHBvcnQpO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gb25IZWxsbyhfbWVzc2FnZSwgcG9ydCkge1xuICAgIHFxcy5wb3N0TWVzc2FnZShwb3J0LCB7XG4gICAgICB0eXBlOiBxcXMuTWVzc2FnZVR5cGUuV0VMQ09NRSxcbiAgICAgIGlkZW50aXR5OiBxcXMuY2xvbmVEdG8ocG9ydC5zZW5kZXIpLFxuICAgIH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gb25Ob3RpZnlTZWxlY3Rpb25VcGRhdGVkKG1lc3NhZ2UsIHBvcnQpIHtcbiAgICBpZiAobWVzc2FnZS5zZWxlY3Rpb24uYmx1cikge1xuICAgICAgaWYgKCFpc093bmVyT2ZDdXJyZW50U2VsZWN0aW9uKHBvcnQuc2VuZGVyLnRhYi5pZCwgcG9ydC5zZW5kZXIuZnJhbWVJZCkpIHtcbiAgICAgICAgcXFzLmxvZ2dlci5pbmZvKFxuICAgICAgICAgIFwiSWdub3JlIG1lc3NhZ2UgZnJvbSBibHVycmVkIGNvbnRlbnQgYmVjYXVzZSBzZWxlY3Rpb24gc3RhdGUgaGFzIGFscmVhZHkgYmVlbiB1cGRhdGVkIGJ5IG5ld2x5IGZvY3VzZWQgY29udGVudFwiXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICB9XG5cbiAgICB1cGRhdGVDdXJyZW50U2VsZWN0aW9uKG1lc3NhZ2Uuc2VsZWN0aW9uLCBwb3J0LnNlbmRlcik7XG4gICAgdXBkYXRlQ29udGV4dE1lbnUoY3VycmVudFNlbGVjdGlvbik7XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBvbkRvUXVvdGVkU2VhcmNoKG1lc3NhZ2UsIHBvcnQpIHtcbiAgICBhd2FpdCBkb1F1b3RlZFNlYXJjaEZvclNlbGVjdGlvblRleHQocG9ydC5zZW5kZXIudGFiLCBtZXNzYWdlLnNlbGVjdGlvblRleHQsIG1lc3NhZ2Uua2V5U3RhdGUpO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gb25PcGVuT3B0aW9uc1BhZ2UobWVzc2FnZSwgcG9ydCkge1xuICAgIGF3YWl0IHFxcy5vcGVuT3B0aW9uc1BhZ2UocG9ydC5zZW5kZXIudGFiLCBtZXNzYWdlLmtleVN0YXRlLCBtZXNzYWdlLmRlZmF1bHRIb3dUb09wZW5MaW5rKTtcbiAgfVxuXG4gIGZ1bmN0aW9uIG9uR2V0U2VsZWN0aW9uKG1lc3NhZ2UsIHBvcnQpIHtcbiAgICBxcXMucG9zdE1lc3NhZ2UocG9ydCwge1xuICAgICAgdHlwZTogcXFzLk1lc3NhZ2VUeXBlLk5PVElGWV9TRUxFQ1RJT04sXG4gICAgICBzZWxlY3Rpb246IGlzT3duZXJPZkN1cnJlbnRTZWxlY3Rpb24obWVzc2FnZS50YWIuaWQpID8gcXFzLmNsb25lRHRvKGN1cnJlbnRTZWxlY3Rpb24pIDogdW5kZWZpbmVkLFxuICAgIH0pO1xuICB9XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIEV2ZW50IExpc3RlbmVycyAoVGFicylcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgLy8gTGlzdGVuIGZvciBgY2hyb21lLnRhYnNgIGV2ZW50cyB0byBlbnN1cmUgQmFja2dyb3VuZCBzZXJ2aWNlIHdvcmtlciB0byBiZVxuICAvLyBsb2FkZWQgYmVmb3JlIENvbnRlbnQgc2NyaXB0cyBjb25uZWN0IHRvIGl0LlxuXG4gIGZ1bmN0aW9uIG9uVGFic0FjdGl2YXRlKGFjdGl2ZUluZm8pIHtcbiAgICBxcXMubG9nZ2VyLmNhbGxiYWNrKFwib25UYWJzQWN0aXZhdGUoKVwiLCB7IGFjdGl2ZUluZm8gfSk7XG4gIH1cblxuICBmdW5jdGlvbiBvblRhYnNVcGRhdGVkKHRhYklkLCBjaGFuZ2VJbmZvLCB0YWIpIHtcbiAgICBxcXMubG9nZ2VyLmNhbGxiYWNrKFwib25UYWJzVXBkYXRlZCgpXCIsIHsgdGFiSWQsIGNoYW5nZUluZm8sIHRhYiB9KTtcbiAgfVxuXG4gIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAvLyBFdmVudCBMaXN0ZW5lcnMgKENvbnRleHQgbWVudXMsIEtleWJvYXJkIHNob3J0Y3V0cylcbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbiAgZnVuY3Rpb24gb25Db250ZXh0TWVudUNsaWNrZWQoaW5mbywgdGFiKSB7XG4gICAgcXFzLmxvZ2dlci5jYWxsYmFjayhcIm9uQ29udGV4dE1lbnVDbGlja2VkKClcIiwgeyBpbmZvLCB0YWIgfSk7XG5cbiAgICBpZiAoIWlzT3duZXJPZkN1cnJlbnRTZWxlY3Rpb24odGFiPy5pZCwgaW5mby5mcmFtZUlkKSkge1xuICAgICAgcXFzLmxvZ2dlci5pbmZvKFwiSWdub3JlIGNvbnRleHQgbWVudSBjbGlja2VkIGV2ZW50IGR1ZSB0byBzZW50IGZyb20gdW5rbm93biBjb250ZW50XCIsIHtcbiAgICAgICAgaW5mbyxcbiAgICAgICAgdGFiLFxuICAgICAgICBjdXJyZW50U2VsZWN0aW9uLFxuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgcXFzLmxvZ2dlci5hc3NlcnQoY29tbWFuZHNbaW5mby5tZW51SXRlbUlkXS5jb250ZXh0TWVudS5yZWdpc3RlcmVkLCBcIlVucmVnaXN0ZXJlZCBjb250ZXh0IG1lbnUgd2FzIGludm9rZWRcIiwge1xuICAgICAgW1wiaW5mby5tZW51SXRlbUlkXCJdOiBpbmZvLm1lbnVJdGVtSWQsXG4gICAgICBpbmZvLFxuICAgICAgdGFiLFxuICAgIH0pO1xuXG4gICAgY29tbWFuZHNbaW5mby5tZW51SXRlbUlkXS5vbkNvbnRleHRNZW51Q2xpY2tlZChpbmZvLCB0YWIpO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gb25Db21tYW5kKGNvbW1hbmQsIHRhYikge1xuICAgIHFxcy5sb2dnZXIuY2FsbGJhY2soXCJvbkNvbW1hbmQoKVwiLCB7IGNvbW1hbmQsIHRhYiB9KTtcblxuICAgIC8vIHRhYiBpcyBudWxsIGlmIHRoZSBzaG9ydGN1dCBrZXkgaXMgc2V0IHRvIGdsb2JhbC5cbiAgICBpZiAoIXRhYikge1xuICAgICAgdGFiID0gYXdhaXQgcXFzLmdldEFjdGl2ZVRhYigpO1xuICAgICAgcXFzLmxvZ2dlci5pbmZvKFwiR290IGFjdGl2ZSB0YWIgYmVjYXVzZSBudWxsIHdhcyBwYXNzZWQgb24gb25Db21tYW5kIGV2ZW50XCIsIHsgY29tbWFuZCwgdGFiIH0pO1xuICAgICAgaWYgKCF0YWIpIHtcbiAgICAgICAgcXFzLmxvZ2dlci5pbmZvKFwiSWdub3JlIGtleWJvYXJkIHNob3J0Y3V0IGV2ZW50IGJlY2F1c2UgYWN0aXZlIHRhYiBjb3VsZCBub3QgYmUgb2J0YWluZWRcIiwgeyBjb21tYW5kIH0pO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCFpc093bmVyT2ZDdXJyZW50U2VsZWN0aW9uKHRhYi5pZCkpIHtcbiAgICAgIHFxcy5sb2dnZXIuaW5mbyhcIklnbm9yZSBrZXlib2FyZCBzaG9ydGN1dCBldmVudCBkdWUgdG8gc2VudCBmcm9tIHVua25vd24gY29udGVudFwiLCB7XG4gICAgICAgIGNvbW1hbmQsXG4gICAgICAgIHRhYixcbiAgICAgICAgY3VycmVudFNlbGVjdGlvbixcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChjdXJyZW50U2VsZWN0aW9uLmJsdXIpIHtcbiAgICAgIHFxcy5sb2dnZXIuaW5mbyhcIklnbm9yZSBrZXlib2FyZCBzaG9ydGN1dCBldmVudCBkdWUgdG8gY3VycmVudCBzZWxlY3Rpb24gYmx1cnJlZFwiLCB7XG4gICAgICAgIGNvbW1hbmQsXG4gICAgICAgIHRhYixcbiAgICAgICAgY3VycmVudFNlbGVjdGlvbixcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbW1hbmRzW2NvbW1hbmRdLm9uU2hvcnRjdXRQcmVzc2VkKHRhYik7XG4gIH1cblxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbiAgLy8gRXZlbnQgTGlzdGVuZXJzIChPcHRpb25zKVxuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBmdW5jdGlvbiBvbk9wdGlvbnNDaGFuZ2VkKCkge1xuICAgIHVwZGF0ZUNvbnRleHRNZW51KGN1cnJlbnRTZWxlY3Rpb24pO1xuICB9XG5cbiAgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG4gIC8vIEZ1bmN0aW9uc1xuICAvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuICBmdW5jdGlvbiB1cGRhdGVDdXJyZW50U2VsZWN0aW9uKHNlbGVjdGlvbiwgc2VuZGVyKSB7XG4gICAgT2JqZWN0LmFzc2lnbihjdXJyZW50U2VsZWN0aW9uLCBzZWxlY3Rpb24pO1xuICAgIGN1cnJlbnRTZWxlY3Rpb24uc2VuZGVyID0gcXFzLmNsb25lRHRvKHNlbmRlcik7XG4gICAgcXFzLmxvZ2dlci5zdGF0ZShcIlVwZGF0ZSBjdXJyZW50IHNlbGVjdGlvblwiLCB7IGN1cnJlbnRTZWxlY3Rpb24gfSk7XG4gIH1cblxuICBmdW5jdGlvbiBpc093bmVyT2ZDdXJyZW50U2VsZWN0aW9uKHRhYklkLCBmcmFtZUlkKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIGN1cnJlbnRTZWxlY3Rpb24uc2VuZGVyICYmXG4gICAgICBjdXJyZW50U2VsZWN0aW9uLnNlbmRlci50YWIuaWQgPT09IHRhYklkICYmXG4gICAgICAoZnJhbWVJZCA9PT0gdW5kZWZpbmVkIHx8IGN1cnJlbnRTZWxlY3Rpb24uc2VuZGVyLmZyYW1lSWQgPT09IGZyYW1lSWQpXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNvbW1hbmRTaG9ydGN1dHMoKSB7XG4gICAgY29uc3QgZXh0ZW5zaW9uQ29tbWFuZHMgPSBhd2FpdCBjaHJvbWUuY29tbWFuZHMuZ2V0QWxsKCk7XG4gICAgZm9yIChjb25zdCB7IG5hbWUsIHNob3J0Y3V0IH0gb2YgZXh0ZW5zaW9uQ29tbWFuZHMpIHtcbiAgICAgIGNvbW1hbmRzW25hbWVdLnNob3J0Y3V0ID0gc2hvcnRjdXQ7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gdXBkYXRlQ29udGV4dE1lbnUoc2VsZWN0aW9uKSB7XG4gICAgY29uc3QgaXNTZWxlY3Rpb25UZXh0VmFsaWQgPSBxcXMuaXNOb3JtYWxpemVkU2VsZWN0aW9uVGV4dFZhbGlkKHFxcy5ub3JtYWxpemVTZWxlY3Rpb25UZXh0KHNlbGVjdGlvbi50ZXh0KSk7XG5cbiAgICBmb3IgKGNvbnN0IFtpZCwgY29tbWFuZF0gb2YgT2JqZWN0LmVudHJpZXMoY29tbWFuZHMpKSB7XG4gICAgICBjb25zdCBjb250ZXh0TWVudSA9IGNvbW1hbmQuY29udGV4dE1lbnU7XG4gICAgICBjb25zdCBwcm9wZXJ0aWVzID0gY29udGV4dE1lbnUucHJvcGVydGllcztcbiAgICAgIGNvbnN0IHZpc2libGUgPVxuICAgICAgICBxcXMub3B0aW9ucy5jb250ZXh0TWVudSAmJlxuICAgICAgICAhc2VsZWN0aW9uLmJsdXIgJiZcbiAgICAgICAgaXNTZWxlY3Rpb25UZXh0VmFsaWQgJiZcbiAgICAgICAgKCFjb250ZXh0TWVudS5vbmx5RWRpdGFibGUgfHwgc2VsZWN0aW9uLmVkaXRhYmxlKTtcbiAgICAgIHFxcy5sb2dnZXIuc3RhdGUoXCJVcGRhdGUgY29udGV4dCBtZW51IHZpc2liaWxpdHlcIiwgeyBpZCwgdmlzaWJsZSB9KTtcblxuICAgICAgaWYgKHZpc2libGUpIHtcbiAgICAgICAgbGV0IHRpdGxlU3VwcGxlbWVudCA9IFwiXCI7XG4gICAgICAgIGlmIChxcXMub3B0aW9ucy5hdXRvRW50ZXIgJiYgc2VsZWN0aW9uLnNlYXJjaGFibGUgJiYgY29udGV4dE1lbnUudGl0bGVDaGFuZ2VzSW5TZWFyY2hhYmxlKSB7XG4gICAgICAgICAgdGl0bGVTdXBwbGVtZW50ICs9IGNocm9tZS5pMThuLmdldE1lc3NhZ2UoXCJtc2dfY29udGV4dF9tZW51X3RpdGxlX3B1dF9xdW90ZXNfc3VwcGxlbWVudFwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoY29tbWFuZC5zaG9ydGN1dCkge1xuICAgICAgICAgIHRpdGxlU3VwcGxlbWVudCArPSBgICAgWyR7Y29tbWFuZC5zaG9ydGN1dH1dYDtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICghY29udGV4dE1lbnUucmVnaXN0ZXJlZCkge1xuICAgICAgICAgIGNocm9tZS5jb250ZXh0TWVudXMuY3JlYXRlKHtcbiAgICAgICAgICAgIGlkOiBpZCxcbiAgICAgICAgICAgIHRpdGxlOiBwcm9wZXJ0aWVzLnRpdGxlICsgdGl0bGVTdXBwbGVtZW50LFxuICAgICAgICAgICAgdHlwZTogcHJvcGVydGllcy50eXBlLFxuICAgICAgICAgICAgY29udGV4dHM6IHByb3BlcnRpZXMuY29udGV4dHMsXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgY29udGV4dE1lbnUucmVnaXN0ZXJlZCA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2hyb21lLmNvbnRleHRNZW51cy51cGRhdGUoaWQsIHsgdGl0bGU6IHByb3BlcnRpZXMudGl0bGUgKyB0aXRsZVN1cHBsZW1lbnQgfSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChjb250ZXh0TWVudS5yZWdpc3RlcmVkKSB7XG4gICAgICAgICAgY2hyb21lLmNvbnRleHRNZW51cy5yZW1vdmUoaWQpO1xuICAgICAgICAgIGNvbnRleHRNZW51LnJlZ2lzdGVyZWQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGRvUXVvdGVkU2VhcmNoRm9yU2VsZWN0aW9uVGV4dCh0YWIsIHNlbGVjdGlvblRleHQsIGtleVN0YXRlKSB7XG4gICAgY29uc3Qgbm9ybWFsaXplZFNlbGVjdGlvblRleHQgPSBxcXMubm9ybWFsaXplU2VsZWN0aW9uVGV4dChzZWxlY3Rpb25UZXh0KTtcbiAgICBpZiAoIXFxcy5pc05vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0VmFsaWQobm9ybWFsaXplZFNlbGVjdGlvblRleHQpKSB7XG4gICAgICBxcXMubG9nZ2VyLmluZm8oYElnbm9yZSAke3Fxcy5Db21tYW5kVHlwZS5ET19RVU9URURfU0VBUkNIfSBjb21tYW5kIGR1ZSB0byB1bmV4cGVjdGVkIHNlbGVjdGlvbiB0ZXh0YCwge1xuICAgICAgICBzZWxlY3Rpb25UZXh0LFxuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKHFxcy5vcHRpb25zLmF1dG9Db3B5KSB7XG4gICAgICBhd2FpdCB3cml0ZVRleHRUb0NsaXBib2FyZCh0YWIsIG5vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0KTtcbiAgICB9XG5cbiAgICBhd2FpdCBxcXMuZG9RdW90ZWRTZWFyY2godGFiLCBub3JtYWxpemVkU2VsZWN0aW9uVGV4dCwga2V5U3RhdGUpO1xuICB9XG5cbiAgZnVuY3Rpb24gcHV0UXVvdGVzQXJvdW5kU2VsZWN0aW9uVGV4dCh0YWIsIGZyYW1lSWQpIHtcbiAgICBjb25zdCBwb3J0ID0gY2hyb21lLnRhYnMuY29ubmVjdCh0YWIuaWQsIHsgbmFtZTogXCJiYWNrZ3JvdW5kXCIsIGZyYW1lSWQ6IGZyYW1lSWQgfSk7XG4gICAgcXFzLnBvc3RNZXNzYWdlKHBvcnQsIHsgdHlwZTogcXFzLk1lc3NhZ2VUeXBlLlBVVF9RVU9URVMgfSk7XG4gICAgcG9ydC5kaXNjb25uZWN0KCk7XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiB3cml0ZVRleHRUb0NsaXBib2FyZCh0YWIsIHRleHQpIHtcbiAgICBhd2FpdCBjaHJvbWUuc2NyaXB0aW5nLmV4ZWN1dGVTY3JpcHQoe1xuICAgICAgdGFyZ2V0OiB7IHRhYklkOiB0YWIuaWQgfSxcbiAgICAgIGluamVjdEltbWVkaWF0ZWx5OiB0cnVlLFxuICAgICAgYXJnczogW3RleHRdLFxuICAgICAgZnVuYzogKHRleHQpID0+IHdpbmRvdy5uYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0KSxcbiAgICB9KTtcbiAgfVxufSkoKTtcbiJdLCJuYW1lcyI6WyJtb2R1bGUiLCJleHBvcnRzIiwiY29uZmlnIiwiU2NyaXB0SWQiLCJBQ1RJT04iLCJCQUNLR1JPVU5EIiwiQ09OVEVOVCIsIk9QVElPTlMiLCJDb21tYW5kVHlwZSIsIkRPX1FVT1RFRF9TRUFSQ0giLCJQVVRfUVVPVEVTIiwiTWVzc2FnZVR5cGUiLCJIRUxMTyIsIk5PVElGWV9TRUxFQ1RJT05fVVBEQVRFRCIsIk9QRU5fT1BUSU9OU19QQUdFIiwiV0VMQ09NRSIsIkdFVF9TRUxFQ1RJT04iLCJOT1RJRllfU0VMRUNUSU9OIiwiUVVPVEFUSU9OX01BUktTIiwiU0VMRUNUSU9OX1RFWFRfTUFYX0xFTkdUSCIsIlNFTEVDVElPTl9URVhUX1RPT19MT05HX01BUktFUiIsImxvZ2dlciIsIm9wdGlvbnMiLCJIb3dUb09wZW5MaW5rIiwiZmlsdGVyU2VsZWN0aW9uVGV4dCIsInNlbGVjdGlvblRleHQiLCJsZW5ndGgiLCJub3JtYWxpemVTZWxlY3Rpb25UZXh0IiwicmVwbGFjZUFsbCIsIlJlZ0V4cCIsInRyaW0iLCJpc05vcm1hbGl6ZWRTZWxlY3Rpb25UZXh0VmFsaWQiLCJub3JtYWxpemVkU2VsZWN0aW9uVGV4dCIsInF1b3RlVGV4dCIsInRleHQiLCJjbG9uZUR0byIsIm9iaiIsIkpTT04iLCJwYXJzZSIsInN0cmluZ2lmeSIsIm1lcmdlT2JqZWN0IiwidGFyZ2V0Iiwic291cmNlIiwiT2JqZWN0IiwiZnJvbUVudHJpZXMiLCJlbnRyaWVzIiwiZmlsdGVyIiwidiIsInVuZGVmaW5lZCIsImFkZERPTUNvbnRlbnRMb2FkZWRFdmVudExpc3RlbmVyIiwid2luIiwibGlzdGVuZXIiLCJkb2N1bWVudCIsInJlYWR5U3RhdGUiLCJhZGRFdmVudExpc3RlbmVyIiwicXVldWVNaWNyb3Rhc2siLCJhZGRMb2FkQ29tcGxldGVkRXZlbnRMaXN0ZW5lciIsImluamVjdEkxOE5NZXNzYWdlc0luSHRtbCIsImRvYyIsIkkxOE5fVEFSR0VUUyIsImVsZW1lbnQiLCJxdWVyeVNlbGVjdG9yQWxsIiwic3Vic3RpdHV0aW9ucyIsInJlc3VsdCIsImFyZ3MiLCJkYXRhc2V0IiwiaTE4bkFyZ3MiLCJpZHMiLCJzcGxpdCIsImlkIiwiYXJnRWxlbWVudCIsImdldEVsZW1lbnRCeUlkIiwiYXJnVGFyZ2V0IiwiaTE4blRhcmdldCIsImFzc2VydCIsImluY2x1ZGVzIiwicHVzaCIsImNocm9tZSIsImkxOG4iLCJnZXRNZXNzYWdlIiwiaTE4bk5hbWUiLCJnZXRTZWxlY3Rpb24iLCJmaW5kU2VsZWN0aW9uUmVjdXJzaXZlbHkiLCJzZWxlY3Rpb24iLCJyYW5nZUNvdW50IiwicmFuZ2UiLCJnZXRSYW5nZUF0Iiwic3RhcnRDb250YWluZXIiLCJlbmRDb250YWluZXIiLCJjb21tb25BbmNlc3RvckNvbnRhaW5lciIsIkVsZW1lbnQiLCJzaGFkb3dSb290IiwiZWxlbWVudHNXaXRoU2hhZG93Um9vdCIsIkFycmF5IiwicHJvdG90eXBlIiwiY2FsbCIsInBvc3RNZXNzYWdlIiwicG9ydCIsIm1lc3NhZ2UiLCJlcnJvciIsIndhcm4iLCJnZXRBY3RpdmVUYWIiLCJ0YWIiLCJ0YWJzIiwicXVlcnkiLCJhY3RpdmUiLCJjdXJyZW50V2luZG93IiwiY3JlYXRlTmV3VGFiIiwicGFyYW1zIiwiY3JlYXRlIiwid2luZG93SWQiLCJvcGVuZXJUYWJJZCIsImluZGV4IiwidXJsIiwiY3JlYXRlTmV3V2luZG93Iiwid2luZG93cyIsImdldEN1cnJlbnQiLCJzdGF0ZSIsImRvUXVvdGVkU2VhcmNoIiwic2VhcmNoVGV4dCIsImtleVN0YXRlIiwiaG93VG9PcGVuTGluayIsImRlY2lkZSIsImRpc3Bvc2l0aW9uIiwiRGlzcG9zaXRpb24iLCJORVdfVEFCIiwibmV3VGFiIiwic2VhcmNoIiwidGFiSWQiLCJ1cGRhdGUiLCJvcGVuTGluayIsImRlZmF1bHRIb3dUb09wZW5MaW5rIiwiQ1VSUkVOVF9UQUIiLCJORVdfV0lORE9XIiwib3Blbk9wdGlvbnNQYWdlIiwicnVudGltZSIsImdldFVSTCIsIm9wZW5TZWFyY2hFbmdpbmVTZXR0aW5ncyIsIm9wZW5TaG9ydGN1dHNTZXR0aW5ncyIsIkxvZ2dlciIsIk9wdGlvbnMiLCJpbml0Iiwic2NyaXB0SWQiLCJjaGVja09zSXNNYWMiLCJTVE9SQUdFX0tFWSIsInN0b3JhZ2UiLCJsb2NhbCIsImlzTWFjIiwiZ2V0UGxhdGZvcm1JbmZvIiwib3MiLCJzZXQiLCJnZXQiLCJLZXlTdGF0ZSIsImN0cmxLZXkiLCJzaGlmdEtleSIsImNvbnN0cnVjdG9yIiwibWV0YUtleSIsImVxdWFscyIsIm90aGVyIiwiTkVXX1RBQl9BQ1RJVkUiLCJORVdfVEFCX0lOQUNUSVZFIiwic2V0SWQiLCJpbmZvIiwib3V0cHV0IiwiY2FsbGJhY2siLCJhc3NlcnRpb24iLCJjb25zb2xlQXBpIiwiaGVhZGVyIiwibG9nRW5hYmxlZCIsIm9wdGlvbmFsQXJncyIsImF0Iiwia2V5IiwidmFsdWUiLCJwb3AiLCJjb25zb2xlIiwic3luYyIsIlVQREFURURfQVRfS0VZIiwiREVGQVVMVF9WQUxVRVMiLCJJQ09OX1NJWkVfTUlOIiwiSUNPTl9TSVpFX01BWCIsIklURU1TIiwibmFtZSIsImRlZmF1bHRWYWx1ZSIsInZhbGlkYXRvciIsInZhbHVlcyIsImRlZmluZU9wdGlvbnMiLCJkZWZpbmVQcm9wZXJ0eSIsIkVycm9yIiwiY2FjaGUiLCJ1cGRhdGVTdG9yYWdlIiwib25DaGFuZ2VkIiwibGlzdGVuZXJzIiwiYWRkTGlzdGVuZXIiLCJfZmlyZSIsImFzc2lnbiIsImNoYW5nZXMiLCJhcmVhTmFtZSIsIm9uQ2hhbmdlZExpc3RlbmVyIiwicmVzZXQiLCJEYXRlIiwibm93IiwiaGFzT3duIiwibmV3VmFsdWUiLCJxcXMiLCJtYWluIiwiTUVTU0FHRV9IQU5ETEVSUyIsIm9uSGVsbG8iLCJvbk5vdGlmeVNlbGVjdGlvblVwZGF0ZWQiLCJvbkRvUXVvdGVkU2VhcmNoIiwib25PcGVuT3B0aW9uc1BhZ2UiLCJvbkdldFNlbGVjdGlvbiIsImN1cnJlbnRTZWxlY3Rpb24iLCJzZW5kZXIiLCJlZGl0YWJsZSIsInNlYXJjaGFibGUiLCJibHVyIiwiY29tbWFuZHMiLCJzaG9ydGN1dCIsImNvbnRleHRNZW51IiwicHJvcGVydGllcyIsInRpdGxlIiwidHlwZSIsImNvbnRleHRzIiwicmVnaXN0ZXJlZCIsIm9ubHlFZGl0YWJsZSIsInRpdGxlQ2hhbmdlc0luU2VhcmNoYWJsZSIsIm9uU2hvcnRjdXRQcmVzc2VkIiwiZG9RdW90ZWRTZWFyY2hGb3JTZWxlY3Rpb25UZXh0Iiwib25Db250ZXh0TWVudUNsaWNrZWQiLCJwdXRRdW90ZXNBcm91bmRTZWxlY3Rpb25UZXh0IiwiZnJhbWVJZCIsIm9uQ29ubmVjdCIsIm9uQWN0aXZhdGVkIiwib25UYWJzQWN0aXZhdGUiLCJvblVwZGF0ZWQiLCJvblRhYnNVcGRhdGVkIiwiY29udGV4dE1lbnVzIiwib25DbGlja2VkIiwib25Db21tYW5kIiwib25PcHRpb25zQ2hhbmdlZCIsIm9uTWVzc2FnZSIsInVwZGF0ZUNvbW1hbmRTaG9ydGN1dHMiLCJfbWVzc2FnZSIsImlkZW50aXR5IiwiaXNPd25lck9mQ3VycmVudFNlbGVjdGlvbiIsInVwZGF0ZUN1cnJlbnRTZWxlY3Rpb24iLCJ1cGRhdGVDb250ZXh0TWVudSIsImFjdGl2ZUluZm8iLCJjaGFuZ2VJbmZvIiwibWVudUl0ZW1JZCIsImNvbW1hbmQiLCJleHRlbnNpb25Db21tYW5kcyIsImdldEFsbCIsImlzU2VsZWN0aW9uVGV4dFZhbGlkIiwidmlzaWJsZSIsInRpdGxlU3VwcGxlbWVudCIsImF1dG9FbnRlciIsInJlbW92ZSIsImF1dG9Db3B5Iiwid3JpdGVUZXh0VG9DbGlwYm9hcmQiLCJjb25uZWN0IiwiZGlzY29ubmVjdCIsInNjcmlwdGluZyIsImV4ZWN1dGVTY3JpcHQiLCJpbmplY3RJbW1lZGlhdGVseSIsImZ1bmMiLCJ3aW5kb3ciLCJuYXZpZ2F0b3IiLCJjbGlwYm9hcmQiLCJ3cml0ZVRleHQiXSwic291cmNlUm9vdCI6IiJ9